"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
require("module-alias/register");
const filePaths_1 = require("@/filePaths");
const ipc_1 = require("../../eventSystem/ipc");
const lockFiles_1 = require("../../eventSystem/lockFiles");
const nvim = __importStar(require("neovim"));
const promises_1 = __importDefault(require("fs/promises"));
const common_1 = require("@/utils/common");
const tmux_1 = require("@/tmux");
let saveTimer;
let server;
let settings = undefined;
let nvimSessions = {};
function resetSaveTimer() {
    return __awaiter(this, arguments, void 0, function* (timeout = undefined) {
        if (!process.env.TMUX || (yield (0, lockFiles_1.lockFileExist)(lockFiles_1.LockFiles.LoadInProgress))) {
            yield (0, lockFiles_1.deleteLockFile)(lockFiles_1.LockFiles.AutoSaveInProgress);
            process.exit(0);
        }
        yield (0, lockFiles_1.createLockFile)(lockFiles_1.LockFiles.AutoSaveInProgress);
        if (saveTimer) {
            clearTimeout(saveTimer);
        }
        saveTimer = setTimeout(() => __awaiter(this, void 0, void 0, function* () {
            const saveFileName = settings.autosave.currentSession;
            try {
                for (const job of Object.keys(nvimSessions)) {
                    const neovimEvent = nvimSessions[job];
                    const nvimSessionFileName = `${job}.vim`;
                    if (neovimEvent.leave) {
                        try {
                            yield promises_1.default.unlink(`${filePaths_1.nvimSessionsPath}/${saveFileName}/${nvimSessionFileName}`);
                        }
                        catch ( /* file might not exit if closed an unsaved neovim, so ignore error */_a) { /* file might not exit if closed an unsaved neovim, so ignore error */ }
                        ;
                    }
                    else {
                        const socket = neovimEvent.socket;
                        const neovim = nvim.attach({ socket })
                            .on('error', () => console.log('error'))
                            .on('disconnect', () => console.log('neovim disconnected'));
                        try {
                            yield promises_1.default.readdir(`${filePaths_1.nvimSessionsPath}/${saveFileName}`);
                        }
                        catch (_b) {
                            yield promises_1.default.mkdir(`${filePaths_1.nvimSessionsPath}/${saveFileName}`);
                        }
                        yield neovim.command(`mksession! ${filePaths_1.nvimSessionsPath}/${saveFileName}/${nvimSessionFileName}`);
                        yield neovim.command(`echo 'kra workflow autosaved : ${filePaths_1.nvimSessionsPath}/${saveFileName}/${nvimSessionFileName}'`);
                    }
                }
                yield (0, tmux_1.quickSave)(saveFileName);
            }
            catch (error) {
                console.log(error);
            }
            finally {
                yield (0, lockFiles_1.deleteLockFile)(lockFiles_1.LockFiles.AutoSaveInProgress);
                server === null || server === void 0 ? void 0 : server.close();
                process.exit(0);
            }
        }), timeout || settings.autosave.timeoutMs);
    });
}
function trackSession(event) {
    const splitEvent = event.split(":");
    const sessionKey = splitEvent.slice(1, 4).join("_");
    const neovimEvent = splitEvent[4];
    const socket = splitEvent[5];
    nvimSessions[sessionKey] = {
        socket,
        leave: neovimEvent === "VimLeave",
    };
}
function main() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const server = (0, ipc_1.createIPCServer)(ipc_1.IPCsockets.AutosaveSocket);
            yield server.addListener((event) => __awaiter(this, void 0, void 0, function* () {
                if (event === ipc_1.IPCEvents.FlushAutosave) {
                    resetSaveTimer(1);
                    return;
                }
                console.log(event);
                if (event.startsWith('neovim')) {
                    trackSession(event);
                }
                resetSaveTimer();
            }));
            settings = yield (0, common_1.loadSettings)();
            if (!settings) {
                throw new Error('Could not load settings for autosave, please update settings file, use settings.yaml.example');
            }
            yield (0, lockFiles_1.createLockFile)(lockFiles_1.LockFiles.AutoSaveInProgress);
            resetSaveTimer();
        }
        catch (error) {
            console.log(error);
        }
    });
}
main().then((_res) => console.log('done'));
