"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
require("module-alias/register");
const lockFiles_1 = require("../../eventSystem/lockFiles");
const common_1 = require("@/utils/common");
const ipc_1 = require("../../eventSystem/ipc");
const packagePaths_1 = require("@/packagePaths");
function main() {
    return __awaiter(this, void 0, void 0, function* () {
        if (!process.env.TMUX
            || (yield (0, lockFiles_1.oneOfMultipleLocksExist)([lockFiles_1.LockFiles.LoadInProgress, lockFiles_1.LockFiles.ServerKillInProgress]))
            || (yield (0, common_1.loadSettings)().then(res => !res.autosave.active))) {
            process.exit(0);
        }
        const event = process.argv[2];
        const client = (0, ipc_1.createIPCClient)(ipc_1.IPCsockets.AutosaveSocket);
        yield ensureServerRunning(client);
        yield client.emit(event);
        process.exit(0);
    });
}
function ensureServerRunning(client) {
    return __awaiter(this, void 0, void 0, function* () {
        if (!(yield (0, lockFiles_1.lockFileExist)(lockFiles_1.LockFiles.AutoSaveInProgress))) {
            return yield client.ensureServerRunning(packagePaths_1.autosaveJsPath);
        }
    });
}
main().catch(err => {
    console.log('Autosave controller error', err);
    process.exit(1);
});
