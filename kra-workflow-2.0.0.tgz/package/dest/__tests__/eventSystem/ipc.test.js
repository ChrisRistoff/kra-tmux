"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs_1 = __importDefault(require("fs"));
const net_1 = __importDefault(require("net"));
const child_process_1 = require("child_process");
const ipc_1 = require("../../eventSystem/ipc");
jest.mock('fs');
jest.mock('net');
jest.mock('child_process');
describe('IPC', () => {
    const mockFs = jest.mocked(fs_1.default);
    const mockNet = jest.mocked(net_1.default);
    const mockSpawn = jest.mocked(child_process_1.spawn);
    const mockSocketPath = '/tmp/test-socket';
    const mockPidFile = '/tmp/test-socket.pid';
    let mockServer;
    let mockSocket;
    let mockClient;
    beforeEach(() => {
        jest.clearAllMocks();
        // mock the server socket
        mockSocket = {
            on: jest.fn(),
            write: jest.fn(),
            end: jest.fn(),
        };
        mockServer = {
            listen: jest.fn((_, callback) => {
                setTimeout(callback, 0); // simulate async listen
            }),
            on: jest.fn(),
            close: jest.fn(),
        };
        mockClient = {
            on: jest.fn(),
            write: jest.fn(),
            end: jest.fn(),
        };
        mockNet.createServer.mockImplementation((callback) => {
            // store the connection callback for later use
            (mockServer).connectionCallback = callback;
            return mockServer;
        });
        mockNet.createConnection.mockReturnValue(mockClient);
        mockFs.existsSync.mockReturnValue(false);
        mockFs.writeFileSync.mockImplementation(() => { });
        mockFs.readFileSync.mockReturnValue('12345');
        mockFs.unlinkSync.mockImplementation(() => { });
        mockFs.chmodSync.mockImplementation(() => { });
        const mockChildProcess = {
            on: jest.fn(),
            unref: jest.fn(),
            pid: 99999
        };
        mockSpawn.mockReturnValue(mockChildProcess);
        Object.defineProperty(process, 'pid', { value: 12345, configurable: true });
        process.env.HOME = '/home/user';
    });
    afterEach(() => {
        jest.restoreAllMocks();
    });
    describe('createIPCServer', () => {
        let server;
        beforeEach(() => {
            server = (0, ipc_1.createIPCServer)(mockSocketPath);
        });
        it('should create server and listen on socket path', () => __awaiter(void 0, void 0, void 0, function* () {
            const handler = jest.fn();
            yield server.addListener(handler);
            expect(mockNet.createServer).toHaveBeenCalled();
            expect(mockServer.listen).toHaveBeenCalledWith(mockSocketPath, expect.any(Function));
            expect(mockFs.writeFileSync).toHaveBeenCalledWith(mockPidFile, '12345');
            expect(mockFs.chmodSync).toHaveBeenCalledWith(mockSocketPath, 0o600);
        }));
        it('should clean up existing socket before listening', () => __awaiter(void 0, void 0, void 0, function* () {
            mockFs.existsSync.mockReturnValue(true);
            const handler = jest.fn();
            yield server.addListener(handler);
            expect(mockFs.unlinkSync).toHaveBeenCalledWith(mockSocketPath);
        }));
        it('should handle EADDRINUSE error by retrying', () => __awaiter(void 0, void 0, void 0, function* () {
            const handler = jest.fn();
            let errorCalled = false;
            mockServer.on.mockImplementation((event, callback) => {
                if (event === 'error' && !errorCalled) {
                    errorCalled = true;
                    setTimeout(() => {
                        const error = new Error('Address already in use');
                        error.code = 'EADDRINUSE';
                        callback(error);
                    }, 0);
                }
            });
            // second attempt should work
            mockServer.listen.mockImplementationOnce(() => { }).mockImplementationOnce((_, callback) => {
                setTimeout(callback, 0);
            });
            yield server.addListener(handler);
            expect(mockServer.listen).toHaveBeenCalledTimes(2);
        }));
        it('should process incoming socket data', () => __awaiter(void 0, void 0, void 0, function* () {
            const handler = jest.fn();
            yield server.addListener(handler);
            // simulate client connection
            const connectionCallback = (mockServer).connectionCallback;
            connectionCallback(mockSocket);
            // simulate data received
            const dataCallback = mockSocket.on.mock.calls.find(([event]) => event === 'data')[1];
            dataCallback(Buffer.from('test-event-data'));
            expect(handler).toHaveBeenCalledWith('test-event-data');
        }));
        it('should handle empty or whitespace-only messages', () => __awaiter(void 0, void 0, void 0, function* () {
            const handler = jest.fn();
            yield server.addListener(handler);
            const connectionCallback = (mockServer).connectionCallback;
            connectionCallback(mockSocket);
            const dataCallback = mockSocket.on.mock.calls.find(([event]) => event === 'data')[1];
            // send empty and whitespace messages
            dataCallback(Buffer.from('   '));
            dataCallback(Buffer.from(''));
            dataCallback(Buffer.from('\n\t  \n'));
            expect(handler).not.toHaveBeenCalled();
        }));
        it('should handle socket client errors', () => __awaiter(void 0, void 0, void 0, function* () {
            const consoleSpy = jest.spyOn(console, 'error').mockImplementation(() => { });
            const handler = jest.fn();
            yield server.addListener(handler);
            const connectionCallback = (mockServer).connectionCallback;
            connectionCallback(mockSocket);
            // simulate socket error
            const errorCallback = mockSocket.on.mock.calls.find(([event]) => event === 'error')[1];
            errorCallback(new Error('Socket error'));
            expect(consoleSpy).toHaveBeenCalledWith('Socket client error:', expect.any(Error));
            consoleSpy.mockRestore();
        }));
        it('should cleanup on close', () => __awaiter(void 0, void 0, void 0, function* () {
            mockFs.existsSync.mockReturnValue(true);
            // need to setup the server first
            yield server.addListener(() => { });
            server.close();
            expect(mockServer.close).toHaveBeenCalled();
            expect(mockFs.unlinkSync).toHaveBeenCalledWith(mockSocketPath);
            expect(mockFs.unlinkSync).toHaveBeenCalledWith(mockPidFile);
        }));
        it('should ignore cleanup errors', () => {
            mockFs.unlinkSync.mockImplementation(() => {
                throw new Error('Cleanup failed');
            });
            // should not throw
            expect(() => server.close()).not.toThrow();
        });
        it('should setup process exit handlers', () => __awaiter(void 0, void 0, void 0, function* () {
            const processOnSpy = jest.spyOn(process, 'on').mockImplementation(() => process);
            const handler = jest.fn();
            yield server.addListener(handler);
            expect(processOnSpy).toHaveBeenCalledWith('exit', expect.any(Function));
            expect(processOnSpy).toHaveBeenCalledWith('SIGINT', expect.any(Function));
            expect(processOnSpy).toHaveBeenCalledWith('SIGTERM', expect.any(Function));
            processOnSpy.mockRestore();
        }));
    });
    describe('createIPCClient', () => {
        let client;
        beforeEach(() => {
            client = (0, ipc_1.createIPCClient)(mockSocketPath);
        });
        it('should emit event through socket connection', () => __awaiter(void 0, void 0, void 0, function* () {
            // simulate successful connection
            mockClient.on.mockImplementation((event, callback) => {
                if (event === 'connect') {
                    setTimeout(callback, 0);
                }
            });
            yield client.emit('test-event');
            expect(mockNet.createConnection).toHaveBeenCalledWith(mockSocketPath);
            expect(mockClient.write).toHaveBeenCalledWith('test-event');
            expect(mockClient.end).toHaveBeenCalled();
        }));
        it('should handle connection errors', () => __awaiter(void 0, void 0, void 0, function* () {
            mockClient.on.mockImplementation((event, callback) => {
                if (event === 'error') {
                    setTimeout(() => {
                        const error = new Error('Connection refused');
                        error.code = 'ECONNREFUSED';
                        callback(error);
                    }, 0);
                }
            });
            yield expect(client.emit('test-event')).rejects.toThrow('IPC server not running');
        }));
        it('should handle ENOENT errors', () => __awaiter(void 0, void 0, void 0, function* () {
            mockClient.on.mockImplementation((event, callback) => {
                if (event === 'error') {
                    setTimeout(() => {
                        const error = new Error('No such file');
                        error.code = 'ENOENT';
                        callback(error);
                    }, 0);
                }
            });
            yield expect(client.emit('test-event')).rejects.toThrow('IPC server not running');
        }));
        it('should check if server is running with valid PID and socket', () => __awaiter(void 0, void 0, void 0, function* () {
            mockFs.existsSync.mockReturnValue(true);
            mockFs.readFileSync.mockReturnValue('54321');
            const processSpy = jest.spyOn(process, 'kill').mockImplementation(() => true);
            // mock successful test connection
            mockClient.on.mockImplementation((event, callback) => {
                if (event === 'connect') {
                    setTimeout(callback, 0);
                }
            });
            yield client.ensureServerRunning('/path/to/server.js');
            expect(mockFs.readFileSync).toHaveBeenCalledWith(mockPidFile, 'utf8');
            expect(processSpy).toHaveBeenCalledWith(54321, 0);
            expect(mockSpawn).not.toHaveBeenCalled();
            processSpy.mockRestore();
        }));
        it('should start server when PID file missing', () => __awaiter(void 0, void 0, void 0, function* () {
            mockFs.existsSync.mockReturnValue(false);
            // simulate server startup
            setTimeout(() => {
                mockFs.existsSync.mockReturnValue(true);
                mockFs.readFileSync.mockReturnValue('99999');
                jest.spyOn(process, 'kill').mockImplementation(() => true);
                mockClient.on.mockImplementation((event, callback) => {
                    if (event === 'connect') {
                        setTimeout(callback, 0);
                    }
                });
            }, 50);
            const ensurePromise = client.ensureServerRunning('/path/to/server.js');
            jest.advanceTimersByTime(100);
            yield ensurePromise;
            expect(mockSpawn).toHaveBeenCalledWith('node', ['/path/to/server.js'], {
                detached: true,
                stdio: 'ignore'
            });
        }));
        it('should clean up stale files when socket test fails', () => __awaiter(void 0, void 0, void 0, function* () {
            // first call - pid file exists but process is dead
            mockFs.existsSync.mockReturnValueOnce(true).mockReturnValueOnce(true);
            mockFs.readFileSync.mockReturnValue('12345');
            // process.kill should throw (process is dead)
            const killSpy = jest.spyOn(process, 'kill').mockImplementation(() => {
                throw new Error('No such process');
            });
            // mock the server startup after spawn
            setTimeout(() => {
                mockFs.existsSync.mockReturnValue(true);
                mockFs.readFileSync.mockReturnValue('99999');
                killSpy.mockImplementation(() => true);
                mockClient.on.mockImplementation((event, callback) => {
                    if (event === 'connect') {
                        setTimeout(callback, 0);
                    }
                });
            }, 50);
            yield client.ensureServerRunning('/path/to/server.js');
            expect(mockSpawn).toHaveBeenCalled();
            killSpy.mockRestore();
        }));
        it('should handle home directory replacement', () => __awaiter(void 0, void 0, void 0, function* () {
            mockFs.existsSync.mockReturnValue(false);
            setTimeout(() => {
                mockFs.existsSync.mockReturnValue(true);
                mockFs.readFileSync.mockReturnValue('99999');
                jest.spyOn(process, 'kill').mockImplementation(() => true);
                mockClient.on.mockImplementation((event, callback) => {
                    if (event === 'connect') {
                        setTimeout(callback, 0);
                    }
                });
            }, 50);
            const ensurePromise = client.ensureServerRunning('~/scripts/server.js');
            jest.advanceTimersByTime(100);
            yield ensurePromise;
            expect(mockSpawn).toHaveBeenCalledWith('node', ['/home/user/scripts/server.js'], {
                detached: true,
                stdio: 'ignore'
            });
        }));
        it('should timeout when server fails to start', () => __awaiter(void 0, void 0, void 0, function* () {
            mockFs.existsSync.mockReturnValue(false);
            const mockChildProcess = {
                on: jest.fn(),
                unref: jest.fn(),
            };
            mockSpawn.mockReturnValue(mockChildProcess);
            // server never actually starts (no mocked successful startup)
            // so it should timeout
            yield expect(client.ensureServerRunning('/path/to/server.js'))
                .rejects.toThrow('Server failed to start within timeout period');
        }), 10000);
        it('should handle cleanup errors silently during stale file removal', () => __awaiter(void 0, void 0, void 0, function* () {
            mockFs.existsSync.mockReturnValue(true);
            mockFs.readFileSync.mockReturnValue('12345');
            jest.spyOn(process, 'kill').mockImplementation(() => {
                throw new Error('No such process');
            });
            mockFs.unlinkSync.mockImplementation(() => {
                throw new Error('Cleanup failed');
            });
            // simulate successful startup after cleanup
            setTimeout(() => {
                mockFs.existsSync.mockReturnValue(true);
                mockFs.readFileSync.mockReturnValue('99999');
                jest.spyOn(process, 'kill').mockImplementation(() => true);
                mockClient.on.mockImplementation((event, callback) => {
                    if (event === 'connect') {
                        setTimeout(callback, 0);
                    }
                });
            }, 50);
            const ensurePromise = client.ensureServerRunning('/path/to/server.js');
            // should not throw despite cleanup error
            yield expect(ensurePromise).resolves.not.toThrow();
        }));
    });
});
