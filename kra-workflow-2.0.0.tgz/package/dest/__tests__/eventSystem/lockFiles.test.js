"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = __importStar(require("fs/promises"));
const lockFiles_1 = require("@/../eventSystem/lockFiles");
jest.mock('fs/promises');
jest.mock('@/../src/filePaths', () => ({
    lockFilesPath: '/mock/lock/files'
}));
jest.mock('@/utils/common', () => ({
    loadSettings: jest.fn().mockResolvedValue({
        autosave: {
            timeoutMs: 300000 // 5 minutes (300,000 ms)
        }
    })
}));
describe('lockFiles', () => {
    const mockFs = jest.mocked(fs);
    const originalDateNow = Date.now;
    beforeEach(() => {
        jest.clearAllMocks();
        mockFs.rm.mockResolvedValue();
        mockFs.readFile.mockResolvedValue('');
        mockFs.writeFile.mockResolvedValue();
        jest.spyOn(Date, 'now').mockReturnValue(1640995200000); // 2022-01-01 00:00:00
    });
    afterEach(() => {
        Date.now = originalDateNow;
    });
    describe('deleteLockFile', () => {
        it('should delete lock file successfully', () => __awaiter(void 0, void 0, void 0, function* () {
            yield (0, lockFiles_1.deleteLockFile)(lockFiles_1.LockFiles.LoadInProgress);
            expect(mockFs.rm).toHaveBeenCalledWith('/mock/lock/files/LoadInProgress');
        }));
        it('should handle deletion errors gracefully', () => __awaiter(void 0, void 0, void 0, function* () {
            const error = new Error('File not found');
            mockFs.rm.mockRejectedValue(error);
            const consoleSpy = jest.spyOn(console, 'log').mockImplementation();
            yield (0, lockFiles_1.deleteLockFile)(lockFiles_1.LockFiles.AutoSaveInProgress);
            expect(consoleSpy).toHaveBeenCalledWith(error);
            consoleSpy.mockRestore();
        }));
        it('should delete all types of lock files', () => __awaiter(void 0, void 0, void 0, function* () {
            yield (0, lockFiles_1.deleteLockFile)(lockFiles_1.LockFiles.LoadInProgress);
            yield (0, lockFiles_1.deleteLockFile)(lockFiles_1.LockFiles.AutoSaveInProgress);
            yield (0, lockFiles_1.deleteLockFile)(lockFiles_1.LockFiles.ServerKillInProgress);
            expect(mockFs.rm).toHaveBeenCalledWith('/mock/lock/files/LoadInProgress');
            expect(mockFs.rm).toHaveBeenCalledWith('/mock/lock/files/AutoSaveInProgress');
            expect(mockFs.rm).toHaveBeenCalledWith('/mock/lock/files/ServerKillInProgress');
        }));
    });
    describe('oneOfMultipleLocksExist', () => {
        it('should return true when at least one lock exists', () => __awaiter(void 0, void 0, void 0, function* () {
            const validLockData = JSON.stringify({ timestamp: Date.now() });
            mockFs.readFile
                .mockResolvedValueOnce(validLockData)
                .mockRejectedValueOnce(new Error('File not found'));
            const result = yield (0, lockFiles_1.oneOfMultipleLocksExist)([
                lockFiles_1.LockFiles.LoadInProgress,
                lockFiles_1.LockFiles.AutoSaveInProgress
            ]);
            expect(result).toBe(true);
        }));
        it('should return false when no locks exist', () => __awaiter(void 0, void 0, void 0, function* () {
            mockFs.readFile.mockRejectedValue(new Error('File not found'));
            const result = yield (0, lockFiles_1.oneOfMultipleLocksExist)([
                lockFiles_1.LockFiles.LoadInProgress,
                lockFiles_1.LockFiles.AutoSaveInProgress,
                lockFiles_1.LockFiles.ServerKillInProgress
            ]);
            expect(result).toBe(false);
        }));
        it('should handle empty array', () => __awaiter(void 0, void 0, void 0, function* () {
            const result = yield (0, lockFiles_1.oneOfMultipleLocksExist)([]);
            expect(result).toBe(false);
        }));
        it('should return true when multiple locks exist', () => __awaiter(void 0, void 0, void 0, function* () {
            const validLockData = JSON.stringify({ timestamp: Date.now() });
            mockFs.readFile.mockResolvedValue(validLockData);
            const result = yield (0, lockFiles_1.oneOfMultipleLocksExist)([
                lockFiles_1.LockFiles.LoadInProgress,
                lockFiles_1.LockFiles.AutoSaveInProgress
            ]);
            expect(result).toBe(true);
        }));
        it('should handle mix of stale and valid locks', () => __awaiter(void 0, void 0, void 0, function* () {
            const currentTime = 1640995200000;
            const staleLockData = JSON.stringify({ timestamp: currentTime - 20000 });
            const validLockData = JSON.stringify({ timestamp: currentTime });
            mockFs.readFile
                .mockResolvedValueOnce(staleLockData)
                .mockResolvedValueOnce(validLockData);
            const result = yield (0, lockFiles_1.oneOfMultipleLocksExist)([
                lockFiles_1.LockFiles.LoadInProgress,
                lockFiles_1.LockFiles.AutoSaveInProgress
            ]);
            expect(result).toBe(true);
            expect(mockFs.rm).toHaveBeenCalledWith('/mock/lock/files/LoadInProgress');
        }));
    });
    describe('lockFileExist', () => {
        it('should return true for valid LoadInProgress lock', () => __awaiter(void 0, void 0, void 0, function* () {
            const validLockData = JSON.stringify({ timestamp: Date.now() });
            mockFs.readFile.mockResolvedValue(validLockData);
            const result = yield (0, lockFiles_1.lockFileExist)(lockFiles_1.LockFiles.LoadInProgress);
            expect(result).toBe(true);
        }));
        it('should return true for valid AutoSaveInProgress lock', () => __awaiter(void 0, void 0, void 0, function* () {
            const validLockData = JSON.stringify({ timestamp: Date.now() });
            mockFs.readFile.mockResolvedValue(validLockData);
            const result = yield (0, lockFiles_1.lockFileExist)(lockFiles_1.LockFiles.AutoSaveInProgress);
            expect(result).toBe(true);
        }));
        it('should return true for valid ServerKillInProgress lock', () => __awaiter(void 0, void 0, void 0, function* () {
            const validLockData = JSON.stringify({ timestamp: Date.now() });
            mockFs.readFile.mockResolvedValue(validLockData);
            const result = yield (0, lockFiles_1.lockFileExist)(lockFiles_1.LockFiles.ServerKillInProgress);
            expect(result).toBe(true);
        }));
        it('should return false when file does not exist', () => __awaiter(void 0, void 0, void 0, function* () {
            mockFs.readFile.mockRejectedValue(new Error('File not found'));
            const result = yield (0, lockFiles_1.lockFileExist)(lockFiles_1.LockFiles.LoadInProgress);
            expect(result).toBe(false);
        }));
        it('should return false and cleanup stale LoadInProgress lock', () => __awaiter(void 0, void 0, void 0, function* () {
            const staleLockData = JSON.stringify({ timestamp: Date.now() - 15000 });
            mockFs.readFile.mockResolvedValue(staleLockData);
            const consoleSpy = jest.spyOn(console, 'log').mockImplementation();
            const result = yield (0, lockFiles_1.lockFileExist)(lockFiles_1.LockFiles.LoadInProgress);
            expect(result).toBe(false);
            expect(consoleSpy).toHaveBeenCalledWith('Removing stale LoadInProgress lock file');
            consoleSpy.mockRestore();
        }));
        it('should return false and cleanup stale AutoSaveInProgress lock', () => __awaiter(void 0, void 0, void 0, function* () {
            const staleLockData = JSON.stringify({ timestamp: Date.now() - 360000 }); // 6 minutes
            mockFs.readFile.mockResolvedValue(staleLockData);
            const consoleSpy = jest.spyOn(console, 'log').mockImplementation();
            const result = yield (0, lockFiles_1.lockFileExist)(lockFiles_1.LockFiles.AutoSaveInProgress);
            expect(result).toBe(false);
            expect(consoleSpy).toHaveBeenCalledWith('Removing stale AutoSaveInProgress lock file');
            consoleSpy.mockRestore();
        }));
        it('should return false and cleanup stale ServerKillInProgress lock', () => __awaiter(void 0, void 0, void 0, function* () {
            const staleLockData = JSON.stringify({ timestamp: Date.now() - 7000 });
            mockFs.readFile.mockResolvedValue(staleLockData);
            const consoleSpy = jest.spyOn(console, 'log').mockImplementation();
            const result = yield (0, lockFiles_1.lockFileExist)(lockFiles_1.LockFiles.ServerKillInProgress);
            expect(result).toBe(false);
            expect(consoleSpy).toHaveBeenCalledWith('Removing stale ServerKillInProgress lock file');
            consoleSpy.mockRestore();
        }));
        it('should handle invalid JSON in lock file', () => __awaiter(void 0, void 0, void 0, function* () {
            mockFs.readFile.mockResolvedValue('invalid json');
            const result = yield (0, lockFiles_1.lockFileExist)(lockFiles_1.LockFiles.LoadInProgress);
            expect(result).toBe(false);
        }));
        it('should handle file read error during cleanup', () => __awaiter(void 0, void 0, void 0, function* () {
            const staleLockData = JSON.stringify({ timestamp: Date.now() - 15000 });
            mockFs.readFile.mockResolvedValue(staleLockData);
            mockFs.rm.mockRejectedValue(new Error('Cannot delete'));
            const consoleSpy = jest.spyOn(console, 'log').mockImplementation();
            const result = yield (0, lockFiles_1.lockFileExist)(lockFiles_1.LockFiles.LoadInProgress);
            expect(result).toBe(false);
            expect(consoleSpy).toHaveBeenCalledWith(expect.any(Error));
            consoleSpy.mockRestore();
        }));
    });
    describe('createLockFile', () => {
        it('should create LoadInProgress lock file', () => __awaiter(void 0, void 0, void 0, function* () {
            yield (0, lockFiles_1.createLockFile)(lockFiles_1.LockFiles.LoadInProgress);
            expect(mockFs.writeFile).toHaveBeenCalledWith('/mock/lock/files/LoadInProgress', JSON.stringify({ timestamp: 1640995200000 }));
        }));
        it('should create AutoSaveInProgress lock file', () => __awaiter(void 0, void 0, void 0, function* () {
            yield (0, lockFiles_1.createLockFile)(lockFiles_1.LockFiles.AutoSaveInProgress);
            expect(mockFs.writeFile).toHaveBeenCalledWith('/mock/lock/files/AutoSaveInProgress', JSON.stringify({ timestamp: 1640995200000 }));
        }));
        it('should create ServerKillInProgress lock file', () => __awaiter(void 0, void 0, void 0, function* () {
            yield (0, lockFiles_1.createLockFile)(lockFiles_1.LockFiles.ServerKillInProgress);
            expect(mockFs.writeFile).toHaveBeenCalledWith('/mock/lock/files/ServerKillInProgress', JSON.stringify({ timestamp: 1640995200000 }));
        }));
        it('should handle write errors', () => __awaiter(void 0, void 0, void 0, function* () {
            mockFs.writeFile.mockRejectedValue(new Error('Write failed'));
            yield expect((0, lockFiles_1.createLockFile)(lockFiles_1.LockFiles.LoadInProgress)).rejects.toThrow('Write failed');
        }));
        it('should create lock files with current timestamp', () => __awaiter(void 0, void 0, void 0, function* () {
            const mockTimestamp = 1641000000000;
            jest.spyOn(Date, 'now').mockReturnValue(mockTimestamp);
            yield (0, lockFiles_1.createLockFile)(lockFiles_1.LockFiles.LoadInProgress);
            expect(mockFs.writeFile).toHaveBeenCalledWith('/mock/lock/files/LoadInProgress', JSON.stringify({ timestamp: mockTimestamp }));
        }));
    });
});
