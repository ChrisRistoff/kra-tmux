"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const systemFileManager_1 = require("@/system/commands/systemFileManager");
jest.mock('@/UI/generalUI', () => ({
    askUserForInput: jest.fn(),
    promptUserYesOrNo: jest.fn(),
    searchSelectAndReturnFromArray: jest.fn()
}));
jest.mock('@/utils/bashHelper', () => ({
    execCommand: jest.fn()
}));
// import after mocking
const ui = __importStar(require("@/UI/generalUI"));
const bash = __importStar(require("@/utils/bashHelper"));
describe('SystemFileManager Integration Tests', () => {
    const TEST_DIR = path.join(process.cwd(), '__tests__/test-files');
    beforeAll(() => {
        if (!fs.existsSync(TEST_DIR)) {
            fs.mkdirSync(TEST_DIR, { recursive: true });
        }
    });
    afterAll(() => {
        if (fs.existsSync(TEST_DIR)) {
            fs.rmSync(TEST_DIR, { recursive: true, force: true });
        }
    });
    beforeEach(() => {
        jest.clearAllMocks();
        // clear the test directory before each test
        fs.readdirSync(TEST_DIR).forEach(file => {
            const filePath = path.join(TEST_DIR, file);
            fs.rmSync(filePath, { recursive: true, force: true });
        });
    });
    describe('removeFile', () => {
        it('should remove a file when user confirms', () => __awaiter(void 0, void 0, void 0, function* () {
            // create test file
            const testFile = path.join(TEST_DIR, 'test.txt');
            fs.writeFileSync(testFile, 'test content');
            ui.askUserForInput.mockResolvedValue('test');
            ui.promptUserYesOrNo.mockResolvedValue(true);
            ui.searchSelectAndReturnFromArray.mockResolvedValue(testFile);
            bash.execCommand.mockResolvedValueOnce({ stdout: testFile, stderr: '' });
            yield (0, systemFileManager_1.removeFile)();
            expect(bash.execCommand).toHaveBeenCalledWith(`rm "${testFile}"`);
        }));
        it('should not remove file when user cancels', () => __awaiter(void 0, void 0, void 0, function* () {
            const testFile = path.join(TEST_DIR, 'test.txt');
            fs.writeFileSync(testFile, 'test content');
            ui.askUserForInput.mockResolvedValue('test');
            ui.promptUserYesOrNo.mockResolvedValue(false);
            ui.searchSelectAndReturnFromArray.mockResolvedValue(testFile);
            bash.execCommand.mockResolvedValueOnce({ stdout: testFile, stderr: '' });
            yield (0, systemFileManager_1.removeFile)();
            expect(bash.execCommand).not.toHaveBeenCalledWith(`rm "${testFile}"`);
            expect(fs.existsSync(testFile)).toBeTruthy();
        }));
    });
    describe('removeDirectory', () => {
        it('should remove a directory when user confirms', () => __awaiter(void 0, void 0, void 0, function* () {
            // create test directory
            const testDir = path.join(TEST_DIR, 'testdir');
            fs.mkdirSync(testDir);
            ui.askUserForInput.mockResolvedValue('testdir');
            ui.promptUserYesOrNo.mockResolvedValue(true);
            ui.searchSelectAndReturnFromArray.mockResolvedValue(testDir);
            bash.execCommand.mockResolvedValueOnce({ stdout: testDir, stderr: '' });
            yield (0, systemFileManager_1.removeDirectory)();
            expect(bash.execCommand).toHaveBeenCalledWith(`rm -rf "${testDir}"`);
        }));
        it('should handle no matches found', () => __awaiter(void 0, void 0, void 0, function* () {
            ui.askUserForInput.mockResolvedValue('nonexistent');
            ui.promptUserYesOrNo.mockResolvedValue(true);
            bash.execCommand.mockResolvedValueOnce({ stdout: '', stderr: '' });
            const consoleSpy = jest.spyOn(console, 'log');
            yield expect((0, systemFileManager_1.removeDirectory)()).rejects.toThrow('User cancelled');
            expect(consoleSpy).toHaveBeenCalledWith('No matches found for the given search criteria.');
            consoleSpy.mockRestore();
        }));
    });
});
