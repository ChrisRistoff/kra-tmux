"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const bash = __importStar(require("@/utils/bashHelper"));
const ui = __importStar(require("@/UI/generalUI"));
const systemFileManager_1 = require("@/system/commands/systemFileManager");
jest.mock('@/utils/bashHelper');
jest.mock('@/UI/generalUI');
describe('SystemFileManager', () => {
    const mockExecCommand = jest.mocked(bash.execCommand);
    const mockAskUserForInput = jest.mocked(ui.askUserForInput);
    const mockPromptYesOrNo = jest.mocked(ui.promptUserYesOrNo);
    const mockSearchSelectAndReturnFromArray = jest.mocked(ui.searchSelectAndReturnFromArray);
    beforeEach(() => {
        jest.clearAllMocks();
    });
    describe('File Operations', () => {
        it('should construct correct find command for file search', () => __awaiter(void 0, void 0, void 0, function* () {
            mockAskUserForInput.mockResolvedValue('test');
            mockPromptYesOrNo.mockResolvedValue(false); // non-exact match
            mockExecCommand.mockResolvedValue({ stdout: '', stderr: '' });
            yield expect((0, systemFileManager_1.removeFile)()).rejects.toThrow('User cancelled');
            expect(mockExecCommand).toHaveBeenCalledWith('find . -type f -iname "*test*"');
        }));
        it('should construct correct remove command for file', () => __awaiter(void 0, void 0, void 0, function* () {
            const testFile = './test.txt';
            mockAskUserForInput.mockResolvedValue('test');
            mockPromptYesOrNo.mockResolvedValueOnce(true) // exact match
                .mockResolvedValueOnce(true); // confirm deletion
            mockExecCommand.mockResolvedValueOnce({ stdout: testFile, stderr: '' })
                .mockResolvedValueOnce({ stdout: '', stderr: '' });
            mockSearchSelectAndReturnFromArray.mockResolvedValue(testFile);
            yield (0, systemFileManager_1.removeFile)();
            expect(mockExecCommand).toHaveBeenLastCalledWith(`rm "${testFile}"`);
        }));
        it('should validate minimum search length for files', () => __awaiter(void 0, void 0, void 0, function* () {
            mockAskUserForInput.mockResolvedValue('a');
            yield expect((0, systemFileManager_1.removeFile)()).rejects.toThrow('Search term must be at least 2 characters long');
            expect(mockExecCommand).not.toHaveBeenCalled();
        }));
    });
    describe('Directory Operations', () => {
        it('should construct correct find command for directory search', () => __awaiter(void 0, void 0, void 0, function* () {
            mockAskUserForInput.mockResolvedValue('test');
            mockPromptYesOrNo.mockResolvedValue(false); // non-exact match
            mockExecCommand.mockResolvedValue({ stdout: '', stderr: '' });
            yield expect((0, systemFileManager_1.removeDirectory)()).rejects.toThrow('User cancelled');
            expect(mockExecCommand).toHaveBeenCalledWith('find . -type d -iname "*test*"');
        }));
        it('should construct correct remove command for directory', () => __awaiter(void 0, void 0, void 0, function* () {
            const testDir = './testdir';
            mockAskUserForInput.mockResolvedValue('test');
            mockPromptYesOrNo.mockResolvedValueOnce(true) // exact match
                .mockResolvedValueOnce(true); // confirm deletion
            mockExecCommand.mockResolvedValueOnce({ stdout: testDir, stderr: '' })
                .mockResolvedValueOnce({ stdout: '', stderr: '' });
            mockSearchSelectAndReturnFromArray.mockResolvedValue(testDir);
            yield (0, systemFileManager_1.removeDirectory)();
            expect(mockExecCommand).toHaveBeenLastCalledWith(`rm -rf "${testDir}"`);
        }));
    });
    describe('Error Handling', () => {
        it('should handle command execution errors', () => __awaiter(void 0, void 0, void 0, function* () {
            mockAskUserForInput.mockResolvedValue('test');
            mockPromptYesOrNo.mockResolvedValueOnce(true)
                .mockResolvedValueOnce(true);
            mockExecCommand.mockResolvedValueOnce({ stdout: './test', stderr: '' })
                .mockRejectedValueOnce(new Error('Permission denied'));
            mockSearchSelectAndReturnFromArray.mockResolvedValue('./test');
            yield expect((0, systemFileManager_1.removeDirectory)()).rejects.toThrow('Failed to remove directory: Permission denied');
        }));
        it('should handle empty search results', () => __awaiter(void 0, void 0, void 0, function* () {
            mockAskUserForInput.mockResolvedValue('nonexistent');
            mockPromptYesOrNo.mockResolvedValue(true);
            mockExecCommand.mockResolvedValue({ stdout: '', stderr: '' });
            const consoleSpy = jest.spyOn(console, 'log');
            yield expect((0, systemFileManager_1.removeFile)()).rejects.toThrow('User cancelled');
            expect(consoleSpy).toHaveBeenCalledWith('No matches found for the given search criteria.');
            consoleSpy.mockRestore();
        }));
    });
    describe('Security', () => {
        it('should sanitize search input while preserving command structure', () => __awaiter(void 0, void 0, void 0, function* () {
            const maliciousInput = 'test";rm -rf /;"';
            mockAskUserForInput.mockResolvedValue(maliciousInput);
            mockPromptYesOrNo.mockResolvedValue(false); // non-exact match
            mockExecCommand.mockResolvedValue({ stdout: '', stderr: '' });
            yield expect((0, systemFileManager_1.removeFile)()).rejects.toThrow('User cancelled');
            // command should contain the sanitized version of the input
            expect(mockExecCommand).toHaveBeenCalledWith('find . -type f -iname "*test;rm -rf /;*"');
        }));
        it('should remove dangerous characters from search input', () => __awaiter(void 0, void 0, void 0, function* () {
            const inputWithSpecialChars = 'test\'"\\file';
            const expectedSanitized = 'testfile';
            mockAskUserForInput.mockResolvedValue(inputWithSpecialChars);
            mockPromptYesOrNo.mockResolvedValue(true); // exact match
            mockExecCommand.mockResolvedValue({ stdout: '', stderr: '' });
            yield expect((0, systemFileManager_1.removeFile)()).rejects.toThrow('User cancelled');
            expect(mockExecCommand).toHaveBeenCalledWith(`find . -type f -iname "${expectedSanitized}"`);
        }));
    });
});
