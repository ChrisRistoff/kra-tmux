"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const events_1 = require("events");
const readline_1 = __importDefault(require("readline"));
const stdioServer_1 = require("@/AI/AIAgent/mcp/stdioServer");
jest.mock('readline', () => ({
    __esModule: true,
    default: {
        createInterface: jest.fn(),
    },
}));
function makeReadline() {
    const rl = new events_1.EventEmitter();
    rl.close = () => {
        rl.emit('close');
    };
    return rl;
}
function parseResponses(writeSpy) {
    return writeSpy.mock.calls
        .map((call) => { var _a; return String((_a = call[0]) !== null && _a !== void 0 ? _a : ''); })
        .flatMap((chunk) => chunk.split('\n'))
        .map((line) => line.trim())
        .filter((line) => line.length > 0)
        .map((line) => JSON.parse(line));
}
function flushAsyncWork() {
    return __awaiter(this, void 0, void 0, function* () {
        yield new Promise((resolve) => setImmediate(resolve));
    });
}
describe('runStdioMcpServer', () => {
    let writeSpy;
    let exitSpy;
    beforeEach(() => {
        jest.clearAllMocks();
        writeSpy = jest.spyOn(process.stdout, 'write').mockImplementation(() => true);
        exitSpy = jest.spyOn(process, 'exit').mockImplementation((() => undefined));
    });
    afterEach(() => {
        writeSpy.mockRestore();
        exitSpy.mockRestore();
    });
    it('responds to initialize and tools/list with advertised server capabilities', () => __awaiter(void 0, void 0, void 0, function* () {
        const rl = makeReadline();
        jest.mocked(readline_1.default.createInterface).mockReturnValue(rl);
        (0, stdioServer_1.runStdioMcpServer)({
            serverName: 'test-server',
            tools: [{ name: 'echo' }],
            handleToolCall: () => __awaiter(void 0, void 0, void 0, function* () { return ({ ok: true }); }),
        });
        rl.emit('line', JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'initialize', params: {} }));
        rl.emit('line', JSON.stringify({ jsonrpc: '2.0', id: 2, method: 'tools/list', params: {} }));
        yield flushAsyncWork();
        const responses = parseResponses(writeSpy);
        const init = responses.find((response) => response['id'] === 1);
        const list = responses.find((response) => response['id'] === 2);
        expect(init === null || init === void 0 ? void 0 : init['result']).toMatchObject({
            protocolVersion: '2024-11-05',
            capabilities: { tools: {} },
            serverInfo: { name: 'test-server' },
        });
        expect((list === null || list === void 0 ? void 0 : list['result']).tools).toEqual([{ name: 'echo' }]);
    }));
    it('maps unknown tools and JsonRpcToolError to expected JSON-RPC errors', () => __awaiter(void 0, void 0, void 0, function* () {
        const rl = makeReadline();
        jest.mocked(readline_1.default.createInterface).mockReturnValue(rl);
        (0, stdioServer_1.runStdioMcpServer)({
            serverName: 'test-server',
            tools: [{ name: 'echo' }],
            handleToolCall: () => __awaiter(void 0, void 0, void 0, function* () {
                throw new stdioServer_1.JsonRpcToolError(-32602, 'Invalid parameters');
            }),
        });
        rl.emit('line', JSON.stringify({ jsonrpc: '2.0', id: 10, method: 'tools/call', params: { name: 'missing' } }));
        rl.emit('line', JSON.stringify({ jsonrpc: '2.0', id: 11, method: 'tools/call', params: { name: 'echo' } }));
        yield flushAsyncWork();
        const responses = parseResponses(writeSpy);
        const unknownTool = responses.find((response) => response['id'] === 10);
        const invalidParams = responses.find((response) => response['id'] === 11);
        expect((unknownTool === null || unknownTool === void 0 ? void 0 : unknownTool['error']).code).toBe(-32601);
        expect(invalidParams === null || invalidParams === void 0 ? void 0 : invalidParams['error']).toEqual({
            code: -32602,
            message: 'Invalid parameters',
        });
    }));
    it('honors parse-error mode and internal error result mapping', () => __awaiter(void 0, void 0, void 0, function* () {
        var _a;
        const rl = makeReadline();
        jest.mocked(readline_1.default.createInterface).mockReturnValue(rl);
        (0, stdioServer_1.runStdioMcpServer)({
            serverName: 'test-server',
            tools: [{ name: 'echo' }],
            respondParseError: false,
            handleToolCall: () => __awaiter(void 0, void 0, void 0, function* () {
                throw new Error('handler boom');
            }),
            onInternalError: () => ({ kind: 'result', result: { recovered: true } }),
        });
        rl.emit('line', '{not-json');
        rl.emit('line', JSON.stringify({ jsonrpc: '2.0', id: 20, method: 'tools/call', params: { name: 'echo' } }));
        yield flushAsyncWork();
        const responses = parseResponses(writeSpy);
        expect(responses.some((response) => { var _a; return ((_a = response['error']) === null || _a === void 0 ? void 0 : _a.code) === -32700; })).toBe(false);
        expect((_a = responses.find((response) => response['id'] === 20)) === null || _a === void 0 ? void 0 : _a['result']).toEqual({ recovered: true });
    }));
    it('exits when stdin closes after pending work is drained', () => __awaiter(void 0, void 0, void 0, function* () {
        const rl = makeReadline();
        jest.mocked(readline_1.default.createInterface).mockReturnValue(rl);
        (0, stdioServer_1.runStdioMcpServer)({
            serverName: 'test-server',
            tools: [{ name: 'echo' }],
            handleToolCall: () => __awaiter(void 0, void 0, void 0, function* () { return ({ ok: true }); }),
        });
        rl.close();
        yield flushAsyncWork();
        expect(exitSpy).toHaveBeenCalledWith(0);
    }));
});
