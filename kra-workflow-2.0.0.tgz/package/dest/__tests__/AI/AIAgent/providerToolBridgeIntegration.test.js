"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
let originalSdkDisconnect = jest.fn(() => __awaiter(void 0, void 0, void 0, function* () { return undefined; }));
let currentSdkSession = {
    disconnect: originalSdkDisconnect,
};
const mockCopilotCreateSession = jest.fn(() => __awaiter(void 0, void 0, void 0, function* () { return currentSdkSession; }));
jest.mock('@github/copilot-sdk', () => ({
    CopilotClient: class {
        constructor() {
            this.createSession = mockCopilotCreateSession;
            this.start = jest.fn(() => __awaiter(this, void 0, void 0, function* () { return undefined; }));
            this.stop = jest.fn(() => __awaiter(this, void 0, void 0, function* () { return undefined; }));
            this.forceStop = jest.fn(() => __awaiter(this, void 0, void 0, function* () { return undefined; }));
            this.getAuthStatus = jest.fn(() => __awaiter(this, void 0, void 0, function* () { return ({}); }));
            this.listModels = jest.fn(() => __awaiter(this, void 0, void 0, function* () { return []; }));
        }
    },
}));
const mockBuildMcpClientPool = jest.fn();
jest.mock('@/AI/AIAgent/providers/byok/mcpClientPool', () => ({
    buildMcpClientPool: (...args) => mockBuildMcpClientPool(...args),
}));
const byokSession_1 = require("@/AI/AIAgent/providers/byok/byokSession");
const copilotClient_1 = require("@/AI/AIAgent/providers/copilot/copilotClient");
function typed(value) {
    return value;
}
function makeSessionOptions() {
    return {
        model: 'test-model',
        workingDirectory: '/tmp/workspace',
        mcpServers: {},
        onPreToolUse: () => __awaiter(this, void 0, void 0, function* () { return ({}); }),
        onPostToolUse: () => __awaiter(this, void 0, void 0, function* () { return undefined; }),
    };
}
function makePoolWithSingleTool(server, name, textResult) {
    const callTool = jest.fn(() => __awaiter(this, void 0, void 0, function* () { return ({ content: [{ type: 'text', text: textResult }] }); }));
    const tool = {
        server,
        originalName: name,
        namespacedName: `${server}__${name}`,
        description: `${server}:${name}`,
        inputSchema: {},
        client: typed({ callTool }),
    };
    return {
        tools: new Map([[`${server}:${name}`, tool]]),
        openaiTools: [],
        disconnect: jest.fn(() => __awaiter(this, void 0, void 0, function* () { return undefined; })),
    };
}
describe('provider executable tool bridge integration', () => {
    beforeEach(() => {
        jest.clearAllMocks();
        originalSdkDisconnect = jest.fn(() => __awaiter(void 0, void 0, void 0, function* () { return undefined; }));
        currentSdkSession = {
            disconnect: originalSdkDisconnect,
        };
    });
    it('BYOK session exposes executable tools from MCP pool and executes by title', () => __awaiter(void 0, void 0, void 0, function* () {
        const session = new byokSession_1.OpenAICompatibleSession({
            sessionOptions: makeSessionOptions(),
            apiKey: 'test-key',
            baseURL: 'https://example.test',
        });
        const pool = makePoolWithSingleTool('kra-bash', 'bash', 'pwd output');
        typed(session).mcp = pool;
        expect(session.listExecutableTools()).toEqual([
            { title: 'kra-bash:bash', server: 'kra-bash', name: 'bash' },
        ]);
        yield expect(session.executeTool('kra-bash:bash', { command: 'pwd' })).resolves.toBe('pwd output');
        yield session.disconnect();
        expect(pool.disconnect).toHaveBeenCalledTimes(1);
    }));
    it('Copilot wrapper wires kra-* side-pool tools for re-execution', () => __awaiter(void 0, void 0, void 0, function* () {
        const sidePool = makePoolWithSingleTool('kra-memory', 'recall', 'memory result');
        mockBuildMcpClientPool.mockResolvedValue(sidePool);
        const wrapper = new copilotClient_1.CopilotClientWrapper({ useLoggedInUser: true });
        const options = Object.assign(Object.assign({}, makeSessionOptions()), { mcpServers: {
                'kra-memory': typed({ type: 'stdio', command: 'node', args: ['memory.js'] }),
                'external-tool': typed({ type: 'stdio', command: 'node', args: ['ext.js'] }),
            } });
        const session = yield wrapper.createSession(options);
        expect(mockBuildMcpClientPool).toHaveBeenCalledWith({
            servers: {
                'kra-memory': options.mcpServers['kra-memory'],
            },
            workingDirectory: '/tmp/workspace',
        });
        if (!session.listExecutableTools || !session.executeTool) {
            throw new Error('Copilot session should expose executable tool bridge methods');
        }
        expect(session.listExecutableTools()).toEqual([
            { title: 'kra-memory:recall', server: 'kra-memory', name: 'recall' },
        ]);
        yield expect(session.executeTool('kra-memory:recall', { query: 'recent' })).resolves.toBe('memory result');
        yield session.disconnect();
        expect(sidePool.disconnect).toHaveBeenCalledTimes(1);
        expect(originalSdkDisconnect).toHaveBeenCalledTimes(1);
    }));
});
