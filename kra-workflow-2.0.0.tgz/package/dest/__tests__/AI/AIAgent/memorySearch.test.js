"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const notes_1 = require("@/AI/AIAgent/shared/memory/notes");
const search_1 = require("@/AI/AIAgent/shared/memory/search");
const db_1 = require("@/AI/AIAgent/shared/memory/db");
const embedder_1 = require("@/AI/AIAgent/shared/memory/embedder");
jest.mock('@/AI/AIAgent/shared/memory/embedder', () => ({
    embedOne: jest.fn(() => __awaiter(void 0, void 0, void 0, function* () { return [0.1, 0.2, 0.3]; })),
}));
jest.mock('@/AI/AIAgent/shared/memory/db', () => ({
    getCodeChunksTable: jest.fn(),
    getFindingsTable: jest.fn(),
    getRevisitsTable: jest.fn(),
}));
jest.mock('@/AI/AIAgent/shared/memory/indexer', () => ({
    matchGlob: jest.fn(() => true),
}));
const mockedEmbedOne = jest.mocked(embedder_1.embedOne);
const mockedGetCodeChunksTable = jest.mocked(db_1.getCodeChunksTable);
const mockedGetFindingsTable = jest.mocked(db_1.getFindingsTable);
const mockedGetRevisitsTable = jest.mocked(db_1.getRevisitsTable);
function makeMemoryRow(id, kind, createdAt) {
    return {
        id,
        kind,
        title: `${kind} ${id}`,
        body: `body for ${id}`,
        tags: JSON.stringify(['memory']),
        paths: JSON.stringify(['src/example.ts']),
        branch: '',
        status: kind === 'revisit' ? 'open' : 'resolved',
        resolution: '',
        createdAt,
        updatedAt: createdAt,
        source: 'agent-auto',
        vector: [0.1, 0.2, 0.3],
    };
}
function makeTable(queryRows, searchRows = queryRows) {
    return {
        countRows: jest.fn(() => __awaiter(this, void 0, void 0, function* () { return queryRows.length; })),
        query: jest.fn(() => ({
            limit: jest.fn(() => ({
                toArray: jest.fn(() => __awaiter(this, void 0, void 0, function* () { return queryRows; })),
            })),
        })),
        search: jest.fn(() => ({
            limit: jest.fn(() => ({
                toArray: jest.fn(() => __awaiter(this, void 0, void 0, function* () { return searchRows; })),
            })),
        })),
    };
}
describe('memory lookup filters', () => {
    beforeEach(() => {
        jest.clearAllMocks();
        mockedGetCodeChunksTable.mockResolvedValue({ table: null, justCreated: false });
        mockedGetRevisitsTable.mockResolvedValue({ table: null, justCreated: false });
    });
    it('recall supports findings as a combined lookup kind', () => __awaiter(void 0, void 0, void 0, function* () {
        const older = makeMemoryRow('note-1', 'note', 100);
        const newer = makeMemoryRow('investigation-1', 'investigation', 200);
        mockedGetFindingsTable.mockResolvedValue({
            table: makeTable([older, newer]),
            justCreated: false,
        });
        const result = yield (0, notes_1.recall)({ kind: 'findings' });
        expect(result.map((entry) => entry.id)).toEqual(['investigation-1', 'note-1']);
    }));
    it('recall limits findings results to the selected ids', () => __awaiter(void 0, void 0, void 0, function* () {
        var _a;
        const note = makeMemoryRow('note-1', 'note', 100);
        const gotcha = makeMemoryRow('gotcha-1', 'gotcha', 200);
        mockedGetFindingsTable.mockResolvedValue({
            table: makeTable([note, gotcha]),
            justCreated: false,
        });
        const result = yield (0, notes_1.recall)({ kind: 'findings', selectedIds: ['note-1'] });
        expect(result).toHaveLength(1);
        expect((_a = result[0]) === null || _a === void 0 ? void 0 : _a.id).toBe('note-1');
    }));
    it('semanticSearch supports findings memory searches and selected ids', () => __awaiter(void 0, void 0, void 0, function* () {
        var _a, _b, _c;
        const noteHit = Object.assign(Object.assign({}, makeMemoryRow('note-1', 'note', 100)), { _distance: 0.05 });
        const decisionHit = Object.assign(Object.assign({}, makeMemoryRow('decision-1', 'decision', 200)), { _distance: 0.02 });
        mockedGetFindingsTable.mockResolvedValue({
            table: makeTable([], [noteHit, decisionHit]),
            justCreated: false,
        });
        const result = yield (0, search_1.semanticSearch)({
            query: 'release decision',
            scope: 'memory',
            memoryKind: 'findings',
            selectedIds: ['note-1'],
        });
        expect(mockedEmbedOne).toHaveBeenCalledWith('release decision');
        expect(result).toHaveLength(1);
        expect((_a = result[0]) === null || _a === void 0 ? void 0 : _a.type).toBe('memory');
        expect((_c = (_b = result[0]) === null || _b === void 0 ? void 0 : _b.memory) === null || _c === void 0 ? void 0 : _c.id).toBe('note-1');
    }));
});
