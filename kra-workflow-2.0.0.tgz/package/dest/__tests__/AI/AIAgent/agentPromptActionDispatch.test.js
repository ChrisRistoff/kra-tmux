"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const agentPromptActionDispatch_1 = require("@/AI/AIAgent/shared/main/agentPromptActionDispatch");
const conversation = __importStar(require("@/AI/shared/conversation"));
const sessionEvents = __importStar(require("@/AI/AIAgent/shared/utils/agentSessionEvents"));
const memoryActions = __importStar(require("@/AI/AIAgent/shared/main/agentMemoryActions"));
jest.mock('@/AI/shared/conversation', () => ({
    handleAddFileContext: jest.fn(),
    showFileContextsPopup: jest.fn(),
    handleRemoveFileContext: jest.fn(),
    clearAllFileContexts: jest.fn(),
}));
jest.mock('@/AI/AIAgent/shared/utils/agentSessionEvents', () => ({
    applyProposal: jest.fn(),
    openChangedProposalFile: jest.fn(),
    rejectCurrentProposal: jest.fn(),
    showProposalReview: jest.fn(),
    updateAgentUi: jest.fn(),
}));
jest.mock('@/AI/AIAgent/shared/main/agentMemoryActions', () => ({
    handleAddMemory: jest.fn(),
    handleDeleteMemory: jest.fn(),
    handleEditMemory: jest.fn(),
    handleSetMemoryStatus: jest.fn(),
    openMemoryBrowser: jest.fn(),
}));
function typed(value) {
    return value;
}
function makeState() {
    const nvimClient = typed({});
    const session = typed({
        abort: jest.fn(() => __awaiter(this, void 0, void 0, function* () { return undefined; })),
        executeTool: jest.fn(() => __awaiter(this, void 0, void 0, function* () { return 'tool ok'; })),
    });
    const state = {
        nvim: nvimClient,
        chatFile: '/tmp/chat.md',
        model: 'test-model',
        client: typed({}),
        session,
        cwd: '/tmp',
        history: typed({}),
        isStreaming: true,
        approvalMode: 'strict',
        allowedToolFamilies: new Set(['bash']),
    };
    return state;
}
describe('dispatchPromptAction', () => {
    const mockedUpdateUi = jest.mocked(sessionEvents.updateAgentUi);
    beforeEach(() => {
        jest.clearAllMocks();
    });
    it('stops active streaming turns and notifies the UI', () => __awaiter(void 0, void 0, void 0, function* () {
        const state = makeState();
        yield (0, agentPromptActionDispatch_1.dispatchPromptAction)(state, 'stop_stream', []);
        expect(state.session.abort).toHaveBeenCalledTimes(1);
        expect(state.isStreaming).toBe(false);
        expect(mockedUpdateUi).toHaveBeenCalledWith(state.nvim, 'stop_turn', ['Stopped current agent turn']);
    }));
    it('toggles approval mode and clears remembered tool approvals', () => __awaiter(void 0, void 0, void 0, function* () {
        const state = makeState();
        yield (0, agentPromptActionDispatch_1.dispatchPromptAction)(state, 'toggle_yolo_mode', []);
        expect(state.approvalMode).toBe('yolo');
        expect(state.allowedToolFamilies.size).toBe(0);
        expect(mockedUpdateUi).toHaveBeenCalledWith(state.nvim, 'show_error', ['Approval mode', 'YOLO mode enabled.']);
    }));
    it('normalizes unsupported memory browser view values to all', () => __awaiter(void 0, void 0, void 0, function* () {
        const state = makeState();
        yield (0, agentPromptActionDispatch_1.dispatchPromptAction)(state, 'browse_memory', [undefined, { view: 'unsupported-view' }]);
        expect(memoryActions.openMemoryBrowser).toHaveBeenCalledWith(state.nvim, 'all');
    }));
    it('reports invalid execute_tool JSON payloads to the UI', () => __awaiter(void 0, void 0, void 0, function* () {
        const state = makeState();
        yield (0, agentPromptActionDispatch_1.dispatchPromptAction)(state, 'execute_tool', [undefined, { title: 'kra:bash', args_json: '{bad json' }]);
        expect(mockedUpdateUi).toHaveBeenCalledWith(state.nvim, 'show_tool_execution_result', ['', expect.stringContaining('Invalid JSON'), 'kra:bash']);
        expect(state.session.executeTool).not.toHaveBeenCalled();
    }));
    it('runs execute_tool and returns result text when tool execution succeeds', () => __awaiter(void 0, void 0, void 0, function* () {
        const state = makeState();
        yield (0, agentPromptActionDispatch_1.dispatchPromptAction)(state, 'execute_tool', [undefined, { title: 'kra:bash', args_json: '{"cmd":"pwd"}' }]);
        expect(state.session.executeTool).toHaveBeenCalledWith('kra:bash', { cmd: 'pwd' });
        expect(mockedUpdateUi).toHaveBeenCalledWith(state.nvim, 'show_tool_execution_result', ['tool ok', '', 'kra:bash']);
    }));
    it('routes file context actions through shared conversation handlers', () => __awaiter(void 0, void 0, void 0, function* () {
        const state = makeState();
        yield (0, agentPromptActionDispatch_1.dispatchPromptAction)(state, 'add_file_context', []);
        yield (0, agentPromptActionDispatch_1.dispatchPromptAction)(state, 'show_contexts_popup', []);
        yield (0, agentPromptActionDispatch_1.dispatchPromptAction)(state, 'remove_file_context', []);
        yield (0, agentPromptActionDispatch_1.dispatchPromptAction)(state, 'clear_contexts', []);
        expect(conversation.handleAddFileContext).toHaveBeenCalledWith(state.nvim, state.chatFile, { agentMode: true });
        expect(conversation.showFileContextsPopup).toHaveBeenCalledWith(state.nvim);
        expect(conversation.handleRemoveFileContext).toHaveBeenCalledWith(state.nvim, state.chatFile, { agentMode: true });
        expect(conversation.clearAllFileContexts).toHaveBeenCalledWith(state.nvim, state.chatFile, { agentMode: true });
    }));
});
