"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const executableToolBridge_1 = require("@/AI/AIAgent/mcp/executableToolBridge");
function makeRegisteredTool(server, originalName, callTool) {
    return {
        server,
        originalName,
        namespacedName: `${server}__${originalName}`,
        description: `${server}:${originalName}`,
        inputSchema: {},
        client: {
            callTool: (callTool !== null && callTool !== void 0 ? callTool : jest.fn(() => __awaiter(this, void 0, void 0, function* () { return ({ content: [] }); }))),
        },
    };
}
function makePool(tools) {
    return {
        tools: new Map(tools.map((tool) => [`${tool.server}:${tool.originalName}`, tool])),
        openaiTools: [],
        disconnect: jest.fn(() => __awaiter(this, void 0, void 0, function* () { return undefined; })),
    };
}
describe('executableToolBridge', () => {
    it('lists tools in executable UI format', () => {
        const pool = makePool([makeRegisteredTool('kra-bash', 'bash')]);
        expect((0, executableToolBridge_1.listExecutableToolsFromPool)(pool)).toEqual([
            { title: 'kra-bash:bash', server: 'kra-bash', name: 'bash' },
        ]);
    });
    it('executes the selected tool and joins text parts only', () => __awaiter(void 0, void 0, void 0, function* () {
        const callTool = jest.fn(() => __awaiter(void 0, void 0, void 0, function* () {
            return ({
                content: [
                    { type: 'text', text: 'first line' },
                    { type: 'image', data: 'ignored' },
                    { type: 'text', text: 'second line' },
                ],
            });
        }));
        const pool = makePool([makeRegisteredTool('kra-file', 'search', callTool)]);
        yield expect((0, executableToolBridge_1.executeToolFromPool)(pool, 'kra-file:search', { query: 'abc' })).resolves.toBe('first line\nsecond line');
        expect(callTool).toHaveBeenCalledWith({ name: 'search', arguments: { query: 'abc' } });
    }));
    it('returns clear errors for unknown or unavailable tools', () => __awaiter(void 0, void 0, void 0, function* () {
        yield expect((0, executableToolBridge_1.executeToolFromPool)(undefined, 'kra-x:y', {}, { uninitializedError: 'Not ready' }))
            .rejects.toThrow('Not ready');
        const pool = makePool([]);
        yield expect((0, executableToolBridge_1.executeToolFromPool)(pool, 'kra-x:y', {})).rejects.toThrow('Unknown tool: kra-x:y');
    }));
    it('bridge delegates listing/execution and disconnect helper supports swallow mode', () => __awaiter(void 0, void 0, void 0, function* () {
        const callTool = jest.fn(() => __awaiter(void 0, void 0, void 0, function* () { return ({ content: [{ type: 'text', text: 'ok' }] }); }));
        const pool = makePool([makeRegisteredTool('kra-memory', 'recall', callTool)]);
        const bridge = (0, executableToolBridge_1.createExecutableToolBridge)(() => pool);
        expect(bridge.listExecutableTools()).toEqual([
            { title: 'kra-memory:recall', server: 'kra-memory', name: 'recall' },
        ]);
        yield expect(bridge.executeTool('kra-memory:recall', {})).resolves.toBe('ok');
        const throwingPool = {
            tools: new Map(),
            openaiTools: [],
            disconnect: jest.fn(() => __awaiter(void 0, void 0, void 0, function* () { throw new Error('disconnect failed'); })),
        };
        yield expect((0, executableToolBridge_1.disconnectPool)(throwingPool, true)).resolves.toBeUndefined();
        yield expect((0, executableToolBridge_1.disconnectPool)(throwingPool, false)).rejects.toThrow('disconnect failed');
    }));
});
