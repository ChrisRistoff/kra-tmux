"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const agentSettings_1 = require("@/AI/AIAgent/shared/utils/agentSettings");
const common_1 = require("@/utils/common");
jest.mock('@/utils/common', () => ({
    loadSettings: jest.fn(),
}));
describe('agentSettings', () => {
    const mockedLoadSettings = jest.mocked(common_1.loadSettings);
    beforeEach(() => {
        jest.clearAllMocks();
    });
    it('returns the configured default model', () => __awaiter(void 0, void 0, void 0, function* () {
        mockedLoadSettings.mockResolvedValue({
            watchCommands: {
                work: { active: false, watch: { windowName: '', command: '' } },
                personal: { active: false, watch: { windowName: '', command: '' } },
            },
            autosave: {
                active: true,
                currentSession: 'session',
                timeoutMs: 20000,
            },
            ai: {
                agent: {
                    defaultModel: 'gpt-5-mini',
                },
            },
        });
        yield expect((0, agentSettings_1.getAgentDefaultModel)()).resolves.toBe('gpt-5-mini');
    }));
    it('maps only active MCP servers into SDK config', () => __awaiter(void 0, void 0, void 0, function* () {
        mockedLoadSettings.mockResolvedValue({
            watchCommands: {
                work: { active: false, watch: { windowName: '', command: '' } },
                personal: { active: false, watch: { windowName: '', command: '' } },
            },
            autosave: {
                active: true,
                currentSession: 'session',
                timeoutMs: 20000,
            },
            ai: {
                agent: {
                    mcpServers: {
                        filesystem: {
                            active: true,
                            type: 'local',
                            command: 'npx',
                            args: ['-y', '@modelcontextprotocol/server-filesystem', '.'],
                            tools: ['*'],
                            timeoutMs: 15000,
                        },
                        github: {
                            active: false,
                            type: 'http',
                            url: 'https://example.com/mcp',
                            headers: { Authorization: 'Bearer token' },
                            tools: ['*'],
                        },
                    },
                },
            },
        });
        yield expect((0, agentSettings_1.getConfiguredMcpServers)()).resolves.toEqual({
            filesystem: {
                type: 'local',
                command: 'npx',
                args: ['-y', '@modelcontextprotocol/server-filesystem', '.'],
                tools: ['*'],
                timeout: 15000,
            },
        });
    }));
});
