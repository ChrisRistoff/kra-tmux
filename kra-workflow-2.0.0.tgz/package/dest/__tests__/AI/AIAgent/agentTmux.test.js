"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const agentTmux_1 = require("@/AI/AIAgent/shared/utils/agentTmux");
const filePaths_1 = require("@/filePaths");
describe('buildAgentTmuxCommand', () => {
    it('uses send-keys as the tmux subcommand after split-window', () => {
        const chatFile = '/tmp/kra-agent-chat.md';
        const socketPath = '/tmp/nvim-agent.sock';
        expect((0, agentTmux_1.buildAgentTmuxCommand)(chatFile, socketPath)).toBe(`tmux split-window -v -p 90 -c "#{pane_current_path}" \\; send-keys -t :. 'sh -c "trap \\"exit 0\\" TERM; nvim -u \\"${filePaths_1.neovimConfig}\\" --listen \\"${socketPath}\\" \\"${chatFile}\\"; tmux send-keys exit C-m"' C-m`);
    });
});
