"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = __importStar(require("fs/promises"));
const os = __importStar(require("os"));
const path = __importStar(require("path"));
const agentHistory_1 = require("@/AI/AIAgent/shared/utils/agentHistory");
const bashHelper_1 = require("@/utils/bashHelper");
// Minimal neovim client stub (revertAll only calls nvim.command).
function makeNvimStub() {
    const messages = [];
    return {
        command: jest.fn((msg) => __awaiter(this, void 0, void 0, function* () { messages.push(msg); })),
        messages,
    };
}
function initGitRepo(dir) {
    return __awaiter(this, void 0, void 0, function* () {
        yield (0, bashHelper_1.execCommand)(`git -C '${dir}' init`);
        yield (0, bashHelper_1.execCommand)(`git -C '${dir}' config user.email test@example.com`);
        yield (0, bashHelper_1.execCommand)(`git -C '${dir}' config user.name Test`);
        // Disable GPG signing so commits don't hang waiting for a passphrase.
        yield (0, bashHelper_1.execCommand)(`git -C '${dir}' config commit.gpgsign false`);
        // Initial commit so HEAD exists (required by bashSnapshotAfter)
        yield (0, bashHelper_1.execCommand)(`git -C '${dir}' commit --allow-empty -m init`);
    });
}
describe('agentHistory', () => {
    jest.setTimeout(30000);
    let tmpDir;
    beforeEach(() => __awaiter(void 0, void 0, void 0, function* () {
        tmpDir = yield fs.mkdtemp(path.join(os.tmpdir(), 'agent-history-test-'));
        yield initGitRepo(tmpDir);
    }));
    afterEach(() => __awaiter(void 0, void 0, void 0, function* () {
        yield fs.rm(tmpDir, { recursive: true, force: true });
    }));
    it('recordMutation then revertAll restores a modified file', () => __awaiter(void 0, void 0, void 0, function* () {
        const filePath = path.join(tmpDir, 'hello.txt');
        yield fs.writeFile(filePath, 'original content', 'utf8');
        const history = (0, agentHistory_1.createAgentHistory)(tmpDir);
        history.recordMutation({
            path: filePath,
            beforeContent: 'original content',
            afterContent: 'new content',
            source: 'test',
        });
        // Simulate the agent having written new content.
        yield fs.writeFile(filePath, 'new content', 'utf8');
        const nvim = makeNvimStub();
        yield history.revertAll(nvim);
        const restored = yield fs.readFile(filePath, 'utf8');
        expect(restored).toBe('original content');
    }));
    it('revertAll deletes a file the agent created (no original)', () => __awaiter(void 0, void 0, void 0, function* () {
        const filePath = path.join(tmpDir, 'new-file.txt');
        yield fs.writeFile(filePath, 'agent created this', 'utf8');
        const history = (0, agentHistory_1.createAgentHistory)(tmpDir);
        history.recordMutation({
            path: filePath,
            beforeContent: null, // did not exist originally
            afterContent: 'agent created this',
            source: 'test',
        });
        const nvim = makeNvimStub();
        yield history.revertAll(nvim);
        yield expect(fs.access(filePath)).rejects.toThrow();
    }));
    it('revertAll re-creates a file the agent deleted (after=null)', () => __awaiter(void 0, void 0, void 0, function* () {
        const filePath = path.join(tmpDir, 'deleted.txt');
        const originalContent = 'I was deleted';
        yield fs.writeFile(filePath, originalContent, 'utf8');
        const history = (0, agentHistory_1.createAgentHistory)(tmpDir);
        history.recordMutation({
            path: filePath,
            beforeContent: originalContent,
            afterContent: null, // agent deleted it
            source: 'test',
        });
        // Simulate the deletion.
        yield fs.rm(filePath, { force: true });
        const nvim = makeNvimStub();
        yield history.revertAll(nvim);
        const restored = yield fs.readFile(filePath, 'utf8');
        expect(restored).toBe(originalContent);
    }));
    it('bashSnapshotBefore + mutation + bashSnapshotAfter records the right paths and contents', () => __awaiter(void 0, void 0, void 0, function* () {
        const filePath = path.join(tmpDir, 'tracked.txt');
        // Commit this file so git tracks it
        yield fs.writeFile(filePath, 'committed content', 'utf8');
        yield (0, bashHelper_1.execCommand)(`git -C '${tmpDir}' add tracked.txt`);
        yield (0, bashHelper_1.execCommand)(`git -C '${tmpDir}' commit -m 'add tracked'`);
        const history = (0, agentHistory_1.createAgentHistory)(tmpDir);
        const before = yield history.bashSnapshotBefore();
        // Simulate bash mutating the file
        yield fs.writeFile(filePath, 'bash mutated this', 'utf8');
        yield history.bashSnapshotAfter(before);
        const changed = history.listChangedPaths();
        expect(changed).toContain(filePath);
        // After revert the file should go back to committed content
        const nvim = makeNvimStub();
        yield history.revertAll(nvim);
        const restored = yield fs.readFile(filePath, 'utf8');
        expect(restored).toBe('committed content');
    }));
    it('skips binary file content (records path but afterContent is null)', () => __awaiter(void 0, void 0, void 0, function* () {
        const filePath = path.join(tmpDir, 'binary.bin');
        // Create a file with a NUL byte within the first 8 KB
        const buf = Buffer.alloc(100);
        buf[42] = 0; // NUL byte → binary heuristic
        yield fs.writeFile(filePath, buf);
        // Add + commit so git knows about it
        yield (0, bashHelper_1.execCommand)(`git -C '${tmpDir}' add binary.bin`);
        yield (0, bashHelper_1.execCommand)(`git -C '${tmpDir}' commit -m 'add binary'`);
        const history = (0, agentHistory_1.createAgentHistory)(tmpDir);
        const before = yield history.bashSnapshotBefore();
        // Modify the binary file post-snapshot
        const buf2 = Buffer.alloc(100);
        buf2[42] = 0;
        buf2[0] = 0xff;
        yield fs.writeFile(filePath, buf2);
        yield history.bashSnapshotAfter(before);
        const changed = history.listChangedPaths();
        // Path should be tracked
        expect(changed).toContain(filePath);
        // But afterContent should be null (binary)
        // We verify indirectly: revertAll tries to restore. Since the original
        // content was binary (git show HEAD:binary.bin) and isBinaryBuffer would
        // return null for afterContent, the original content from git should be used.
        // The key assertion is that the path was captured:
        expect(changed.length).toBeGreaterThan(0);
    }));
});
