"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const agentUi_1 = require("@/AI/AIAgent/shared/utils/agentUi");
describe('agentUi helpers', () => {
    it('formats the submitted prompt body without any header', () => {
        expect((0, agentUi_1.formatSubmittedAgentPrompt)('  Tell me something interesting.  ')).toBe('Tell me something interesting.\n');
        expect((0, agentUi_1.formatSubmittedAgentPrompt)('   ')).toBe('');
    });
    it('formats confirm-task-complete questions and answers', () => {
        expect((0, agentUi_1.formatConfirmQuestion)('Continue?', ['Yes', 'No'])).toBe('\n\n---\n**💬 Continue?**\n\n- Yes\n- No\n\n');
        const answer = (0, agentUi_1.formatConfirmAnswer)('Yes');
        expect(answer).toContain('## 👤 USER PROMPT · ');
        expect(answer.endsWith('Yes\n\n')).toBe(true);
    });
    it('creates short tool call summaries', () => {
        expect((0, agentUi_1.summarizeToolCall)('web_search', { query: 'octopus fun fact site:nationalgeographic.com' })).toBe('web_search: octopus fun fact site:nationalgeographic.com');
    });
    it('formats MCP-backed tool names clearly', () => {
        expect((0, agentUi_1.formatToolDisplayName)('bash', 'functions', 'bash')).toBe('functions:bash');
        expect((0, agentUi_1.formatToolDisplayName)('edit')).toBe('edit');
    });
    it('renders tool arguments as readable JSON', () => {
        expect((0, agentUi_1.formatToolArguments)({ command: 'npm test', initial_wait: 180 })).toBe('{\n  "command": "npm test",\n  "initial_wait": 180\n}');
    });
    it('prefers detailed tool completion output and failure messages', () => {
        expect((0, agentUi_1.formatToolCompletion)(true, {
            content: 'short',
            detailedContent: 'detailed output',
        })).toBe('detailed output');
        expect((0, agentUi_1.formatToolCompletion)(false, undefined, new Error('tool exploded'))).toBe('tool exploded');
    });
});
