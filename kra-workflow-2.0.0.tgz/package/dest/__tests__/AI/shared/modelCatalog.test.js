"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = __importStar(require("fs"));
const os = __importStar(require("os"));
const path = __importStar(require("path"));
jest.mock('os', () => {
    const actual = jest.requireActual('os');
    return Object.assign(Object.assign({}, actual), { homedir: jest.fn(actual.homedir) });
});
const modelCatalog_1 = require("@/AI/shared/data/modelCatalog");
describe('modelCatalog', () => {
    const realFetch = global.fetch;
    const realHome = process.env['HOME'];
    let tmpHome;
    beforeEach(() => {
        tmpHome = fs.mkdtempSync(path.join(os.tmpdir(), 'model-catalog-test-'));
        os.homedir.mockReturnValue(tmpHome);
    });
    afterEach(() => {
        if (realHome === undefined) {
            delete process.env['HOME'];
        }
        else {
            process.env['HOME'] = realHome;
        }
        global.fetch = realFetch;
        fs.rmSync(tmpHome, { recursive: true, force: true });
    });
    function mockFetchOnceJson(json) {
        const mock = jest.fn().mockResolvedValue({
            ok: true,
            status: 200,
            json: () => __awaiter(this, void 0, void 0, function* () { return json; }),
        });
        global.fetch = mock;
        return mock;
    }
    function mockFetchReject(err) {
        const mock = jest.fn().mockRejectedValue(err);
        global.fetch = mock;
        return mock;
    }
    describe('open-router live fetch', () => {
        it('parses pricing ($/token → $/M) and context length', () => __awaiter(void 0, void 0, void 0, function* () {
            var _a, _b, _c;
            const fetchMock = mockFetchOnceJson({
                data: [
                    {
                        id: 'openai/gpt-4o',
                        name: 'GPT-4o',
                        context_length: 128000,
                        pricing: { prompt: '0.0000025', completion: '0.00001', input_cache_read: '0.00000125' },
                    },
                ],
            });
            const models = yield (0, modelCatalog_1.getModelCatalog)('open-router', { forceRefresh: true });
            expect(fetchMock).toHaveBeenCalledWith('https://openrouter.ai/api/v1/models');
            expect(models).toHaveLength(1);
            const m = models[0];
            expect(m.id).toBe('openai/gpt-4o');
            expect(m.label).toBe('GPT-4o');
            expect(m.contextWindow).toBe(128000);
            expect((_a = m.pricing) === null || _a === void 0 ? void 0 : _a.inputPerM).toBeCloseTo(2.5, 4);
            expect((_b = m.pricing) === null || _b === void 0 ? void 0 : _b.outputPerM).toBeCloseTo(10, 4);
            expect((_c = m.pricing) === null || _c === void 0 ? void 0 : _c.cachedInputPerM).toBeCloseTo(1.25, 4);
        }));
        it('writes results to disk cache', () => __awaiter(void 0, void 0, void 0, function* () {
            mockFetchOnceJson({
                data: [{ id: 'a/b', name: 'A/B', context_length: 1000, pricing: { prompt: '0.000001', completion: '0.000002' } }],
            });
            yield (0, modelCatalog_1.getModelCatalog)('open-router', { forceRefresh: true });
            const cacheFile = path.join(tmpHome, '.kra', 'model-catalog', 'open-router.json');
            expect(fs.existsSync(cacheFile)).toBe(true);
            const parsed = JSON.parse(fs.readFileSync(cacheFile, 'utf8'));
            expect(parsed.models).toHaveLength(1);
            expect(parsed.models[0].id).toBe('a/b');
            expect(typeof parsed.fetchedAt).toBe('number');
        }));
    });
    describe('cache behavior', () => {
        it('returns fresh cache without calling fetch', () => __awaiter(void 0, void 0, void 0, function* () {
            mockFetchOnceJson({ data: [{ id: 'first/model', name: 'first', context_length: 100, pricing: { prompt: '0', completion: '0' } }] });
            yield (0, modelCatalog_1.getModelCatalog)('open-router', { forceRefresh: true });
            const fetchMock = mockFetchOnceJson({ data: [] });
            const models = yield (0, modelCatalog_1.getModelCatalog)('open-router');
            expect(fetchMock).not.toHaveBeenCalled();
            expect(models[0].id).toBe('first/model');
        }));
        it('forceRefresh bypasses fresh cache', () => __awaiter(void 0, void 0, void 0, function* () {
            mockFetchOnceJson({ data: [{ id: 'old/model', name: 'old', context_length: 100, pricing: { prompt: '0', completion: '0' } }] });
            yield (0, modelCatalog_1.getModelCatalog)('open-router', { forceRefresh: true });
            const fetchMock = mockFetchOnceJson({ data: [{ id: 'new/model', name: 'new', context_length: 100, pricing: { prompt: '0', completion: '0' } }] });
            const models = yield (0, modelCatalog_1.getModelCatalog)('open-router', { forceRefresh: true });
            expect(fetchMock).toHaveBeenCalled();
            expect(models[0].id).toBe('new/model');
        }));
    });
    describe('fallback chain', () => {
        it('falls back to stale cache when live fetch fails', () => __awaiter(void 0, void 0, void 0, function* () {
            mockFetchOnceJson({ data: [{ id: 'cached/model', name: 'cached', context_length: 100, pricing: { prompt: '0', completion: '0' } }] });
            yield (0, modelCatalog_1.getModelCatalog)('open-router', { forceRefresh: true });
            mockFetchReject(new Error('network down'));
            const models = yield (0, modelCatalog_1.getModelCatalog)('open-router', { forceRefresh: true });
            expect(models[0].id).toBe('cached/model');
        }));
        it('falls back to STATIC_FALLBACK_MODELS when live fails and no cache exists', () => __awaiter(void 0, void 0, void 0, function* () {
            mockFetchReject(new Error('network down'));
            const models = yield (0, modelCatalog_1.getModelCatalog)('open-router', { forceRefresh: true });
            expect(models.length).toBeGreaterThan(0);
            expect(models.some((m) => m.id === 'openai/gpt-4o-mini')).toBe(true);
        }));
        it('falls back to static when fetch returns empty list', () => __awaiter(void 0, void 0, void 0, function* () {
            mockFetchOnceJson({ data: [] });
            const models = yield (0, modelCatalog_1.getModelCatalog)('open-router', { forceRefresh: true });
            expect(models.length).toBeGreaterThan(0);
        }));
    });
    describe('deep-infra live fetch', () => {
        it('filters to text-generation and converts cents/token → $/M', () => __awaiter(void 0, void 0, void 0, function* () {
            var _a, _b;
            mockFetchOnceJson([
                {
                    model_name: 'meta-llama/Llama-3-70B',
                    type: 'text-generation',
                    max_tokens: 8192,
                    pricing: { cents_per_input_token: 0.00006, cents_per_output_token: 0.00009 },
                },
                { model_name: 'should-skip', type: 'embedding' },
            ]);
            const models = yield (0, modelCatalog_1.getModelCatalog)('deep-infra', { forceRefresh: true });
            expect(models).toHaveLength(1);
            const m = models[0];
            expect(m.id).toBe('meta-llama/Llama-3-70B');
            expect(m.contextWindow).toBe(8192);
            expect((_a = m.pricing) === null || _a === void 0 ? void 0 : _a.inputPerM).toBeCloseTo(0.6, 4);
            expect((_b = m.pricing) === null || _b === void 0 ? void 0 : _b.outputPerM).toBeCloseTo(0.9, 4);
        }));
    });
    describe('formatModelInfoForPicker', () => {
        it('renders ctx + pricing with cached input', () => {
            const out = (0, modelCatalog_1.formatModelInfoForPicker)({
                id: 'x/y',
                label: 'x/y',
                contextWindow: 128000,
                pricing: { inputPerM: 0.5, outputPerM: 1.5, cachedInputPerM: 0.1 },
            });
            expect(out).toContain('x/y');
            expect(out).toContain('128k ctx');
            expect(out).toContain('$0.50/$1.50');
            expect(out).toContain('cached $0.10');
        });
        it('renders placeholders when ctx and pricing missing', () => {
            const out = (0, modelCatalog_1.formatModelInfoForPicker)({ id: 'a', label: 'a', contextWindow: 0 });
            expect(out).toContain('? ctx');
            expect(out).toContain('? pricing');
        });
    });
});
