"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const fileContexts_1 = require("@/AI/shared/utils/conversationUtils/fileContexts");
const promises_1 = __importDefault(require("fs/promises"));
jest.mock('fs/promises');
jest.mock('@/AI/shared/data/filetypes', () => ({
    fileTypes: {
        ts: 'typescript',
        js: 'javascript',
        txt: 'text'
    }
}));
const mockNvimClient = {
    command: jest.fn(),
    channelId: Promise.resolve(1),
    on: jest.fn(),
    removeListener: jest.fn(),
    executeLua: jest.fn(),
    setVar: jest.fn(),
    getVar: jest.fn(),
    call: jest.fn()
};
describe('fileContexts', () => {
    const testFilePath = '/test/file.ts';
    const testFileContent = 'console.log("test");\nconst x = 1;\n';
    beforeEach(() => {
        fileContexts_1.fileContexts.length = 0;
        jest.clearAllMocks();
        promises_1.default.readFile.mockResolvedValue(testFileContent);
    });
    describe('clearFileContexts', () => {
        it('should clear all file contexts', () => {
            fileContexts_1.fileContexts.push({ filePath: testFilePath, isPartial: false });
            expect(fileContexts_1.fileContexts).toHaveLength(1);
            (0, fileContexts_1.clearFileContexts)();
            expect(fileContexts_1.fileContexts).toHaveLength(0);
        });
    });
    describe('clearAllFileContexts', () => {
        it('should clear all file contexts and show count', () => __awaiter(void 0, void 0, void 0, function* () {
            fileContexts_1.fileContexts.push({ filePath: testFilePath, isPartial: false });
            expect(fileContexts_1.fileContexts).toHaveLength(1);
            yield (0, fileContexts_1.clearAllFileContexts)(mockNvimClient);
            expect(fileContexts_1.fileContexts).toHaveLength(0);
            expect(mockNvimClient.command).toHaveBeenCalledWith('echohl MoreMsg | echo "Cleared 1 file context(s)" | echohl None');
        }));
    });
    describe('showFileContexts', () => {
        it('should show warning when no contexts exist', () => __awaiter(void 0, void 0, void 0, function* () {
            yield (0, fileContexts_1.showFileContexts)(mockNvimClient);
            expect(mockNvimClient.command).toHaveBeenCalledWith('echohl WarningMsg | echo "No file contexts currently loaded" | echohl None');
        }));
        it('should show full file context', () => __awaiter(void 0, void 0, void 0, function* () {
            fileContexts_1.fileContexts.push({
                filePath: testFilePath,
                isPartial: false
            });
            yield (0, fileContexts_1.showFileContexts)(mockNvimClient);
            expect(mockNvimClient.command).toHaveBeenCalledWith(expect.stringContaining('Loaded contexts: file.ts (full file)'));
        }));
        it('should show partial file context', () => __awaiter(void 0, void 0, void 0, function* () {
            fileContexts_1.fileContexts.push({
                filePath: testFilePath,
                isPartial: true,
                startLine: 1,
                endLine: 3
            });
            yield (0, fileContexts_1.showFileContexts)(mockNvimClient);
            expect(mockNvimClient.command).toHaveBeenCalledWith(expect.stringContaining('Loaded contexts: file.ts (lines 1-3)'));
        }));
    });
    describe('getFileExtension', () => {
        it('should return correct extension for known file types', () => {
            expect((0, fileContexts_1.getFileExtension)('file.ts')).toBe('typescript');
            expect((0, fileContexts_1.getFileExtension)('file.js')).toBe('javascript');
        });
        it('should return file extension for unknown types', () => {
            expect((0, fileContexts_1.getFileExtension)('file.unknown')).toBe('unknown');
        });
        it('should return text for files without extension', () => {
            expect((0, fileContexts_1.getFileExtension)('README')).toBe('text');
        });
    });
    describe('getFileContextsForPrompt', () => {
        it('should return empty string when no contexts exist', () => __awaiter(void 0, void 0, void 0, function* () {
            const result = yield (0, fileContexts_1.getFileContextsForPrompt)();
            expect(result).toBe('');
        }));
        it('should generate context string for full file contexts', () => __awaiter(void 0, void 0, void 0, function* () {
            fileContexts_1.fileContexts.push({
                filePath: testFilePath,
                isPartial: false
            });
            const result = yield (0, fileContexts_1.getFileContextsForPrompt)();
            expect(result).toContain('--- FILE CONTEXTS ---');
            expect(result).toContain('The following files have been provided as context for this conversation');
            expect(result).toContain(testFilePath);
            expect(result).toContain(testFileContent);
        }));
        it('should handle file read errors gracefully', () => __awaiter(void 0, void 0, void 0, function* () {
            promises_1.default.readFile.mockRejectedValue(new Error('File not found'));
            fileContexts_1.fileContexts.push({
                filePath: testFilePath,
                isPartial: false
            });
            const result = yield (0, fileContexts_1.getFileContextsForPrompt)();
            expect(result).toContain('Error: Could not load file');
        }));
        it('should skip partial file contexts', () => __awaiter(void 0, void 0, void 0, function* () {
            fileContexts_1.fileContexts.push({
                filePath: testFilePath,
                isPartial: true,
                startLine: 1,
                endLine: 2
            });
            const result = yield (0, fileContexts_1.getFileContextsForPrompt)();
            expect(result).toBe('\n\n--- FILE CONTEXTS ---\nThe following files have been provided as context for this conversation:\n\n');
        }));
    });
    describe('rebuildFileContextsFromChat', () => {
        it('should rebuild full file contexts from chat content', () => __awaiter(void 0, void 0, void 0, function* () {
            const chatContent = `Some chat content
📁 file.ts (544 lines, 23KB)
\`\`\`typescript
// Full file content loaded: /test/file.ts
// Use this file context in your responses
// File contains 544 lines of typescript code
\`\`\``;
            promises_1.default.readFile.mockResolvedValue(chatContent);
            yield (0, fileContexts_1.rebuildFileContextsFromChat)('/test/chat.md');
            expect(fileContexts_1.fileContexts).toHaveLength(1);
            expect(fileContexts_1.fileContexts[0]).toEqual({
                filePath: '/test/file.ts',
                isPartial: false,
                summary: 'Full file:  file.ts'
            });
        }));
        it('should rebuild partial file contexts from chat content', () => __awaiter(void 0, void 0, void 0, function* () {
            const chatContent = `📁 file.ts (lines 1-3)
\`\`\`typescript
// Selected from: /test/file.ts (lines 1-3)
console.log("test");
\`\`\``;
            promises_1.default.readFile.mockResolvedValue(chatContent);
            yield (0, fileContexts_1.rebuildFileContextsFromChat)('/test/chat.md');
            expect(fileContexts_1.fileContexts).toHaveLength(1);
            expect(fileContexts_1.fileContexts[0]).toEqual({
                filePath: '/test/file.ts',
                isPartial: true,
                startLine: 1,
                endLine: 3,
                summary: 'Partial file:  file.ts'
            });
        }));
        it('should handle single line selections', () => __awaiter(void 0, void 0, void 0, function* () {
            const chatContent = `📁 file.ts (line 5)
\`\`\`typescript
// Selected from: /test/file.ts (line 5)
const x = 1;
\`\`\``;
            promises_1.default.readFile.mockResolvedValue(chatContent);
            yield (0, fileContexts_1.rebuildFileContextsFromChat)('/test/chat.md');
            expect(fileContexts_1.fileContexts).toHaveLength(1);
            expect(fileContexts_1.fileContexts[0]).toEqual({
                filePath: '/test/file.ts',
                isPartial: true,
                startLine: 5,
                endLine: 5,
                summary: 'Partial file:  file.ts'
            });
        }));
        it('should handle file read errors', () => __awaiter(void 0, void 0, void 0, function* () {
            promises_1.default.readFile.mockRejectedValue(new Error('File not found'));
            yield expect((0, fileContexts_1.rebuildFileContextsFromChat)('/test/chat.md')).resolves.not.toThrow();
            expect(fileContexts_1.fileContexts).toHaveLength(0);
        }));
        it('should handle empty chat file', () => __awaiter(void 0, void 0, void 0, function* () {
            promises_1.default.readFile.mockResolvedValue('');
            yield (0, fileContexts_1.rebuildFileContextsFromChat)('/test/chat.md');
            expect(fileContexts_1.fileContexts).toHaveLength(0);
        }));
    });
    describe('showFileContextsPopup', () => {
        it('should show warning when no contexts exist', () => __awaiter(void 0, void 0, void 0, function* () {
            yield (0, fileContexts_1.showFileContextsPopup)(mockNvimClient);
            expect(mockNvimClient.command).toHaveBeenCalledWith(expect.stringContaining('No file contexts currently loaded'));
        }));
        it('should show full file context in popup', () => __awaiter(void 0, void 0, void 0, function* () {
            fileContexts_1.fileContexts.push({
                filePath: testFilePath,
                isPartial: false
            });
            yield (0, fileContexts_1.showFileContextsPopup)(mockNvimClient);
            expect(mockNvimClient.executeLua).toHaveBeenCalled();
        }));
        it('should show partial file context in popup', () => __awaiter(void 0, void 0, void 0, function* () {
            fileContexts_1.fileContexts.push({
                filePath: testFilePath,
                isPartial: true,
                startLine: 1,
                endLine: 3
            });
            yield (0, fileContexts_1.showFileContextsPopup)(mockNvimClient);
            expect(mockNvimClient.executeLua).toHaveBeenCalled();
        }));
        it('should handle file read errors in popup', () => __awaiter(void 0, void 0, void 0, function* () {
            promises_1.default.readFile.mockRejectedValue(new Error('File not found'));
            fileContexts_1.fileContexts.push({
                filePath: testFilePath,
                isPartial: false
            });
            yield (0, fileContexts_1.showFileContextsPopup)(mockNvimClient);
            expect(mockNvimClient.executeLua).toHaveBeenCalled();
        }));
        it('should fallback to echo when popup fails', () => __awaiter(void 0, void 0, void 0, function* () {
            mockNvimClient.executeLua.mockRejectedValue(new Error('Popup failed'));
            fileContexts_1.fileContexts.push({
                filePath: testFilePath,
                isPartial: false
            });
            yield (0, fileContexts_1.showFileContextsPopup)(mockNvimClient);
            expect(mockNvimClient.command).toHaveBeenCalledWith(expect.stringContaining('Loaded contexts:'));
        }));
    });
});
