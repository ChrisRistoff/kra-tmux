"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const fileContexts_1 = require("@/AI/shared/utils/conversationUtils/fileContexts");
const fileContextPickers = __importStar(require("@/AI/shared/utils/conversationUtils/fileContextPickers"));
const fileContextOps = __importStar(require("@/AI/shared/utils/conversationUtils/fileContextOps"));
jest.mock('@/AI/shared/utils/conversationUtils/fileContextPickers', () => ({
    selectContextToRemove: jest.fn(),
    selectFileOrFolder: jest.fn(),
    promptShareMode: jest.fn(),
    selectFileFromFolder: jest.fn(),
}));
jest.mock('@/AI/shared/utils/conversationUtils/fileContextOps', () => ({
    addFolderContext: jest.fn(),
    addEntireFileContext: jest.fn(),
    addPartialFileContext: jest.fn(),
}));
describe('handleAddFileContext', () => {
    const mockCommand = jest.fn().mockResolvedValue(undefined);
    const mockNvimClient = {
        command: mockCommand,
    };
    const mockSelectFileOrFolder = jest.mocked(fileContextPickers.selectFileOrFolder);
    const mockPromptShareMode = jest.mocked(fileContextPickers.promptShareMode);
    const mockSelectFileFromFolder = jest.mocked(fileContextPickers.selectFileFromFolder);
    const mockAddFolderContext = jest.mocked(fileContextOps.addFolderContext);
    const mockAddEntireFileContext = jest.mocked(fileContextOps.addEntireFileContext);
    const mockAddPartialFileContext = jest.mocked(fileContextOps.addPartialFileContext);
    beforeEach(() => {
        jest.clearAllMocks();
        mockCommand.mockResolvedValue(undefined);
    });
    it('adds every selected file when entire mode is chosen', () => __awaiter(void 0, void 0, void 0, function* () {
        mockSelectFileOrFolder.mockResolvedValue([
            { path: '/repo/src/one.ts', isDir: false },
            { path: '/repo/src/two.ts', isDir: false },
        ]);
        mockPromptShareMode.mockResolvedValue('entire');
        yield (0, fileContexts_1.handleAddFileContext)(mockNvimClient, '/tmp/chat.md');
        expect(mockAddEntireFileContext).toHaveBeenNthCalledWith(1, mockNvimClient, '/tmp/chat.md', '/repo/src/one.ts', undefined);
        expect(mockAddEntireFileContext).toHaveBeenNthCalledWith(2, mockNvimClient, '/tmp/chat.md', '/repo/src/two.ts', undefined);
        expect(mockAddPartialFileContext).not.toHaveBeenCalled();
        expect(mockAddFolderContext).not.toHaveBeenCalled();
    }));
    it('adds every selected folder file and standalone file in snippet mode', () => __awaiter(void 0, void 0, void 0, function* () {
        mockSelectFileOrFolder.mockResolvedValue([
            { path: '/repo/src/components', isDir: true },
            { path: '/repo/src/app.ts', isDir: false },
        ]);
        mockPromptShareMode.mockResolvedValue('snippet');
        mockSelectFileFromFolder.mockResolvedValue([
            '/repo/src/components/Button.tsx',
            '/repo/src/components/Card.tsx',
        ]);
        yield (0, fileContexts_1.handleAddFileContext)(mockNvimClient, '/tmp/chat.md', { agentMode: true });
        expect(mockSelectFileFromFolder).toHaveBeenCalledWith(mockNvimClient, '/repo/src/components');
        expect(mockAddPartialFileContext).toHaveBeenNthCalledWith(1, mockNvimClient, '/tmp/chat.md', '/repo/src/components/Button.tsx', true);
        expect(mockAddPartialFileContext).toHaveBeenNthCalledWith(2, mockNvimClient, '/tmp/chat.md', '/repo/src/components/Card.tsx', true);
        expect(mockAddPartialFileContext).toHaveBeenNthCalledWith(3, mockNvimClient, '/tmp/chat.md', '/repo/src/app.ts', true);
        expect(mockAddEntireFileContext).not.toHaveBeenCalled();
    }));
});
