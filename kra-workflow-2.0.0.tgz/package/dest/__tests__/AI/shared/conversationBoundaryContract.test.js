"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const conversation = __importStar(require("@/AI/shared/conversation"));
describe('shared conversation boundary contract', () => {
    it('exposes AI Neovim helper capabilities used by chat and agent flows', () => {
        expect(typeof conversation.generateSocketPath).toBe('function');
        expect(typeof conversation.waitForSocket).toBe('function');
        expect(typeof conversation.addNeovimFunctions).toBe('function');
        expect(typeof conversation.addCommands).toBe('function');
        expect(typeof conversation.setupKeyBindings).toBe('function');
        expect(typeof conversation.updateNvimAndGoToLastLine).toBe('function');
    });
    it('exposes file-context lifecycle APIs through one stable import path', () => {
        expect(Array.isArray(conversation.fileContexts)).toBe(true);
        expect(typeof conversation.handleAddFileContext).toBe('function');
        expect(typeof conversation.showFileContextsPopup).toBe('function');
        expect(typeof conversation.handleRemoveFileContext).toBe('function');
        expect(typeof conversation.clearAllFileContexts).toBe('function');
        expect(typeof conversation.clearFileContexts).toBe('function');
        expect(typeof conversation.getFileContextsForPrompt).toBe('function');
        expect(typeof conversation.getFileExtension).toBe('function');
    });
    it('keeps shared file-context state accessible and resettable via boundary', () => {
        conversation.fileContexts.push({ filePath: '/tmp/a.ts', isPartial: false, summary: 'Full file: a.ts' });
        expect(conversation.fileContexts).toHaveLength(1);
        conversation.clearFileContexts();
        expect(conversation.fileContexts).toHaveLength(0);
    });
});
