"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const aiNeovimHelper_1 = require("@/AI/shared/utils/conversationUtils/aiNeovimHelper");
const os_1 = __importDefault(require("os"));
const fs = __importStar(require("fs/promises"));
// Mock modules
jest.mock('os');
jest.mock('fs/promises');
// Mock StreamController
const mockStreamController = {
    isAborted: false,
    abort: jest.fn()
};
// Mock NeovimClient
const mockNvim = {
    command: jest.fn(),
    executeLua: jest.fn(),
};
const mockedOs = jest.mocked(os_1.default);
const mockedFs = jest.mocked(fs);
describe('nvim-utils', () => {
    beforeEach(() => {
        jest.clearAllMocks();
        mockStreamController.isAborted = false;
    });
    describe('handleStopStream', () => {
        it('should abort active stream and show stopped message', () => __awaiter(void 0, void 0, void 0, function* () {
            yield (0, aiNeovimHelper_1.handleStopStream)(mockStreamController, mockNvim);
            expect(mockStreamController.abort).toHaveBeenCalled();
            expect(mockNvim.command).toHaveBeenCalledWith('echohl WarningMsg | echo "Generation stopped" | echohl None');
        }));
        it('should show no active generation message when stream is already aborted', () => __awaiter(void 0, void 0, void 0, function* () {
            mockStreamController.isAborted = true;
            yield (0, aiNeovimHelper_1.handleStopStream)(mockStreamController, mockNvim);
            expect(mockStreamController.abort).not.toHaveBeenCalled();
            expect(mockNvim.command).toHaveBeenCalledWith('echohl WarningMsg | echo "No active generation to stop" | echohl None');
        }));
        it('should show no active generation message when no stream controller', () => __awaiter(void 0, void 0, void 0, function* () {
            yield (0, aiNeovimHelper_1.handleStopStream)(null, mockNvim);
            expect(mockNvim.command).toHaveBeenCalledWith('echohl WarningMsg | echo "No active generation to stop" | echohl None');
        }));
    });
    describe('generateSocketPath', () => {
        it('should generate socket path with random string', () => __awaiter(void 0, void 0, void 0, function* () {
            const mockTmpDir = '/tmp';
            mockedOs.tmpdir.mockReturnValue(mockTmpDir);
            const socketPath = yield (0, aiNeovimHelper_1.generateSocketPath)();
            expect(socketPath).toMatch(/^\/tmp\/nvim-[a-z0-9]+\.sock$/);
            expect(os_1.default.tmpdir).toHaveBeenCalled();
        }));
        describe('waitForSocket', () => {
            beforeEach(() => {
                jest.useFakeTimers();
            });
            afterEach(() => {
                jest.useRealTimers();
            });
            it('should return true when socket exists', () => __awaiter(void 0, void 0, void 0, function* () {
                mockedFs.access.mockResolvedValue(undefined);
                const promise = (0, aiNeovimHelper_1.waitForSocket)('/test/socket', 1000);
                const result = yield promise;
                expect(result).toBe(true);
                expect(mockedFs.access).toHaveBeenCalledWith('/test/socket');
            }));
        });
        describe('addNeovimFunctions', () => {
            it('should add all required VimL functions', () => __awaiter(void 0, void 0, void 0, function* () {
                const channelId = 123;
                yield (0, aiNeovimHelper_1.addNeovimFunctions)(mockNvim, channelId);
                expect(mockNvim.command).toHaveBeenCalledTimes(6);
                expect(mockNvim.command).toHaveBeenCalledWith(expect.stringContaining('SaveAndSubmit()'));
                expect(mockNvim.command).toHaveBeenCalledWith(expect.stringContaining('g:kra_chat_prompt_buf'));
                expect(mockNvim.command).toHaveBeenCalledWith(expect.stringContaining('AddFileContext()'));
                expect(mockNvim.command).toHaveBeenCalledWith(expect.stringContaining('StopStream()'));
                expect(mockNvim.command).toHaveBeenCalledWith(expect.stringContaining('ShowFileContextsPopup()'));
                expect(mockNvim.command).toHaveBeenCalledWith(expect.stringContaining('RemoveFileContext()'));
                expect(mockNvim.command).toHaveBeenCalledWith(expect.stringContaining('ClearContexts()'));
                // Verify channel ID is properly interpolated
                expect(mockNvim.command).toHaveBeenCalledWith(expect.stringContaining(`rpcnotify(${channelId}`));
            }));
        });
        describe('addCommands', () => {
            it('should add all required commands', () => __awaiter(void 0, void 0, void 0, function* () {
                yield (0, aiNeovimHelper_1.addCommands)(mockNvim);
                expect(mockNvim.command).toHaveBeenCalledTimes(5);
                expect(mockNvim.command).toHaveBeenCalledWith('command! -nargs=0 SubmitPrompt call SaveAndSubmit()');
                expect(mockNvim.command).toHaveBeenCalledWith('command! -nargs=0 AddFile call AddFileContext()');
                expect(mockNvim.command).toHaveBeenCalledWith('command! -nargs=0 StopGeneration call StopStream()');
                expect(mockNvim.command).toHaveBeenCalledWith('command! -nargs=0 ClearContexts call ClearContexts()');
                expect(mockNvim.command).toHaveBeenCalledWith('command! -nargs=0 RemoveFileContext call RemoveFileContext()');
            }));
        });
        describe('setupKeyBindings', () => {
            it('should set up all key bindings', () => __awaiter(void 0, void 0, void 0, function* () {
                yield (0, aiNeovimHelper_1.setupKeyBindings)(mockNvim);
                expect(mockNvim.executeLua).toHaveBeenCalledTimes(1);
                expect(mockNvim.executeLua).toHaveBeenCalledWith(expect.stringContaining("map('n', '<CR>'"), []);
            }));
        });
        describe('chat split layout helpers', () => {
            it('should delegate chat prompt layout operations to the Lua module', () => __awaiter(void 0, void 0, void 0, function* () {
                const executeLuaMock = mockNvim.executeLua;
                executeLuaMock
                    .mockResolvedValueOnce(undefined)
                    .mockResolvedValueOnce('Prompt text')
                    .mockResolvedValueOnce(undefined)
                    .mockResolvedValueOnce(undefined)
                    .mockResolvedValueOnce(undefined);
                yield (0, aiNeovimHelper_1.setupChatSplitLayout)(mockNvim, 123);
                expect(mockNvim.executeLua).toHaveBeenNthCalledWith(1, `require('kra_chat_layout').setup(...)`, [123]);
                const prompt = yield (0, aiNeovimHelper_1.getChatPromptText)(mockNvim);
                expect(prompt).toBe('Prompt text');
                expect(mockNvim.executeLua).toHaveBeenNthCalledWith(2, `return require('kra_chat_layout').get_prompt_text()`, []);
                yield (0, aiNeovimHelper_1.clearChatPrompt)(mockNvim);
                expect(mockNvim.executeLua).toHaveBeenNthCalledWith(3, `require('kra_chat_layout').clear_prompt()`, []);
                yield (0, aiNeovimHelper_1.focusChatPrompt)(mockNvim);
                expect(mockNvim.executeLua).toHaveBeenNthCalledWith(4, `require('kra_chat_layout').focus_prompt()`, []);
                yield (0, aiNeovimHelper_1.refreshChatLayout)(mockNvim);
                expect(mockNvim.executeLua).toHaveBeenNthCalledWith(5, `require('kra_chat_layout').refresh()`, []);
            }));
            it('should return an empty string when the prompt text is not a string', () => __awaiter(void 0, void 0, void 0, function* () {
                mockNvim.executeLua.mockResolvedValueOnce(123);
                yield expect((0, aiNeovimHelper_1.getChatPromptText)(mockNvim)).resolves.toBe('');
            }));
        });
        describe('updateNvimAndGoToLastLine', () => {
            it('should refresh buffer, go to last line, and create new line', () => __awaiter(void 0, void 0, void 0, function* () {
                yield (0, aiNeovimHelper_1.updateNvimAndGoToLastLine)(mockNvim);
                expect(mockNvim.command).toHaveBeenCalledTimes(3);
                expect(mockNvim.command).toHaveBeenNthCalledWith(1, 'edit!');
                expect(mockNvim.command).toHaveBeenNthCalledWith(2, 'normal! G');
                expect(mockNvim.command).toHaveBeenNthCalledWith(3, 'normal! o');
            }));
        });
    });
});
