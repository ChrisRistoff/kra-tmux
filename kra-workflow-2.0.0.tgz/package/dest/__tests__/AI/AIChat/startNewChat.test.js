"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const startNewChat_1 = require("@/AI/AIChat/commands/startNewChat");
const conversation = __importStar(require("@/AI/AIChat/main/conversation"));
const utils = __importStar(require("@/AI/AIChat/utils/aiUtils"));
const ui = __importStar(require("@/UI/generalUI"));
const roles_1 = require("@/AI/shared/data/roles");
jest.mock('@/AI/AIChat/main/conversation');
jest.mock('@/UI/generalUI');
jest.mock('@/AI/AIChat/utils/aiUtils');
describe('startNewChat', () => {
    const fixedTimestamp = 1000;
    const chatFile = `/tmp/ai-chat-${fixedTimestamp}.md`;
    const roleSelection = 'userRole';
    const provider = 'dummyProvider';
    const model = 'dummyModel';
    const temperature = 0.7;
    beforeEach(() => {
        jest.clearAllMocks();
        jest.spyOn(Date, 'now').mockReturnValue(fixedTimestamp);
        ui.searchSelectAndReturnFromArray.mockResolvedValue(roleSelection);
        utils.pickProviderAndModel.mockResolvedValue({ provider, model });
        utils.promptUserForTemperature.mockResolvedValue(temperature);
        conversation.converse.mockResolvedValue(undefined);
    });
    afterEach(() => {
        jest.restoreAllMocks();
    });
    it('should start a new chat successfully', () => __awaiter(void 0, void 0, void 0, function* () {
        yield (0, startNewChat_1.startNewChat)();
        // ui.searchSelectAndReturnFromArray was called with the expected parameters.
        expect(ui.searchSelectAndReturnFromArray).toHaveBeenCalledWith({
            itemsArray: Object.keys(roles_1.aiRoles),
            prompt: 'Select a role from the list: '
        });
        // provider and model have been picked
        expect(utils.pickProviderAndModel).toHaveBeenCalled();
        // temperature was prompted
        expect(utils.promptUserForTemperature).toHaveBeenCalledWith(model);
        // conversation is started with the proper arguments
        expect(conversation.converse).toHaveBeenCalledWith(chatFile, temperature, roleSelection, provider, model);
    }));
    it('should throw error and log error if an error occurs', () => __awaiter(void 0, void 0, void 0, function* () {
        const testError = new Error('Test Error');
        conversation.converse.mockRejectedValue(testError);
        const consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation(() => { return; });
        yield expect((0, startNewChat_1.startNewChat)()).rejects.toThrow('Test Error');
        consoleErrorSpy.mockRestore();
    }));
});
