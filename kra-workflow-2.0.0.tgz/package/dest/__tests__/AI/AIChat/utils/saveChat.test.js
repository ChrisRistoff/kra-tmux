"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __await = (this && this.__await) || function (v) { return this instanceof __await ? (this.v = v, this) : new __await(v); }
var __asyncGenerator = (this && this.__asyncGenerator) || function (thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = Object.create((typeof AsyncIterator === "function" ? AsyncIterator : Object).prototype), verb("next"), verb("throw"), verb("return", awaitReturn), i[Symbol.asyncIterator] = function () { return this; }, i;
    function awaitReturn(f) { return function (v) { return Promise.resolve(v).then(f, reject); }; }
    function verb(n, f) { if (g[n]) { i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; if (f) i[n] = f(i[n]); } }
    function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
    function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
    function fulfill(value) { resume("next", value); }
    function reject(value) { resume("throw", value); }
    function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = __importStar(require("fs/promises"));
const bash = __importStar(require("@/utils/bashHelper"));
const nvim = __importStar(require("@/utils/neovimHelper"));
const ui = __importStar(require("@/UI/generalUI"));
const saveChat_1 = require("@/AI/AIChat/utils/saveChat");
const promptModel_1 = require("@/AI/AIChat/utils/promptModel");
const filePaths_1 = require("@/filePaths");
const aiTypes_1 = require("@/AI/shared/types/aiTypes");
jest.mock('@/utils/bashHelper');
jest.mock('@/utils/neovimHelper');
jest.mock('@/UI/generalUI');
jest.mock('fs/promises');
jest.mock('@/AI/AIChat/utils/promptModel');
jest.mock('@/AI/AIChat/utils/aiUtils', () => ({
    formatChatEntry: jest.fn((title, text, _flag) => `Formatted: ${title}: ${text}`)
}));
describe('saveChat', () => {
    const chatFile = 'dummyChat.txt';
    const temperature = 0.5;
    const role = 'user';
    const provider = 'gemini';
    const model = 'dummyModel';
    const saveName = 'testSave';
    const chatContent = 'Chat content from file';
    const chatHistory = [
        { role: aiTypes_1.Role.User, message: 'test', timestamp: 'date' },
        { role: aiTypes_1.Role.AI, message: 'test response', timestamp: 'date' },
    ];
    const exit = jest.spyOn(process, 'exit').mockImplementation((() => { throw new Error('process.exit called'); }));
    beforeEach(() => {
        jest.clearAllMocks();
        delete process.env.TMUX;
    });
    afterEach(() => {
        exit.mockRestore();
    });
    it('should not save chat if user declines', () => __awaiter(void 0, void 0, void 0, function* () {
        ui.promptUserYesOrNo.mockResolvedValue(false);
        fs.readdir.mockResolvedValue([]);
        promptModel_1.promptModel.mockImplementation(function () { return __asyncGenerator(this, arguments, function* () { }); });
        try {
            yield (0, saveChat_1.saveChat)(chatFile, provider, model, role, temperature, chatHistory);
        }
        catch (e) {
            expect(e.message).toBe('process.exit called');
        }
        expect(ui.promptUserYesOrNo).toHaveBeenCalledWith('Do you want to save the chat history?');
        expect(ui.searchAndSelect).not.toHaveBeenCalled();
        expect(bash.execCommand).not.toHaveBeenCalled();
    }));
    it('should save chat and summary when TMUX is not set', () => __awaiter(void 0, void 0, void 0, function* () {
        ui.promptUserYesOrNo.mockResolvedValue(true);
        fs.readdir.mockResolvedValue([]);
        ui.searchAndSelect.mockResolvedValue(saveName);
        fs.readFile.mockResolvedValue(chatContent);
        promptModel_1.promptModel.mockImplementation(function () {
            return __asyncGenerator(this, arguments, function* () {
                yield yield __await("Generated summary");
            });
        });
        yield (0, saveChat_1.saveChat)(chatFile, provider, model, role, temperature, chatHistory);
        const expectedSavePath = `${filePaths_1.aiHistoryPath}/${saveName}`;
        const expectedHistoryFile = `${expectedSavePath}/${saveName}`;
        expect(fs.mkdir).toHaveBeenCalledWith(expectedSavePath);
        expect(fs.writeFile).toHaveBeenCalledWith(`${expectedHistoryFile}.json`, expect.any(String));
        expect(nvim.openVim).toHaveBeenCalledWith(`${expectedSavePath}/summary.md`);
    }));
    it('should save chat and summary when TMUX is set', () => __awaiter(void 0, void 0, void 0, function* () {
        process.env.TMUX = '1';
        ui.promptUserYesOrNo.mockResolvedValue(true);
        fs.readdir.mockResolvedValue([saveName]);
        ui.searchAndSelect.mockResolvedValue(saveName);
        fs.readFile.mockResolvedValue(chatContent);
        promptModel_1.promptModel.mockImplementation(function () {
            return __asyncGenerator(this, arguments, function* () {
                yield yield __await("Summary chunk");
            });
        });
        yield (0, saveChat_1.saveChat)(chatFile, provider, model, role, temperature, chatHistory);
        const expectedSavePath = `${filePaths_1.aiHistoryPath}/${saveName}`;
        expect(bash.execCommand).toHaveBeenCalledWith(`rm -rf ${filePaths_1.aiHistoryPath}/${saveName}`);
        expect(fs.mkdir).toHaveBeenCalledWith(expectedSavePath);
        const tmuxCommandMatcher = expect.stringContaining('tmux split-window');
        expect(bash.execCommand).toHaveBeenCalledWith(tmuxCommandMatcher);
        expect(nvim.openVim).not.toHaveBeenCalled();
    }));
});
