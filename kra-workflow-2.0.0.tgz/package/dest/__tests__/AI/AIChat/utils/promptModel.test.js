"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __await = (this && this.__await) || function (v) { return this instanceof __await ? (this.v = v, this) : new __await(v); }
var __asyncGenerator = (this && this.__asyncGenerator) || function (thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = Object.create((typeof AsyncIterator === "function" ? AsyncIterator : Object).prototype), verb("next"), verb("throw"), verb("return", awaitReturn), i[Symbol.asyncIterator] = function () { return this; }, i;
    function awaitReturn(f) { return function (v) { return Promise.resolve(v).then(f, reject); }; }
    function verb(n, f) { if (g[n]) { i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; if (f) i[n] = f(i[n]); } }
    function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
    function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
    function fulfill(value) { resume("next", value); }
    function reject(value) { resume("throw", value); }
    function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
};
var __asyncValues = (this && this.__asyncValues) || function (o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
    function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
    function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const openai_1 = __importDefault(require("openai"));
const promptModel_1 = require("@/AI/AIChat/utils/promptModel");
const providers = __importStar(require("@/AI/shared/data/providers"));
jest.mock('openai');
jest.mock('@/AI/shared/data/providers');
describe('promptModel', () => {
    const mockOpenAI = jest.mocked(openai_1.default);
    const mockGetBaseURL = jest.mocked(providers.getProviderBaseURL);
    const mockGetApiKey = jest.mocked(providers.getProviderApiKey);
    function buildOpenAIInstance(stream) {
        return {
            chat: {
                completions: {
                    create: jest.fn().mockResolvedValue(stream),
                },
            },
        };
    }
    function createMockStream(chunks = []) {
        return {
            [Symbol.asyncIterator]() {
                return __asyncGenerator(this, arguments, function* _a() {
                    for (const chunk of chunks) {
                        yield yield __await(chunk);
                    }
                });
            },
        };
    }
    beforeEach(() => {
        jest.clearAllMocks();
        mockGetApiKey.mockImplementation((p) => `${p}-key`);
        mockGetBaseURL.mockImplementation((p) => `https://${p}.example/v1`);
    });
    it.each(['deep-infra', 'deep-seek', 'open-router', 'gemini', 'open-ai', 'mistral'])('initializes OpenAI client with shared provider config for %s', (provider) => __awaiter(void 0, void 0, void 0, function* () {
        const instance = buildOpenAIInstance(createMockStream());
        mockOpenAI.mockImplementation(() => instance);
        yield (0, promptModel_1.promptModel)(provider, 'model-x', 'test prompt', 0.7, 'test system');
        expect(mockGetApiKey).toHaveBeenCalledWith(provider);
        expect(mockGetBaseURL).toHaveBeenCalledWith(provider);
        expect(mockOpenAI).toHaveBeenCalledWith({
            apiKey: `${provider}-key`,
            baseURL: `https://${provider}.example/v1`,
        });
    }));
    it('passes the right messages, model, temperature, and stream flag', () => __awaiter(void 0, void 0, void 0, function* () {
        const instance = buildOpenAIInstance(createMockStream());
        mockOpenAI.mockImplementation(() => instance);
        yield (0, promptModel_1.promptModel)('deep-infra', 'gpt-3.5-turbo', 'test prompt', 0.7, 'test system');
        expect(instance.chat.completions.create).toHaveBeenCalledWith({
            messages: [
                { role: 'system', content: 'test system' },
                { role: 'user', content: 'test prompt' },
            ],
            model: 'gpt-3.5-turbo',
            temperature: 0.7,
            stream: true,
        });
    }));
    it('yields text from stream chunks', () => __awaiter(void 0, void 0, void 0, function* () {
        var _a, e_1, _b, _c;
        const stream = createMockStream([
            { choices: [{ delta: { content: 'Hello' } }] },
            { choices: [{ delta: { content: ' world' } }] },
            { choices: [{ delta: { content: '!' } }] },
        ]);
        mockOpenAI.mockImplementation(() => buildOpenAIInstance(stream));
        const result = yield (0, promptModel_1.promptModel)('open-ai', 'gpt-4', 'test', 0.7, 'system');
        const chunks = [];
        try {
            for (var _d = true, result_1 = __asyncValues(result), result_1_1; result_1_1 = yield result_1.next(), _a = result_1_1.done, !_a; _d = true) {
                _c = result_1_1.value;
                _d = false;
                const chunk = _c;
                chunks.push(chunk);
            }
        }
        catch (e_1_1) { e_1 = { error: e_1_1 }; }
        finally {
            try {
                if (!_d && !_a && (_b = result_1.return)) yield _b.call(result_1);
            }
            finally { if (e_1) throw e_1.error; }
        }
        expect(chunks).toEqual(['Hello', ' world', '!']);
    }));
    it('treats missing/null content as empty string', () => __awaiter(void 0, void 0, void 0, function* () {
        var _a, e_2, _b, _c;
        const stream = createMockStream([
            { choices: [{ delta: {} }] },
            { choices: [{ delta: { content: null } }] },
            { choices: [{ delta: { content: 'Hello' } }] },
        ]);
        mockOpenAI.mockImplementation(() => buildOpenAIInstance(stream));
        const result = yield (0, promptModel_1.promptModel)('open-ai', 'gpt-4', 'test', 0.7, 'system');
        const chunks = [];
        try {
            for (var _d = true, result_2 = __asyncValues(result), result_2_1; result_2_1 = yield result_2.next(), _a = result_2_1.done, !_a; _d = true) {
                _c = result_2_1.value;
                _d = false;
                const chunk = _c;
                chunks.push(chunk);
            }
        }
        catch (e_2_1) { e_2 = { error: e_2_1 }; }
        finally {
            try {
                if (!_d && !_a && (_b = result_2.return)) yield _b.call(result_2);
            }
            finally { if (e_2) throw e_2.error; }
        }
        expect(chunks).toEqual(['', '', 'Hello']);
    }));
});
