"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __await = (this && this.__await) || function (v) { return this instanceof __await ? (this.v = v, this) : new __await(v); }
var __asyncGenerator = (this && this.__asyncGenerator) || function (thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = Object.create((typeof AsyncIterator === "function" ? AsyncIterator : Object).prototype), verb("next"), verb("throw"), verb("return", awaitReturn), i[Symbol.asyncIterator] = function () { return this; }, i;
    function awaitReturn(f) { return function (v) { return Promise.resolve(v).then(f, reject); }; }
    function verb(n, f) { if (g[n]) { i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; if (f) i[n] = f(i[n]); } }
    function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
    function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
    function fulfill(value) { resume("next", value); }
    function reject(value) { resume("throw", value); }
    function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = __importStar(require("fs/promises"));
const neovim = __importStar(require("neovim"));
const bash = __importStar(require("@/utils/bashHelper"));
const conversation_1 = require("@/AI/AIChat/main/conversation");
const promptModel_1 = require("@/AI/AIChat/utils/promptModel");
const saveChat_1 = require("@/AI/AIChat/utils/saveChat");
const neovimHelper_1 = require("@/utils/neovimHelper");
const roles_1 = require("@/AI/shared/data/roles");
const aiUtils_1 = require("@/AI/AIChat/utils/aiUtils");
const filePaths_1 = require("@/filePaths");
jest.mock('fs/promises');
jest.mock('@/utils/bashHelper');
jest.mock('@/utils/neovimHelper');
jest.mock('@/AI/AIChat/utils/promptModel');
jest.mock('@/AI/AIChat/utils/saveChat');
jest.mock('@/AI/AIChat/utils/aiUtils');
jest.mock('@/filePaths', () => ({
    neovimConfig: '/home/krasen/programming/kra-tmux/ai-files/init.lua'
}));
describe('converse', () => {
    const chatFile = 'chat.md';
    const temperature = 0.7;
    const role = 'testRole';
    const provider = 'providerA';
    const model = 'model1';
    let originalTmux;
    let fakeNvim;
    let nvimEvents;
    beforeEach(() => {
        originalTmux = process.env.TMUX;
        delete process.env.TMUX;
        nvimEvents = {};
        fakeNvim = {
            command: jest.fn().mockResolvedValue(undefined),
            executeLua: jest.fn().mockImplementation((code) => __awaiter(void 0, void 0, void 0, function* () {
                if (code.includes('get_prompt_text')) {
                    return 'USER message';
                }
                return undefined;
            })),
            on: jest.fn((event, fn) => {
                nvimEvents[event] = fn;
            }),
            buffer: Promise.resolve({
                lines: Promise.resolve(['USER message', '']),
            }),
            channelId: Promise.resolve(123),
        };
        jest.spyOn(neovim, 'attach').mockReturnValue(fakeNvim);
        fs.access.mockResolvedValue(undefined);
        neovimHelper_1.openVim.mockClear();
        bash.execCommand.mockClear();
        promptModel_1.promptModel.mockClear();
        saveChat_1.saveChat.mockClear();
        fs.writeFile.mockClear();
        fs.readFile.mockClear();
        fs.rm.mockClear();
        promptModel_1.promptModel.mockResolvedValue('AI response');
        fs.readFile.mockResolvedValue('Chat history content');
        aiUtils_1.formatChatEntry.mockImplementation((header, content = '') => content ? `${header}\n${content}` : header);
    });
    afterEach(() => {
        if (originalTmux !== undefined) {
            process.env.TMUX = originalTmux;
        }
        else {
            delete process.env.TMUX;
        }
        jest.restoreAllMocks();
    });
    it('should call openVim when TMUX is not set and process submit notification', () => __awaiter(void 0, void 0, void 0, function* () {
        yield (0, conversation_1.converse)(chatFile, temperature, role, provider, model, false);
        expect(fs.writeFile).toHaveBeenCalledWith(chatFile, expect.stringContaining('# AI Chat History'), 'utf-8');
        expect(neovimHelper_1.openVim).toHaveBeenCalled();
        const openVimCall = neovimHelper_1.openVim.mock.calls[0];
        expect(openVimCall[0]).toBe(chatFile);
        expect(openVimCall[1]).toBe('-u');
        expect(openVimCall[2]).toBe(filePaths_1.neovimConfig);
        expect(openVimCall[3]).toBe('--listen');
        const socketPath = openVimCall[4];
        expect(socketPath).toMatch(/nvim-.*\.sock/);
        if (nvimEvents.notification) {
            yield nvimEvents.notification('prompt_action', ['submit_pressed']);
        }
        else {
            throw new Error('Notification event handler not registered');
        }
        expect(promptModel_1.promptModel).toHaveBeenCalledWith(provider, model, expect.stringContaining('USER message'), temperature, roles_1.aiRoles[role], expect.objectContaining({
            abort: expect.any(Function),
            isAborted: expect.any(Boolean)
        }));
        if (nvimEvents.disconnect) {
            yield nvimEvents.disconnect();
        }
        else {
            throw new Error('Disconnect event handler not registered');
        }
        expect(fs.readFile).toHaveBeenCalledWith(chatFile, 'utf8');
        expect(saveChat_1.saveChat).toHaveBeenCalledWith(chatFile, provider, model, role, temperature, []);
        expect(fs.rm).toHaveBeenCalledWith(chatFile);
    }));
    it('should execute tmux command when TMUX is set', () => __awaiter(void 0, void 0, void 0, function* () {
        process.env.TMUX = 'tmux';
        bash.execCommand.mockClear();
        neovimHelper_1.openVim.mockClear();
        yield (0, conversation_1.converse)(chatFile, temperature, role, provider, model, false);
        expect(bash.execCommand).toHaveBeenCalled();
        expect(neovimHelper_1.openVim).not.toHaveBeenCalled();
        if (nvimEvents.notification) {
            yield nvimEvents.notification('prompt_action', ['submit_pressed']);
        }
        else {
            throw new Error('Notification event handler not registered');
        }
        expect(promptModel_1.promptModel).toHaveBeenCalledWith(provider, model, expect.stringContaining('USER message'), temperature, roles_1.aiRoles[role], expect.objectContaining({
            abort: expect.any(Function),
            isAborted: expect.any(Boolean)
        }));
        if (nvimEvents.disconnect) {
            yield nvimEvents.disconnect();
        }
        else {
            throw new Error('Disconnect event handler not registered');
        }
    }));
    it('should process streaming responses from promptModel', () => __awaiter(void 0, void 0, void 0, function* () {
        function streamResponse() {
            return __asyncGenerator(this, arguments, function* streamResponse_1() {
                yield yield __await('chunk1 ');
                yield yield __await('chunk2');
            });
        }
        promptModel_1.promptModel.mockResolvedValue(streamResponse());
        fs.appendFile.mockClear();
        neovimHelper_1.openVim.mockClear();
        yield (0, conversation_1.converse)(chatFile, temperature, role, provider, model, false);
        if (nvimEvents.notification) {
            yield nvimEvents.notification('prompt_action', ['submit_pressed']);
        }
        else {
            throw new Error('Notification event handler not registered');
        }
        expect(promptModel_1.promptModel).toHaveBeenCalledWith(provider, model, expect.stringContaining('USER message'), temperature, roles_1.aiRoles[role], expect.objectContaining({
            abort: expect.any(Function),
            isAborted: expect.any(Boolean)
        }));
        if (nvimEvents.disconnect) {
            yield nvimEvents.disconnect();
        }
        else {
            throw new Error('Disconnect event handler not registered');
        }
        expect(fs.appendFile).toHaveBeenCalled();
    }));
});
