"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const aiUtils_1 = require("@/AI/AIChat/utils/aiUtils");
const ui = __importStar(require("@/UI/generalUI"));
const modelCatalog_1 = require("@/AI/shared/data/modelCatalog");
const providers_1 = require("@/AI/shared/data/providers");
jest.mock('@/UI/generalUI', () => ({
    searchSelectAndReturnFromArray: jest.fn(),
    searchAndSelect: jest.fn(),
}));
jest.mock('@/AI/shared/data/modelCatalog', () => ({
    getModelCatalog: jest.fn(),
    formatModelInfoForPicker: jest.fn((m) => m.label),
}));
describe('promptUserForTemperature', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });
    it('should return 0.5 when selected option is "5" for a non-gemini model', () => __awaiter(void 0, void 0, void 0, function* () {
        ui.searchAndSelect.mockResolvedValue('5');
        const result = yield (0, aiUtils_1.promptUserForTemperature)('otherModel');
        expect(result).toBe(0.5);
        expect(ui.searchAndSelect).toHaveBeenCalled();
    }));
    it('should return 2.0 when selected option is "20" for a gemini model', () => __awaiter(void 0, void 0, void 0, function* () {
        ui.searchAndSelect.mockResolvedValue('20');
        const result = yield (0, aiUtils_1.promptUserForTemperature)('gemini-sample');
        expect(result).toBe(2.0);
        expect(ui.searchAndSelect).toHaveBeenCalled();
    }));
});
describe('formatChatEntry', () => {
    beforeEach(() => {
        jest.spyOn(Date.prototype, 'toISOString').mockReturnValue('2020-01-01T00:00:00.000Z');
    });
    afterEach(() => {
        jest.restoreAllMocks();
    });
    it('should return formatted entry with default header when content is provided', () => {
        const result = (0, aiUtils_1.formatChatEntry)('user', 'Hello chat', false);
        const expected = `\n---\n### user (2020-01-01T00:00:00.000Z)\n\nHello chat\n---\n`;
        expect(result).toBe(expected);
    });
    it('should return header only if no content is provided', () => {
        const result = (0, aiUtils_1.formatChatEntry)('user', '', false);
        const expected = `\n---\n### user (2020-01-01T00:00:00.000Z)\n\n`;
        expect(result).toBe(expected);
    });
    it('should use top level header when topLevel is true', () => {
        const result = (0, aiUtils_1.formatChatEntry)('user', 'Test content', true);
        const expected = `### user (2020-01-01T00:00:00.000Z)\n\nTest content\n---\n`;
        expect(result).toBe(expected);
    });
});
describe('pickProviderAndModel', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });
    it('should pick provider and model correctly', () => __awaiter(void 0, void 0, void 0, function* () {
        modelCatalog_1.getModelCatalog.mockResolvedValue([
            { id: 'finalModelA', label: 'modelA', contextWindow: 128000 },
        ]);
        ui.searchSelectAndReturnFromArray
            .mockResolvedValueOnce('gemini')
            .mockResolvedValueOnce('modelA');
        const result = yield (0, aiUtils_1.pickProviderAndModel)();
        expect(ui.searchSelectAndReturnFromArray).toHaveBeenCalledTimes(2);
        expect(ui.searchSelectAndReturnFromArray).toHaveBeenNthCalledWith(1, {
            itemsArray: [...providers_1.SUPPORTED_PROVIDERS],
            prompt: 'Select a provider',
        });
        expect(modelCatalog_1.getModelCatalog).toHaveBeenCalledWith('gemini');
        expect(result).toEqual({ provider: 'gemini', model: 'finalModelA' });
    }));
});
