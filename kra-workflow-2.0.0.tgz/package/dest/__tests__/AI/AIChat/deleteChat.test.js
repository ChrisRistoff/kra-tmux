"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const deleteChat_1 = require("@/AI/AIChat/commands/deleteChat");
const fs = __importStar(require("fs/promises"));
const ui = __importStar(require("@/UI/generalUI"));
const filePaths_1 = require("@/filePaths");
jest.mock('fs/promises', () => ({
    readdir: jest.fn(),
    rmdir: jest.fn()
}));
jest.mock('@/UI/generalUI', () => ({
    searchSelectAndReturnFromArray: jest.fn()
}));
jest.mock('@/utils/common', () => ({
    filterGitKeep: jest.fn((files) => files.filter((file) => file !== '.gitkeep'))
}));
describe('deleteChats', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });
    it('should print message and not delete when no chats found', () => __awaiter(void 0, void 0, void 0, function* () {
        fs.readdir.mockResolvedValue([]);
        const consoleLogSpy = jest.spyOn(console, 'log').mockImplementation(() => { return; });
        yield (0, deleteChat_1.deleteChats)();
        expect(consoleLogSpy).toHaveBeenCalledWith('No active chat sessions found.');
        expect(ui.searchSelectAndReturnFromArray).not.toHaveBeenCalled();
        consoleLogSpy.mockRestore();
    }));
    it('should delete the selected chat', () => __awaiter(void 0, void 0, void 0, function* () {
        const chats = ['chat1', '.gitkeep'];
        fs.readdir.mockResolvedValue(chats);
        ui.searchSelectAndReturnFromArray.mockResolvedValue('chat1');
        const consoleLogSpy = jest.spyOn(console, 'log').mockImplementation(() => { return; });
        yield (0, deleteChat_1.deleteChats)();
        expect(ui.searchSelectAndReturnFromArray).toHaveBeenCalledWith({
            itemsArray: ['chat1'],
            prompt: 'Select a chat to delete: '
        });
        expect(fs.rmdir).toHaveBeenCalledWith(`${filePaths_1.aiHistoryPath}/chat1`, { recursive: true });
        expect(consoleLogSpy).toHaveBeenCalledWith('Chat chat1 has been deleted.');
        consoleLogSpy.mockRestore();
    }));
    it('should log error and throw when fs.readdir fails', () => __awaiter(void 0, void 0, void 0, function* () {
        const error = new Error('readdir failed');
        fs.readdir.mockRejectedValue(error);
        const consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation(() => { return; });
        yield expect((0, deleteChat_1.deleteChats)()).rejects.toThrow('readdir failed');
        expect(consoleErrorSpy).toHaveBeenCalledWith('Error deleting chat:', 'readdir failed');
        consoleErrorSpy.mockRestore();
    }));
});
