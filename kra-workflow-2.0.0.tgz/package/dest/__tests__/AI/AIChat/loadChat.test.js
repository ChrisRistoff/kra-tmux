"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = __importStar(require("fs/promises"));
const bash = __importStar(require("@/utils/bashHelper"));
const nvim = __importStar(require("@/utils/neovimHelper"));
const ui = __importStar(require("@/UI/generalUI"));
const conversation = __importStar(require("@/AI/AIChat/main/conversation"));
const loadChat_1 = require("@/AI/AIChat/commands/loadChat");
const filePaths_1 = require("@/filePaths");
const aiUtils_1 = require("@/AI/AIChat/utils/aiUtils");
const modelCatalog_1 = require("@/AI/shared/data/modelCatalog");
const aiTypes_1 = require("@/AI/shared/types/aiTypes");
const path = __importStar(require("path"));
jest.mock('fs/promises');
jest.mock('@/utils/bashHelper');
jest.mock('@/utils/neovimHelper');
jest.mock('@/UI/generalUI');
jest.mock('@/AI/AIChat/main/conversation');
jest.mock('@/AI/AIChat/utils/aiUtils');
jest.mock('@/utils/common', () => ({
    filterGitKeep: jest.fn((chats) => chats)
}));
jest.mock('@/AI/shared/data/modelCatalog', () => ({
    getModelCatalog: jest.fn(),
}));
describe('loadChat', () => {
    const savedChatName = 'chat1';
    const fakeChats = [savedChatName];
    const fixedTimestamp = 123456789;
    const chatFile = `/tmp/ai-chat-${fixedTimestamp}.md`;
    const chatHistoryPath = path.join(filePaths_1.aiHistoryPath, savedChatName, `${savedChatName}.md`);
    const chatSummaryPath = path.join(filePaths_1.aiHistoryPath, savedChatName, 'summary.md');
    const validChatData = {
        temperature: 0.6,
        role: 'testRole',
        provider: 'gemini',
        model: 'model1'
    };
    const invalidChatData = {
        temperature: 0.6,
        role: 'testRole',
        provider: 'gemini',
        model: 'invalidModel'
    };
    beforeAll(() => {
        modelCatalog_1.getModelCatalog.mockResolvedValue([
            { id: 'model1', label: 'model1', contextWindow: 128000 },
        ]);
    });
    beforeEach(() => {
        jest.clearAllMocks();
        jest.spyOn(Date, 'now').mockReturnValue(fixedTimestamp);
        delete process.env.TMUX;
    });
    afterEach(() => {
        jest.restoreAllMocks();
    });
    it('should print message and return when no saved chats are found', () => __awaiter(void 0, void 0, void 0, function* () {
        fs.readdir.mockResolvedValue([]);
        const consoleLogSpy = jest.spyOn(console, 'log').mockImplementation(() => { return; });
        yield (0, loadChat_1.loadChat)();
        expect(fs.readdir).toHaveBeenCalledWith(filePaths_1.aiHistoryPath);
        expect(consoleLogSpy).toHaveBeenCalledWith('No saved chats found.');
        consoleLogSpy.mockRestore();
    }));
    it('should load chat and call conversation.converse when provider is valid and TMUX is not set', () => __awaiter(void 0, void 0, void 0, function* () {
        fs.readdir.mockResolvedValue(fakeChats);
        ui.searchSelectAndReturnFromArray.mockResolvedValue(savedChatName);
        ui.promptUserYesOrNo.mockResolvedValue(true);
        fs.readFile.mockResolvedValue(JSON.stringify(validChatData));
        fs.copyFile.mockResolvedValue(undefined);
        conversation.converse.mockResolvedValue(undefined);
        yield (0, loadChat_1.loadChat)();
        expect(nvim.openVim).toHaveBeenCalledWith(chatSummaryPath);
        expect(fs.copyFile).toHaveBeenCalledWith(chatHistoryPath, chatFile);
        expect(conversation.converse).toHaveBeenCalledWith(chatFile, validChatData.temperature, validChatData.role, validChatData.provider, validChatData.model, true);
    }));
    it('should call bash.execCommand with tmux command when TMUX is set', () => __awaiter(void 0, void 0, void 0, function* () {
        process.env.TMUX = '1';
        fs.readdir.mockResolvedValue(fakeChats);
        ui.searchSelectAndReturnFromArray.mockResolvedValue(savedChatName);
        ui.promptUserYesOrNo.mockResolvedValue(true);
        fs.readFile.mockResolvedValue(JSON.stringify(validChatData));
        fs.copyFile.mockResolvedValue(undefined);
        conversation.converse.mockResolvedValue(undefined);
        yield (0, loadChat_1.loadChat)();
        expect(bash.execCommand).toHaveBeenCalled();
        expect(nvim.openVim).not.toHaveBeenCalled();
        expect(conversation.converse).toHaveBeenCalledWith(chatFile, validChatData.temperature, validChatData.role, validChatData.provider, validChatData.model, true);
    }));
    it('should rebuild saved chat history without appending a blank draft user turn', () => __awaiter(void 0, void 0, void 0, function* () {
        var _a;
        const chatDataWithHistory = Object.assign(Object.assign({}, validChatData), { chatHistory: [
                { role: aiTypes_1.Role.User, message: 'First prompt', timestamp: '2026-04-28T10:00:00.000Z' },
                { role: aiTypes_1.Role.AI, message: 'First reply', timestamp: '2026-04-28T10:00:01.000Z' },
            ] });
        fs.readdir.mockResolvedValue(fakeChats);
        ui.searchSelectAndReturnFromArray.mockResolvedValue(savedChatName);
        ui.promptUserYesOrNo.mockResolvedValue(true);
        fs.readFile.mockResolvedValue(JSON.stringify(chatDataWithHistory));
        fs.appendFile.mockResolvedValue(undefined);
        conversation.converse.mockResolvedValue(undefined);
        yield (0, loadChat_1.loadChat)();
        expect(conversation.initializeChatFile).toHaveBeenCalledWith(chatFile);
        expect(fs.appendFile).toHaveBeenCalledWith(chatFile, expect.stringContaining('First prompt'));
        const transcript = fs.appendFile.mock.calls[0][1];
        expect(((_a = transcript.match(/USER PROMPT/g)) !== null && _a !== void 0 ? _a : [])).toHaveLength(1);
    }));
    it('should prompt for new provider and model if the saved chat has invalid provider', () => __awaiter(void 0, void 0, void 0, function* () {
        fs.readdir.mockResolvedValue(fakeChats);
        ui.searchSelectAndReturnFromArray.mockResolvedValue(savedChatName);
        ui.promptUserYesOrNo.mockResolvedValue(true);
        fs.readFile.mockResolvedValue(JSON.stringify(invalidChatData));
        fs.copyFile.mockResolvedValue(undefined);
        conversation.converse.mockResolvedValue(undefined);
        aiUtils_1.pickProviderAndModel.mockResolvedValue({ provider: 'gemini', model: 'model1' });
        yield (0, loadChat_1.loadChat)();
        expect(aiUtils_1.pickProviderAndModel).toHaveBeenCalled();
        expect(conversation.converse).toHaveBeenCalledWith(chatFile, invalidChatData.temperature, invalidChatData.role, 'gemini', 'model1', true);
    }));
    it('should recursively call loadChat if user declines to open the chat', () => __awaiter(void 0, void 0, void 0, function* () {
        fs.readdir.mockResolvedValue(fakeChats);
        ui.searchSelectAndReturnFromArray.mockResolvedValue(savedChatName);
        const promptUserYesOrNoMock = ui.promptUserYesOrNo;
        promptUserYesOrNoMock
            .mockResolvedValueOnce(false)
            .mockResolvedValueOnce(true);
        fs.readFile.mockResolvedValue(JSON.stringify(validChatData));
        fs.copyFile.mockResolvedValue(undefined);
        conversation.converse.mockResolvedValue(undefined);
        yield (0, loadChat_1.loadChat)();
        expect(promptUserYesOrNoMock).toHaveBeenCalledTimes(2);
        expect(conversation.converse).toHaveBeenCalledWith(chatFile, validChatData.temperature, validChatData.role, validChatData.provider, validChatData.model, true);
    }));
    it('should log error and rethrow if an error occurs', () => __awaiter(void 0, void 0, void 0, function* () {
        const testError = new Error('Test error');
        fs.readdir.mockRejectedValue(testError);
        const consoleErrorSpy = jest.spyOn(console, 'error').mockImplementation(() => { return; });
        yield expect((0, loadChat_1.loadChat)()).rejects.toThrow('Test error');
        expect(consoleErrorSpy).toHaveBeenCalledWith('Error loading chat:', 'Test error');
        consoleErrorSpy.mockRestore();
    }));
});
