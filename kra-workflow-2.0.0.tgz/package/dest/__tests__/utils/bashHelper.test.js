"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const bashHelper_1 = require("@/utils/bashHelper");
const mockExecCommand = jest.fn();
jest.mock('child_process', () => ({
    exec: (...args) => {
        const callback = args[args.length - 1];
        if (typeof callback === 'function') {
            return mockExecCommand(...args);
        }
        return {};
    }
}));
const mockConsoleError = jest.spyOn(console, 'error').mockImplementation();
describe('tmux-utils', () => {
    beforeEach(() => {
        jest.clearAllMocks();
        jest.clearAllTimers();
        jest.useFakeTimers();
        mockExecCommand.mockImplementation((_, callback) => {
            callback(null, '', '');
            return {};
        });
    });
    afterEach(() => {
        jest.useRealTimers();
    });
    afterAll(() => {
        mockConsoleError.mockRestore();
    });
    describe('execCommand', () => {
        it('should resolve with stdout and stderr on success', () => __awaiter(void 0, void 0, void 0, function* () {
            mockExecCommand.mockImplementation((_, callback) => {
                callback(null, 'success output', 'warning message');
                return {};
            });
            const result = yield (0, bashHelper_1.execCommand)('test command');
            expect(result).toEqual({
                stdout: 'success output',
                stderr: 'warning message'
            });
        }));
        it('should reject with error on command failure', () => __awaiter(void 0, void 0, void 0, function* () {
            mockExecCommand.mockImplementation((_, callback) => {
                callback(new Error('Command failed'), '', '');
                return {};
            });
            yield expect((0, bashHelper_1.execCommand)('failing command')).rejects.toThrow('Command failed');
        }));
    });
    describe('sendKeysToTmuxTargetSession', () => {
        it('should send basic command without target', () => __awaiter(void 0, void 0, void 0, function* () {
            const options = {
                command: 'ls -la'
            };
            yield (0, bashHelper_1.sendKeysToTmuxTargetSession)(options);
            expect(mockExecCommand).toHaveBeenCalledWith('tmux send-keys "ls -la" C-m', expect.any(Function));
        }));
        it('should send command with session name only', () => __awaiter(void 0, void 0, void 0, function* () {
            const options = {
                sessionName: 'my-session',
                command: 'pwd'
            };
            yield (0, bashHelper_1.sendKeysToTmuxTargetSession)(options);
            expect(mockExecCommand).toHaveBeenCalledWith('tmux send-keys -t my-session "pwd" C-m', expect.any(Function));
        }));
        it('should send command with session and window index', () => __awaiter(void 0, void 0, void 0, function* () {
            const options = {
                sessionName: 'my-session',
                windowIndex: 2,
                command: 'git status'
            };
            yield (0, bashHelper_1.sendKeysToTmuxTargetSession)(options);
            expect(mockExecCommand).toHaveBeenCalledWith('tmux send-keys -t my-session:2 "git status" C-m', expect.any(Function));
        }));
        it('should send command with session, window, and pane index', () => __awaiter(void 0, void 0, void 0, function* () {
            const options = {
                sessionName: 'my-session',
                windowIndex: 1,
                paneIndex: 3,
                command: 'npm test'
            };
            yield (0, bashHelper_1.sendKeysToTmuxTargetSession)(options);
            expect(mockExecCommand).toHaveBeenCalledWith('tmux send-keys -t my-session:1.3 "npm test" C-m', expect.any(Function));
        }));
        it('should send command with window index only', () => __awaiter(void 0, void 0, void 0, function* () {
            const options = {
                windowIndex: 0,
                command: 'echo test'
            };
            yield (0, bashHelper_1.sendKeysToTmuxTargetSession)(options);
            // The actual implementation sends "0" not ":0" when only windowIndex is provided
            expect(mockExecCommand).toHaveBeenCalledWith('tmux send-keys -t 0 "echo test" C-m', expect.any(Function));
        }));
        it('should send command with pane index only', () => __awaiter(void 0, void 0, void 0, function* () {
            const options = {
                paneIndex: 2,
                command: 'vim'
            };
            yield (0, bashHelper_1.sendKeysToTmuxTargetSession)(options);
            // The actual implementation sends "2" not ".2" when only paneIndex is provided
            expect(mockExecCommand).toHaveBeenCalledWith('tmux send-keys -t 2 "vim" C-m', expect.any(Function));
        }));
        it('should handle windowIndex 0 correctly', () => __awaiter(void 0, void 0, void 0, function* () {
            const options = {
                sessionName: 'test',
                windowIndex: 0,
                command: 'test'
            };
            yield (0, bashHelper_1.sendKeysToTmuxTargetSession)(options);
            expect(mockExecCommand).toHaveBeenCalledWith('tmux send-keys -t test:0 "test" C-m', expect.any(Function));
        }));
        it('should handle paneIndex 0 correctly', () => __awaiter(void 0, void 0, void 0, function* () {
            const options = {
                sessionName: 'test',
                paneIndex: 0,
                command: 'test'
            };
            yield (0, bashHelper_1.sendKeysToTmuxTargetSession)(options);
            expect(mockExecCommand).toHaveBeenCalledWith('tmux send-keys -t test.0 "test" C-m', expect.any(Function));
        }));
    });
    describe('sendKeysToTargetSessionAndWait', () => {
        it('should send marker command and wait for it to appear', () => __awaiter(void 0, void 0, void 0, function* () {
            let captureCallCount = 0;
            mockExecCommand.mockImplementation((command, callback) => {
                if (command.includes('capture-pane')) {
                    captureCallCount++;
                    const stdout = captureCallCount === 1 ? 'some output' : 'some output\n__DONE_\n';
                    // Use setTimeout instead of process.nextTick for fake timers
                    setTimeout(() => callback(null, stdout, ''), 0);
                }
                else {
                    setTimeout(() => callback(null, '', ''), 0);
                }
                return {};
            });
            const options = {
                sessionName: 'test-session',
                command: 'original command'
            };
            const promise = (0, bashHelper_1.sendKeysToTargetSessionAndWait)(options);
            // Advance timers to trigger the polling intervals and async callbacks
            yield jest.advanceTimersByTimeAsync(600);
            yield promise;
            expect(mockExecCommand).toHaveBeenCalledWith('tmux send-keys -t test-session "echo __DONE_" C-m', expect.any(Function));
            expect(mockExecCommand).toHaveBeenCalledWith('tmux capture-pane -p -t test-session', expect.any(Function));
        }));
    });
    describe('grepFileForString', () => {
        it('should return true when string is found', () => __awaiter(void 0, void 0, void 0, function* () {
            mockExecCommand.mockImplementation((_, callback) => {
                callback(null, 'matching line with search term', '');
                return {};
            });
            const result = yield (0, bashHelper_1.grepFileForString)('test.txt', 'search term');
            expect(result).toBe(true);
        }));
        it('should return false when string is not found', () => __awaiter(void 0, void 0, void 0, function* () {
            mockExecCommand.mockImplementation((_, callback) => {
                callback(null, '', '');
                return {};
            });
            const result = yield (0, bashHelper_1.grepFileForString)('test.txt', 'not found');
            expect(result).toBe(false);
        }));
        it('should return false and log error when grep has stderr', () => __awaiter(void 0, void 0, void 0, function* () {
            mockExecCommand.mockImplementation((_, callback) => {
                callback(null, '', 'grep: test.txt: No such file or directory');
                return {};
            });
            const result = yield (0, bashHelper_1.grepFileForString)('test.txt', 'anything');
            expect(result).toBe(false);
            expect(mockConsoleError).toHaveBeenCalledWith('grep error: grep: test.txt: No such file or directory');
        }));
        it('should return false when exec throws an error', () => __awaiter(void 0, void 0, void 0, function* () {
            mockExecCommand.mockImplementation((_, callback) => {
                callback(new Error('Command failed'), '', '');
                return {};
            });
            const result = yield (0, bashHelper_1.grepFileForString)('test.txt', 'search');
            expect(result).toBe(false);
        }));
        it('should properly escape file name in command', () => __awaiter(void 0, void 0, void 0, function* () {
            mockExecCommand.mockImplementation((_, callback) => {
                callback(null, 'found', '');
                return {};
            });
            yield (0, bashHelper_1.grepFileForString)('file with spaces.txt', 'pattern');
            expect(mockExecCommand).toHaveBeenCalledWith(`grep -E "pattern" 'file with spaces.txt'`, expect.any(Function));
        }));
    });
});
