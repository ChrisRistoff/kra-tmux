"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = __importStar(require("fs"));
const events_1 = require("events");
const bash = __importStar(require("@/utils/bashHelper"));
const filePaths_1 = require("@/filePaths");
const neovimHelper_1 = require("@/utils/neovimHelper");
jest.mock('fs', () => ({
    existsSync: jest.fn(),
    mkdirSync: jest.fn(),
    unlinkSync: jest.fn(),
}));
jest.mock('@/utils/bashHelper');
const mockedSendKeysToTmuxTargetSession = jest.mocked(bash.sendKeysToTmuxTargetSession);
const mockedExecCommand = jest.mocked(bash.execCommand);
describe('Nvim Session Operations', () => {
    const folderName = 'testFolder';
    const session = 'testSession';
    const windowIndex = 1;
    const paneIndex = 2;
    const nvimSessionFileName = `${session}_${windowIndex}_${paneIndex}.vim`;
    const fullFolderPath = `${filePaths_1.nvimSessionsPath}/${folderName}`;
    const fullSessionPath = `${fullFolderPath}/${nvimSessionFileName}`;
    beforeEach(() => {
        jest.clearAllMocks();
    });
    describe('saveNvimSession', () => {
        let existsSyncMock;
        let mkdirSyncMock;
        let unlinkSyncMock;
        beforeEach(() => {
            existsSyncMock = fs.existsSync;
            mkdirSyncMock = fs.mkdirSync;
            unlinkSyncMock = fs.unlinkSync;
            // assume that none of the directories or the file exist.
            existsSyncMock.mockImplementation((_path) => false);
            mockedSendKeysToTmuxTargetSession.mockResolvedValue(undefined);
        });
        it('should create directories if they do not exist and then save the session', () => __awaiter(void 0, void 0, void 0, function* () {
            yield (0, neovimHelper_1.saveNvimSession)(folderName, session, windowIndex, paneIndex);
            expect(mkdirSyncMock).toHaveBeenCalledWith(filePaths_1.nvimSessionsPath, { recursive: true });
            expect(mkdirSyncMock).toHaveBeenCalledWith(fullFolderPath, { recursive: true });
            expect(unlinkSyncMock).not.toHaveBeenCalled();
            expect(mockedSendKeysToTmuxTargetSession).toHaveBeenCalledWith({
                sessionName: session,
                windowIndex,
                paneIndex,
                command: `:mksession ${fullSessionPath}`,
            });
        }));
        it('should delete the existing session file before saving a new one', () => __awaiter(void 0, void 0, void 0, function* () {
            existsSyncMock.mockImplementation((path) => {
                if (path === filePaths_1.nvimSessionsPath)
                    return true;
                if (path === fullFolderPath)
                    return true;
                if (path === fullSessionPath)
                    return true;
                return false;
            });
            yield (0, neovimHelper_1.saveNvimSession)(folderName, session, windowIndex, paneIndex);
            expect(unlinkSyncMock).toHaveBeenCalledWith(fullSessionPath);
            expect(mockedSendKeysToTmuxTargetSession).toHaveBeenCalledWith({
                sessionName: session,
                windowIndex,
                paneIndex,
                command: `:mksession ${fullSessionPath}`,
            });
        }));
    });
    describe('loadNvimSession', () => {
        beforeEach(() => {
            mockedSendKeysToTmuxTargetSession.mockResolvedValue(undefined);
        });
        it('should load the saved session in nvim', () => __awaiter(void 0, void 0, void 0, function* () {
            yield (0, neovimHelper_1.loadNvimSession)(folderName, session, windowIndex, paneIndex);
            expect(mockedSendKeysToTmuxTargetSession).toHaveBeenCalledWith({
                sessionName: session,
                windowIndex,
                paneIndex,
                command: `nvim -S ${fullSessionPath}`,
            });
        }));
    });
    describe('openVim', () => {
        const filePath = '/path/to/file.txt';
        let spawnMock;
        beforeEach(() => {
            mockedExecCommand.mockResolvedValue({ stdout: '', stderr: '' });
            spawnMock = jest.spyOn(require('child_process'), 'spawn');
        });
        afterEach(() => {
            spawnMock.mockRestore();
        });
        // helper - create a fake child process that is an EventEmitter.
        function createFakeProcess() {
            return new events_1.EventEmitter();
        }
        it('should resolve when nvim process exits with code 0', () => __awaiter(void 0, void 0, void 0, function* () {
            const fakeProcess = createFakeProcess();
            spawnMock.mockReturnValue(fakeProcess);
            const promise = (0, neovimHelper_1.openVim)(filePath);
            process.nextTick(() => {
                fakeProcess.emit('close', 0);
            });
            yield expect(promise).resolves.toBeUndefined();
            expect(spawnMock).toHaveBeenCalledWith('nvim', [filePath], {
                stdio: 'inherit',
                shell: false,
            });
        }));
        it('should resolve and send tmux keys when colon-prefixed args are provided', () => __awaiter(void 0, void 0, void 0, function* () {
            const argWithColon = ':SomeCommand';
            const fakeProcess = createFakeProcess();
            spawnMock.mockReturnValue(fakeProcess);
            const promise = (0, neovimHelper_1.openVim)(filePath, argWithColon, 'anotherArg');
            process.nextTick(() => {
                fakeProcess.emit('close', 0);
            });
            yield promise;
            expect(mockedExecCommand).toHaveBeenCalledWith(`tmux send-keys ${argWithColon} C-m`);
            expect(spawnMock).toHaveBeenCalledWith('nvim', [filePath, 'anotherArg'], {
                stdio: 'inherit',
                shell: false,
            });
        }));
        it('should reject when nvim process exits with non-zero code', () => __awaiter(void 0, void 0, void 0, function* () {
            const fakeProcess = createFakeProcess();
            spawnMock.mockReturnValue(fakeProcess);
            const promise = (0, neovimHelper_1.openVim)(filePath);
            process.nextTick(() => {
                fakeProcess.emit('close', 1);
            });
            yield expect(promise).rejects.toThrow('Vim exited with code 1');
        }));
        it('should reject when nvim process emits an error', () => __awaiter(void 0, void 0, void 0, function* () {
            const fakeProcess = createFakeProcess();
            spawnMock.mockReturnValue(fakeProcess);
            const error = new Error('Spawn failed');
            const promise = (0, neovimHelper_1.openVim)(filePath);
            process.nextTick(() => {
                fakeProcess.emit('error', error);
            });
            yield expect(promise).rejects.toThrow('Spawn failed');
        }));
    });
});
