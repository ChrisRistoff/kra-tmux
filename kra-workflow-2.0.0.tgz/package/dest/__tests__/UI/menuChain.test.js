"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const menuChain_1 = require("@/UI/menuChain");
describe('menuChain', () => {
    it('returns the seed when no steps are chained', () => __awaiter(void 0, void 0, void 0, function* () {
        const result = yield (0, menuChain_1.menuChain)({ source: 'seed' }).run();
        expect(result).toEqual({ source: 'seed' });
    }));
    it('builds one object across chained steps', () => __awaiter(void 0, void 0, void 0, function* () {
        const result = yield (0, menuChain_1.menuChain)()
            .step('provider', () => 'deepinfra')
            .step('model', (data) => `${data.provider}-gemini`)
            .step('temperature', () => 10)
            .run();
        expect(result).toEqual({
            provider: 'deepinfra',
            model: 'deepinfra-gemini',
            temperature: 10,
        });
    }));
    it('passes seeded data into the first step', () => __awaiter(void 0, void 0, void 0, function* () {
        const result = yield (0, menuChain_1.menuChain)({ prompt: 'hi' })
            .step('shout', (data) => data.prompt.toUpperCase())
            .run();
        expect(result).toEqual({ prompt: 'hi', shout: 'HI' });
    }));
    it('rethrows non-UserCancelled errors immediately', () => __awaiter(void 0, void 0, void 0, function* () {
        const boom = new Error('boom');
        yield expect((0, menuChain_1.menuChain)()
            .step('a', () => 1)
            .step('b', () => {
            throw boom;
        })
            .run()).rejects.toBe(boom);
    }));
    it('propagates UserCancelled when thrown from the first step', () => __awaiter(void 0, void 0, void 0, function* () {
        yield expect((0, menuChain_1.menuChain)()
            .step('a', () => {
            throw new menuChain_1.UserCancelled();
        })
            .run()).rejects.toBeInstanceOf(menuChain_1.UserCancelled);
    }));
    it('re-runs the previous step with its original snapshot after Esc', () => __awaiter(void 0, void 0, void 0, function* () {
        const calls = [];
        let stepB = 0;
        let stepC = 0;
        const result = yield (0, menuChain_1.menuChain)()
            .step('a', (data) => {
            calls.push(`a(${JSON.stringify(data)})`);
            return 'A';
        })
            .step('b', (data) => {
            calls.push(`b(${JSON.stringify(data)})`);
            stepB++;
            return stepB === 1 ? 'B1' : 'B2';
        })
            .step('c', (data) => {
            calls.push(`c(${JSON.stringify(data)})`);
            stepC++;
            if (stepC === 1) {
                throw new menuChain_1.UserCancelled();
            }
            return 'C';
        })
            .run();
        expect(result).toEqual({ a: 'A', b: 'B2', c: 'C' });
        expect(calls).toEqual([
            'a({})',
            'b({"a":"A"})',
            'c({"a":"A","b":"B1"})',
            'b({"a":"A"})',
            'c({"a":"A","b":"B2"})',
        ]);
    }));
    it('supports backtracking across an arbitrarily long chain', () => __awaiter(void 0, void 0, void 0, function* () {
        const runs = [0, 0, 0, 0];
        const escAtStep = { 0: [], 1: [2], 2: [2], 3: [1] };
        const result = yield (0, menuChain_1.menuChain)()
            .step('s0', () => ++runs[0])
            .step('s1', () => {
            if (escAtStep[1].includes(++runs[1])) {
                throw new menuChain_1.UserCancelled();
            }
            return runs[1];
        })
            .step('s2', () => {
            if (escAtStep[2].includes(++runs[2])) {
                throw new menuChain_1.UserCancelled();
            }
            return runs[2];
        })
            .step('s3', () => {
            if (escAtStep[3].includes(++runs[3])) {
                throw new menuChain_1.UserCancelled();
            }
            return runs[3];
        })
            .run();
        expect(result).toEqual({ s0: 2, s1: 3, s2: 3, s3: 2 });
        expect(runs).toEqual([2, 3, 3, 2]);
    }));
});
