"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs_1 = __importDefault(require("fs"));
const bash = __importStar(require("@/utils/bashHelper"));
const ui = __importStar(require("@/UI/generalUI"));
const gitUntracked_1 = require("@/git/commands/gitUntracked");
const gitBranch_1 = require("@/git/core/gitBranch");
const path_1 = __importDefault(require("path"));
const filePaths_1 = require("@/filePaths");
const gitConstants_1 = require("@/git/config/gitConstants");
const gitFileUtils_1 = require("@/git/utils/gitFileUtils");
jest.mock('fs');
jest.mock('path');
jest.mock('@/utils/bashHelper');
jest.mock('@/UI/generalUI');
jest.mock('@/git/core/gitBranch');
describe('Git Untracked Operations', () => {
    const mockFs = jest.mocked(fs_1.default);
    const mockExecCommand = jest.mocked(bash.execCommand);
    const mockSearchSelect = jest.mocked(ui.searchSelectAndReturnFromArray);
    const mockGetCurrentBranch = jest.mocked(gitBranch_1.getCurrentBranch);
    beforeEach(() => {
        jest.clearAllMocks();
        mockGetCurrentBranch.mockResolvedValue('main');
    });
    describe('saveUntracked', () => {
        it('should save single untracked file', () => __awaiter(void 0, void 0, void 0, function* () {
            const file = 'test.txt';
            mockExecCommand
                .mockResolvedValueOnce({ stdout: file + '\n', stderr: '' })
                .mockResolvedValueOnce({ stdout: '/project', stderr: '' });
            mockSearchSelect.mockResolvedValue(file);
            mockFs.existsSync.mockReturnValue(false);
            mockFs.mkdirSync.mockImplementation(() => undefined);
            mockFs.writeFileSync.mockImplementation(() => undefined);
            yield (0, gitUntracked_1.saveUntracked)();
            expect(mockFs.mkdirSync).toHaveBeenCalled();
            expect(mockExecCommand).toHaveBeenCalledWith(expect.stringContaining('mv'));
            expect(mockFs.writeFileSync).toHaveBeenCalled();
        }));
        it('should save all untracked files', () => __awaiter(void 0, void 0, void 0, function* () {
            const files = ['test1.txt', 'test2.txt'];
            const topLevel = '/project';
            mockFs.existsSync.mockReturnValue(false);
            mockFs.mkdirSync.mockImplementation(() => undefined);
            mockFs.writeFileSync.mockImplementation(() => undefined);
            mockExecCommand
                .mockResolvedValueOnce({ stdout: files.join('\n'), stderr: '' }) // getUntrackedFiles
                .mockResolvedValueOnce({ stdout: topLevel, stderr: '' }); // getTopLevelPath
            mockSearchSelect.mockResolvedValue(gitFileUtils_1.allFiles);
            yield (0, gitUntracked_1.saveUntracked)();
            // mv commands for each file
            files.forEach(file => {
                expect(mockExecCommand).toHaveBeenCalledWith(expect.stringContaining(`mv ${path_1.default.join(topLevel, file)}`));
            });
        }));
    });
    describe('loadUntracked', () => {
        it('should load single untracked file', () => __awaiter(void 0, void 0, void 0, function* () {
            const file = 'test.txt';
            mockFs.readdirSync.mockReturnValue([
                { name: file, isFile: () => true },
                { name: 'pathInfo', isFile: () => true }
            ]);
            mockSearchSelect.mockResolvedValue(file);
            mockFs.readFileSync.mockReturnValue(JSON.stringify({
                [file]: '/project/test.txt'
            }));
            yield (0, gitUntracked_1.loadUntracked)();
            expect(mockExecCommand).toHaveBeenCalledWith(expect.stringContaining('mv'));
        }));
        it('should load all untracked files', () => __awaiter(void 0, void 0, void 0, function* () {
            const files = ['test1.txt', 'test2.txt'];
            const pathInfoObject = {
                'test1.txt': '/project/path/to/test1.txt',
                'test2.txt': '/project/path/to/test2.txt'
            };
            const branchName = 'main';
            mockGetCurrentBranch.mockResolvedValue(branchName);
            mockFs.readdirSync.mockReturnValue([
                { name: 'test1.txt', isFile: () => true },
                { name: 'test2.txt', isFile: () => true },
                { name: 'pathInfo', isFile: () => true }
            ]);
            mockFs.readFileSync.mockReturnValue(Buffer.from(JSON.stringify(pathInfoObject)));
            mockSearchSelect.mockResolvedValue(gitFileUtils_1.allFiles);
            yield (0, gitUntracked_1.loadUntracked)();
            // mv commands
            expect(mockExecCommand).toHaveBeenCalledTimes(2);
            files.forEach(file => {
                const sourcePath = path_1.default.join(filePaths_1.gitFilesFolder, gitConstants_1.UNTRACKED_CONFIG.untrackedFilesFolderName, branchName, file);
                const destPath = '/project/path/to';
                expect(mockExecCommand).toHaveBeenCalledWith(`mv ${sourcePath} ${destPath}`);
            });
        }));
        it('should throw error when path info is missing for a file', () => __awaiter(void 0, void 0, void 0, function* () {
            const pathInfoObject = {}; // empty path info
            const branchName = 'main';
            mockGetCurrentBranch.mockResolvedValue(branchName);
            mockFs.readdirSync.mockReturnValue([
                { name: 'test1.txt', isFile: () => true },
                { name: 'pathInfo', isFile: () => true }
            ]);
            mockFs.readFileSync.mockReturnValue(Buffer.from(JSON.stringify(pathInfoObject)));
            mockSearchSelect.mockResolvedValue('test1.txt');
            yield expect((0, gitUntracked_1.loadUntracked)()).rejects.toThrow('No path information found for file: test1.txt');
        }));
    });
});
