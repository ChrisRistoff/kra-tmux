"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const bash = __importStar(require("@/utils/bashHelper"));
const ui = __importStar(require("@/UI/generalUI"));
const vim = __importStar(require("@/utils/neovimHelper"));
const gitConflicts_1 = require("@/git/commands/gitConflicts");
const gitRestore_1 = require("@/git/commands/gitRestore");
const gitStash_1 = require("@/git/commands/gitStash");
const gitConstants_1 = require("@/git/config/gitConstants");
const gitFileUtils_1 = require("@//git/utils/gitFileUtils");
// Mock dependencies
jest.mock('@/utils/bashHelper');
jest.mock('@/UI/generalUI');
jest.mock('@/utils/neovimHelper');
describe('Git Commands', () => {
    const mockExecCommand = jest.mocked(bash.execCommand);
    const mockSearchSelect = jest.mocked(ui.searchSelectAndReturnFromArray);
    const mockOpenVim = jest.mocked(vim.openVim);
    beforeEach(() => {
        jest.clearAllMocks();
    });
    describe('handleConflicts', () => {
        it('should handle no conflicts scenario', () => __awaiter(void 0, void 0, void 0, function* () {
            mockExecCommand.mockResolvedValueOnce({ stdout: '', stderr: '' }); // No conflicted files
            const consoleSpy = jest.spyOn(console, 'log');
            yield (0, gitConflicts_1.handleConflicts)();
            expect(consoleSpy).toHaveBeenCalledWith('No Conflicts to Handle!');
            expect(mockOpenVim).not.toHaveBeenCalled();
            consoleSpy.mockRestore();
        }));
        it('should handle conflicts resolution', () => __awaiter(void 0, void 0, void 0, function* () {
            const conflictedFile = 'src/test.ts';
            mockExecCommand
                .mockResolvedValueOnce({ stdout: conflictedFile + '\n', stderr: '' }) // Initial conflicts check
                .mockResolvedValueOnce({ stdout: '', stderr: '' }); // No conflicts after resolution
            mockSearchSelect.mockResolvedValueOnce(conflictedFile);
            yield (0, gitConflicts_1.handleConflicts)();
            expect(mockOpenVim).toHaveBeenCalledWith(conflictedFile, '-c', 'Gvdiffsplit!');
            expect(mockExecCommand).toHaveBeenCalledWith(gitConstants_1.GIT_COMMANDS.GET_CONFLICTS);
        }));
    });
    describe('restoreFile', () => {
        it('should restore all files when "All" is selected', () => __awaiter(void 0, void 0, void 0, function* () {
            mockExecCommand.mockResolvedValueOnce({ stdout: 'file1.ts\nfile2.ts', stderr: '' });
            mockSearchSelect.mockResolvedValueOnce(gitFileUtils_1.allFiles);
            yield (0, gitRestore_1.restoreFile)();
            expect(mockExecCommand).toHaveBeenLastCalledWith('git restore ./');
        }));
        it('should restore specific file when selected', () => __awaiter(void 0, void 0, void 0, function* () {
            const fileToRestore = 'src/test.ts';
            mockExecCommand.mockResolvedValueOnce({ stdout: fileToRestore + '\n', stderr: '' });
            mockSearchSelect.mockResolvedValueOnce(fileToRestore);
            yield (0, gitRestore_1.restoreFile)();
            expect(mockExecCommand).toHaveBeenLastCalledWith(`git restore ${fileToRestore}`);
        }));
        it('should handle empty selection', () => __awaiter(void 0, void 0, void 0, function* () {
            mockExecCommand.mockResolvedValueOnce({ stdout: 'file1.ts\n', stderr: '' });
            mockSearchSelect.mockResolvedValueOnce('');
            yield (0, gitRestore_1.restoreFile)();
            expect(mockExecCommand).toHaveBeenCalledTimes(1); // Only the initial files check
        }));
    });
    describe('stash operations', () => {
        describe('applyOrDropStash', () => {
            it('should apply selected stash', () => __awaiter(void 0, void 0, void 0, function* () {
                const stashList = ['stash@{0}: WIP on main', 'stash@{1}: feature work'];
                mockExecCommand.mockResolvedValueOnce({ stdout: stashList.join('\n'), stderr: '' });
                mockSearchSelect
                    .mockResolvedValueOnce(stashList[0]) // Select first stash
                    .mockResolvedValueOnce('apply'); // Choose to apply
                yield (0, gitStash_1.applyOrDropStash)();
                expect(mockExecCommand).toHaveBeenLastCalledWith('git stash apply stash@{0}');
            }));
            it('should drop selected stash', () => __awaiter(void 0, void 0, void 0, function* () {
                const stashList = ['stash@{0}: WIP on main'];
                mockExecCommand.mockResolvedValueOnce({ stdout: stashList.join('\n'), stderr: '' });
                mockSearchSelect
                    .mockResolvedValueOnce(stashList[0])
                    .mockResolvedValueOnce('drop');
                yield (0, gitStash_1.applyOrDropStash)();
                expect(mockExecCommand).toHaveBeenLastCalledWith('git stash drop stash@{0}');
            }));
        });
        describe('dropMultipleStashes', () => {
            it('should drop multiple stashes until stop is selected', () => __awaiter(void 0, void 0, void 0, function* () {
                const stashList = ['stash@{0}: WIP', 'stash@{1}: feature'];
                mockExecCommand
                    .mockResolvedValueOnce({ stdout: stashList.join('\n'), stderr: '' })
                    .mockResolvedValueOnce({ stdout: stashList[1], stderr: '' });
                mockSearchSelect
                    .mockResolvedValueOnce(stashList[0]) // Select first stash
                    .mockResolvedValueOnce('stop'); // Stop after first drop
                yield (0, gitStash_1.dropMultipleStashes)();
                expect(mockExecCommand).toHaveBeenCalledWith('git stash drop stash@{0}');
            }));
        });
    });
});
