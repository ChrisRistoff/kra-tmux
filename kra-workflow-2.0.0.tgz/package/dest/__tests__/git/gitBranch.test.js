"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const bash = __importStar(require("@/utils/bashHelper"));
const neovim = __importStar(require("@/utils/neovimHelper"));
const gitBranch_1 = require("@/git/core/gitBranch");
const gitConstants_1 = require("@/git/config/gitConstants");
jest.mock('@/utils/bashHelper');
jest.mock('@/utils/neovimHelper');
describe('Git Branch Operations', () => {
    const originalTmux = process.env.TMUX;
    const mockExecCommand = jest.mocked(bash.execCommand);
    const mockSendKeysToTmux = jest.mocked(bash.sendKeysToTmuxTargetSession);
    const mockOpenVim = jest.mocked(neovim.openVim);
    beforeEach(() => {
        jest.clearAllMocks();
        if (originalTmux === undefined) {
            delete process.env.TMUX;
        }
        else {
            process.env.TMUX = originalTmux;
        }
    });
    afterAll(() => {
        if (originalTmux === undefined) {
            delete process.env.TMUX;
        }
        else {
            process.env.TMUX = originalTmux;
        }
    });
    describe('getCurrentBranch', () => {
        it('should return current branch name', () => __awaiter(void 0, void 0, void 0, function* () {
            mockExecCommand.mockResolvedValue({ stdout: 'main\nanother line\n', stderr: '' });
            const result = yield (0, gitBranch_1.getCurrentBranch)();
            expect(result).toBe('main');
            expect(mockExecCommand).toHaveBeenCalledWith(gitConstants_1.GIT_COMMANDS.GET_BRANCH);
        }));
        it('should handle error when getting branch name', () => __awaiter(void 0, void 0, void 0, function* () {
            mockExecCommand.mockRejectedValue(new Error('Not a git repository'));
            yield expect((0, gitBranch_1.getCurrentBranch)()).rejects.toThrow('Not a git repository');
        }));
    });
    describe('getTopLevelPath', () => {
        it('should return top level git path', () => __awaiter(void 0, void 0, void 0, function* () {
            const topLevel = '/path/to/repo';
            mockExecCommand.mockResolvedValue({ stdout: `${topLevel}\nother info\n`, stderr: '' });
            const result = yield (0, gitBranch_1.getTopLevelPath)();
            expect(result).toBe(topLevel);
            expect(mockExecCommand).toHaveBeenCalledWith(gitConstants_1.GIT_COMMANDS.GET_TOP_LEVEL);
        }));
    });
    describe('hardReset', () => {
        it('should perform hard reset and show branch changes', () => __awaiter(void 0, void 0, void 0, function* () {
            const consoleSpy = jest.spyOn(console, 'table').mockImplementation(() => { });
            mockExecCommand.mockResolvedValueOnce({ stdout: 'main\n', stderr: '' }) // getCurrentBranch
                .mockResolvedValueOnce({ stdout: 'origin/branch1\n', stderr: '' }) // before fetch
                .mockResolvedValueOnce({ stdout: '', stderr: '' }) // fetch
                .mockResolvedValueOnce({ stdout: 'origin/branch1\norigin/branch2\n', stderr: '' }) // after fetch
                .mockResolvedValueOnce({ stdout: 'HEAD is now at abc123', stderr: '' }); // reset
            yield (0, gitBranch_1.hardReset)();
            expect(mockExecCommand).toHaveBeenNthCalledWith(1, gitConstants_1.GIT_COMMANDS.GET_BRANCH);
            expect(mockExecCommand).toHaveBeenNthCalledWith(2, gitConstants_1.GIT_COMMANDS.GET_REMOTE_BRANCHES);
            expect(mockExecCommand).toHaveBeenNthCalledWith(3, 'git fetch --prune');
            expect(mockExecCommand).toHaveBeenNthCalledWith(4, gitConstants_1.GIT_COMMANDS.GET_REMOTE_BRANCHES);
            expect(mockExecCommand).toHaveBeenNthCalledWith(5, 'git reset --hard origin/main');
            expect(consoleSpy).toHaveBeenCalledWith({
                HEAD: 'HEAD is now at abc123',
                '': '=======================',
                'Fetched Branches': ['origin/branch2'],
                'Pruned Branches': []
            });
            consoleSpy.mockRestore();
        }));
        it('should handle errors during reset', () => __awaiter(void 0, void 0, void 0, function* () {
            const consoleSpy = jest.spyOn(console, 'error').mockImplementation(() => { });
            mockExecCommand.mockRejectedValue(new Error('Network error'));
            yield (0, gitBranch_1.hardReset)();
            expect(consoleSpy).toHaveBeenCalledWith('Failed to reset branch:', expect.any(Error));
            consoleSpy.mockRestore();
        }));
    });
    describe('getGitLog', () => {
        it('should open git log in tmux when TMUX is set', () => __awaiter(void 0, void 0, void 0, function* () {
            process.env.TMUX = '1';
            mockExecCommand.mockResolvedValue({ stdout: '', stderr: '' });
            yield (0, gitBranch_1.getGitLog)();
            expect(mockExecCommand).toHaveBeenCalledWith(expect.stringContaining('git log --graph'));
            expect(mockSendKeysToTmux).toHaveBeenCalledWith({
                command: expect.stringContaining('nvim -c \'set filetype=git\'')
            });
            expect(mockOpenVim).not.toHaveBeenCalled();
        }));
        it('should open git log with openVim when TMUX is not set', () => __awaiter(void 0, void 0, void 0, function* () {
            delete process.env.TMUX;
            mockExecCommand.mockResolvedValue({ stdout: '', stderr: '' });
            yield (0, gitBranch_1.getGitLog)();
            expect(mockExecCommand).toHaveBeenCalledWith(expect.stringContaining('git log --graph'));
            expect(mockOpenVim).toHaveBeenCalledWith('/tmp/git-log-XXXXXX.txt', '-c', 'set filetype=git');
            expect(mockSendKeysToTmux).not.toHaveBeenCalled();
        }));
        it('should handle errors when getting git log', () => __awaiter(void 0, void 0, void 0, function* () {
            const consoleSpy = jest.spyOn(console, 'error').mockImplementation(() => { });
            mockExecCommand.mockRejectedValue(new Error('Git log failed'));
            yield (0, gitBranch_1.getGitLog)();
            expect(consoleSpy).toHaveBeenCalledWith('Failed to run git log or open nvim:', expect.any(Error));
            consoleSpy.mockRestore();
        }));
    });
});
