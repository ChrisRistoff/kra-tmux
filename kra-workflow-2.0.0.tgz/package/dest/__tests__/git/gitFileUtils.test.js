"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const bash = __importStar(require("@/utils/bashHelper"));
const gitFileUtils_1 = require("@/git/utils/gitFileUtils");
const gitConstants_1 = require("@/git/config/gitConstants");
jest.mock('@/utils/bashHelper');
describe('Git File Utils', () => {
    const mockExecCommand = jest.mocked(bash.execCommand);
    beforeEach(() => {
        jest.clearAllMocks();
    });
    describe('getFileList', () => {
        it('should return array of files from command output', () => __awaiter(void 0, void 0, void 0, function* () {
            const files = ['file1.ts', 'file2.ts', 'file3.ts'];
            mockExecCommand.mockResolvedValue({ stdout: files.join('\n'), stderr: '' });
            const result = yield (0, gitFileUtils_1.getFileList)('test-command');
            expect(result).toEqual(files);
        }));
        it('should filter out empty lines', () => __awaiter(void 0, void 0, void 0, function* () {
            mockExecCommand.mockResolvedValue({ stdout: 'file1.ts\n\nfile2.ts\n\n', stderr: '' });
            const result = yield (0, gitFileUtils_1.getFileList)('test-command');
            expect(result).toEqual(['file1.ts', 'file2.ts']);
        }));
        it('should handle undefined response', () => __awaiter(void 0, void 0, void 0, function* () {
            mockExecCommand.mockResolvedValue(undefined);
            const result = yield (0, gitFileUtils_1.getFileList)('test-command');
            expect(result).toEqual([]);
        }));
        it('should handle null stdout', () => __awaiter(void 0, void 0, void 0, function* () {
            mockExecCommand.mockResolvedValue({ stdout: null, stderr: '' });
            const result = yield (0, gitFileUtils_1.getFileList)('test-command');
            expect(result).toEqual([]);
        }));
        it('should handle empty stdout', () => __awaiter(void 0, void 0, void 0, function* () {
            mockExecCommand.mockResolvedValue({ stdout: '', stderr: '' });
            const result = yield (0, gitFileUtils_1.getFileList)('test-command');
            expect(result).toEqual([]);
        }));
        it('should propagate errors from bash.execCommand', () => __awaiter(void 0, void 0, void 0, function* () {
            // bash.execCommand rejects, getFileList should return the error
            mockExecCommand.mockRejectedValue(new Error('Git command failed'));
            yield expect((0, gitFileUtils_1.getFileList)('test-command')).rejects.toThrow('Git command failed');
        }));
        it('should return files even when stderr has messages', () => __awaiter(void 0, void 0, void 0, function* () {
            // stderr contains warnings, we still use stdout to return our file list
            mockExecCommand.mockResolvedValue({
                stdout: 'file1.ts\nfile2.ts',
                stderr: 'warning: some git warning'
            });
            const result = yield (0, gitFileUtils_1.getFileList)('test-command');
            expect(result).toEqual(['file1.ts', 'file2.ts']);
        }));
    });
    describe('file status utilities', () => {
        it('should get modified files', () => __awaiter(void 0, void 0, void 0, function* () {
            const files = ['modified1.ts', 'modified2.ts'];
            mockExecCommand.mockResolvedValue({ stdout: files.join('\n'), stderr: '' });
            const result = yield (0, gitFileUtils_1.getModifiedFiles)();
            expect(mockExecCommand).toHaveBeenCalledWith(gitConstants_1.GIT_COMMANDS.GET_MODIFIED);
            expect(result).toEqual(files);
        }));
        it('should get untracked files', () => __awaiter(void 0, void 0, void 0, function* () {
            const files = ['untracked1.ts', 'untracked2.ts'];
            mockExecCommand.mockResolvedValue({ stdout: files.join('\n'), stderr: '' });
            const result = yield (0, gitFileUtils_1.getUntrackedFiles)();
            expect(mockExecCommand).toHaveBeenCalledWith(gitConstants_1.GIT_COMMANDS.GET_UNTRACKED);
            expect(result).toEqual(files);
        }));
        it('should get conflicted files', () => __awaiter(void 0, void 0, void 0, function* () {
            const files = ['conflict1.ts', 'conflict2.ts'];
            mockExecCommand.mockResolvedValue({ stdout: files.join('\n'), stderr: '' });
            const result = yield (0, gitFileUtils_1.getConflictedFiles)();
            expect(mockExecCommand).toHaveBeenCalledWith(gitConstants_1.GIT_COMMANDS.GET_CONFLICTS);
            expect(result).toEqual(files);
        }));
        it('should get stashes', () => __awaiter(void 0, void 0, void 0, function* () {
            const stashes = ['stash@{0}: WIP', 'stash@{1}: feature'];
            mockExecCommand.mockResolvedValue({ stdout: stashes.join('\n'), stderr: '' });
            const result = yield (0, gitFileUtils_1.getStashes)();
            expect(mockExecCommand).toHaveBeenCalledWith(gitConstants_1.GIT_COMMANDS.GET_STASHES);
            expect(result).toEqual(stashes);
        }));
        it('should handle no modified files', () => __awaiter(void 0, void 0, void 0, function* () {
            mockExecCommand.mockResolvedValue({ stdout: '', stderr: '' });
            const result = yield (0, gitFileUtils_1.getModifiedFiles)();
            expect(result).toEqual([]);
        }));
        it('should handle no untracked files', () => __awaiter(void 0, void 0, void 0, function* () {
            mockExecCommand.mockResolvedValue({ stdout: '', stderr: '' });
            const result = yield (0, gitFileUtils_1.getUntrackedFiles)();
            expect(result).toEqual([]);
        }));
        it('should handle no conflicted files', () => __awaiter(void 0, void 0, void 0, function* () {
            mockExecCommand.mockResolvedValue({ stdout: '', stderr: '' });
            const result = yield (0, gitFileUtils_1.getConflictedFiles)();
            expect(result).toEqual([]);
        }));
        it('should handle no stashes', () => __awaiter(void 0, void 0, void 0, function* () {
            mockExecCommand.mockResolvedValue({ stdout: '', stderr: '' });
            const result = yield (0, gitFileUtils_1.getStashes)();
            expect(result).toEqual([]);
        }));
    });
});
