"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const manageSessions_1 = require("@/tmux/commands/manageSessions");
const sessionUtils_1 = require("@/tmux/utils/sessionUtils");
const fs = __importStar(require("fs/promises"));
const generalUI = __importStar(require("@/UI/generalUI"));
const filePaths_1 = require("@/filePaths");
jest.mock('@/tmux/utils/sessionUtils');
jest.mock('fs/promises');
jest.mock('@/UI/generalUI');
describe('Session Management', () => {
    const mockGetSavedSessionsNames = jest.mocked(sessionUtils_1.getSavedSessionsNames);
    const mockGetSavedSessionsByFilePath = jest.mocked(sessionUtils_1.getSavedSessionsByFilePath);
    const mockFsRm = jest.mocked(fs.rm);
    const mockGeneralUI = jest.mocked(generalUI);
    beforeEach(() => {
        jest.clearAllMocks();
    });
    describe('deleteSession', () => {
        it('should delete a session file when confirmed', () => __awaiter(void 0, void 0, void 0, function* () {
            const testFileName = 'test-session';
            const testSessions = {
                [testFileName]: {
                    windows: [{ windowName: 'test-window', panes: [], layout: '', currentPath: '' }]
                }
            };
            mockGetSavedSessionsNames.mockResolvedValue([testFileName]);
            mockGetSavedSessionsByFilePath.mockResolvedValue(testSessions);
            mockGeneralUI.searchSelectAndReturnFromArray.mockResolvedValue(testFileName);
            mockGeneralUI.promptUserYesOrNo.mockResolvedValue(true);
            yield (0, manageSessions_1.deleteSession)();
            expect(mockFsRm).toHaveBeenCalledWith(`${filePaths_1.sessionFilesFolder}/${testFileName}`);
        }));
        it('should not delete session when not confirmed', () => __awaiter(void 0, void 0, void 0, function* () {
            const testFileName = 'test-session';
            const testSessions = {
                [testFileName]: {
                    windows: [{ windowName: 'test-window', panes: [], layout: '', currentPath: '' }]
                }
            };
            mockGetSavedSessionsNames.mockResolvedValue([testFileName]);
            mockGetSavedSessionsByFilePath.mockResolvedValue(testSessions);
            mockGeneralUI.searchSelectAndReturnFromArray.mockResolvedValue(testFileName);
            mockGeneralUI.promptUserYesOrNo.mockResolvedValue(false);
            yield (0, manageSessions_1.deleteSession)();
            expect(mockFsRm).not.toHaveBeenCalled();
        }));
    });
});
