"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = __importStar(require("fs/promises"));
const bash = __importStar(require("@/utils/bashHelper"));
const nvim = __importStar(require("@/utils/neovimHelper"));
const generalUI = __importStar(require("@/UI/generalUI"));
const sessionUtils_1 = require("@/tmux/utils/sessionUtils");
const common_1 = require("@/utils/common");
const common_2 = require("@/tmux/utils/common");
const saveSessions_1 = require("@/tmux/commands/saveSessions");
jest.mock('fs/promises');
jest.mock('@/utils/bashHelper');
jest.mock('@/utils/neovimHelper');
jest.mock('@/UI/generalUI');
jest.mock('@/tmux/utils/sessionUtils');
jest.mock('@/utils/common');
jest.mock('@/tmux/utils/common');
jest.mock('@/filePaths', () => ({
    nvimSessionsPath: '/mock/nvim/sessions',
    sessionFilesFolder: '/mock/session/files'
}));
describe('saveSessions', () => {
    const mockFs = jest.mocked(fs);
    const mockBash = jest.mocked(bash);
    const mockNvim = jest.mocked(nvim);
    const mockGeneralUI = jest.mocked(generalUI);
    const mockGetCurrentSessions = jest.mocked(sessionUtils_1.getCurrentSessions);
    const mockGetDateString = jest.mocked(sessionUtils_1.getDateString);
    const mockFilterGitKeep = jest.mocked(common_1.filterGitKeep);
    const mockUpdateCurrentSession = jest.mocked(common_2.updateCurrentSession);
    const mockSessions = {
        'dev-session': {
            windows: [
                {
                    windowName: 'editor',
                    layout: 'main-vertical',
                    currentCommand: 'nvim',
                    currentPath: '/home/user/project',
                    gitRepoLink: 'git@github.com:user/repo.git',
                    panes: [
                        {
                            currentCommand: 'nvim',
                            currentPath: '/home/user/project/src',
                            gitRepoLink: 'git@github.com:user/repo.git',
                            paneLeft: '0',
                            paneTop: '0'
                        },
                        {
                            currentCommand: 'bash',
                            currentPath: '/home/user/project',
                            gitRepoLink: 'git@github.com:user/repo.git',
                            paneLeft: '1',
                            paneTop: '0'
                        }
                    ]
                },
                {
                    windowName: 'terminal',
                    layout: '15x15x15',
                    currentCommand: 'bash',
                    currentPath: '/home/user',
                    gitRepoLink: undefined,
                    panes: [
                        {
                            currentCommand: 'htop',
                            currentPath: '/home/user',
                            gitRepoLink: undefined,
                            paneLeft: '0',
                            paneTop: '0'
                        }
                    ]
                }
            ]
        }
    };
    beforeEach(() => {
        jest.clearAllMocks();
        // Default mock implementations
        mockFs.writeFile.mockResolvedValue();
        mockFs.readdir.mockResolvedValue([]);
        mockFs.rm.mockResolvedValue();
        mockBash.execCommand.mockResolvedValue({ stdout: '', stderr: '' });
        mockNvim.saveNvimSession.mockResolvedValue();
        mockGeneralUI.searchAndSelect.mockResolvedValue('test-session');
        mockGeneralUI.promptUserYesOrNo.mockResolvedValue(false);
        mockGetCurrentSessions.mockResolvedValue(mockSessions);
        mockGetDateString.mockReturnValue('2024-01-15');
        mockFilterGitKeep.mockImplementation((files) => files);
        mockUpdateCurrentSession.mockResolvedValue();
    });
    describe('quickSave', () => {
        it('should save sessions to file when sessions exist', () => __awaiter(void 0, void 0, void 0, function* () {
            yield (0, saveSessions_1.quickSave)('quick-save-test');
            expect(mockGetCurrentSessions).toHaveBeenCalled();
            expect(mockFs.writeFile).toHaveBeenCalledWith('/mock/session/files/quick-save-test', JSON.stringify(mockSessions, null, 2), 'utf-8');
        }));
        it('should not save when no sessions exist', () => __awaiter(void 0, void 0, void 0, function* () {
            mockGetCurrentSessions.mockResolvedValue({});
            yield (0, saveSessions_1.quickSave)('empty-sessions');
            expect(mockGetCurrentSessions).toHaveBeenCalled();
            expect(mockFs.writeFile).not.toHaveBeenCalled();
        }));
        it('should handle complex session data', () => __awaiter(void 0, void 0, void 0, function* () {
            const complexSessions = {
                'session1': {
                    windows: [
                        {
                            windowName: 'main',
                            layout: 'tiled',
                            currentCommand: 'vim',
                            currentPath: '/workspace',
                            gitRepoLink: 'https://github.com/test/repo.git',
                            panes: [
                                {
                                    currentCommand: 'vim',
                                    currentPath: '/workspace/src',
                                    gitRepoLink: 'https://github.com/test/repo.git',
                                    paneLeft: '0',
                                    paneTop: '0'
                                }
                            ]
                        }
                    ]
                },
                'session2': {
                    windows: [
                        {
                            windowName: 'logs',
                            layout: '15x15x15',
                            currentCommand: 'tail',
                            currentPath: '/var/log',
                            gitRepoLink: undefined,
                            panes: [
                                {
                                    currentCommand: 'tail',
                                    currentPath: '/var/log',
                                    gitRepoLink: undefined,
                                    paneLeft: '0',
                                    paneTop: '0'
                                }
                            ]
                        }
                    ]
                }
            };
            mockGetCurrentSessions.mockResolvedValue(complexSessions);
            yield (0, saveSessions_1.quickSave)('complex-save');
            expect(mockFs.writeFile).toHaveBeenCalledWith('/mock/session/files/complex-save', JSON.stringify(complexSessions, null, 2), 'utf-8');
        }));
    });
    describe('saveSessionsToFile', () => {
        it('should save sessions with user-provided filename', () => __awaiter(void 0, void 0, void 0, function* () {
            mockGeneralUI.searchAndSelect.mockResolvedValue('my-session');
            const consoleSpy = jest.spyOn(console, 'log').mockImplementation();
            yield (0, saveSessions_1.saveSessionsToFile)();
            expect(mockGetCurrentSessions).toHaveBeenCalled();
            expect(mockGeneralUI.searchAndSelect).toHaveBeenCalled();
            expect(mockNvim.saveNvimSession).toHaveBeenCalledWith('my-session', 'dev-session', 0, 0);
            expect(mockFs.writeFile).toHaveBeenCalledWith('/mock/session/files/my-session', JSON.stringify(mockSessions, null, 2), 'utf-8');
            expect(mockUpdateCurrentSession).toHaveBeenCalledWith('my-session');
            expect(consoleSpy).toHaveBeenCalledWith('Save Successful!');
            consoleSpy.mockRestore();
        }));
        it('should not save when no sessions exist', () => __awaiter(void 0, void 0, void 0, function* () {
            mockGetCurrentSessions.mockResolvedValue({});
            const consoleSpy = jest.spyOn(console, 'log').mockImplementation();
            yield (0, saveSessions_1.saveSessionsToFile)();
            expect(consoleSpy).toHaveBeenCalledWith('No sessions found to save!');
            expect(mockFs.writeFile).not.toHaveBeenCalled();
            expect(mockNvim.saveNvimSession).not.toHaveBeenCalled();
            consoleSpy.mockRestore();
        }));
        it('should use git branch name when user chooses to', () => __awaiter(void 0, void 0, void 0, function* () {
            const branchName = 'feature/new-feature';
            const userInput = 'work-session';
            mockBash.execCommand.mockResolvedValue({ stdout: `${branchName}\n`, stderr: '' });
            mockGeneralUI.promptUserYesOrNo.mockResolvedValue(true);
            mockGeneralUI.searchAndSelect.mockResolvedValue(userInput);
            mockFilterGitKeep.mockReturnValue(['existing-session', 'another-session']);
            yield (0, saveSessions_1.saveSessionsToFile)();
            const expectedFileName = `${branchName}-${userInput}-2024-01-15`;
            expect(mockBash.execCommand).toHaveBeenCalledWith('git rev-parse --abbrev-ref HEAD');
            expect(mockGeneralUI.promptUserYesOrNo).toHaveBeenCalledWith(`Would you like to use ${branchName} as part of your name for your save?`);
            expect(mockFs.writeFile).toHaveBeenCalledWith(`/mock/session/files/${expectedFileName}`, JSON.stringify(mockSessions, null, 2), 'utf-8');
            expect(mockUpdateCurrentSession).toHaveBeenCalledWith(expectedFileName);
        }));
        it('should handle git command failure gracefully', () => __awaiter(void 0, void 0, void 0, function* () {
            mockBash.execCommand.mockRejectedValue(new Error('Not a git repository'));
            mockGeneralUI.searchAndSelect.mockResolvedValue('manual-session');
            yield (0, saveSessions_1.saveSessionsToFile)();
            expect(mockGeneralUI.searchAndSelect).toHaveBeenCalledWith({
                itemsArray: [],
                prompt: 'Please write a name for save: ',
            });
            expect(mockGeneralUI.promptUserYesOrNo).not.toHaveBeenCalled();
            expect(mockFs.writeFile).toHaveBeenCalledWith('/mock/session/files/manual-session', JSON.stringify(mockSessions, null, 2), 'utf-8');
        }));
        it('should not use git branch when user declines', () => __awaiter(void 0, void 0, void 0, function* () {
            const branchName = 'main';
            mockBash.execCommand.mockResolvedValue({ stdout: `${branchName}\n`, stderr: '' });
            mockGeneralUI.promptUserYesOrNo.mockResolvedValue(false);
            mockGeneralUI.searchAndSelect.mockResolvedValue('custom-session');
            mockFilterGitKeep.mockReturnValue(['session1', 'session2']);
            yield (0, saveSessions_1.saveSessionsToFile)();
            expect(mockGeneralUI.promptUserYesOrNo).toHaveBeenCalledWith(`Would you like to use ${branchName} as part of your name for your save?`);
            expect(mockGeneralUI.searchAndSelect).toHaveBeenCalledWith({
                prompt: 'Please write a name for save: ',
                itemsArray: ['session1', 'session2'],
            });
            expect(mockFs.writeFile).toHaveBeenCalledWith('/mock/session/files/custom-session', JSON.stringify(mockSessions, null, 2), 'utf-8');
        }));
        it('should save neovim sessions only for nvim panes', () => __awaiter(void 0, void 0, void 0, function* () {
            const mixedSessions = {
                'mixed-session': {
                    windows: [
                        {
                            windowName: 'editor',
                            layout: 'main-vertical',
                            currentCommand: 'nvim',
                            currentPath: '/project',
                            gitRepoLink: undefined,
                            panes: [
                                {
                                    currentCommand: 'nvim',
                                    currentPath: '/project/src',
                                    gitRepoLink: undefined,
                                    paneLeft: '0',
                                    paneTop: '0'
                                },
                                {
                                    currentCommand: 'bash',
                                    currentPath: '/project',
                                    gitRepoLink: undefined,
                                    paneLeft: '1',
                                    paneTop: '0'
                                },
                                {
                                    currentCommand: 'nvim',
                                    currentPath: '/project/tests',
                                    gitRepoLink: undefined,
                                    paneLeft: '0',
                                    paneTop: '1'
                                }
                            ]
                        }
                    ]
                }
            };
            mockGetCurrentSessions.mockResolvedValue(mixedSessions);
            mockGeneralUI.searchAndSelect.mockResolvedValue('mixed-save');
            yield (0, saveSessions_1.saveSessionsToFile)();
            expect(mockNvim.saveNvimSession).toHaveBeenCalledTimes(2);
            expect(mockNvim.saveNvimSession).toHaveBeenCalledWith('mixed-save', 'mixed-session', 0, 0);
            expect(mockNvim.saveNvimSession).toHaveBeenCalledWith('mixed-save', 'mixed-session', 0, 2);
            expect(mockNvim.saveNvimSession).not.toHaveBeenCalledWith('mixed-save', 'mixed-session', 0, 1);
        }));
        it('should handle empty search and select result', () => __awaiter(void 0, void 0, void 0, function* () {
            mockGeneralUI.searchAndSelect.mockResolvedValue('');
            const consoleSpy = jest.spyOn(console, 'log').mockImplementation();
            yield (0, saveSessions_1.saveSessionsToFile)();
            expect(consoleSpy).toHaveBeenCalledWith('Save cancelled.');
            expect(mockFs.writeFile).not.toHaveBeenCalled();
            consoleSpy.mockRestore();
        }));
        it('should clean up stale nvim sessions', () => __awaiter(void 0, void 0, void 0, function* () {
            const sessionsWithMixedCommands = {
                'cleanup-session': {
                    windows: [
                        {
                            windowName: 'mixed',
                            layout: 'main-vertical',
                            currentCommand: 'bash',
                            currentPath: '/home',
                            gitRepoLink: undefined,
                            panes: [
                                {
                                    currentCommand: 'bash', // Should trigger cleanup
                                    currentPath: '/home',
                                    gitRepoLink: undefined,
                                    paneLeft: '0',
                                    paneTop: '0'
                                },
                                {
                                    currentCommand: 'nvim', // Should not trigger cleanup
                                    currentPath: '/home/project',
                                    gitRepoLink: undefined,
                                    paneLeft: '1',
                                    paneTop: '0'
                                }
                            ]
                        }
                    ]
                }
            };
            mockGetCurrentSessions.mockResolvedValue(sessionsWithMixedCommands);
            mockGeneralUI.searchAndSelect.mockResolvedValue('cleanup-test');
            yield (0, saveSessions_1.saveSessionsToFile)();
            // cleanup happens asynchronously, so we need to wait a bit
            yield new Promise(resolve => setTimeout(resolve, 10));
            expect(mockFs.rm).toHaveBeenCalledWith('/mock/nvim/sessions/cleanup-session_0_0');
            expect(mockFs.rm).not.toHaveBeenCalledWith('/mock/nvim/sessions/cleanup-session_0_1');
        }));
    });
});
