"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = __importStar(require("fs/promises"));
const bash = __importStar(require("@/utils/bashHelper"));
const filePaths_1 = require("@/filePaths");
const formatters_1 = require("@/tmux/utils/formatters");
const common_1 = require("@/utils/common");
const sessionUtils_1 = require("@/tmux/utils/sessionUtils");
jest.mock('fs/promises');
jest.mock('@/utils/bashHelper');
jest.mock('@/filePaths');
jest.mock('@/tmux/utils/formatters');
jest.mock('@/utils/common');
const mockedFs = fs;
const mockedBash = bash;
const mockedFormatWindow = formatters_1.formatWindow;
const mockedFormatPane = formatters_1.formatPane;
const mockedFilterGitKeep = common_1.filterGitKeep;
filePaths_1.sessionFilesFolder = '/mock/sessions/path';
describe('Tmux Session Management', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });
    describe('getCurrentSessions', () => {
        it('should return current tmux sessions with windows', () => __awaiter(void 0, void 0, void 0, function* () {
            // Mock bash command output
            mockedBash.execCommand.mockResolvedValueOnce({
                stdout: 'session1\nsession2',
                stderr: '',
                code: 0
            });
            // Mock getWindowsForSession calls (indirectly through bash commands)
            mockedBash.execCommand
                .mockResolvedValueOnce({
                stdout: 'window1:bash:/home/user:layout1',
                stderr: '',
                code: 0
            })
                .mockResolvedValueOnce({
                stdout: '1234:/home/user:0x0',
                stderr: '',
                code: 0
            })
                .mockResolvedValueOnce({
                stdout: 'window1:zsh:/home/user:layout1',
                stderr: '',
                code: 0
            })
                .mockResolvedValueOnce({
                stdout: '5678:/home/user:0x0',
                stderr: '',
                code: 0
            });
            const mockWindow1 = {
                windowName: 'window1',
                currentCommand: 'bash',
                currentPath: '/home/user',
                gitRepoLink: undefined,
                layout: 'layout1',
                panes: []
            };
            const mockWindow2 = {
                windowName: 'window1',
                currentCommand: 'zsh',
                currentPath: '/home/user',
                gitRepoLink: undefined,
                layout: 'layout1',
                panes: []
            };
            const mockPane1 = {
                currentCommand: 'bash',
                currentPath: '/home/user',
                gitRepoLink: undefined,
                paneLeft: '0',
                paneTop: '0'
            };
            const mockPane2 = {
                currentCommand: 'zsh',
                currentPath: '/home/user',
                gitRepoLink: undefined,
                paneLeft: '0',
                paneTop: '0'
            };
            mockedFormatWindow.mockResolvedValueOnce(mockWindow1);
            mockedFormatWindow.mockResolvedValueOnce(mockWindow2);
            mockedFormatPane.mockResolvedValueOnce(mockPane1);
            mockedFormatPane.mockResolvedValueOnce(mockPane2);
            const result = yield (0, sessionUtils_1.getCurrentSessions)();
            expect(result).toEqual({
                session1: {
                    windows: [Object.assign(Object.assign({}, mockWindow1), { panes: [mockPane1] })]
                },
                session2: {
                    windows: [Object.assign(Object.assign({}, mockWindow2), { panes: [mockPane2] })]
                }
            });
            expect(mockedBash.execCommand).toHaveBeenCalledWith(`tmux list-sessions -F '#S'`);
        }));
        it('should return empty object when tmux command fails', () => __awaiter(void 0, void 0, void 0, function* () {
            mockedBash.execCommand.mockRejectedValueOnce(new Error('tmux not running'));
            const result = yield (0, sessionUtils_1.getCurrentSessions)();
            expect(result).toEqual({});
        }));
        it('should handle empty session list', () => __awaiter(void 0, void 0, void 0, function* () {
            // stdout is empty string, split('\n') creates ['']
            mockedBash.execCommand
                .mockResolvedValueOnce({
                stdout: '',
                stderr: '',
                code: 0
            })
                // call to list-windows for the empty string session
                .mockResolvedValueOnce({
                stdout: '',
                stderr: '',
                code: 0
            })
                // getPanesForWindow call that happens even when formatWindow returns undefined
                .mockResolvedValueOnce({
                stdout: '',
                stderr: '',
                code: 0
            });
            // formatWindow to return a valid window object even for empty input
            // because code tries to set panes property
            const emptyWindow = {
                windowName: '',
                currentCommand: '',
                currentPath: '',
                gitRepoLink: undefined,
                layout: '',
                panes: []
            };
            mockedFormatWindow.mockResolvedValueOnce(emptyWindow);
            mockedFormatPane.mockResolvedValue({
                currentCommand: '',
                currentPath: '',
                gitRepoLink: undefined,
                paneLeft: '0',
                paneTop: '0'
            });
            const result = yield (0, sessionUtils_1.getCurrentSessions)();
            // result will have an empty string key with the empty window
            expect(result).toEqual({
                '': { windows: [emptyWindow] }
            });
        }));
        it('should handle truly no sessions', () => __awaiter(void 0, void 0, void 0, function* () {
            // tmux has no sessions at all
            mockedBash.execCommand.mockRejectedValueOnce(new Error('no sessions'));
            const result = yield (0, sessionUtils_1.getCurrentSessions)();
            expect(result).toEqual({});
        }));
    });
    describe('getWindowsForSession', () => {
        it('should return formatted windows with panes for a session', () => __awaiter(void 0, void 0, void 0, function* () {
            mockedBash.execCommand
                .mockResolvedValueOnce({
                stdout: 'window1:vim:/home/user:layout1\nwindow2:bash:/tmp:layout2',
                stderr: '',
                code: 0
            })
                .mockResolvedValueOnce({
                stdout: '1111:/home/user:0x0',
                stderr: '',
                code: 0
            })
                .mockResolvedValueOnce({
                stdout: '2222:/tmp:0x0',
                stderr: '',
                code: 0
            });
            const mockWindow1 = {
                windowName: 'window1',
                currentCommand: 'vim',
                currentPath: '/home/user',
                gitRepoLink: 'https://github.com/user/repo',
                layout: 'layout1',
                panes: []
            };
            const mockWindow2 = {
                windowName: 'window2',
                currentCommand: 'bash',
                currentPath: '/tmp',
                gitRepoLink: undefined,
                layout: 'layout2',
                panes: []
            };
            const mockPane1 = {
                currentCommand: 'vim',
                currentPath: '/home/user',
                gitRepoLink: undefined,
                paneLeft: '0',
                paneTop: '0'
            };
            const mockPane2 = {
                currentCommand: 'bash',
                currentPath: '/tmp',
                gitRepoLink: undefined,
                paneLeft: '0',
                paneTop: '0'
            };
            mockedFormatWindow.mockResolvedValueOnce(mockWindow1);
            mockedFormatWindow.mockResolvedValueOnce(mockWindow2);
            mockedFormatPane.mockResolvedValueOnce(mockPane1);
            mockedFormatPane.mockResolvedValueOnce(mockPane2);
            const result = yield (0, sessionUtils_1.getWindowsForSession)('test-session');
            expect(result).toEqual([
                Object.assign(Object.assign({}, mockWindow1), { panes: [mockPane1] }),
                Object.assign(Object.assign({}, mockWindow2), { panes: [mockPane2] })
            ]);
            expect(mockedBash.execCommand).toHaveBeenCalledWith(`tmux list-windows -t test-session -F "#{window_name}:#{pane_current_command}:#{pane_current_path}:#{window_layout}"`);
        }));
        it('should handle empty windows output', () => __awaiter(void 0, void 0, void 0, function* () {
            // windows stdout is empty string, split('\n') creates ['']
            mockedBash.execCommand
                .mockResolvedValueOnce({
                stdout: '',
                stderr: '',
                code: 0
            })
                // getPanesForWindow call for empty window
                .mockResolvedValueOnce({
                stdout: '',
                stderr: '',
                code: 0
            });
            // formatWindow to return a valid window object
            // code try to set panes property
            const emptyWindow = {
                windowName: '',
                currentCommand: '',
                currentPath: '',
                gitRepoLink: undefined,
                layout: '',
                panes: []
            };
            mockedFormatWindow.mockResolvedValueOnce(emptyWindow);
            mockedFormatPane.mockResolvedValue({
                currentCommand: '',
                currentPath: '',
                gitRepoLink: undefined,
                paneLeft: '0',
                paneTop: '0'
            });
            const result = yield (0, sessionUtils_1.getWindowsForSession)('empty-session');
            expect(result).toEqual([emptyWindow]);
        }));
    });
    describe('getPanesForWindow', () => {
        it('should return formatted panes for a window', () => __awaiter(void 0, void 0, void 0, function* () {
            mockedBash.execCommand.mockResolvedValueOnce({
                stdout: '1234:/home/user:0x0\n5678:/tmp:10x5',
                stderr: '',
                code: 0
            });
            const mockPane1 = {
                currentCommand: 'bash',
                currentPath: '/home/user',
                gitRepoLink: undefined,
                paneLeft: '0',
                paneTop: '0'
            };
            const mockPane2 = {
                currentCommand: 'vim',
                currentPath: '/tmp',
                gitRepoLink: undefined,
                paneLeft: '10',
                paneTop: '5'
            };
            mockedFormatPane.mockResolvedValueOnce(mockPane1);
            mockedFormatPane.mockResolvedValueOnce(mockPane2);
            const result = yield (0, sessionUtils_1.getPanesForWindow)('test-session', 0);
            expect(result).toEqual([mockPane1, mockPane2]);
            expect(mockedBash.execCommand).toHaveBeenCalledWith(`tmux list-panes -t test-session:0 -F "#{pane_pid}:#{pane_current_path}:#{pane_left}x#{pane_top}"`);
        }));
        it('should return empty array when pane command fails', () => __awaiter(void 0, void 0, void 0, function* () {
            const consoleSpy = jest.spyOn(console, 'log').mockImplementation();
            mockedBash.execCommand.mockRejectedValueOnce(new Error('No such window'));
            const result = yield (0, sessionUtils_1.getPanesForWindow)('test-session', 99);
            expect(result).toEqual([]);
            expect(consoleSpy).toHaveBeenCalledWith('Error getting panes:', expect.any(Error));
            consoleSpy.mockRestore();
        }));
    });
    describe('getSavedSessionsNames', () => {
        it('should return filtered session names', () => __awaiter(void 0, void 0, void 0, function* () {
            const mockFiles = ['session1.json', 'session2.json', '.gitkeep'];
            const filteredFiles = ['session1.json', 'session2.json'];
            mockedFs.readdir.mockResolvedValueOnce(mockFiles);
            mockedFilterGitKeep.mockReturnValueOnce(filteredFiles);
            const result = yield (0, sessionUtils_1.getSavedSessionsNames)();
            expect(result).toEqual(filteredFiles);
            expect(mockedFs.readdir).toHaveBeenCalledWith(filePaths_1.sessionFilesFolder);
            expect(mockedFilterGitKeep).toHaveBeenCalledWith(mockFiles);
        }));
        it('should return empty array when directory read fails', () => __awaiter(void 0, void 0, void 0, function* () {
            const consoleSpy = jest.spyOn(console, 'error').mockImplementation();
            mockedFs.readdir.mockRejectedValueOnce(new Error('Directory not found'));
            const result = yield (0, sessionUtils_1.getSavedSessionsNames)();
            expect(result).toEqual([]);
            expect(consoleSpy).toHaveBeenCalledWith('Error reading directory:', expect.any(Error));
            consoleSpy.mockRestore();
        }));
    });
    describe('getSavedSessionsByFilePath', () => {
        it('should parse and return sessions from file', () => __awaiter(void 0, void 0, void 0, function* () {
            const mockSessionData = {
                'saved-session': {
                    windows: [
                        {
                            windowName: 'main',
                            currentCommand: 'bash',
                            currentPath: '/home/user',
                            gitRepoLink: 'https://github.com/user/project',
                            layout: 'even-horizontal',
                            panes: []
                        }
                    ]
                }
            };
            mockedFs.readFile.mockResolvedValueOnce(Buffer.from(JSON.stringify(mockSessionData)));
            const result = yield (0, sessionUtils_1.getSavedSessionsByFilePath)('/path/to/session.json');
            expect(result).toEqual(mockSessionData);
            expect(mockedFs.readFile).toHaveBeenCalledWith('/path/to/session.json');
        }));
        it('should throw error for invalid JSON', () => __awaiter(void 0, void 0, void 0, function* () {
            mockedFs.readFile.mockResolvedValueOnce(Buffer.from('invalid json'));
            yield expect((0, sessionUtils_1.getSavedSessionsByFilePath)('/path/to/invalid.json'))
                .rejects.toThrow();
        }));
        it('should throw error when file read fails', () => __awaiter(void 0, void 0, void 0, function* () {
            mockedFs.readFile.mockRejectedValueOnce(new Error('File not found'));
            yield expect((0, sessionUtils_1.getSavedSessionsByFilePath)('/path/to/missing.json'))
                .rejects.toThrow('File not found');
        }));
    });
    describe('getDateString', () => {
        beforeEach(() => {
            // Date to return consistent results
            jest.useFakeTimers();
        });
        afterEach(() => {
            jest.useRealTimers();
        });
        it('should format current date correctly', () => {
            // specific date for testing
            const mockDate = new Date('2023-08-25T14:30:45.123Z');
            jest.setSystemTime(mockDate);
            const result = (0, sessionUtils_1.getDateString)();
            // test assumes the date toString format, adjust as needed
            expect(result).toMatch(/^\d{4}-\w{3}-\d{2}-\d{2}:\d{2}$/);
        });
        it('should handle different times consistently', () => {
            const mockDate1 = new Date('2023-12-31T23:59:59.999Z');
            jest.setSystemTime(mockDate1);
            const result1 = (0, sessionUtils_1.getDateString)();
            const mockDate2 = new Date('2024-01-01T00:00:00.000Z');
            jest.setSystemTime(mockDate2);
            const result2 = (0, sessionUtils_1.getDateString)();
            expect(result1).not.toBe(result2);
            expect(result1).toMatch(/^\d{4}-\w{3}-\d{2}-\d{2}:\d{2}$/);
            expect(result2).toMatch(/^\d{4}-\w{3}-\d{2}-\d{2}:\d{2}$/);
        });
    });
    describe('Integration scenarios', () => {
        it('should handle a complete session lifecycle', () => __awaiter(void 0, void 0, void 0, function* () {
            // current sessions
            mockedBash.execCommand
                .mockResolvedValueOnce({
                stdout: 'dev-session',
                stderr: '',
                code: 0
            })
                .mockResolvedValueOnce({
                stdout: 'editor:nvim:/project:main-vertical',
                stderr: '',
                code: 0
            })
                .mockResolvedValueOnce({
                stdout: '9999:/project:0x0',
                stderr: '',
                code: 0
            });
            const mockWindow = {
                windowName: 'editor',
                currentCommand: 'nvim',
                currentPath: '/project',
                gitRepoLink: 'https://github.com/user/project',
                layout: 'main-vertical',
                panes: []
            };
            const mockPane = {
                currentCommand: 'nvim',
                currentPath: '/project',
                gitRepoLink: undefined,
                paneLeft: '0',
                paneTop: '0'
            };
            mockedFormatWindow.mockResolvedValueOnce(mockWindow);
            mockedFormatPane.mockResolvedValueOnce(mockPane);
            const sessions = yield (0, sessionUtils_1.getCurrentSessions)();
            expect(sessions).toEqual({
                'dev-session': {
                    windows: [Object.assign(Object.assign({}, mockWindow), { panes: [mockPane] })]
                }
            });
            expect(mockedBash.execCommand).toHaveBeenCalledTimes(3);
            expect(mockedFormatWindow).toHaveBeenCalledTimes(1);
            expect(mockedFormatPane).toHaveBeenCalledTimes(1);
        }));
    });
});
describe('Tmux Session Management - Edge Cases', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });
    it('should handle malformed tmux output gracefully', () => __awaiter(void 0, void 0, void 0, function* () {
        mockedBash.execCommand
            .mockResolvedValueOnce({
            stdout: 'malformed:output:without:proper:format',
            stderr: '',
            code: 0
        })
            // getPanesForWindow
            .mockResolvedValueOnce({
            stdout: '',
            stderr: '',
            code: 0
        });
        // formatWindow to return a valid window object
        const mockWindow = {
            windowName: 'unknown',
            currentCommand: 'unknown',
            currentPath: '/unknown',
            gitRepoLink: undefined,
            layout: 'unknown',
            panes: []
        };
        mockedFormatWindow.mockResolvedValueOnce(mockWindow);
        mockedFormatPane.mockResolvedValue({
            currentCommand: 'unknown',
            currentPath: '/unknown',
            gitRepoLink: undefined,
            paneLeft: '0',
            paneTop: '0'
        });
        const result = yield (0, sessionUtils_1.getWindowsForSession)('test');
        expect(Array.isArray(result)).toBe(true);
        expect(result.length).toBe(1);
        expect(result[0]).toEqual(mockWindow);
    }));
    it('should handle concurrent session access', () => __awaiter(void 0, void 0, void 0, function* () {
        // concurrent operations, need to mock multiple sequential calls
        mockedBash.execCommand
            // getCurrentSessions call
            .mockResolvedValueOnce({
            stdout: 'session1',
            stderr: '',
            code: 0
        })
            .mockResolvedValueOnce({
            stdout: 'window1:bash:/tmp:even',
            stderr: '',
            code: 0
        })
            .mockResolvedValueOnce({
            stdout: '1234:/tmp:0x0',
            stderr: '',
            code: 0
        })
            // 2nd getCurrentSessions call
            .mockResolvedValueOnce({
            stdout: 'session1',
            stderr: '',
            code: 0
        })
            .mockResolvedValueOnce({
            stdout: 'window1:bash:/tmp:even',
            stderr: '',
            code: 0
        })
            .mockResolvedValueOnce({
            stdout: '1234:/tmp:0x0',
            stderr: '',
            code: 0
        })
            // getWindowsForSession call
            .mockResolvedValueOnce({
            stdout: 'window1:bash:/tmp:even',
            stderr: '',
            code: 0
        })
            .mockResolvedValueOnce({
            stdout: '1234:/tmp:0x0',
            stderr: '',
            code: 0
        });
        const mockWindow = {
            windowName: 'test',
            currentCommand: 'bash',
            currentPath: '/tmp',
            gitRepoLink: undefined,
            layout: 'even',
            panes: []
        };
        const mockPane = {
            currentCommand: 'bash',
            currentPath: '/tmp',
            gitRepoLink: undefined,
            paneLeft: '0',
            paneTop: '0'
        };
        mockedFormatWindow.mockResolvedValue(mockWindow);
        mockedFormatPane.mockResolvedValue(mockPane);
        // multiple concurrent operations
        const promises = [
            (0, sessionUtils_1.getCurrentSessions)(),
            (0, sessionUtils_1.getCurrentSessions)(),
            (0, sessionUtils_1.getWindowsForSession)('session1')
        ];
        const results = yield Promise.all(promises);
        expect(results).toHaveLength(3);
        results.forEach((result) => {
            expect(result).toBeDefined();
        });
    }));
});
