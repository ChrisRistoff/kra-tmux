"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const child_process_1 = require("child_process");
const common_1 = require("@/tmux/utils/common");
const bash = __importStar(require("@/utils/bashHelper"));
const lockFiles = __importStar(require("@/../eventSystem/lockFiles"));
const ipc = __importStar(require("@/../eventSystem/ipc"));
const utils = __importStar(require("@/utils/common"));
jest.mock('child_process');
jest.mock('@/utils/bashHelper');
jest.mock('@/../eventSystem/lockFiles');
jest.mock('@/../eventSystem/ipc');
jest.mock('@/utils/common');
const mockExecSync = child_process_1.execSync;
const mockBash = bash;
const mockLockFiles = lockFiles;
const mockIPC = ipc;
const mockUtils = utils;
const mockConsoleLog = jest.spyOn(console, 'log').mockImplementation();
describe('tmux-session', () => {
    beforeEach(() => {
        jest.clearAllMocks();
        mockLockFiles.createLockFile.mockResolvedValue(undefined);
        mockLockFiles.lockFileExist.mockResolvedValue(false);
        mockBash.execCommand.mockResolvedValue({ stdout: '', stderr: '' });
        mockUtils.sleep.mockResolvedValue(undefined);
        mockUtils.loadSettings.mockResolvedValue({
            watchCommands: {
                work: { active: false, watch: { windowName: '', command: '' } },
                personal: { active: false, watch: { windowName: '', command: '' } }
            },
            autosave: { active: true, currentSession: '', timeoutMs: 5000 }
        });
        mockUtils.saveSettings.mockResolvedValue(undefined);
    });
    afterAll(() => {
        mockConsoleLog.mockRestore();
    });
    describe('checkSessionExists', () => {
        it('should return true when session exists', () => {
            mockExecSync.mockReturnValue(Buffer.from(''));
            const result = (0, common_1.checkSessionExists)('my-session');
            expect(result).toBe(true);
            expect(mockExecSync).toHaveBeenCalledWith('tmux has-session -t my-session');
        });
        it('should return false when session does not exist', () => {
            const error = new Error("can't find session");
            mockExecSync.mockImplementation(() => {
                throw error;
            });
            const result = (0, common_1.checkSessionExists)('nonexistent-session');
            expect(result).toBe(false);
            expect(mockExecSync).toHaveBeenCalledWith('tmux has-session -t nonexistent-session');
        });
        it('should throw error for unexpected errors', () => {
            const unexpectedError = new Error('Connection refused');
            mockExecSync.mockImplementation(() => {
                throw unexpectedError;
            });
            expect(() => {
                (0, common_1.checkSessionExists)('test-session');
            }).toThrow('Unexpected error while checking session: Error: Connection refused');
        });
        it('should handle non-Error exceptions', () => {
            mockExecSync.mockImplementation(() => {
                throw 'string error';
            });
            expect(() => {
                (0, common_1.checkSessionExists)('test-session');
            }).toThrow('Unexpected error while checking session: string error');
        });
    });
    describe('sourceTmuxConfig', () => {
        it('should source tmux configuration and log success', () => __awaiter(void 0, void 0, void 0, function* () {
            yield (0, common_1.sourceTmuxConfig)();
            expect(mockBash.execCommand).toHaveBeenCalledWith(expect.stringContaining('tmux source'));
            expect(mockBash.execCommand).toHaveBeenCalledWith(expect.stringContaining('.tmux.conf'));
            expect(mockConsoleLog).toHaveBeenCalledWith('Sourced tmux configuration file.');
        }));
        it('should throw error if bash.execCommand fails', () => __awaiter(void 0, void 0, void 0, function* () {
            const error = new Error('Config file not found');
            mockBash.execCommand.mockRejectedValue(error);
            yield expect((0, common_1.sourceTmuxConfig)()).rejects.toThrow('Config file not found');
            expect(mockConsoleLog).not.toHaveBeenCalled();
        }));
    });
    describe('killServer', () => {
        it('should kill server when no autosave is in progress', () => __awaiter(void 0, void 0, void 0, function* () {
            mockLockFiles.lockFileExist.mockResolvedValue(false);
            yield (0, common_1.killServer)();
            expect(mockLockFiles.createLockFile).toHaveBeenCalledWith(mockLockFiles.LockFiles.ServerKillInProgress);
            expect(mockBash.execCommand).toHaveBeenCalledWith('tmux kill-server');
            expect(mockConsoleLog).not.toHaveBeenCalledWith('No Server Running');
        }));
        it('should wait for autosave to complete before killing server', () => __awaiter(void 0, void 0, void 0, function* () {
            const mockClient = {
                emit: jest.fn().mockResolvedValue(undefined),
                ensureServerRunning: jest.fn().mockResolvedValue(undefined)
            };
            mockIPC.createIPCClient.mockReturnValue(mockClient);
            // autosave in progress, autosave complete
            mockLockFiles.lockFileExist
                .mockResolvedValueOnce(true) // autosave in progress
                .mockResolvedValueOnce(true) // while loop iteration - still in progress
                .mockResolvedValueOnce(false); // while loop iteration - complete
            yield (0, common_1.killServer)();
            expect(mockLockFiles.createLockFile).toHaveBeenCalledWith(mockLockFiles.LockFiles.ServerKillInProgress);
            expect(mockIPC.createIPCClient).toHaveBeenCalledWith(mockIPC.IPCsockets.AutosaveSocket);
            expect(mockClient.emit).toHaveBeenCalledWith(mockIPC.IPCEvents.FlushAutosave);
            expect(mockConsoleLog).toHaveBeenCalledWith('Autosaving completing before exit');
            expect(mockUtils.sleep).toHaveBeenCalledWith(500);
            expect(mockBash.execCommand).toHaveBeenCalledWith('tmux kill-server');
        }));
        it('should handle case where no server is running', () => __awaiter(void 0, void 0, void 0, function* () {
            mockLockFiles.lockFileExist.mockResolvedValue(false);
            mockBash.execCommand.mockRejectedValue(new Error('No server running'));
            yield (0, common_1.killServer)();
            expect(mockConsoleLog).toHaveBeenCalledWith('No Server Running');
        }));
        it('should continue checking autosave status multiple times', () => __awaiter(void 0, void 0, void 0, function* () {
            const mockClient = {
                emit: jest.fn().mockResolvedValue(undefined),
                ensureServerRunning: jest.fn().mockResolvedValue(undefined)
            };
            mockIPC.createIPCClient.mockReturnValue(mockClient);
            // autosave taking multiple cycles to complete
            mockLockFiles.lockFileExist
                .mockResolvedValueOnce(true) // initial check
                .mockResolvedValueOnce(true) // while iteration
                .mockResolvedValueOnce(true) // while iteration
                .mockResolvedValueOnce(true) // while iteration
                .mockResolvedValueOnce(false); // complete
            yield (0, common_1.killServer)();
            expect(mockUtils.sleep).toHaveBeenCalledTimes(3);
            expect(mockConsoleLog).toHaveBeenCalledTimes(3);
            expect(mockConsoleLog).toHaveBeenNthCalledWith(1, 'Autosaving completing before exit');
            expect(mockConsoleLog).toHaveBeenNthCalledWith(2, 'Autosaving completing before exit');
            expect(mockConsoleLog).toHaveBeenNthCalledWith(3, 'Autosaving completing before exit');
        }));
    });
    describe('updateCurrentSession', () => {
        it('should update current session in settings', () => __awaiter(void 0, void 0, void 0, function* () {
            const mockSettings = {
                watchCommands: {
                    work: { active: false, watch: { windowName: 'work-window', command: 'npm start' } },
                    personal: { active: true, watch: { windowName: 'personal-window', command: 'vim' } }
                },
                autosave: { active: true, currentSession: 'old-session', timeoutMs: 5000 }
            };
            mockUtils.loadSettings.mockResolvedValue(mockSettings);
            yield (0, common_1.updateCurrentSession)('new-session');
            expect(mockUtils.loadSettings).toHaveBeenCalledTimes(1);
            expect(mockUtils.saveSettings).toHaveBeenCalledWith({
                watchCommands: {
                    work: { active: false, watch: { windowName: 'work-window', command: 'npm start' } },
                    personal: { active: true, watch: { windowName: 'personal-window', command: 'vim' } }
                },
                autosave: { active: true, currentSession: 'new-session', timeoutMs: 5000 }
            });
        }));
        it('should handle settings loading failure', () => __awaiter(void 0, void 0, void 0, function* () {
            const error = new Error('Settings file not found');
            mockUtils.loadSettings.mockRejectedValue(error);
            yield expect((0, common_1.updateCurrentSession)('test-session')).rejects.toThrow('Settings file not found');
            expect(mockUtils.saveSettings).not.toHaveBeenCalled();
        }));
        it('should handle settings saving failure', () => __awaiter(void 0, void 0, void 0, function* () {
            const mockSettings = {
                watchCommands: {
                    work: { active: false, watch: { windowName: '', command: '' } },
                    personal: { active: false, watch: { windowName: '', command: '' } }
                },
                autosave: { active: true, currentSession: 'old', timeoutMs: 3000 }
            };
            mockUtils.loadSettings.mockResolvedValue(mockSettings);
            mockUtils.saveSettings.mockRejectedValue(new Error('Disk full'));
            yield expect((0, common_1.updateCurrentSession)('new-session')).rejects.toThrow('Disk full');
        }));
    });
});
