"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = __importStar(require("fs/promises"));
const utils = __importStar(require("@/utils/common"));
const generalUI = __importStar(require("@/UI/generalUI"));
const sessionUtils_1 = require("@/tmux/utils/sessionUtils");
const printSessions_1 = require("@/tmux/commands/printSessions");
const tmux = __importStar(require("@/tmux/utils/common"));
const saveSessions_1 = require("@/tmux/commands/saveSessions");
const lockFiles_1 = require("@/../eventSystem/lockFiles");
const bash = __importStar(require("@/utils/bashHelper"));
const loadSession_1 = require("@/tmux/commands/loadSession");
jest.mock('fs/promises');
jest.mock('@/utils/common');
jest.mock('@/UI/generalUI');
jest.mock('@/tmux/utils/sessionUtils');
jest.mock('@/tmux/commands/printSessions');
jest.mock('@/tmux/utils/common');
jest.mock('@/tmux/commands/saveSessions');
jest.mock('@/../eventSystem/lockFiles');
jest.mock('@/utils/bashHelper');
jest.mock('@/filePaths', () => ({
    nvimSessionsPath: '/mock/nvim/sessions',
    sessionFilesFolder: '/mock/session/files'
}));
describe('loadSession', () => {
    const mockFs = jest.mocked(fs);
    const mockUtils = jest.mocked(utils);
    const mockGeneralUI = jest.mocked(generalUI);
    const mockGetSavedSessionsNames = jest.mocked(sessionUtils_1.getSavedSessionsNames);
    const mockGetCurrentSessions = jest.mocked(sessionUtils_1.getCurrentSessions);
    const mockPrintSessions = jest.mocked(printSessions_1.printSessions);
    const mockTmux = jest.mocked(tmux);
    const mockSaveSessionsToFile = jest.mocked(saveSessions_1.saveSessionsToFile);
    const mockCreateLockFile = jest.mocked(lockFiles_1.createLockFile);
    const mockBash = jest.mocked(bash);
    beforeEach(() => {
        jest.clearAllMocks();
        process.env.SHELL = '/bin/zsh';
        mockCreateLockFile.mockResolvedValue();
        mockTmux.sourceTmuxConfig.mockResolvedValue();
        mockTmux.updateCurrentSession.mockImplementation(() => __awaiter(void 0, void 0, void 0, function* () { return new Promise(() => { }); }));
        mockTmux.killServer.mockResolvedValue();
        mockUtils.sleep.mockResolvedValue();
        mockSaveSessionsToFile.mockResolvedValue();
        mockPrintSessions.mockImplementation(() => { });
        mockFs.rm.mockResolvedValue();
    });
    describe('loadSession', () => {
        it('should successfully load a session', () => __awaiter(void 0, void 0, void 0, function* () {
            const mockSessionNames = ['server1', 'server2'];
            const mockSavedData = {
                session1: {
                    windows: [
                        {
                            windowName: 'main',
                            layout: 'main-vertical',
                            currentCommand: 'vim',
                            currentPath: '/home/user/project',
                            gitRepoLink: 'git@github.com:user/repo.git',
                            panes: [
                                {
                                    currentCommand: 'vim',
                                    currentPath: '/home/user/project',
                                    gitRepoLink: 'git@github.com:user/repo.git',
                                    paneLeft: '0',
                                    paneTop: '0'
                                }
                            ]
                        }
                    ]
                }
            };
            mockGetSavedSessionsNames.mockResolvedValue(mockSessionNames);
            mockGeneralUI.searchSelectAndReturnFromArray.mockResolvedValue('server1');
            mockFs.readFile.mockResolvedValue(Buffer.from(JSON.stringify(mockSavedData)));
            // session creation
            mockBash.execCommand
                .mockResolvedValueOnce({ stdout: '', stderr: '' }) // kill existing session
                .mockResolvedValueOnce({ stdout: '', stderr: '' }) // create new session
                .mockResolvedValueOnce({ stdout: '', stderr: '' }) // verify session exists
                .mockResolvedValueOnce({ stdout: '0:main\n', stderr: '' }) // list windows
                .mockResolvedValueOnce({ stdout: '', stderr: '' }) // create script file
                .mockResolvedValueOnce({ stdout: '', stderr: '' }); // execute script
            const consoleSpy = jest.spyOn(console, 'log').mockImplementation();
            yield (0, loadSession_1.loadSession)();
            expect(mockCreateLockFile).toHaveBeenCalledWith(lockFiles_1.LockFiles.LoadInProgress);
            expect(mockGetSavedSessionsNames).toHaveBeenCalled();
            expect(mockGeneralUI.searchSelectAndReturnFromArray).toHaveBeenCalledWith({
                itemsArray: mockSessionNames,
                prompt: "Select a session to load from the list:",
            });
            expect(mockFs.readFile).toHaveBeenCalledWith('/mock/session/files/server1');
            expect(mockTmux.sourceTmuxConfig).toHaveBeenCalled();
            expect(mockTmux.updateCurrentSession).toHaveBeenCalledWith('server1');
            expect(consoleSpy).toHaveBeenCalledWith('Sessions loaded successfully');
            consoleSpy.mockRestore();
        }));
        it('should handle error when no saved sessions found', () => __awaiter(void 0, void 0, void 0, function* () {
            const mockSessionNames = ['server1'];
            mockGetSavedSessionsNames.mockResolvedValue(mockSessionNames);
            mockGeneralUI.searchSelectAndReturnFromArray.mockResolvedValue('server1');
            mockFs.readFile.mockResolvedValue(Buffer.from('null'));
            const consoleSpy = jest.spyOn(console, 'error').mockImplementation();
            yield (0, loadSession_1.loadSession)();
            expect(consoleSpy).toHaveBeenCalledWith('No saved sessions found.');
            consoleSpy.mockRestore();
        }));
        it('should handle errors during session loading', () => __awaiter(void 0, void 0, void 0, function* () {
            mockGetSavedSessionsNames.mockRejectedValue(new Error('Failed to get sessions'));
            const consoleSpy = jest.spyOn(console, 'error').mockImplementation();
            yield (0, loadSession_1.loadSession)();
            expect(consoleSpy).toHaveBeenCalledWith('Load session error:', expect.any(Error));
            consoleSpy.mockRestore();
        }));
    });
    describe('getSessionsFromSaved', () => {
        it('should successfully read and parse session data', () => __awaiter(void 0, void 0, void 0, function* () {
            const mockData = {
                session1: {
                    windows: [
                        {
                            windowName: 'editor',
                            layout: 'main-horizontal',
                            currentCommand: 'nvim',
                            currentPath: '/workspace',
                            gitRepoLink: undefined,
                            panes: []
                        }
                    ]
                }
            };
            mockFs.readFile.mockResolvedValue(Buffer.from(JSON.stringify(mockData)));
            const result = yield (0, loadSession_1.getSessionsFromSaved)('test-server');
            expect(mockFs.readFile).toHaveBeenCalledWith('/mock/session/files/test-server');
            expect(result).toEqual(mockData);
        }));
        it('should handle file read errors', () => __awaiter(void 0, void 0, void 0, function* () {
            mockFs.readFile.mockRejectedValue(new Error('File not found'));
            yield expect((0, loadSession_1.getSessionsFromSaved)('nonexistent')).rejects.toThrow('File not found');
        }));
        it('should handle JSON parse errors', () => __awaiter(void 0, void 0, void 0, function* () {
            mockFs.readFile.mockResolvedValue(Buffer.from('invalid json'));
            yield expect((0, loadSession_1.getSessionsFromSaved)('corrupt-file')).rejects.toThrow();
        }));
    });
    describe('handleSessionsIfServerIsRunning', () => {
        it('should handle server with existing sessions and save them', () => __awaiter(void 0, void 0, void 0, function* () {
            const mockCurrentSessions = {
                session1: {
                    windows: [
                        {
                            windowName: 'main',
                            layout: 'tiled',
                            currentCommand: 'bash',
                            currentPath: '/home',
                            gitRepoLink: undefined,
                            panes: []
                        }
                    ]
                }
            };
            mockGetCurrentSessions.mockResolvedValue(mockCurrentSessions);
            mockGeneralUI.promptUserYesOrNo.mockResolvedValue(true);
            yield (0, loadSession_1.handleSessionsIfServerIsRunning)();
            expect(mockPrintSessions).toHaveBeenCalledWith(mockCurrentSessions);
            expect(mockGeneralUI.promptUserYesOrNo).toHaveBeenCalledWith('Would you like to save currently running sessions?');
            expect(mockSaveSessionsToFile).toHaveBeenCalled();
            expect(mockTmux.killServer).toHaveBeenCalled();
            expect(mockUtils.sleep).toHaveBeenCalledWith(200);
        }));
        it('should handle server with existing sessions and not save them', () => __awaiter(void 0, void 0, void 0, function* () {
            const mockCurrentSessions = {
                session1: {
                    windows: [
                        {
                            windowName: 'temp',
                            layout: '15x15x15',
                            currentCommand: 'top',
                            currentPath: '/tmp',
                            gitRepoLink: undefined,
                            panes: []
                        }
                    ]
                }
            };
            mockGetCurrentSessions.mockResolvedValue(mockCurrentSessions);
            mockGeneralUI.promptUserYesOrNo.mockResolvedValue(false);
            yield (0, loadSession_1.handleSessionsIfServerIsRunning)();
            expect(mockPrintSessions).toHaveBeenCalledWith(mockCurrentSessions);
            expect(mockGeneralUI.promptUserYesOrNo).toHaveBeenCalledWith('Would you like to save currently running sessions?');
            expect(mockSaveSessionsToFile).not.toHaveBeenCalled();
            expect(mockTmux.killServer).toHaveBeenCalled();
            expect(mockUtils.sleep).toHaveBeenCalledWith(200);
        }));
        it('should handle server with no existing sessions', () => __awaiter(void 0, void 0, void 0, function* () {
            mockGetCurrentSessions.mockResolvedValue({});
            yield (0, loadSession_1.handleSessionsIfServerIsRunning)();
            expect(mockPrintSessions).not.toHaveBeenCalled();
            expect(mockGeneralUI.promptUserYesOrNo).not.toHaveBeenCalled();
            expect(mockSaveSessionsToFile).not.toHaveBeenCalled();
            expect(mockTmux.killServer).not.toHaveBeenCalled();
            expect(mockUtils.sleep).not.toHaveBeenCalled();
        }));
    });
    describe('session creation and script generation', () => {
        it('should handle session creation failure', () => __awaiter(void 0, void 0, void 0, function* () {
            const mockSessionNames = ['server1'];
            const mockSavedData = {
                session1: {
                    windows: [
                        {
                            windowName: 'main',
                            layout: 'main-vertical',
                            currentCommand: 'bash',
                            currentPath: '/home/user',
                            gitRepoLink: undefined,
                            panes: [
                                {
                                    currentCommand: 'bash',
                                    currentPath: '/home/user',
                                    gitRepoLink: undefined,
                                    paneLeft: '0',
                                    paneTop: '0'
                                }
                            ]
                        }
                    ]
                }
            };
            mockGetSavedSessionsNames.mockResolvedValue(mockSessionNames);
            mockGeneralUI.searchSelectAndReturnFromArray.mockResolvedValue('server1');
            mockFs.readFile.mockResolvedValue(Buffer.from(JSON.stringify(mockSavedData)));
            // session creation failure
            mockBash.execCommand
                .mockResolvedValueOnce({ stdout: '', stderr: '' }) // kill existing session
                .mockRejectedValueOnce(new Error('Failed to create session')); // create session fails
            const consoleSpy = jest.spyOn(console, 'error').mockImplementation();
            yield (0, loadSession_1.loadSession)();
            expect(consoleSpy).toHaveBeenCalledWith('Failed to create session session1:', expect.any(Error));
            consoleSpy.mockRestore();
        }));
        it('should handle windows with multiple panes and nvim commands', () => __awaiter(void 0, void 0, void 0, function* () {
            const mockSessionNames = ['server1'];
            const mockSavedData = {
                session1: {
                    windows: [
                        {
                            windowName: 'editor',
                            layout: 'main-vertical',
                            currentCommand: 'nvim',
                            currentPath: '/home/user/project',
                            gitRepoLink: 'git@github.com:user/repo.git',
                            panes: [
                                {
                                    currentCommand: 'nvim',
                                    currentPath: '/home/user/project/src',
                                    gitRepoLink: 'git@github.com:user/repo.git',
                                    paneLeft: '0',
                                    paneTop: '0'
                                },
                                {
                                    currentCommand: 'bash',
                                    currentPath: '/home/user/project',
                                    gitRepoLink: 'git@github.com:user/repo.git',
                                    paneLeft: '1',
                                    paneTop: '0'
                                }
                            ]
                        },
                        {
                            windowName: 'terminal',
                            layout: '15x15x15',
                            currentCommand: 'htop',
                            currentPath: '/home/user',
                            gitRepoLink: undefined,
                            panes: [
                                {
                                    currentCommand: 'htop',
                                    currentPath: '/home/user',
                                    gitRepoLink: undefined,
                                    paneLeft: '0',
                                    paneTop: '0'
                                }
                            ]
                        }
                    ]
                }
            };
            mockGetSavedSessionsNames.mockResolvedValue(mockSessionNames);
            mockGeneralUI.searchSelectAndReturnFromArray.mockResolvedValue('server1');
            mockFs.readFile.mockResolvedValue(Buffer.from(JSON.stringify(mockSavedData)));
            // successful session creation
            mockBash.execCommand
                .mockResolvedValueOnce({ stdout: '', stderr: '' }) // kill existing session
                .mockResolvedValueOnce({ stdout: '', stderr: '' }) // create new session
                .mockResolvedValueOnce({ stdout: '', stderr: '' }) // verify session exists
                .mockResolvedValueOnce({ stdout: '0:editor\n', stderr: '' }) // list windows
                .mockResolvedValueOnce({ stdout: '', stderr: '' }) // create script file
                .mockResolvedValueOnce({ stdout: '', stderr: '' }); // execute script
            const consoleSpy = jest.spyOn(console, 'log').mockImplementation();
            yield (0, loadSession_1.loadSession)();
            expect(consoleSpy).toHaveBeenCalledWith('Sessions loaded successfully');
            consoleSpy.mockRestore();
        }));
        it('should handle script execution failure', () => __awaiter(void 0, void 0, void 0, function* () {
            const mockSessionNames = ['server1'];
            const mockSavedData = {
                session1: {
                    windows: [
                        {
                            windowName: 'main',
                            layout: '15x15x15',
                            currentCommand: 'bash',
                            currentPath: '/home/user',
                            gitRepoLink: undefined,
                            panes: [
                                {
                                    currentCommand: 'bash',
                                    currentPath: '/home/user',
                                    gitRepoLink: undefined,
                                    paneLeft: '0',
                                    paneTop: '0'
                                }
                            ]
                        }
                    ]
                }
            };
            mockGetSavedSessionsNames.mockResolvedValue(mockSessionNames);
            mockGeneralUI.searchSelectAndReturnFromArray.mockResolvedValue('server1');
            mockFs.readFile.mockResolvedValue(Buffer.from(JSON.stringify(mockSavedData)));
            // successful session creation but script execution failure
            mockBash.execCommand
                .mockResolvedValueOnce({ stdout: '', stderr: '' }) // kill existing session
                .mockResolvedValueOnce({ stdout: '', stderr: '' }) // create new session
                .mockResolvedValueOnce({ stdout: '', stderr: '' }) // verify session exists
                .mockResolvedValueOnce({ stdout: '0:main\n', stderr: '' }) // list windows
                .mockResolvedValueOnce({ stdout: '', stderr: '' }) // create script file
                .mockRejectedValueOnce(new Error('Script execution failed')); // execute script fails
            const consoleSpy = jest.spyOn(console, 'error').mockImplementation();
            yield (0, loadSession_1.loadSession)();
            expect(consoleSpy).toHaveBeenCalledWith('Load session error:', expect.any(Error));
            expect(mockFs.rm).toHaveBeenCalled(); // should still clean up
            consoleSpy.mockRestore();
        }));
    });
});
