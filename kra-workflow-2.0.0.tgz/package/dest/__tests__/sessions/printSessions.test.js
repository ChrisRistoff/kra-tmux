"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const printSessions_1 = require("@/tmux/commands/printSessions");
const sessionUtils_1 = require("@/tmux/utils/sessionUtils");
jest.mock('@/tmux/utils/sessionUtils');
const mockConsoleTable = jest.fn();
global.console = Object.assign(Object.assign({}, console), { table: mockConsoleTable });
describe('printSessions', () => {
    const mockGetCurrentSessions = jest.mocked(sessionUtils_1.getCurrentSessions);
    const mockConsoleTable = jest.mocked(console.table);
    beforeEach(() => {
        jest.clearAllMocks();
    });
    describe('printSessions', () => {
        it('should print session information in table format', () => {
            const testSessions = {
                'session1': {
                    windows: [{
                            windowName: 'window1',
                            currentCommand: '',
                            layout: '',
                            currentPath: '/path1',
                            gitRepoLink: undefined,
                            panes: [
                                { currentCommand: '', currentPath: '', gitRepoLink: undefined, paneLeft: '0', paneTop: '0' }
                            ]
                        }]
                }
            };
            (0, printSessions_1.printSessions)(testSessions);
            expect(mockConsoleTable).toHaveBeenCalledWith({
                Name: 'session1',
                Path: '/path1',
                Windows: 1,
                Panes: 1
            });
        });
        it('should handle multiple windows and panes', () => {
            const testSessions = {
                'session2': {
                    windows: [
                        {
                            windowName: 'window1',
                            currentCommand: '',
                            layout: '',
                            currentPath: '/path2',
                            gitRepoLink: undefined,
                            panes: [
                                { currentCommand: '', currentPath: '', gitRepoLink: undefined, paneLeft: '0', paneTop: '0' },
                                { currentCommand: '', currentPath: '', gitRepoLink: undefined, paneLeft: '0', paneTop: '0' }
                            ]
                        },
                        {
                            windowName: 'window2',
                            currentCommand: '',
                            layout: '',
                            currentPath: '/path3',
                            gitRepoLink: undefined,
                            panes: [
                                { currentCommand: '', currentPath: '', gitRepoLink: undefined, paneLeft: '0', paneTop: '0' }
                            ]
                        }
                    ]
                }
            };
            (0, printSessions_1.printSessions)(testSessions);
            expect(mockConsoleTable).toHaveBeenCalledWith({
                Name: 'session2',
                Path: '/path2',
                Windows: 2,
                Panes: 3
            });
        });
    });
    describe('printCurrentSessions', () => {
        it('should get and print current sessions', () => __awaiter(void 0, void 0, void 0, function* () {
            const testSessions = {
                'session3': {
                    windows: [{
                            windowName: 'window1',
                            currentCommand: '',
                            layout: '',
                            currentPath: '/path4',
                            gitRepoLink: undefined,
                            panes: [
                                { currentCommand: '', currentPath: '', gitRepoLink: undefined, paneLeft: '0', paneTop: '0' }
                            ]
                        }]
                }
            };
            mockGetCurrentSessions.mockResolvedValue(testSessions);
            yield (0, printSessions_1.printCurrentSessions)();
            expect(mockGetCurrentSessions).toHaveBeenCalled();
            expect(mockConsoleTable).toHaveBeenCalledWith({
                Name: 'session3',
                Path: '/path4',
                Windows: 1,
                Panes: 1
            });
        }));
    });
});
