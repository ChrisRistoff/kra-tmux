"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const generalUI_1 = require("@/UI/generalUI");
const menuChain_1 = require("@/UI/menuChain");
// Mock blessed and figlet
const mockWidgets = {
    screen: [],
    box: [],
    list: [],
    textbox: []
};
const createMockWidget = (type, options) => {
    const handlers = {};
    let value = '';
    let items = (options === null || options === void 0 ? void 0 : options.items) || [];
    let selected = 0;
    const widget = Object.assign(Object.assign({}, options), { on: jest.fn((event, handler) => {
            handlers[event] = handler;
        }), key: jest.fn((key, handler) => {
            if (Array.isArray(key)) {
                key.forEach((k) => {
                    handlers[`key ${k}`] = handler;
                });
            }
            else {
                handlers[`key ${key}`] = handler;
            }
            return widget; // for chaining
        }), focus: jest.fn(), append: jest.fn(), render: jest.fn(), destroy: jest.fn(), getValue: jest.fn(() => value), setValue: jest.fn((v) => {
            value = v;
        }), getItem: jest.fn((idx) => ({
            getText: () => items[idx],
            content: items[idx]
        })), get selected() {
            return selected;
        },
        set selected(v) {
            selected = v;
        }, up: jest.fn(), down: jest.fn(), fuzzyFind: jest.fn(), clearItems: jest.fn(() => {
            items = [];
        }), setItems: jest.fn((newItems) => {
            items = newItems;
        }), _emit: (event, ...args) => {
            if (handlers[event]) {
                handlers[event](...args);
            }
        }, _handlers: handlers, _items: () => items });
    mockWidgets[type].push(widget);
    return widget;
};
jest.mock('blessed', () => ({
    screen: jest.fn((options) => createMockWidget('screen', options)),
    box: jest.fn((options) => createMockWidget('box', options)),
    list: jest.fn((options) => createMockWidget('list', options)),
    textbox: jest.fn((options) => createMockWidget('textbox', options))
}));
jest.mock('figlet', () => ({
    textSync: jest.fn((text) => text)
}));
describe('generalUI', () => {
    beforeEach(() => {
        jest.clearAllMocks();
        mockWidgets.screen = [];
        mockWidgets.box = [];
        mockWidgets.list = [];
        mockWidgets.textbox = [];
    });
    describe('promptUserYesOrNo', () => {
        it('should return true when user confirms with "y" key', () => __awaiter(void 0, void 0, void 0, function* () {
            const promise = (0, generalUI_1.promptUserYesOrNo)('Are you sure?');
            mockWidgets.screen[0]._handlers['key y']();
            yield expect(promise).resolves.toBe(true);
        }));
        it('should return false when user declines with "n" key', () => __awaiter(void 0, void 0, void 0, function* () {
            const promise = (0, generalUI_1.promptUserYesOrNo)('Are you sure?');
            mockWidgets.screen[0]._handlers['key n']();
            yield expect(promise).resolves.toBe(false);
        }));
        it('should return true when user selects "Yes"', () => __awaiter(void 0, void 0, void 0, function* () {
            const promise = (0, generalUI_1.promptUserYesOrNo)('Are you sure?');
            mockWidgets.list[0]._emit('select', {}, 0); // 0 is the index for 'Yes'
            yield expect(promise).resolves.toBe(true);
        }));
        it('should return false when user selects "No"', () => __awaiter(void 0, void 0, void 0, function* () {
            const promise = (0, generalUI_1.promptUserYesOrNo)('Are you sure?');
            mockWidgets.list[0]._emit('select', {}, 1); // 1 is the index for 'No'
            yield expect(promise).resolves.toBe(false);
        }));
        it('should reject with UserCancelled on escape', () => __awaiter(void 0, void 0, void 0, function* () {
            const promise = (0, generalUI_1.promptUserYesOrNo)('Are you sure?');
            mockWidgets.screen[0]._handlers['key escape']();
            yield expect(promise).rejects.toBeInstanceOf(menuChain_1.UserCancelled);
        }));
    });
    describe('askUserForInput', () => {
        it('should return user input on enter', () => __awaiter(void 0, void 0, void 0, function* () {
            const promise = (0, generalUI_1.askUserForInput)('Enter value:');
            const textbox = mockWidgets.textbox[0];
            textbox.setValue('test input');
            textbox._handlers['key enter']();
            yield expect(promise).resolves.toBe('test input');
        }));
        it('should reject with UserCancelled on escape', () => __awaiter(void 0, void 0, void 0, function* () {
            const promise = (0, generalUI_1.askUserForInput)('Enter value:');
            mockWidgets.screen[0]._handlers['key escape']();
            yield expect(promise).rejects.toBeInstanceOf(menuChain_1.UserCancelled);
        }));
    });
    describe('searchSelectAndReturnFromArray', () => {
        const options = {
            itemsArray: ['option1', 'option2', 'option3'],
            prompt: 'Select option:'
        };
        it('should return selected option on enter', () => __awaiter(void 0, void 0, void 0, function* () {
            const promise = (0, generalUI_1.searchSelectAndReturnFromArray)(options);
            const searchBox = mockWidgets.textbox[0];
            const list = mockWidgets.list[0];
            list.selected = 1; // user navigates to 'option2'
            searchBox._handlers['key enter']();
            yield expect(promise).resolves.toBe('option2');
        }));
        it('should filter options based on search input', () => __awaiter(void 0, void 0, void 0, function* () {
            const promise = (0, generalUI_1.searchSelectAndReturnFromArray)({
                itemsArray: ['test1', 'test2', 'other'],
                prompt: 'Select:'
            });
            const searchBox = mockWidgets.textbox[0];
            const list = mockWidgets.list[0];
            // Simulate typing 'test'
            searchBox._emit('keypress', 't', { name: 't', ctrl: false, meta: false });
            searchBox._emit('keypress', 'e', { name: 'e', ctrl: false, meta: false });
            searchBox._emit('keypress', 's', { name: 's', ctrl: false, meta: false });
            searchBox._emit('keypress', 't', { name: 't', ctrl: false, meta: false });
            expect(list.setItems).toHaveBeenLastCalledWith(['test1', 'test2']);
            // To resolve promise
            searchBox._handlers['key enter']();
            yield promise;
        }));
    });
    describe('searchAndSelect', () => {
        const options = {
            itemsArray: ['item1', 'item2'],
            prompt: 'Select:'
        };
        it('should return selected item on enter', () => __awaiter(void 0, void 0, void 0, function* () {
            const mockSearchAndSelect = jest.fn().mockResolvedValue('item1');
            const originalSearchAndSelect = generalUI_1.searchAndSelect;
            generalUI_1.searchAndSelect = mockSearchAndSelect;
            const promise = (0, generalUI_1.searchAndSelect)(options);
            yield expect(promise).resolves.toBe('item1');
            generalUI_1.searchAndSelect = originalSearchAndSelect;
        }));
        it('should filter items when user types', () => __awaiter(void 0, void 0, void 0, function* () {
            const mockSearchAndSelect = jest.fn().mockResolvedValue('existing1');
            const originalSearchAndSelect = generalUI_1.searchAndSelect;
            generalUI_1.searchAndSelect = mockSearchAndSelect;
            const promise = (0, generalUI_1.searchAndSelect)({
                itemsArray: ['existing1', 'existing2', 'another'],
                prompt: 'Select:'
            });
            yield expect(promise).resolves.toBe('existing1');
            generalUI_1.searchAndSelect = originalSearchAndSelect;
        }));
    });
});
