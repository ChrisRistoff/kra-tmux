"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LockFiles = void 0;
exports.deleteLockFile = deleteLockFile;
exports.oneOfMultipleLocksExist = oneOfMultipleLocksExist;
exports.lockFileExist = lockFileExist;
exports.createLockFile = createLockFile;
const common_1 = require("@/utils/common");
const filePaths_1 = require("../src/filePaths");
const fs = __importStar(require("fs/promises"));
var LockFiles;
(function (LockFiles) {
    LockFiles["LoadInProgress"] = "LoadInProgress";
    LockFiles["AutoSaveInProgress"] = "AutoSaveInProgress";
    LockFiles["ServerKillInProgress"] = "ServerKillInProgress";
})(LockFiles || (exports.LockFiles = LockFiles = {}));
function deleteLockFile(type) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            yield fs.rm(`${filePaths_1.lockFilesPath}/${type}`);
        }
        catch (error) {
            console.log(error);
        }
    });
}
function oneOfMultipleLocksExist(types) {
    return __awaiter(this, void 0, void 0, function* () {
        const res = yield Promise.all(types
            .map((fileType) => __awaiter(this, void 0, void 0, function* () { return lockFileExist(fileType); })));
        return res.some(file => file);
    });
}
function lockFileExist(type) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const data = yield fs.readFile(`${filePaths_1.lockFilesPath}/${type}`, 'utf-8');
            const lockInfo = JSON.parse(data);
            const timeouts = {
                [LockFiles.LoadInProgress]: 10 * 1000, // 5s - loading takes ms, this should be more than safe to assume
                [LockFiles.AutoSaveInProgress]: (yield (0, common_1.loadSettings)().then((set) => set.autosave.timeoutMs)) + 10000, // autosave timeout + 10 sec buffer
                [LockFiles.ServerKillInProgress]: 5 * 1000 // 5s - kill session is instant, 5s is enough to complete the autosave
            };
            // check if lock is stale (older than X seconds)
            const xSecondsAgo = Date.now() - (timeouts[type]);
            if (lockInfo.timestamp < xSecondsAgo) {
                console.log(`Removing stale ${type} lock file`);
                yield deleteLockFile(type);
                return false;
            }
            return true;
        }
        catch (error) {
            // if we can't read the lock file assume it doesn't exist
            return false;
        }
    });
}
function createLockFile(type) {
    return __awaiter(this, void 0, void 0, function* () {
        const lockData = {
            timestamp: Date.now(),
        };
        yield fs.writeFile(`${filePaths_1.lockFilesPath}/${type}`, JSON.stringify(lockData));
    });
}
