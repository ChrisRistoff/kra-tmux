"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.IPCEvents = exports.IPCsockets = void 0;
exports.createIPCServer = createIPCServer;
exports.createIPCClient = createIPCClient;
const fs_1 = __importDefault(require("fs"));
const net_1 = __importDefault(require("net"));
const child_process_1 = require("child_process");
var IPCsockets;
(function (IPCsockets) {
    IPCsockets["AutosaveSocket"] = "/tmp/autosave.sock";
})(IPCsockets || (exports.IPCsockets = IPCsockets = {}));
var IPCEvents;
(function (IPCEvents) {
    IPCEvents["FlushAutosave"] = "flush-autosave";
})(IPCEvents || (exports.IPCEvents = IPCEvents = {}));
function createIPCServer(socketPath) {
    let server;
    let eventHandler;
    const pidFile = `${socketPath}.pid`;
    const cleanup = () => {
        if (server) {
            server.close();
            server = undefined;
        }
        try {
            if (fs_1.default.existsSync(socketPath))
                fs_1.default.unlinkSync(socketPath);
            if (fs_1.default.existsSync(pidFile))
                fs_1.default.unlinkSync(pidFile);
        }
        catch (e) {
            // ignore cleanup errors
        }
    };
    const addListener = (handler) => __awaiter(this, void 0, void 0, function* () {
        return new Promise((resolve, reject) => {
            eventHandler = handler;
            // clean up existing socket if it exists
            if (fs_1.default.existsSync(socketPath)) {
                fs_1.default.unlinkSync(socketPath);
            }
            server = net_1.default.createServer((socket) => {
                socket.on('data', (data) => {
                    const message = data.toString().trim();
                    if (message && eventHandler) {
                        eventHandler(message);
                    }
                });
                socket.on('error', (err) => {
                    console.error('Socket client error:', err);
                });
                socket.on('close', () => {
                    // Client disconnected
                });
            });
            server.on('error', (err) => {
                if (err.code === 'EADDRINUSE') {
                    // socket already in use, try to clean it up
                    cleanup();
                    setTimeout(() => {
                        // retry after cleanup
                        addListener(handler).then(resolve).catch(reject);
                    }, 100);
                    return;
                }
                reject(err);
            });
            server.listen(socketPath, () => {
                // write PID file so client knows we're running
                fs_1.default.writeFileSync(pidFile, process.pid.toString());
                // set socket permissions (owner read/write only for security)
                fs_1.default.chmodSync(socketPath, 0o600);
                resolve();
            });
            // cleanup on exit
            process.on('exit', cleanup);
            process.on('SIGINT', () => { cleanup(); process.exit(0); });
            process.on('SIGTERM', () => { cleanup(); process.exit(0); });
        });
    });
    const close = () => {
        cleanup();
    };
    return { addListener, close };
}
function createIPCClient(socketPath) {
    const pidFile = `${socketPath}.pid`;
    const emit = (event) => __awaiter(this, void 0, void 0, function* () {
        return new Promise((resolve, reject) => {
            const client = net_1.default.createConnection(socketPath);
            client.on('connect', () => {
                client.write(event);
                client.end();
                resolve();
            });
            client.on('error', (err) => {
                if (err.code === 'ENOENT' || err.code === 'ECONNREFUSED') {
                    reject(new Error('IPC server not running'));
                }
                else {
                    reject(err);
                }
            });
            client.on('close', () => {
                // connection closed, event sent successfully
            });
        });
    });
    const isServerRunning = () => {
        if (!fs_1.default.existsSync(pidFile))
            return false;
        if (!fs_1.default.existsSync(socketPath))
            return false;
        try {
            const pid = parseInt(fs_1.default.readFileSync(pidFile, 'utf8').trim());
            // check if process is actually running
            process.kill(pid, 0); // throws if process doesn't exist
            // also test socket connectivity
            const testClient = net_1.default.createConnection(socketPath);
            testClient.on('connect', () => {
                testClient.end();
            });
            testClient.on('error', () => {
                // socket exists but not connectable, clean up stale files
                try {
                    fs_1.default.unlinkSync(pidFile);
                    fs_1.default.unlinkSync(socketPath);
                }
                catch (_a) { }
                return false;
            });
            return true;
        }
        catch (e) {
            // PID file exists but process is dead, clean it up
            try {
                fs_1.default.unlinkSync(pidFile);
                if (fs_1.default.existsSync(socketPath))
                    fs_1.default.unlinkSync(socketPath);
            }
            catch (_a) { }
            return false;
        }
    };
    const ensureServerRunning = (serverScript) => __awaiter(this, void 0, void 0, function* () {
        if (isServerRunning()) {
            return;
        }
        const child = (0, child_process_1.spawn)('node', [serverScript.replace('~', process.env.HOME || '')], {
            detached: true,
            stdio: 'ignore'
        });
        child.unref();
        child.on('error', (err) => {
            throw new Error(`Failed to spawn server: ${err.message}`);
        });
        // Wait for server to create socket and PID file
        let attempts = 0;
        while (attempts < 50 && !isServerRunning()) {
            yield new Promise(r => setTimeout(r, 100));
            attempts++;
        }
        if (!isServerRunning()) {
            throw new Error('Server failed to start within timeout period');
        }
    });
    return { emit, ensureServerRunning };
}
