"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.loadSessionWorkerPath = exports.quotaCachePath = exports.fastembedCacheDir = exports.modelCatalogDir = exports.lockFilesPath = exports.systemScriptsPath = exports.systemFilesPath = exports.aiLuaDir = exports.neovimConfig = exports.aiHistoryPath = exports.nvimSessionsPath = exports.sessionFilesFolder = exports.gitFilesFolder = exports.settingsFilePath = void 0;
exports.kraHome = kraHome;
const os_1 = __importDefault(require("os"));
const path_1 = __importDefault(require("path"));
/**
 * Resolves the user-data root for kra-workflow. Defaults to ~/.kra; can be
 * overridden by setting the KRA_HOME environment variable (useful for
 * dotfiles repos or testing).
 */
function kraHome() {
    return process.env.KRA_HOME || path_1.default.join(os_1.default.homedir(), '.kra');
}
const root = kraHome();
//settings
exports.settingsFilePath = path_1.default.join(root, 'settings.toml');
// git
exports.gitFilesFolder = path_1.default.join(root, 'git-files');
// tmux
exports.sessionFilesFolder = path_1.default.join(root, 'tmux-files', 'sessions');
// nvim
exports.nvimSessionsPath = path_1.default.join(root, 'tmux-files', 'nvim-sessions');
// ai
exports.aiHistoryPath = path_1.default.join(root, 'ai-files', 'chat-history');
// Agent neovim UI (init.lua + lua/) ships with the package — see packagePaths.
var packagePaths_1 = require("./packagePaths");
Object.defineProperty(exports, "neovimConfig", { enumerable: true, get: function () { return packagePaths_1.aiInitLuaPath; } });
Object.defineProperty(exports, "aiLuaDir", { enumerable: true, get: function () { return packagePaths_1.aiLuaDir; } });
// system
exports.systemFilesPath = path_1.default.join(root, 'system-files');
exports.systemScriptsPath = path_1.default.join(root, 'system-files', 'scripts');
// lock
exports.lockFilesPath = path_1.default.join(root, 'lock-files');
// AI paths consolidated under ~/.kra (previously under ~/.config, ~/.cache, ~/.local/share)
exports.modelCatalogDir = path_1.default.join(root, 'model-catalog');
exports.fastembedCacheDir = path_1.default.join(root, 'cache', 'fastembed');
exports.quotaCachePath = path_1.default.join(root, 'quota-cache.json');
// Re-export for backwards compatibility — actual location is packagePaths.ts
var packagePaths_2 = require("./packagePaths");
Object.defineProperty(exports, "loadSessionWorkerPath", { enumerable: true, get: function () { return packagePaths_2.loadSessionWorkerPath; } });
