"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.makeExecutableIfNoPermissions = makeExecutableIfNoPermissions;
const promises_1 = __importDefault(require("fs/promises"));
function makeExecutableIfNoPermissions(filePath) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const stats = yield promises_1.default.stat(filePath);
            const currentPermissions = stats.mode;
            const hasExecutePermissions = (currentPermissions & promises_1.default.constants.S_IXUSR)
                || (currentPermissions & promises_1.default.constants.S_IXGRP)
                || (currentPermissions & promises_1.default.constants.S_IXOTH);
            if (!hasExecutePermissions) {
                const newPermissions = currentPermissions | promises_1.default.constants.S_IXUSR | promises_1.default.constants.S_IXGRP | promises_1.default.constants.S_IXOTH;
                yield promises_1.default.chmod(filePath, newPermissions);
                console.log(`Added execute permissions to ${filePath}`);
            }
            else {
                console.log(`${filePath} already has execute permissions.`);
            }
        }
        catch (error) {
            console.error(`An error occurred: ${error}`);
        }
    });
}
