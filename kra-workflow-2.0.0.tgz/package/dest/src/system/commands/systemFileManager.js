"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.removeDirectory = exports.removeFile = void 0;
const bash = __importStar(require("@/utils/bashHelper"));
const ui = __importStar(require("@/UI/generalUI"));
const menuChain_1 = require("@/UI/menuChain");
var SearchTargetType;
(function (SearchTargetType) {
    SearchTargetType["File"] = "f";
    SearchTargetType["Directory"] = "d";
})(SearchTargetType || (SearchTargetType = {}));
const SYSTEM_CONSTANTS = {
    MESSAGES: {
        FILE_PROMPT: 'Pick the file you want to remove:',
        DIR_PROMPT: 'Pick the directory you want to remove:',
        SEARCH_INPUT: 'Enter a search term (minimum 2 characters):',
        EXACT_MATCH: 'Do you want to search for exact match?',
        NO_RESULTS: 'No matches found for the given search criteria.',
        CONFIRM_FILE_DELETE: 'Are you sure you want to delete this file?',
        CONFIRM_DIR_DELETE: 'Are you sure you want to delete this directory and all its contents?',
    },
    VALIDATION: {
        MIN_SEARCH_LENGTH: 2,
    }
};
const isValidSearchTerm = (term, type) => {
    if (type === SearchTargetType.Directory) {
        return term !== undefined && term !== null;
    }
    return Boolean(term && term.length >= SYSTEM_CONSTANTS.VALIDATION.MIN_SEARCH_LENGTH);
};
const sanitizeSearchTerm = (term) => {
    return term.replace(/['"\\]/g, '');
};
const searchByName = (name, exactMatch, type) => __awaiter(void 0, void 0, void 0, function* () {
    if (!isValidSearchTerm(name, type)) {
        throw new Error(`Search term must be at least ${SYSTEM_CONSTANTS.VALIDATION.MIN_SEARCH_LENGTH} characters long`);
    }
    try {
        const match = exactMatch ? '' : '*';
        const sanitizedName = sanitizeSearchTerm(name);
        const grepResult = yield bash.execCommand(`find . -type ${type} -iname "${match}${sanitizedName}${match}"`);
        return grepResult.stdout.split('\n').filter(Boolean);
    }
    catch (error) {
        throw new Error(`Search failed: ${error.message}`);
    }
});
const getSearchCriteria = () => __awaiter(void 0, void 0, void 0, function* () {
    const { searchString, exactMatch } = yield (0, menuChain_1.menuChain)()
        .step('searchString', () => __awaiter(void 0, void 0, void 0, function* () { return ui.askUserForInput(SYSTEM_CONSTANTS.MESSAGES.SEARCH_INPUT); }))
        .step('exactMatch', () => __awaiter(void 0, void 0, void 0, function* () { return ui.promptUserYesOrNo(SYSTEM_CONSTANTS.MESSAGES.EXACT_MATCH); }))
        .run();
    return {
        searchString: (searchString).trim(),
        exactMatch: exactMatch,
    };
});
const selectFromMatchingFiles = () => __awaiter(void 0, void 0, void 0, function* () {
    const criteria = yield getSearchCriteria();
    const matchingFiles = yield searchByName(criteria.searchString, criteria.exactMatch, SearchTargetType.File);
    if (!matchingFiles.length) {
        return null;
    }
    return yield ui.searchSelectAndReturnFromArray({
        itemsArray: matchingFiles,
        prompt: SYSTEM_CONSTANTS.MESSAGES.DIR_PROMPT
    });
});
const selectFromMatchingDirectories = () => __awaiter(void 0, void 0, void 0, function* () {
    const criteria = yield getSearchCriteria();
    const matchingDirs = yield searchByName(criteria.searchString, criteria.exactMatch, SearchTargetType.Directory);
    if (!matchingDirs.length) {
        return null;
    }
    return yield ui.searchSelectAndReturnFromArray({
        itemsArray: matchingDirs,
        prompt: SYSTEM_CONSTANTS.MESSAGES.DIR_PROMPT
    });
});
const removeFile = () => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { fileToRemove, confirmed } = yield (0, menuChain_1.menuChain)()
            .step('fileToRemove', () => __awaiter(void 0, void 0, void 0, function* () {
            const f = yield selectFromMatchingFiles();
            if (!f) {
                console.log(SYSTEM_CONSTANTS.MESSAGES.NO_RESULTS);
                throw new menuChain_1.UserCancelled();
            }
            return f;
        }))
            .step('confirmed', () => __awaiter(void 0, void 0, void 0, function* () { return ui.promptUserYesOrNo(SYSTEM_CONSTANTS.MESSAGES.CONFIRM_FILE_DELETE); }))
            .run();
        if (!confirmed)
            return;
        yield bash.execCommand(`rm "${fileToRemove}"`);
    }
    catch (error) {
        if (error instanceof menuChain_1.UserCancelled)
            throw error;
        throw new Error(`Failed to remove file: ${error.message}`);
    }
});
exports.removeFile = removeFile;
const removeDirectory = () => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { dirToRemove, confirmed } = yield (0, menuChain_1.menuChain)()
            .step('dirToRemove', () => __awaiter(void 0, void 0, void 0, function* () {
            const d = yield selectFromMatchingDirectories();
            if (!d) {
                console.log(SYSTEM_CONSTANTS.MESSAGES.NO_RESULTS);
                throw new menuChain_1.UserCancelled();
            }
            return d;
        }))
            .step('confirmed', () => __awaiter(void 0, void 0, void 0, function* () { return ui.promptUserYesOrNo(SYSTEM_CONSTANTS.MESSAGES.CONFIRM_DIR_DELETE); }))
            .run();
        if (!confirmed)
            return;
        yield bash.execCommand(`rm -rf "${dirToRemove}"`);
    }
    catch (error) {
        if (error instanceof menuChain_1.UserCancelled)
            throw error;
        throw new Error(`Failed to remove directory: ${error.message}`);
    }
});
exports.removeDirectory = removeDirectory;
