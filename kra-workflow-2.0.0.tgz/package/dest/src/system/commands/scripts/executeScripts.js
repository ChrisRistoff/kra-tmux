"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.executeScript = executeScript;
const promises_1 = __importDefault(require("fs/promises"));
const filePaths_1 = require("@/filePaths");
const ui = __importStar(require("@/UI/generalUI"));
const bash = __importStar(require("@/utils/bashHelper"));
const utils = __importStar(require("@/system/utils/fileUtils"));
const common_1 = require("@/utils/common");
function executeScript() {
    return __awaiter(this, void 0, void 0, function* () {
        const availableScripts = (0, common_1.filterGitKeep)(yield promises_1.default.readdir(filePaths_1.systemScriptsPath));
        const scriptToRun = yield ui.searchSelectAndReturnFromArray({
            itemsArray: availableScripts,
            prompt: 'Choose a script from the list to run: '
        });
        const scriptFilePath = `${filePaths_1.systemScriptsPath}/${scriptToRun}`;
        yield utils.makeExecutableIfNoPermissions(scriptFilePath);
        const script = yield bash.execCommand(`sh ${scriptFilePath}`);
        if (script.stdout) {
            console.log(script.stdout);
        }
        else if (script.stderr) {
            console.log(script.stderr);
        }
    });
}
