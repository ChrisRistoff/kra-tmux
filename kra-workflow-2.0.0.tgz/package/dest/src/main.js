#!/usr/bin/env node
"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const aiCommands_1 = require("@/commandsMaps/aiCommands");
const gitCommands_1 = require("@/commandsMaps/gitCommands");
const tmuxCommands_1 = require("@/commandsMaps/tmuxCommands");
const systemCommands_1 = require("@/commandsMaps/systemCommands");
const manageSettings_1 = require("@/manageSettings");
const workflow_ascii_1 = require("@/data/workflow-ascii");
const menuChain_1 = require("@/UI/menuChain");
const install_1 = require("@/setup/install");
const main = () => __awaiter(void 0, void 0, void 0, function* () {
    const args = process.argv.slice(2);
    if (args.length === 0) {
        console.log(workflow_ascii_1.workflowAscii);
        process.exit(1);
    }
    if (!(0, install_1.isInstalled)()) {
        (0, install_1.runInstall)();
    }
    const commandType = args[0];
    let commandName = args[1];
    let command;
    switch (commandType) {
        case 'sys':
            (0, systemCommands_1.handleSysCommandNotExist)(commandName);
            command = systemCommands_1.systemCommands[commandName];
            break;
        case 'tmux':
            (0, tmuxCommands_1.handleTmuxCommandNotExist)(commandName);
            command = tmuxCommands_1.tmuxCommands[commandName];
            break;
        case 'git':
            (0, gitCommands_1.handleGitCommandNotExist)(commandName);
            command = gitCommands_1.gitCommands[commandName];
            break;
        case 'ai':
            (0, aiCommands_1.handleAiCommandNotExist)(commandName);
            command = aiCommands_1.aiCommands[commandName];
            break;
        case 'settings':
            yield (0, manageSettings_1.handleChangeSettings)();
            return;
        case 'init':
        case 'migrate':
            console.log(`'${commandType}' is no longer a kra subcommand. Setup runs automatically via npm postinstall (and on first run as a fallback).`);
            console.log('To force re-run setup: delete ~/.kra/.installed and run any kra command again, or reinstall the package.');
            process.exit(1);
        default:
            console.log(workflow_ascii_1.workflowAscii);
            console.table({ [`${commandType}`]: 'Is not a valid command' });
            process.exit(1);
    }
    try {
        yield command();
    }
    catch (error) {
        throw error;
    }
});
main().catch((err) => {
    if (err instanceof menuChain_1.UserCancelled) {
        process.exit(0);
    }
    console.error(err);
    process.exit(1);
});
