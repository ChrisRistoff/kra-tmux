"use strict";
/**
 * Provider registry shared between AIChat and AIAgent (BYOK).
 *
 * All listed providers speak the OpenAI Chat Completions wire format.
 * Mistral exposes an OpenAI-compatible endpoint at https://api.mistral.ai/v1,
 * so it lives here too — no separate SDK path is needed.
 *
 * Adding a new provider: add it to SUPPORTED_PROVIDERS, add a baseURL case
 * in getProviderBaseURL, an apiKey case in getProviderApiKey, and (optionally)
 * a live fetcher branch in modelCatalog.ts.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.SUPPORTED_PROVIDERS = void 0;
exports.getProviderBaseURL = getProviderBaseURL;
exports.getProviderApiKey = getProviderApiKey;
const keys = __importStar(require("@/AI/AIChat/data/keys"));
exports.SUPPORTED_PROVIDERS = [
    'deep-infra',
    'deep-seek',
    'open-router',
    'gemini',
    'open-ai',
    'mistral',
];
function getProviderBaseURL(provider) {
    switch (provider) {
        case 'deep-infra':
            return 'https://api.deepinfra.com/v1/openai';
        case 'deep-seek':
            return 'https://api.deepseek.com/v1';
        case 'open-router':
            return 'https://openrouter.ai/api/v1';
        case 'gemini':
            return 'https://generativelanguage.googleapis.com/v1beta/openai/';
        case 'open-ai':
            return 'https://api.openai.com/v1';
        case 'mistral':
            return 'https://api.mistral.ai/v1';
        default:
            throw new Error(`Provider '${provider}' has no configured baseURL.`);
    }
}
function getProviderApiKey(provider) {
    switch (provider) {
        case 'deep-infra':
            return keys.getDeepInfraKey();
        case 'deep-seek':
            return keys.getDeepSeekKey();
        case 'open-router':
            return keys.getOpenRouterKey();
        case 'gemini':
            return keys.getGeminiKey();
        case 'mistral':
            return keys.getMistralKey();
        case 'open-ai': {
            const fromEnv = process.env['OPENAI_API_KEY'];
            if (!fromEnv) {
                throw new Error('OPENAI_API_KEY environment variable is not set');
            }
            return fromEnv;
        }
        default:
            throw new Error(`Provider '${provider}' has no configured API key getter.`);
    }
}
