"use strict";
/**
 * Live model catalog — shared between AIChat and AIAgent (BYOK).
 *
 * Fetches the available models for each provider directly from the provider's
 * HTTP API at session-start time, attaching whatever metadata the provider
 * exposes (context window, per-token pricing). For providers whose model-list
 * endpoint does not include such metadata, a small static fallback table fills
 * in the well-known values.
 *
 * Results are cached on disk under `~/.kra/model-catalog/<provider>.json`
 * with a 24-hour TTL. On network failure we return the most recently cached
 * snapshot (even if expired) and only fall through to the built-in static
 * lists if no cache exists.
 *
 * The catalog is the single source of truth for provider models — for both
 * the AIChat picker and the BYOK agent picker. It also provides the
 * context-window number that drives proactive compaction in
 * `byokSession.streamOnePass`.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getModelCatalog = getModelCatalog;
exports.formatModelInfoForPicker = formatModelInfoForPicker;
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const filePaths_1 = require("@/filePaths");
const providers_1 = require("@/AI/shared/data/providers");
// ─── Cache layout ────────────────────────────────────────────────────────────
const CACHE_TTL_MS = 24 * 60 * 60 * 1000;
function cacheDir() {
    return path.join((0, filePaths_1.kraHome)(), 'model-catalog');
}
function cachePath(provider) {
    return path.join(cacheDir(), `${provider}.json`);
}
function readCache(provider) {
    try {
        const raw = fs.readFileSync(cachePath(provider), 'utf8');
        const parsed = JSON.parse(raw);
        if (typeof parsed.fetchedAt !== 'number' || !Array.isArray(parsed.models)) {
            return undefined;
        }
        return parsed;
    }
    catch (_a) {
        return undefined;
    }
}
function writeCache(provider, models) {
    try {
        fs.mkdirSync(cacheDir(), { recursive: true });
        const entry = { fetchedAt: Date.now(), models };
        fs.writeFileSync(cachePath(provider), JSON.stringify(entry, null, 2), 'utf8');
    }
    catch (_a) {
        // best-effort; not fatal
    }
}
// ─── Static fallback metadata ────────────────────────────────────────────────
const STATIC_DEEPSEEK = {
    'deepseek-chat': { contextWindow: 128000, pricing: { inputPerM: 0.27, outputPerM: 1.10, cachedInputPerM: 0.07 } },
    'deepseek-reasoner': { contextWindow: 128000, pricing: { inputPerM: 0.55, outputPerM: 2.19, cachedInputPerM: 0.14 } },
};
const STATIC_OPENAI = {
    'gpt-4o': { contextWindow: 128000, pricing: { inputPerM: 2.50, outputPerM: 10.00, cachedInputPerM: 1.25 } },
    'gpt-4o-mini': { contextWindow: 128000, pricing: { inputPerM: 0.15, outputPerM: 0.60, cachedInputPerM: 0.075 } },
    'o1-mini': { contextWindow: 128000, pricing: { inputPerM: 1.10, outputPerM: 4.40 } },
    'o3-mini': { contextWindow: 200000, pricing: { inputPerM: 1.10, outputPerM: 4.40 } },
    'gpt-5-mini': { contextWindow: 400000, pricing: { inputPerM: 0.25, outputPerM: 2.00 } },
};
const STATIC_GEMINI_PRICES = {
    'gemini-2.5-pro': { inputPerM: 1.25, outputPerM: 10.00 },
    'gemini-2.5-flash': { inputPerM: 0.30, outputPerM: 2.50 },
    'gemini-2.5-flash-lite': { inputPerM: 0.10, outputPerM: 0.40 },
};
const STATIC_MISTRAL = {
    'mistral-large-latest': { contextWindow: 128000, pricing: { inputPerM: 2.00, outputPerM: 6.00 } },
    'mistral-small-latest': { contextWindow: 128000, pricing: { inputPerM: 0.20, outputPerM: 0.60 } },
    'codestral-latest': { contextWindow: 256000, pricing: { inputPerM: 0.30, outputPerM: 0.90 } },
    'open-mistral-nemo': { contextWindow: 128000, pricing: { inputPerM: 0.15, outputPerM: 0.15 } },
    'open-mixtral-8x22b': { contextWindow: 64000, pricing: { inputPerM: 2.00, outputPerM: 6.00 } },
};
const STATIC_FALLBACK_MODELS = {
    'deep-infra': [
        { id: 'moonshotai/Kimi-K2-Instruct', label: 'moonshotai/Kimi-K2-Instruct', contextWindow: 128000, pricing: { inputPerM: 0.75, outputPerM: 4.00, cachedInputPerM: 0.15 } },
        { id: 'deepseek-ai/DeepSeek-V3', label: 'deepseek-ai/DeepSeek-V3', contextWindow: 64000, pricing: { inputPerM: 0.27, outputPerM: 1.10 } },
        { id: 'Qwen/Qwen3-Coder-480B-A35B-Instruct', label: 'Qwen/Qwen3-Coder-480B-A35B-Instruct', contextWindow: 256000, pricing: { inputPerM: 0.40, outputPerM: 1.60 } },
    ],
    'deep-seek': [
        { id: 'deepseek-chat', label: 'deepseek-chat', contextWindow: 128000, pricing: STATIC_DEEPSEEK['deepseek-chat'].pricing },
        { id: 'deepseek-reasoner', label: 'deepseek-reasoner', contextWindow: 128000, pricing: STATIC_DEEPSEEK['deepseek-reasoner'].pricing },
    ],
    'open-router': [
        { id: 'openai/gpt-4o-mini', label: 'openai/gpt-4o-mini', contextWindow: 128000, pricing: { inputPerM: 0.15, outputPerM: 0.60 } },
        { id: 'anthropic/claude-3.5-sonnet', label: 'anthropic/claude-3.5-sonnet', contextWindow: 200000, pricing: { inputPerM: 3.00, outputPerM: 15.00 } },
    ],
    'gemini': [
        { id: 'gemini-2.5-pro', label: 'gemini-2.5-pro', contextWindow: 1048576, pricing: STATIC_GEMINI_PRICES['gemini-2.5-pro'] },
        { id: 'gemini-2.5-flash', label: 'gemini-2.5-flash', contextWindow: 1048576, pricing: STATIC_GEMINI_PRICES['gemini-2.5-flash'] },
    ],
    'open-ai': [
        { id: 'gpt-4o', label: 'gpt-4o', contextWindow: 128000, pricing: STATIC_OPENAI['gpt-4o'].pricing },
        { id: 'gpt-4o-mini', label: 'gpt-4o-mini', contextWindow: 128000, pricing: STATIC_OPENAI['gpt-4o-mini'].pricing },
    ],
    'mistral': [
        { id: 'mistral-large-latest', label: 'mistral-large-latest', contextWindow: 128000, pricing: STATIC_MISTRAL['mistral-large-latest'].pricing },
        { id: 'mistral-small-latest', label: 'mistral-small-latest', contextWindow: 128000, pricing: STATIC_MISTRAL['mistral-small-latest'].pricing },
        { id: 'codestral-latest', label: 'codestral-latest', contextWindow: 256000, pricing: STATIC_MISTRAL['codestral-latest'].pricing },
    ],
};
function fetchOpenRouter() {
    return __awaiter(this, void 0, void 0, function* () {
        const res = yield fetch('https://openrouter.ai/api/v1/models');
        if (!res.ok) {
            throw new Error(`OpenRouter /models returned ${res.status}`);
        }
        const json = yield res.json();
        const dollarPerToken = (s) => {
            if (!s) {
                return undefined;
            }
            const n = Number(s);
            return Number.isFinite(n) ? n : undefined;
        };
        return json.data.map((m) => {
            var _a, _b, _c, _d, _e;
            const inputPerToken = dollarPerToken((_a = m.pricing) === null || _a === void 0 ? void 0 : _a.prompt);
            const outputPerToken = dollarPerToken((_b = m.pricing) === null || _b === void 0 ? void 0 : _b.completion);
            const cachedPerToken = dollarPerToken((_c = m.pricing) === null || _c === void 0 ? void 0 : _c.input_cache_read);
            const pricing = inputPerToken !== undefined && outputPerToken !== undefined
                ? Object.assign({ inputPerM: inputPerToken * 1000000, outputPerM: outputPerToken * 1000000 }, (cachedPerToken !== undefined ? { cachedInputPerM: cachedPerToken * 1000000 } : {})) : undefined;
            return Object.assign({ id: m.id, label: (_d = m.name) !== null && _d !== void 0 ? _d : m.id, contextWindow: (_e = m.context_length) !== null && _e !== void 0 ? _e : 0 }, (pricing ? { pricing } : {}));
        });
    });
}
function fetchDeepInfra() {
    return __awaiter(this, void 0, void 0, function* () {
        const res = yield fetch('https://api.deepinfra.com/models/list');
        if (!res.ok) {
            throw new Error(`DeepInfra /models/list returned ${res.status}`);
        }
        const json = yield res.json();
        return json
            .filter((m) => m.type === 'text-generation')
            .map((m) => {
            var _a, _b, _c;
            const inputCents = (_a = m.pricing) === null || _a === void 0 ? void 0 : _a.cents_per_input_token;
            const outputCents = (_b = m.pricing) === null || _b === void 0 ? void 0 : _b.cents_per_output_token;
            const pricing = typeof inputCents === 'number' && typeof outputCents === 'number'
                ? {
                    inputPerM: inputCents * 10000,
                    outputPerM: outputCents * 10000,
                }
                : undefined;
            return Object.assign({ id: m.model_name, label: m.model_name, contextWindow: (_c = m.max_tokens) !== null && _c !== void 0 ? _c : 0 }, (pricing ? { pricing } : {}));
        });
    });
}
function fetchDeepSeek(apiKey) {
    return __awaiter(this, void 0, void 0, function* () {
        const res = yield fetch('https://api.deepseek.com/models', {
            headers: { Authorization: `Bearer ${apiKey}` },
        });
        if (!res.ok) {
            throw new Error(`DeepSeek /models returned ${res.status}`);
        }
        const json = yield res.json();
        return json.data.map((m) => {
            var _a;
            const meta = STATIC_DEEPSEEK[m.id];
            return Object.assign({ id: m.id, label: m.id, contextWindow: (_a = meta.contextWindow) !== null && _a !== void 0 ? _a : 0 }, (meta ? { pricing: meta.pricing } : {}));
        });
    });
}
function fetchGemini(apiKey) {
    return __awaiter(this, void 0, void 0, function* () {
        const res = yield fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${encodeURIComponent(apiKey)}`);
        if (!res.ok) {
            throw new Error(`Gemini /models returned ${res.status}`);
        }
        const json = yield res.json();
        return json.models
            .filter((m) => { var _a; return (_a = m.supportedGenerationMethods) === null || _a === void 0 ? void 0 : _a.includes('generateContent'); })
            .map((m) => {
            var _a, _b;
            const id = m.name.replace(/^models\//, '');
            const pricing = STATIC_GEMINI_PRICES[id];
            return Object.assign({ id, label: (_a = m.displayName) !== null && _a !== void 0 ? _a : id, contextWindow: (_b = m.inputTokenLimit) !== null && _b !== void 0 ? _b : 0 }, (pricing ? { pricing } : {}));
        });
    });
}
function fetchOpenAI(apiKey) {
    return __awaiter(this, void 0, void 0, function* () {
        const res = yield fetch('https://api.openai.com/v1/models', {
            headers: { Authorization: `Bearer ${apiKey}` },
        });
        if (!res.ok) {
            throw new Error(`OpenAI /models returned ${res.status}`);
        }
        const json = yield res.json();
        return json.data.map((m) => {
            const meta = STATIC_OPENAI[m.id];
            return Object.assign({ id: m.id, label: m.id, contextWindow: meta.contextWindow || 0 }, (meta ? { pricing: meta.pricing } : {}));
        });
    });
}
function fetchMistral(apiKey) {
    return __awaiter(this, void 0, void 0, function* () {
        const res = yield fetch('https://api.mistral.ai/v1/models', {
            headers: { Authorization: `Bearer ${apiKey}` },
        });
        if (!res.ok) {
            throw new Error(`Mistral /models returned ${res.status}`);
        }
        const json = yield res.json();
        return json.data.map((m) => {
            var _a, _b;
            const meta = STATIC_MISTRAL[m.id];
            return Object.assign({ id: m.id, label: m.id, contextWindow: (_b = (_a = m.max_context_length) !== null && _a !== void 0 ? _a : meta.contextWindow) !== null && _b !== void 0 ? _b : 0 }, (meta.pricing ? { pricing: meta.pricing } : {}));
        });
    });
}
function fetchLive(provider) {
    return __awaiter(this, void 0, void 0, function* () {
        switch (provider) {
            case 'open-router':
                return fetchOpenRouter();
            case 'deep-infra':
                return fetchDeepInfra();
            case 'deep-seek':
                return fetchDeepSeek((0, providers_1.getProviderApiKey)(provider));
            case 'gemini':
                return fetchGemini((0, providers_1.getProviderApiKey)(provider));
            case 'open-ai':
                return fetchOpenAI((0, providers_1.getProviderApiKey)(provider));
            case 'mistral':
                return fetchMistral((0, providers_1.getProviderApiKey)(provider));
            default: {
                const exhaustive = provider;
                throw new Error(`No live fetcher for provider '${exhaustive}'`);
            }
        }
    });
}
// ─── Public API ──────────────────────────────────────────────────────────────
function getModelCatalog(provider_1) {
    return __awaiter(this, arguments, void 0, function* (provider, opts = {}) {
        if (!opts.forceRefresh) {
            const cached = readCache(provider);
            if (cached && Date.now() - cached.fetchedAt < CACHE_TTL_MS) {
                return cached.models;
            }
        }
        try {
            const models = yield fetchLive(provider);
            if (models.length > 0) {
                writeCache(provider, models);
                return models;
            }
        }
        catch (_a) {
            // fall through to stale cache / static fallback
        }
        const stale = readCache(provider);
        if (stale) {
            return stale.models;
        }
        return STATIC_FALLBACK_MODELS[provider];
    });
}
function formatModelInfoForPicker(modelInfo) {
    const ctxStr = modelInfo.contextWindow > 0
        ? `${Math.round(modelInfo.contextWindow / 1000)}k ctx`.padEnd(10)
        : '? ctx    '.padEnd(10);
    const priceStr = modelInfo.pricing
        ? `$${modelInfo.pricing.inputPerM.toFixed(2)}/$${modelInfo.pricing.outputPerM.toFixed(2)} in/out` +
            (modelInfo.pricing.cachedInputPerM !== undefined
                ? `  cached $${modelInfo.pricing.cachedInputPerM.toFixed(2)}`
                : '')
        : '? pricing';
    const label = modelInfo.label.padEnd(48);
    return `${label}  ${ctxStr}  ${priceStr}`;
}
