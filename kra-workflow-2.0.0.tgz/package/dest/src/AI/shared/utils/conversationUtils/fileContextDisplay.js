"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.formatContextSummary = formatContextSummary;
exports.formatContextPickerItem = formatContextPickerItem;
exports.formatContextPopupEntry = formatContextPopupEntry;
const promises_1 = __importDefault(require("fs/promises"));
const fileContextStore_1 = require("./fileContextStore");
function readFileStats(filePath) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const content = yield promises_1.default.readFile(filePath, 'utf-8');
            return {
                lineCount: content.split('\n').length,
                sizeKB: Math.round(content.length / 1024),
            };
        }
        catch (_a) {
            return null;
        }
    });
}
function formatContextSummary(context) {
    const fileName = (0, fileContextStore_1.getContextFileName)(context.filePath);
    if (!context.isPartial) {
        return `${fileName} (full file)`;
    }
    const lineRange = (0, fileContextStore_1.getContextLineRange)(context.startLine, context.endLine);
    return `${fileName} (${lineRange})`;
}
function formatContextPickerItem(context, index) {
    return __awaiter(this, void 0, void 0, function* () {
        const fileName = (0, fileContextStore_1.getContextFileName)(context.filePath);
        if (context.isPartial) {
            const lineRange = (0, fileContextStore_1.getContextLineRange)(context.startLine, context.endLine);
            return `${index + 1}. 📄 ${fileName} (${lineRange})`;
        }
        const stats = yield readFileStats(context.filePath);
        if (!stats) {
            return `${index + 1}. ❌ ${fileName} (error reading file)`;
        }
        return `${index + 1}. 📁 ${fileName} (${stats.lineCount} lines, ${stats.sizeKB}KB)`;
    });
}
function formatContextPopupEntry(context, index) {
    return __awaiter(this, void 0, void 0, function* () {
        const fileName = (0, fileContextStore_1.getContextFileName)(context.filePath);
        if (context.isPartial) {
            const lineRange = (0, fileContextStore_1.getContextLineRange)(context.startLine, context.endLine);
            return [`${index + 1}. 📄 ${fileName} (${lineRange})`, `   ${context.filePath}`, ''];
        }
        const stats = yield readFileStats(context.filePath);
        if (!stats) {
            return [`${index + 1}. ❌ ${fileName} (error reading file)`, `   ${context.filePath}`, ''];
        }
        return [
            `${index + 1}. 📁 ${fileName} (${stats.lineCount} lines, ${stats.sizeKB}KB)`,
            `   ${context.filePath}`,
            '',
        ];
    });
}
