"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.refreshTranscript = refreshTranscript;
exports.addFolderContext = addFolderContext;
exports.addEntireFileContext = addEntireFileContext;
exports.addPartialFileContext = addPartialFileContext;
const promises_1 = __importDefault(require("fs/promises"));
const fileContextStore_1 = require("./fileContextStore");
/**
 * Reload the chat transcript window so just-appended file-context entries
 * become visible immediately. The bare `edit!` we used before reloaded
 * whichever window had focus (often the prompt buffer), leaving the chat
 * transcript stale until the next layout refresh.
 */
function refreshTranscript(nvim, agentMode) {
    return __awaiter(this, void 0, void 0, function* () {
        const moduleName = agentMode ? 'kra_agent_layout' : 'kra_chat_layout';
        try {
            yield nvim.executeLua(`require('${moduleName}').refresh()`, []);
        }
        catch (err) {
            console.warn('refreshTranscript: layout refresh failed, falling back to edit!', err);
            try {
                yield nvim.command('edit!');
                yield nvim.command('redraw!');
                yield nvim.command('normal! G');
            }
            catch (fallbackErr) {
                console.warn('refreshTranscript: fallback edit! also failed', fallbackErr);
            }
        }
    });
}
const MAX_FILE_BYTES = 300000;
/**
 * Build the chat-file summary block written when a file is added to context.
 * Agent mode keeps it tiny because the SDK attachment carries the actual content.
 */
function buildContextSummary(agentMode, fileName, filePath, ext, lineCount, sizeBytes, extraHint) {
    if (agentMode) {
        return `# 📎 ${filePath} (${lineCount} lines, ${ext}) attached\n`;
    }
    const sizeKB = Math.round(sizeBytes / 1024);
    const hintLine = extraHint ? `// ${extraHint}\n` : '';
    return `📁 ${fileName} (${lineCount} lines, ${sizeKB}KB)\n\n\`\`\`${ext}\n// Full file content loaded: ${filePath}\n${hintLine}// File contains ${lineCount} lines of ${ext} code\n\`\`\`\n\n`;
}
/**
 * Recursively collect all files inside a folder (skips hidden dirs and node_modules)
**/
function getAllFilesInFolder(folderPath) {
    return __awaiter(this, void 0, void 0, function* () {
        const files = [];
        function walk(dir) {
            return __awaiter(this, void 0, void 0, function* () {
                try {
                    const entries = yield promises_1.default.readdir(dir, { withFileTypes: true });
                    for (const entry of entries) {
                        if (entry.name.startsWith('.') || entry.name === 'node_modules')
                            continue;
                        const fullPath = `${dir}/${entry.name}`;
                        if (entry.isDirectory()) {
                            yield walk(fullPath);
                        }
                        else if (entry.isFile()) {
                            files.push(fullPath);
                        }
                    }
                }
                catch (_a) {
                    // skip unreadable directories
                }
            });
        }
        yield walk(folderPath);
        return files;
    });
}
/**
 * Add all files in a folder to context (skips files larger than MAX_FILE_BYTES)
**/
function addFolderContext(nvim, chatFile, folderPath, agentMode) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const allFiles = yield getAllFilesInFolder(folderPath);
            if (allFiles.length === 0) {
                yield nvim.command('echohl WarningMsg | echo "No files found in folder" | echohl None');
                return;
            }
            let addedCount = 0;
            let totalLines = 0;
            for (const filePath of allFiles) {
                try {
                    const content = yield promises_1.default.readFile(filePath, 'utf-8');
                    if (content.length > MAX_FILE_BYTES)
                        continue;
                    const fileName = filePath.split('/').pop() || filePath;
                    const ext = (0, fileContextStore_1.getFileExtension)(fileName);
                    const lineCount = content.split('\n').length;
                    totalLines += lineCount;
                    const chatEntry = buildContextSummary(agentMode, fileName, filePath, ext, lineCount, content.length);
                    (0, fileContextStore_1.upsertFileContext)({ filePath, isPartial: false, summary: `Full file: ${fileName} (${lineCount} lines)`, chatEntry });
                    yield promises_1.default.appendFile(chatFile, chatEntry);
                    addedCount++;
                }
                catch (_a) {
                    // skip unreadable files
                }
            }
            const folderName = folderPath.split('/').pop() || folderPath;
            yield refreshTranscript(nvim, agentMode);
            yield nvim.command(`echohl MoreMsg | echo "Added ${addedCount} files from '${folderName}' (${totalLines} total lines)" | echohl None`);
        }
        catch (error) {
            console.error('addFolderContext error:', error);
            yield nvim.command('echohl ErrorMsg | echo "Error reading folder" | echohl None');
        }
    });
}
/**
 * Add entire file content to context
**/
function addEntireFileContext(nvim, chatFile, filePath, agentMode) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const content = yield promises_1.default.readFile(filePath, 'utf-8');
            const fileName = filePath.split('/').pop() || filePath;
            const ext = (0, fileContextStore_1.getFileExtension)(fileName);
            const lineCount = content.split('\n').length;
            const chatEntry = buildContextSummary(agentMode, fileName, filePath, ext, lineCount, content.length, 'Use this file context in your responses');
            (0, fileContextStore_1.upsertFileContext)({ filePath, isPartial: false, summary: `Full file: ${fileName} (${lineCount} lines)`, chatEntry });
            // In agent mode, only write a short reference — the SDK attachment delivers the actual content
            yield promises_1.default.appendFile(chatFile, chatEntry);
            yield refreshTranscript(nvim, agentMode);
            yield nvim.command(`echohl MoreMsg | echo "Added ${fileName} (${lineCount} lines) - full content available to AI" | echohl None`);
        }
        catch (error) {
            yield nvim.command(`echohl ErrorMsg | echo "Failed to read file: ${filePath}" | echohl None`);
            console.error('Node.js readFile error:', error);
        }
    });
}
/**
 * Add partial file content to context via visual selection
**/
function addPartialFileContext(nvim, chatFile, filePath, agentMode) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            yield nvim.command(`vs ${filePath.replace(/ /g, '\\ ')}`);
            yield nvim.command('setlocal cursorline');
            yield nvim.command('echohl MoreMsg | echo "Select text with visual mode, then press Space to add to context" | echohl None');
            const channelId = yield nvim.channelId;
            let handler = null;
            yield nvim.command(`
            function! CaptureAndSendSelection()
                let l:start_pos = getpos("'<")
                let l:end_pos = getpos("'>")
                let l:lines = getline(l:start_pos[1], l:end_pos[1])
                if len(l:lines) == 0
                    echohl WarningMsg | echo "No text selected" | echohl None
                    return
                endif

                if l:start_pos[1] == l:end_pos[1]
                    let l:selected_text = strpart(l:lines[0], l:start_pos[2] - 1, l:end_pos[2] - l:start_pos[2] + 1)
                else
                    let l:lines[0] = strpart(l:lines[0], l:start_pos[2] - 1)
                    let l:lines[-1] = strpart(l:lines[-1], 0, l:end_pos[2])
                    let l:selected_text = join(l:lines, "\\n")
                endif

                call rpcnotify(${channelId}, 'file_selection', 'add_selection', expand('%:p'), l:selected_text, l:start_pos[1], l:end_pos[1])
            endfunction
        `);
            const result = yield new Promise(resolve => {
                const timeout = setTimeout(() => {
                    if (handler) {
                        nvim.removeListener('notification', handler);
                        handler = null;
                    }
                    resolve('timeout');
                }, 60000);
                handler = (method, args) => {
                    if (method !== 'file_selection' || args[0] !== 'add_selection') {
                        return;
                    }
                    void (() => __awaiter(this, void 0, void 0, function* () {
                        clearTimeout(timeout);
                        if (handler) {
                            nvim.removeListener('notification', handler);
                            handler = null;
                        }
                        try {
                            const [, currentFile, selectedText, startLine, endLine] = args;
                            if (!(selectedText === null || selectedText === void 0 ? void 0 : selectedText.trim())) {
                                yield nvim.command('echohl WarningMsg | echo "No text selected or selection is empty" | echohl None');
                                resolve('error');
                                return;
                            }
                            const fileName = currentFile.split('/').pop() || currentFile;
                            const lineRange = startLine === endLine ? `line ${startLine}` : `lines ${startLine}-${endLine}`;
                            const ext = (0, fileContextStore_1.getFileExtension)(fileName);
                            const contextEntry = agentMode
                                ? `# 📎 ${currentFile} (${lineRange}) attached\n`
                                : `📁 ${fileName} (${lineRange})\n\n\`\`\`${ext}\n// Selected from: ${currentFile} (${lineRange})\n${selectedText}\n\`\`\`\n\n`;
                            (0, fileContextStore_1.upsertFileContext)({
                                filePath: currentFile,
                                isPartial: true,
                                startLine,
                                endLine,
                                summary: `Partial file: ${fileName} (${lineRange})`,
                                chatEntry: contextEntry,
                            });
                            try {
                                const winCount = yield nvim.call('winnr', '$');
                                if (winCount > 1)
                                    yield nvim.command('close');
                                else
                                    yield nvim.command(`edit ${chatFile.replace(/ /g, '\\ ')}`);
                            }
                            catch (closeError) {
                                console.warn('Failed to close window, editing chat file directly:', closeError);
                                yield nvim.command(`edit ${chatFile.replace(/ /g, '\\ ')}`);
                            }
                            yield promises_1.default.appendFile(chatFile, contextEntry);
                            yield refreshTranscript(nvim, agentMode);
                            yield nvim.command(`echohl MoreMsg | echo "Added ${fileName} (${lineRange}) - ${selectedText.length} chars" | echohl None`);
                            resolve('success');
                        }
                        catch (err) {
                            console.error('Error processing selection:', err);
                            yield nvim.command('echohl ErrorMsg | echo "Error processing selection" | echohl None');
                            resolve('error');
                        }
                    }))();
                };
                nvim.on('notification', handler);
                nvim.command(`
                vnoremap <buffer> <Space> <Esc>:call CaptureAndSendSelection()<CR>
                nnoremap <buffer> <Space> <Cmd>echohl WarningMsg <Bar> echo "Select text in visual mode first" <Bar> echohl None<CR>
            `).catch((err) => console.warn('Failed to set up keymaps:', err));
            });
            try {
                yield nvim.command('silent! nunmap <buffer> <Space>');
                yield nvim.command('silent! vunmap <buffer> <Space>');
                yield nvim.command('silent! delfunction CaptureAndSendSelection');
            }
            catch (err) {
                console.log('Failed to clean up keymaps/functions:', err);
            }
            if (result === 'timeout') {
                yield nvim.command('echohl WarningMsg | echo "Selection timed out" | echohl None');
            }
        }
        catch (error) {
            console.error('Error in addPartialFileContext:', error);
            yield nvim.command('echohl ErrorMsg | echo "Error opening file for selection" | echohl None');
        }
    });
}
