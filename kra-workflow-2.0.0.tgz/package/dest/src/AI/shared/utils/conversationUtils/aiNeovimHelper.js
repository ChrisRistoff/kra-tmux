"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleStopStream = handleStopStream;
exports.generateSocketPath = generateSocketPath;
exports.waitForSocket = waitForSocket;
exports.addNeovimFunctions = addNeovimFunctions;
exports.addCommands = addCommands;
exports.setupKeyBindings = setupKeyBindings;
exports.setupChatSplitLayout = setupChatSplitLayout;
exports.getChatPromptText = getChatPromptText;
exports.clearChatPrompt = clearChatPrompt;
exports.focusChatPrompt = focusChatPrompt;
exports.refreshChatLayout = refreshChatLayout;
exports.updateNvimAndGoToLastLine = updateNvimAndGoToLastLine;
const os_1 = __importDefault(require("os"));
const fs = __importStar(require("fs/promises"));
function handleStopStream(currentStreamController, nvim) {
    return __awaiter(this, void 0, void 0, function* () {
        if (currentStreamController && !currentStreamController.isAborted) {
            currentStreamController.abort();
            yield nvim.command('echohl WarningMsg | echo "Generation stopped" | echohl None');
        }
        else {
            yield nvim.command('echohl WarningMsg | echo "No active generation to stop" | echohl None');
        }
    });
}
function generateSocketPath() {
    return __awaiter(this, void 0, void 0, function* () {
        const randomString = Math.random().toString(36).substring(2, 15);
        return `${os_1.default.tmpdir()}/nvim-${randomString}.sock`;
    });
}
function waitForSocket(socketPath_1) {
    return __awaiter(this, arguments, void 0, function* (socketPath, timeout = 5000) {
        const start = Date.now();
        while (Date.now() - start < timeout) {
            try {
                yield fs.access(socketPath);
                return true;
            }
            catch (err) {
                yield new Promise(resolve => setTimeout(resolve, 200));
            }
        }
        return false;
    });
}
function addNeovimFunctions(nvim, channelId) {
    return __awaiter(this, void 0, void 0, function* () {
        yield nvim.command(`
        function! SaveAndSubmit()
            if exists('g:kra_agent_prompt_buf') || exists('g:kra_chat_prompt_buf')
                call rpcnotify(${channelId}, 'prompt_action', 'submit_pressed')
                return
            endif

            write
            call rpcnotify(${channelId}, 'prompt_action', 'submit_pressed')
        endfunction
    `);
        yield nvim.command(`
        function! AddFileContext()
            call rpcnotify(${channelId}, 'prompt_action', 'add_file_context')
        endfunction
    `);
        yield nvim.command(`
        function! StopStream()
            call rpcnotify(${channelId}, 'prompt_action', 'stop_stream')
        endfunction
    `);
        yield nvim.command(`
        function! ShowFileContextsPopup()
            call rpcnotify(${channelId}, 'prompt_action', 'show_contexts_popup')
        endfunction
    `);
        yield nvim.command(`
        function! RemoveFileContext()
            call rpcnotify(${channelId}, 'prompt_action', 'remove_file_context')
        endfunction
    `);
        yield nvim.command(`
        function! ClearContexts()
            call rpcnotify(${channelId}, 'prompt_action', 'clear_contexts')
        endfunction
    `);
    });
}
function addCommands(nvim) {
    return __awaiter(this, void 0, void 0, function* () {
        yield nvim.command(`command! -nargs=0 SubmitPrompt call SaveAndSubmit()`);
        yield nvim.command(`command! -nargs=0 AddFile call AddFileContext()`);
        yield nvim.command(`command! -nargs=0 StopGeneration call StopStream()`);
        yield nvim.command(`command! -nargs=0 ClearContexts call ClearContexts()`);
        yield nvim.command(`command! -nargs=0 RemoveFileContext call RemoveFileContext()`);
    });
}
function setupKeyBindings(nvim) {
    return __awaiter(this, void 0, void 0, function* () {
        if ('executeLua' in nvim && typeof nvim.executeLua === 'function') {
            // Global keymaps — no buffer=0 so they work regardless of which buffer is
            // current when this runs (timing with lazy.nvim startup is non-deterministic).
            yield nvim.executeLua(`
            local map = vim.keymap.set
            local opts = { silent = true }
            map('n', '<CR>', '<Cmd>call SaveAndSubmit()<CR>', vim.tbl_extend('force', opts, { desc = 'Submit user prompt' }))
            map('n', '@', '<Cmd>call AddFileContext()<CR>', vim.tbl_extend('force', opts, { desc = 'Add file context' }))
            map('n', '<C-c>', '<Cmd>call StopStream()<CR>', vim.tbl_extend('force', opts, { desc = 'Stop current agent turn' }))
            map('n', 'f', '<Cmd>call ShowFileContextsPopup()<CR>', vim.tbl_extend('force', opts, { desc = 'Show active file contexts' }))
            map('n', '<C-x>', '<Cmd>call ClearContexts()<CR>', vim.tbl_extend('force', opts, { desc = 'Clear file contexts' }))
            map('n', 'r', '<Cmd>call RemoveFileContext()<CR>', vim.tbl_extend('force', opts, { desc = 'Remove a file context' }))
        `, []);
            return;
        }
        yield nvim.command(`nnoremap <CR> :call SaveAndSubmit()<CR>`);
        yield nvim.command(`nnoremap @ :call AddFileContext()<CR>`);
        yield nvim.command(`nnoremap <C-c> :call StopStream()<CR>`);
        yield nvim.command(`nnoremap f :call ShowFileContextsPopup()<CR>`);
        yield nvim.command(`nnoremap <C-x> :call ClearContexts()<CR>`);
        yield nvim.command(`nnoremap r :call RemoveFileContext()<CR>`);
    });
}
function setupChatSplitLayout(nvim, channelId) {
    return __awaiter(this, void 0, void 0, function* () {
        yield nvim.executeLua(`require('kra_chat_layout').setup(...)`, [channelId]);
    });
}
function getChatPromptText(nvim) {
    return __awaiter(this, void 0, void 0, function* () {
        const prompt = yield nvim.executeLua(`return require('kra_chat_layout').get_prompt_text()`, []);
        return typeof prompt === 'string' ? prompt : '';
    });
}
function clearChatPrompt(nvim) {
    return __awaiter(this, void 0, void 0, function* () {
        yield nvim.executeLua(`require('kra_chat_layout').clear_prompt()`, []);
    });
}
function focusChatPrompt(nvim) {
    return __awaiter(this, void 0, void 0, function* () {
        yield nvim.executeLua(`require('kra_chat_layout').focus_prompt()`, []);
    });
}
function refreshChatLayout(nvim) {
    return __awaiter(this, void 0, void 0, function* () {
        yield nvim.executeLua(`require('kra_chat_layout').refresh()`, []);
    });
}
function updateNvimAndGoToLastLine(nvim) {
    return __awaiter(this, void 0, void 0, function* () {
        yield nvim.command('edit!');
        yield nvim.command('normal! G');
        yield nvim.command('normal! o');
    });
}
