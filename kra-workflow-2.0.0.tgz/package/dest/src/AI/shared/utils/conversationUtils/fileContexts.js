"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.clearFileContexts = exports.getFileExtension = exports.fileContexts = void 0;
exports.handleAddFileContext = handleAddFileContext;
exports.clearAllFileContexts = clearAllFileContexts;
exports.getFileContextsForPrompt = getFileContextsForPrompt;
exports.showFileContexts = showFileContexts;
exports.rebuildFileContextsFromChat = rebuildFileContextsFromChat;
exports.handleRemoveFileContext = handleRemoveFileContext;
exports.showFileContextsPopup = showFileContextsPopup;
const promises_1 = __importDefault(require("fs/promises"));
const fileContextDisplay_1 = require("./fileContextDisplay");
const fileContextPickers_1 = require("./fileContextPickers");
const fileContextOps_1 = require("./fileContextOps");
const fileContextStore_1 = require("./fileContextStore");
Object.defineProperty(exports, "fileContexts", { enumerable: true, get: function () { return fileContextStore_1.fileContexts; } });
Object.defineProperty(exports, "getFileExtension", { enumerable: true, get: function () { return fileContextStore_1.getFileExtension; } });
function handleAddFileContext(nvim, chatFile, options) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            yield nvim.command('echohl MoreMsg | echo "Opening context selector..." | echohl None');
            const selections = yield (0, fileContextPickers_1.selectFileOrFolder)(nvim);
            if (!selections || selections.length === 0) {
                yield nvim.command('echohl WarningMsg | echo "Cancelled" | echohl None');
                return;
            }
            const shareMode = yield (0, fileContextPickers_1.promptShareMode)(nvim);
            if (!shareMode) {
                yield nvim.command('echohl WarningMsg | echo "Cancelled" | echohl None');
                return;
            }
            const agentMode = options === null || options === void 0 ? void 0 : options.agentMode;
            for (const selection of selections) {
                const { path, isDir } = selection;
                if (isDir && shareMode === 'entire') {
                    yield (0, fileContextOps_1.addFolderContext)(nvim, chatFile, path.replace(/\/$/, ''), agentMode);
                    continue;
                }
                if (isDir && shareMode === 'snippet') {
                    const filesInFolder = yield (0, fileContextPickers_1.selectFileFromFolder)(nvim, path);
                    if (!filesInFolder || filesInFolder.length === 0) {
                        yield nvim.command('echohl WarningMsg | echo "No file selected" | echohl None');
                        continue;
                    }
                    for (const fileInFolder of filesInFolder) {
                        yield (0, fileContextOps_1.addPartialFileContext)(nvim, chatFile, fileInFolder, agentMode);
                    }
                    continue;
                }
                if (shareMode === 'entire') {
                    yield (0, fileContextOps_1.addEntireFileContext)(nvim, chatFile, path, agentMode);
                    continue;
                }
                yield (0, fileContextOps_1.addPartialFileContext)(nvim, chatFile, path, agentMode);
            }
        }
        catch (error) {
            console.error('Error adding file context:', error);
            yield nvim.command('echohl ErrorMsg | echo "Error adding file context" | echohl None');
        }
    });
}
/**
 * Clear all file contexts and show count
**/
function clearAllFileContexts(nvim, chatFile, options) {
    return __awaiter(this, void 0, void 0, function* () {
        const count = fileContextStore_1.fileContexts.length;
        const removed = fileContextStore_1.fileContexts.slice();
        (0, fileContextStore_1.clearStoredFileContexts)();
        if (chatFile) {
            yield removeContextEntriesFromChatFile(chatFile, removed);
            yield (0, fileContextOps_1.refreshTranscript)(nvim, options === null || options === void 0 ? void 0 : options.agentMode);
        }
        yield nvim.command(`echohl MoreMsg | echo "Cleared ${count} file context(s)" | echohl None`);
    });
}
/**
 * Clear file contexts array
**/
const clearFileContexts = () => {
    (0, fileContextStore_1.clearStoredFileContexts)();
};
exports.clearFileContexts = clearFileContexts;
/**
 * Strip the chat-file entries that were appended when each of the given
 * contexts was added. Keeps the visible chat in sync with the in-memory list
 * so the user sees adds/removes immediately.
 */
function removeContextEntriesFromChatFile(chatFile, removed) {
    return __awaiter(this, void 0, void 0, function* () {
        const entries = removed
            .map((ctx) => ctx.chatEntry)
            .filter((entry) => typeof entry === 'string' && entry.length > 0);
        if (entries.length === 0) {
            return;
        }
        try {
            let content = yield promises_1.default.readFile(chatFile, 'utf-8');
            for (const entry of entries) {
                const idx = content.lastIndexOf(entry);
                if (idx === -1)
                    continue;
                content = content.slice(0, idx) + content.slice(idx + entry.length);
            }
            yield promises_1.default.writeFile(chatFile, content, 'utf-8');
        }
        catch (error) {
            console.error('Failed to strip removed contexts from chat file:', error);
        }
    });
}
/**
 * Generate context string for AI prompt from loaded file contexts
**/
function getFileContextsForPrompt() {
    return __awaiter(this, void 0, void 0, function* () {
        if (fileContextStore_1.fileContexts.length === 0)
            return '';
        let contextString = '\n\n--- FILE CONTEXTS ---\nThe following files have been provided as context for this conversation:\n\n';
        for (const context of fileContextStore_1.fileContexts) {
            try {
                if (context.isPartial)
                    continue;
                const content = yield promises_1.default.readFile(context.filePath, 'utf-8');
                contextString += `File: ${context.filePath} (complete file)\n${content}\n\n---\n\n`;
            }
            catch (error) {
                console.error(`Error loading context for ${context.filePath}:`, error);
                contextString += `File: ${context.filePath}\n// Error: Could not load file\n\n---\n\n`;
            }
        }
        return contextString;
    });
}
/**
 * Display current file contexts in command line
**/
function showFileContexts(nvim) {
    return __awaiter(this, void 0, void 0, function* () {
        if (fileContextStore_1.fileContexts.length === 0) {
            yield nvim.command('echohl WarningMsg | echo "No file contexts currently loaded" | echohl None');
            return;
        }
        const summaries = fileContextStore_1.fileContexts.map((context) => (0, fileContextDisplay_1.formatContextSummary)(context));
        yield nvim.command(`echohl MoreMsg | echo "Loaded contexts: ${summaries.join(', ')}" | echohl None`);
    });
}
/**
 * Rebuild file contexts from existing chat file content
**/
function rebuildFileContextsFromChat(chatFile) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const content = yield promises_1.default.readFile(chatFile, 'utf-8');
            const lines = content.split('\n');
            for (let i = 0; i < lines.length; i++) {
                if (!lines[i].startsWith('📁 '))
                    continue;
                const fileName = lines[i].substring(2, lines[i].indexOf(' ('));
                let j = i + 1;
                while (j < lines.length && !lines[j].startsWith('```'))
                    j++;
                if (j >= lines.length)
                    continue;
                j++;
                while (j < lines.length && !lines[j].startsWith('// Full file content loaded: ') && !lines[j].startsWith('// Selected from: '))
                    j++;
                if (j >= lines.length)
                    continue;
                if (lines[j].startsWith('// Full file content loaded: ')) {
                    const filePath = lines[j].substring('// Full file content loaded: '.length).trim();
                    fileContextStore_1.fileContexts.push({ filePath, isPartial: false, summary: `Full file: ${fileName}` });
                }
                else if (lines[j].startsWith('// Selected from: ')) {
                    const fileInfo = lines[j].substring('// Selected from: '.length).trim();
                    const filePath = fileInfo.substring(0, fileInfo.indexOf(' ('));
                    const lineMatch = fileInfo.match(/\((lines? (\d+)-(\d+)|line (\d+))\)/);
                    let startLine, endLine;
                    if (lineMatch) {
                        [startLine, endLine] = lineMatch[4]
                            ? [parseInt(lineMatch[4]), parseInt(lineMatch[4])]
                            : [parseInt(lineMatch[2]), parseInt(lineMatch[3])];
                    }
                    fileContextStore_1.fileContexts.push({ filePath, isPartial: true, startLine, endLine, summary: `Partial file: ${fileName}` });
                }
            }
        }
        catch (error) {
            console.error('Error rebuilding file contexts:', error);
        }
    });
}
/**
 * Handle removing a file context via selection
**/
function handleRemoveFileContext(nvim, chatFile, options) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            if (fileContextStore_1.fileContexts.length === 0) {
                yield nvim.command('echohl WarningMsg | echo "No file contexts to remove" | echohl None');
                return;
            }
            const selectedIndices = yield (0, fileContextPickers_1.selectContextToRemove)(nvim);
            if (!selectedIndices || selectedIndices.length === 0) {
                yield nvim.command('echohl WarningMsg | echo "No context selected" | echohl None');
                return;
            }
            const validIndices = Array.from(new Set(selectedIndices))
                .filter((idx) => idx >= 0 && idx < fileContextStore_1.fileContexts.length)
                .sort((a, b) => b - a);
            if (validIndices.length === 0) {
                yield nvim.command('echohl WarningMsg | echo "Invalid selection" | echohl None');
                return;
            }
            const removedContexts = [];
            for (const idx of validIndices) {
                removedContexts.push(fileContextStore_1.fileContexts.splice(idx, 1)[0]);
            }
            if (chatFile) {
                yield removeContextEntriesFromChatFile(chatFile, removedContexts);
                yield (0, fileContextOps_1.refreshTranscript)(nvim, options === null || options === void 0 ? void 0 : options.agentMode);
            }
            const names = removedContexts
                .map((ctx) => (0, fileContextStore_1.getContextFileName)(ctx.filePath))
                .reverse()
                .join(', ');
            yield nvim.command(`echohl MoreMsg | echo "Removed ${removedContexts.length} context(s): ${names}" | echohl None`);
            yield showFileContextsPopup(nvim);
        }
        catch (error) {
            console.error('Error removing file context:', error);
            yield nvim.command('echohl ErrorMsg | echo "Error removing file context" | echohl None');
        }
    });
}
/**
 * Show file contexts in a popup window
**/
function showFileContextsPopup(nvim) {
    return __awaiter(this, void 0, void 0, function* () {
        if (fileContextStore_1.fileContexts.length === 0) {
            yield nvim.command('echohl WarningMsg | echo "No file contexts currently loaded" | echohl None');
            return;
        }
        const popupLines = ['📁 Active File Contexts:', '', '💡 Tip: press "r" to remove files from the context', ''];
        for (const [index, context] of fileContextStore_1.fileContexts.entries()) {
            const entryLines = yield (0, fileContextDisplay_1.formatContextPopupEntry)(context, index);
            popupLines.push(...entryLines);
        }
        popupLines.push('Press any key to close...');
        const luaLines = '{' + popupLines.map(s => `"${s.replace(/"/g, '\\"')}"`).join(', ') + '}';
        const luaScript = `
        local lines = ${luaLines}
        local buf = vim.api.nvim_create_buf(false, true)
        local success, err = pcall(vim.api.nvim_buf_set_lines, buf, 0, -1, false, lines)
        if not success then
            vim.api.nvim_echo({{"Failed to create popup: " .. tostring(err), "ErrorMsg"}}, false, {})
            return
        end

        local width = math.min(math.max(unpack(vim.tbl_map(vim.fn.strdisplaywidth, lines))) + 2, vim.o.columns - 4)
        local height = math.min(#lines, vim.o.lines - 4)

        local win_success, win = pcall(vim.api.nvim_open_win, buf, true, {
            relative = 'editor',
            width = width,
            height = height,
            row = math.floor((vim.o.lines - height) / 2),
            col = math.floor((vim.o.columns - width) / 2),
            style = 'minimal',
            border = 'rounded',
            title = ' File Contexts ',
            title_pos = 'center'
        })

        if not win_success then
            vim.api.nvim_echo({{"Popup failed: " .. tostring(win), "ErrorMsg"}}, false, {})
            return
        end

        vim.api.nvim_buf_set_option(buf, 'modifiable', false)
        vim.api.nvim_buf_set_option(buf, 'bufhidden', 'wipe')

        for _, key in ipairs({'<CR>', '<Esc>', 'q'}) do
            vim.api.nvim_buf_set_keymap(buf, 'n', key, '<cmd>close<CR>', {silent = true})
        end

        vim.api.nvim_create_autocmd({'BufLeave'}, {
            buffer = buf,
            once = true,
            callback = function() pcall(vim.api.nvim_win_close, win, true) end
        })
    `;
        try {
            yield nvim.executeLua(luaScript, []);
        }
        catch (error) {
            console.log('Popup failed, falling back to echo:', error);
            yield showFileContexts(nvim);
        }
    });
}
