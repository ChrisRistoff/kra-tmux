"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fileContexts = void 0;
exports.clearStoredFileContexts = clearStoredFileContexts;
exports.upsertFileContext = upsertFileContext;
exports.getFileExtension = getFileExtension;
exports.getContextFileName = getContextFileName;
exports.getContextLineRange = getContextLineRange;
const filetypes_1 = require("@/AI/shared/data/filetypes");
exports.fileContexts = [];
function clearStoredFileContexts() {
    exports.fileContexts.length = 0;
}
function upsertFileContext(ctx) {
    const existingIndex = ctx.isPartial
        ? exports.fileContexts.findIndex((candidate) => candidate.filePath === ctx.filePath &&
            candidate.startLine === ctx.startLine &&
            candidate.endLine === ctx.endLine)
        : exports.fileContexts.findIndex((candidate) => candidate.filePath === ctx.filePath);
    if (existingIndex >= 0) {
        exports.fileContexts[existingIndex] = ctx;
        return;
    }
    exports.fileContexts.push(ctx);
}
function getFileExtension(filename) {
    const idx = filename.lastIndexOf('.');
    if (idx === -1)
        return 'text';
    const ext = filename.slice(idx + 1).toLowerCase();
    return filetypes_1.fileTypes[ext] || ext || 'text';
}
function getContextFileName(filePath) {
    var _a;
    return (_a = filePath.split('/').pop()) !== null && _a !== void 0 ? _a : filePath;
}
function getContextLineRange(startLine, endLine) {
    if (typeof startLine !== 'number' || typeof endLine !== 'number') {
        return 'unknown range';
    }
    return startLine === endLine ? `line ${startLine}` : `lines ${startLine}-${endLine}`;
}
