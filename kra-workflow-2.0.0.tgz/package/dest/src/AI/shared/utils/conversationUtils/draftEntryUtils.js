"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.extractDraftContent = extractDraftContent;
exports.stripDraftEntry = stripDraftEntry;
exports.setDraftContent = setDraftContent;
exports.mergePromptAndDraft = mergePromptAndDraft;
function trimBlankEdges(lines) {
    let start = 0;
    let end = lines.length;
    while (start < end && !lines[start].trim()) {
        start += 1;
    }
    while (end > start && !lines[end - 1].trim()) {
        end -= 1;
    }
    return lines.slice(start, end);
}
function findDraftHeaderIndex(lines, headerLine) {
    for (let index = lines.length - 1; index >= 0; index -= 1) {
        if (lines[index] === headerLine) {
            return index;
        }
    }
    return -1;
}
function getDraftStartIndex(lines, headerIndex) {
    let start = headerIndex;
    while (start > 0 && !lines[start - 1].trim()) {
        start -= 1;
    }
    if (start > 0 && lines[start - 1].trim() === '---') {
        start -= 1;
        while (start > 0 && !lines[start - 1].trim()) {
            start -= 1;
        }
    }
    return start;
}
function extractDraftContent(lines, headerLine) {
    const draftIndex = findDraftHeaderIndex(lines, headerLine);
    if (draftIndex === -1) {
        return '';
    }
    return trimBlankEdges(lines.slice(draftIndex + 1)).join('\n');
}
function stripDraftEntry(history, headerLine) {
    const lines = history.split('\n');
    const draftIndex = findDraftHeaderIndex(lines, headerLine);
    if (draftIndex === -1) {
        return history.trimEnd();
    }
    const prefix = lines.slice(0, getDraftStartIndex(lines, draftIndex));
    while (prefix.length > 0 && !prefix[prefix.length - 1].trim()) {
        prefix.pop();
    }
    return prefix.join('\n');
}
function setDraftContent(history, headerLine, renderDraftEntry, content) {
    const stripped = stripDraftEntry(history, headerLine);
    const draftEntry = renderDraftEntry(content);
    if (!stripped.trim()) {
        return draftEntry.trimStart();
    }
    return `${stripped}${draftEntry}`;
}
function mergePromptAndDraft(prompt, draftContent) {
    const trimmedPrompt = prompt.trim();
    const trimmedDraft = draftContent.trim();
    if (trimmedPrompt && trimmedDraft) {
        return `${trimmedPrompt}\n\n${trimmedDraft}`;
    }
    return trimmedPrompt || trimmedDraft;
}
