"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildDraftFileContextBody = buildDraftFileContextBody;
exports.syncDraftFileContextEntry = syncDraftFileContextEntry;
const promises_1 = __importDefault(require("fs/promises"));
const agentUi_1 = require("@/AI/AIAgent/shared/utils/agentUi");
const aiUtils_1 = require("@/AI/AIChat/utils/aiUtils");
const fileContextStore_1 = require("./fileContextStore");
function formatFullContextEntry(context, content, agentMode) {
    const fileName = (0, fileContextStore_1.getContextFileName)(context.filePath);
    const ext = (0, fileContextStore_1.getFileExtension)(fileName);
    const lineCount = content.split('\n').length;
    const fence = '```';
    if (agentMode) {
        return `# 📎 ${context.filePath} (${lineCount} lines, ${ext}) attached`;
    }
    return `📁 ${fileName} (${lineCount} lines, ${Math.round(content.length / 1024)}KB)\n\n${fence}${ext}\n// Full file content loaded: ${context.filePath}\n// Use this file context in your responses\n// File contains ${lineCount} lines of ${ext} code\n${fence}`;
}
function formatPartialContextEntry(context, content, agentMode) {
    var _a, _b;
    const fileName = (0, fileContextStore_1.getContextFileName)(context.filePath);
    const lineRange = (0, fileContextStore_1.getContextLineRange)(context.startLine, context.endLine);
    const fence = '```';
    if (agentMode) {
        return `# 📎 ${context.filePath} (${lineRange}) attached`;
    }
    const ext = (0, fileContextStore_1.getFileExtension)(fileName);
    const startLine = (_a = context.startLine) !== null && _a !== void 0 ? _a : 1;
    const endLine = (_b = context.endLine) !== null && _b !== void 0 ? _b : startLine;
    const selectedText = content.split('\n').slice(startLine - 1, endLine).join('\n');
    return `📁 ${fileName} (${lineRange})\n\n${fence}${ext}\n// Selected from: ${context.filePath} (${lineRange})\n${selectedText}\n${fence}`;
}
function formatDraftFileContext(context, agentMode) {
    return __awaiter(this, void 0, void 0, function* () {
        const content = yield promises_1.default.readFile(context.filePath, 'utf8');
        return context.isPartial
            ? formatPartialContextEntry(context, content, agentMode)
            : formatFullContextEntry(context, content, agentMode);
    });
}
function buildDraftFileContextBody(agentMode) {
    return __awaiter(this, void 0, void 0, function* () {
        const entries = [];
        for (const context of fileContextStore_1.fileContexts) {
            try {
                entries.push(yield formatDraftFileContext(context, agentMode));
            }
            catch (error) {
                console.error(`Error rendering context draft for ${context.filePath}:`, error);
                const label = context.isPartial
                    ? `${context.filePath} (${(0, fileContextStore_1.getContextLineRange)(context.startLine, context.endLine)})`
                    : context.filePath;
                entries.push(agentMode ? `# 📎 ${label} attached` : `📁 ${label}`);
            }
        }
        return entries.join('\n\n').trim();
    });
}
function syncDraftFileContextEntry(chatFile, options) {
    return __awaiter(this, void 0, void 0, function* () {
        const history = yield promises_1.default.readFile(chatFile, 'utf8');
        const body = yield buildDraftFileContextBody(options === null || options === void 0 ? void 0 : options.agentMode);
        const updatedHistory = (options === null || options === void 0 ? void 0 : options.agentMode)
            ? (0, agentUi_1.setAgentDraftContent)(history, body)
            : (0, aiUtils_1.setChatDraftContent)(history, body);
        yield promises_1.default.writeFile(chatFile, updatedHistory, 'utf8');
    });
}
