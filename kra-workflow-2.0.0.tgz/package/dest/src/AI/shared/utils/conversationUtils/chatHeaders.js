"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ASSISTANT_HEADER_PREFIX = exports.USER_HEADER_PREFIX = exports.USER_DRAFT_HEADER = void 0;
exports.formatUserDraftHeader = formatUserDraftHeader;
exports.formatUserHeader = formatUserHeader;
exports.formatAssistantHeader = formatAssistantHeader;
exports.isUserDraftHeader = isUserDraftHeader;
exports.isUserHeader = isUserHeader;
exports.isAssistantHeader = isAssistantHeader;
exports.extractTimestampFromHeader = extractTimestampFromHeader;
exports.materializeUserDraft = materializeUserDraft;
const fs = __importStar(require("fs/promises"));
/**
 * Shared chat header formatting used by both the AI chat and the agent UIs.
 * The chat file is the single source of truth for what the user sees in
 * Neovim, and these headers structure that file.
 *
 * Lifecycle of a USER PROMPT entry:
 *   1. A draft header (`USER PROMPT (draft)`) is written when a chat opens
 *      and again whenever the AI finishes a turn. This is the slot under
 *      which `@`-added file contexts visibly accumulate before submission.
 *   2. On submit, `materializeUserDraft` rewrites that draft header in
 *      place, replacing it with a timestamped header. The body (prompt
 *      text + any file context already appended) stays put.
 *   3. After the AI is done streaming, a fresh draft header is appended
 *      so the user has a place to type the next message.
 */
exports.USER_DRAFT_HEADER = '## 👤 USER PROMPT (draft)';
exports.USER_HEADER_PREFIX = '## 👤 USER PROMPT · ';
exports.ASSISTANT_HEADER_PREFIX = '## 🤖 ASSISTANT · ';
function formatUserDraftHeader() {
    return `\n\n---\n${exports.USER_DRAFT_HEADER}\n\n`;
}
function formatUserHeader(timestamp = new Date().toISOString()) {
    return `\n\n---\n${exports.USER_HEADER_PREFIX}${timestamp}\n\n`;
}
function formatAssistantHeader(model, timestamp = new Date().toISOString()) {
    return `\n\n---\n${exports.ASSISTANT_HEADER_PREFIX}${model} · ${timestamp}\n\n`;
}
function isUserDraftHeader(line) {
    return line.trim() === exports.USER_DRAFT_HEADER;
}
function isUserHeader(line) {
    return line.startsWith(exports.USER_HEADER_PREFIX);
}
function isAssistantHeader(line) {
    return line.startsWith(exports.ASSISTANT_HEADER_PREFIX);
}
function extractTimestampFromHeader(line) {
    if (isUserHeader(line)) {
        return line.slice(exports.USER_HEADER_PREFIX.length).trim();
    }
    if (isAssistantHeader(line)) {
        // Format: "## 🤖 ASSISTANT · model · timestamp"
        const remainder = line.slice(exports.ASSISTANT_HEADER_PREFIX.length);
        const lastDot = remainder.lastIndexOf(' · ');
        return lastDot === -1 ? remainder.trim() : remainder.slice(lastDot + 3).trim();
    }
    return '';
}
/**
 * Replace the last `(draft)` marker in the chat file with a timestamped
 * USER header. No-op if no draft marker is present (e.g. when the agent
 * resumes mid-turn after `confirm_task_complete`).
 */
function materializeUserDraft(filePath_1) {
    return __awaiter(this, arguments, void 0, function* (filePath, timestamp = new Date().toISOString()) {
        const content = yield fs.readFile(filePath, 'utf-8');
        const idx = content.lastIndexOf(exports.USER_DRAFT_HEADER);
        if (idx === -1) {
            return;
        }
        const updated = content.slice(0, idx) +
            `${exports.USER_HEADER_PREFIX}${timestamp}` +
            content.slice(idx + exports.USER_DRAFT_HEADER.length);
        yield fs.writeFile(filePath, updated, 'utf-8');
    });
}
