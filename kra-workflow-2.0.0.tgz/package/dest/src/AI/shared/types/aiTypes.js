"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Role = void 0;
var Role;
(function (Role) {
    Role["User"] = "USER";
    Role["AI"] = "AI";
})(Role || (exports.Role = Role = {}));
