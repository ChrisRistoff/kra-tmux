"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.showQuota = showQuota;
const promises_1 = __importDefault(require("fs/promises"));
const path_1 = __importDefault(require("path"));
const agentSettings_1 = require("@/AI/AIAgent/shared/utils/agentSettings");
const filePaths_1 = require("@/filePaths");
const quotaCachePath = () => path_1.default.join((0, filePaths_1.kraHome)(), 'quota-cache.json');
const SESSION_SNAPSHOT_KEYS = new Set(['weekly', 'session']);
function buildBar(percentRemaining, width = 30) {
    const filled = Math.round((percentRemaining / 100) * width);
    const bar = '█'.repeat(filled) + '░'.repeat(width - filled);
    if (percentRemaining <= 10)
        return `\x1b[31m${bar}\x1b[0m`;
    if (percentRemaining <= 25)
        return `\x1b[33m${bar}\x1b[0m`;
    return `\x1b[32m${bar}\x1b[0m`;
}
function formatMonthlySnapshot(name, snap) {
    const bar = buildBar(snap.percent_remaining);
    const used = snap.entitlement - snap.remaining;
    console.log(`  ${name}:`);
    console.log(`    ${bar} ${snap.percent_remaining.toFixed(1)}% remaining`);
    console.log(`    ${used} / ${snap.entitlement} used  (${snap.remaining} left)`);
    if (snap.overage_permitted) {
        console.log(`    Overage: ${snap.overage_count} extra requests used`);
    }
}
function formatCachedSnapshot(name, snap, updatedAt) {
    const bar = buildBar(snap.remainingPercentage);
    const resetStr = snap.resetDate
        ? new Date(snap.resetDate).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })
        : 'unknown';
    const ageMin = Math.round((Date.now() - new Date(updatedAt).getTime()) / 60000);
    console.log(`  ${name}:`);
    console.log(`    ${bar} ${snap.remainingPercentage.toFixed(1)}% remaining`);
    console.log(`    Resets: ${resetStr}  (cached ${ageMin}m ago)`);
}
function readQuotaCache() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            return JSON.parse(yield promises_1.default.readFile(quotaCachePath(), 'utf8'));
        }
        catch (_a) {
            return null;
        }
    });
}
function showQuota() {
    return __awaiter(this, void 0, void 0, function* () {
        const token = (0, agentSettings_1.getGithubToken)();
        if (!token) {
            throw new Error('No GitHub token found. Set GITHUB_TOKEN, GH_TOKEN, or GITHUB_API.');
        }
        const response = yield fetch('https://api.github.com/copilot_internal/user', {
            headers: {
                'Authorization': `Bearer ${token}`,
                'Accept': 'application/vnd.github+json',
            },
        });
        if (!response.ok) {
            throw new Error(`Failed to fetch Copilot quota: ${response.status} ${response.statusText}`);
        }
        const data = yield response.json();
        const { quota_snapshots: quotaSnapshots, quota_reset_date_utc: quotaResetDateUtc } = data;
        const resetDate = new Date(quotaResetDateUtc).toLocaleDateString(undefined, {
            year: 'numeric', month: 'long', day: 'numeric',
        });
        console.log('\n\x1b[1mCopilot Quota — Monthly\x1b[0m');
        console.log(`  Resets on: ${resetDate}\n`);
        if (quotaSnapshots.premium_interactions) {
            formatMonthlySnapshot('Premium interactions', quotaSnapshots.premium_interactions);
        }
        const cache = yield readQuotaCache();
        const sessionSnapshots = cache
            ? Object.entries(cache.snapshots).filter(([id, s]) => SESSION_SNAPSHOT_KEYS.has(id) && !s.isUnlimitedEntitlement)
            : [];
        if (sessionSnapshots.length > 0) {
            console.log('\n\x1b[1mCopilot Quota — Usage Limits (last session)\x1b[0m\n');
            for (const [id, snap] of sessionSnapshots) {
                formatCachedSnapshot(id.charAt(0).toUpperCase() + id.slice(1), snap, cache.updatedAt);
            }
        }
        else {
            console.log('\n  \x1b[2m(Weekly/session limits shown here after your first AI session)\x1b[0m');
        }
        console.log('');
    });
}
