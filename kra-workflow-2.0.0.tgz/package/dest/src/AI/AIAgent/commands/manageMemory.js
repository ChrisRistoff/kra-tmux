"use strict";
/**
 * `kra ai memory` — interactive blessed UI to manage both:
 *   1. Indexed codebases (registry entries + per-repo code_chunks tables).
 *   2. Long-term memories (memory_findings + memory_revisits tables).
 *
 * Designed as a standalone command so the user can clean up / inspect without
 * launching the agent. Uses the same generalUI helpers as the rest of the CLI.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.manageMemory = manageMemory;
const path_1 = __importDefault(require("path"));
const os_1 = __importDefault(require("os"));
const promises_1 = __importDefault(require("fs/promises"));
const lancedb = __importStar(require("@lancedb/lancedb"));
const ui = __importStar(require("@/UI/generalUI"));
const menuChain_1 = require("@/UI/menuChain");
const neovimHelper_1 = require("@/utils/neovimHelper");
const registry_1 = require("@/AI/AIAgent/shared/memory/registry");
const notes_1 = require("@/AI/AIAgent/shared/memory/notes");
const types_1 = require("@/AI/AIAgent/shared/memory/types");
const QUIT = 'Quit';
/**
 * Open `initial` in nvim for editing. Returns the saved contents (or the
 * original if the user wrote nothing). Throws on nvim non-zero exit.
 */
function editInVim(initial_1) {
    return __awaiter(this, arguments, void 0, function* (initial, suffix = '.md') {
        const tmp = path_1.default.join(os_1.default.tmpdir(), `kra-mem-edit-${Date.now()}${suffix}`);
        yield promises_1.default.writeFile(tmp, initial, 'utf8');
        try {
            yield (0, neovimHelper_1.openVim)(tmp);
            const out = yield promises_1.default.readFile(tmp, 'utf8');
            return out;
        }
        finally {
            yield promises_1.default.unlink(tmp).catch(() => undefined);
        }
    });
}
function manageMemory() {
    return __awaiter(this, void 0, void 0, function* () {
        yield (0, menuChain_1.menuChain)()
            .step('action', () => __awaiter(this, void 0, void 0, function* () {
            const choice = yield ui.searchSelectAndReturnFromArray({
                itemsArray: [
                    'Manage indexed codebases',
                    'Manage long-term memories',
                    QUIT,
                ],
                prompt: 'kra-memory',
            });
            if (!choice || choice === QUIT)
                throw new menuChain_1.UserCancelled();
            return choice;
        }))
            .step('_', (_a) => __awaiter(this, [_a], void 0, function* ({ action }) {
            if (action === 'Manage indexed codebases')
                yield manageIndexedRepos();
            else if (action === 'Manage long-term memories')
                yield manageLongTermMemories();
            throw new menuChain_1.UserCancelled();
        }))
            .run()
            .catch((e) => { if (!(e instanceof menuChain_1.UserCancelled))
            throw e; });
    });
}
// ============================================================================
// Indexed codebases
// ============================================================================
function manageIndexedRepos() {
    return __awaiter(this, void 0, void 0, function* () {
        yield (0, menuChain_1.menuChain)()
            .step('pick', () => __awaiter(this, void 0, void 0, function* () {
            var _a;
            const reg = yield (0, registry_1.loadRegistry)();
            const ids = Object.keys(reg.repos);
            if (ids.length === 0) {
                yield ui.showInfoScreen('No repos', 'No indexed codebases yet.\n\nIndex one with: kra ai index');
                throw new menuChain_1.UserCancelled();
            }
            const labelToId = new Map();
            const labels = [];
            for (const id of ids) {
                const e = reg.repos[id];
                const label = `${e.alias}  (${e.rootPath})  -  ${e.chunksCount} chunks`;
                labels.push(label);
                labelToId.set(label, id);
            }
            const picked = yield ui.searchSelectAndReturnFromArray({
                itemsArray: labels,
                prompt: 'Indexed codebases',
            });
            if (!picked)
                throw new menuChain_1.UserCancelled();
            const id = (_a = labelToId.get(picked)) !== null && _a !== void 0 ? _a : '';
            return { id, entry: reg.repos[id] };
        }))
            .step('_', (_a) => __awaiter(this, [_a], void 0, function* ({ pick }) {
            const { id, entry } = pick;
            yield indexedRepoActions(id, entry);
            throw new menuChain_1.UserCancelled();
        }))
            .run()
            .catch((e) => { if (!(e instanceof menuChain_1.UserCancelled))
            throw e; });
    });
}
function indexedRepoActions(id, entry) {
    return __awaiter(this, void 0, void 0, function* () {
        yield (0, menuChain_1.menuChain)()
            .step('action', () => __awaiter(this, void 0, void 0, function* () {
            const action = yield ui.searchSelectAndReturnFromArray({
                itemsArray: [
                    '(VIEW) details',
                    '(DROP) index (delete code_chunks + registry entry)',
                    '(RESET) baseline (force full reindex on next launch)',
                    '(RENAME) alias',
                ],
                prompt: entry.alias,
            });
            if (!action)
                throw new menuChain_1.UserCancelled();
            return action;
        }))
            .step('_', (_a) => __awaiter(this, [_a], void 0, function* ({ action }) {
            if (action === 'View details') {
                const details = [
                    `alias:               ${entry.alias}`,
                    `id:                  ${id}`,
                    `rootPath:            ${entry.rootPath}`,
                    `lastIndexedCommit:   ${entry.lastIndexedCommit || '(none)'}`,
                    `lastIndexedAt:       ${entry.lastIndexedAt ? new Date(entry.lastIndexedAt).toISOString() : '(never)'}`,
                    `chunksCount:         ${entry.chunksCount}`,
                ].join('\n');
                yield ui.showInfoScreen(entry.alias, details + '\n');
                throw new menuChain_1.UserCancelled();
            }
            if (action === 'Drop index (delete code_chunks + registry entry)') {
                const ok = yield ui.promptUserYesOrNo(`Drop the code_chunks table for '${entry.alias}' AND remove it from the registry?\n` +
                    `Long-term memories (findings/revisits) will be untouched.`);
                if (!ok)
                    throw new menuChain_1.UserCancelled();
                const dropped = yield dropCodeChunksAt(entry.rootPath);
                yield (0, registry_1.removeRegistryEntry)(id);
                console.log(`kra-memory: ${dropped ? 'dropped code_chunks at ' + entry.rootPath : 'no code_chunks table existed'}; registry entry removed.`);
                return;
            }
            if (action === 'Reset baseline (force full reindex on next launch)') {
                const ok = yield ui.promptUserYesOrNo(`Clear lastIndexedCommit/lastIndexedAt for '${entry.alias}'?\n` +
                    `The next agent launch in this repo will trigger a full reindex.`);
                if (!ok)
                    throw new menuChain_1.UserCancelled();
                yield (0, registry_1.upsertRegistryEntry)(id, { lastIndexedCommit: '', lastIndexedAt: 0 });
                console.log(`kra-memory: baseline cleared for '${entry.alias}'`);
                return;
            }
            if (action === 'Rename alias') {
                const next = yield ui.askUserForInput(`Enter new alias for '${entry.alias}'`);
                const trimmed = next.trim();
                if (!trimmed)
                    throw new menuChain_1.UserCancelled();
                yield (0, registry_1.upsertRegistryEntry)(id, { alias: trimmed });
                entry.alias = trimmed;
                console.log(`kra-memory: alias updated to '${trimmed}'`);
                throw new menuChain_1.UserCancelled();
            }
        }))
            .run()
            .catch((e) => { if (!(e instanceof menuChain_1.UserCancelled))
            throw e; });
    });
}
function dropCodeChunksAt(repoRoot) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const lanceRoot = path_1.default.join(repoRoot, '.kra-memory', 'lance');
            const db = yield lancedb.connect(lanceRoot);
            const names = yield db.tableNames();
            if (!names.includes('code_chunks'))
                return false;
            yield db.dropTable('code_chunks');
            return true;
        }
        catch (err) {
            console.warn(`kra-memory: failed to drop code_chunks at ${repoRoot}: ${err instanceof Error ? err.message : String(err)}`);
            return false;
        }
    });
}
// ============================================================================
// Long-term memories
// ============================================================================
function manageLongTermMemories() {
    return __awaiter(this, void 0, void 0, function* () {
        yield (0, menuChain_1.menuChain)()
            .step('scope', () => __awaiter(this, void 0, void 0, function* () {
            const scope = yield ui.searchSelectAndReturnFromArray({
                itemsArray: ['All', 'Findings', 'Revisits', '+ Add new memory'],
                prompt: 'Long-term memories',
            });
            if (!scope)
                throw new menuChain_1.UserCancelled();
            return scope;
        }))
            .step('_', (_a) => __awaiter(this, [_a], void 0, function* ({ scope }) {
            if (scope === '+ Add new memory') {
                yield addNewMemory();
                throw new menuChain_1.UserCancelled();
            }
            const scopeKey = scope === 'Findings' ? 'findings' : scope === 'Revisits' ? 'revisits' : 'all';
            yield browseMemories(scopeKey);
            throw new menuChain_1.UserCancelled();
        }))
            .run()
            .catch((e) => { if (!(e instanceof menuChain_1.UserCancelled))
            throw e; });
    });
}
function browseMemories(scope) {
    return __awaiter(this, void 0, void 0, function* () {
        yield (0, menuChain_1.menuChain)()
            .step('pick', () => __awaiter(this, void 0, void 0, function* () {
            const entries = yield (0, notes_1.listMemories)({ scope, limit: 200 });
            if (entries.length === 0) {
                yield ui.showInfoScreen('Empty', `No ${scope} memories yet.`);
                throw new menuChain_1.UserCancelled();
            }
            const labelToEntry = new Map();
            const labels = [];
            for (const e of entries) {
                const created = new Date(e.createdAt).toISOString().slice(0, 10);
                const label = `[${e.kind}] ${created} ${e.status === 'open' ? '○' : '●'} ${e.title}`;
                labels.push(label);
                labelToEntry.set(label, e);
            }
            const picked = yield ui.searchSelectAndReturnFromArray({
                itemsArray: labels,
                prompt: `${scope} memories`,
            });
            if (!picked)
                throw new menuChain_1.UserCancelled();
            const entry = labelToEntry.get(picked);
            if (!entry)
                throw new menuChain_1.UserCancelled();
            return entry;
        }))
            .step('_', (_a) => __awaiter(this, [_a], void 0, function* ({ pick }) {
            yield memoryEntryActions(pick);
            throw new menuChain_1.UserCancelled();
        }))
            .run()
            .catch((e) => { if (!(e instanceof menuChain_1.UserCancelled))
            throw e; });
    });
}
function memoryEntryActions(entry) {
    return __awaiter(this, void 0, void 0, function* () {
        yield (0, menuChain_1.menuChain)()
            .step('action', () => __awaiter(this, void 0, void 0, function* () {
            const action = yield ui.searchSelectAndReturnFromArray({
                itemsArray: [
                    'View body / details',
                    'Edit body in nvim',
                    'Change status',
                    'Delete memory',
                ],
                prompt: entry.title,
            });
            if (!action)
                throw new menuChain_1.UserCancelled();
            return action;
        }))
            .step('_', (_a) => __awaiter(this, [_a], void 0, function* ({ action }) {
            var _b;
            if (action === 'View body / details') {
                const lines = [
                    `Title:    ${entry.title}`,
                    `Kind:     ${entry.kind}`,
                    `Status:   ${entry.status}`,
                    `Tags:     ${entry.tags.join(', ') || '(none)'}`,
                    `Paths:    ${entry.paths.join(', ') || '(none)'}`,
                    `Branch:   ${(_b = entry.branch) !== null && _b !== void 0 ? _b : '(none)'}`,
                    `Created:  ${new Date(entry.createdAt).toISOString()}`,
                    `Updated:  ${new Date(entry.updatedAt).toISOString()}`,
                    '',
                    '── body ──',
                    entry.body,
                ].join('\n');
                yield ui.showInfoScreen(entry.title, lines + '\n');
                throw new menuChain_1.UserCancelled();
            }
            if (action === 'Edit body in nvim') {
                const next = yield editInVim(entry.body, '.md');
                const trimmed = next.replace(/\s+$/, '');
                if (trimmed === entry.body) {
                    console.log('kra-memory: body unchanged.');
                    throw new menuChain_1.UserCancelled();
                }
                const ok = yield ui.promptUserYesOrNo(`Save edited body for '${entry.title}'?`);
                if (!ok)
                    throw new menuChain_1.UserCancelled();
                yield (0, notes_1.editMemory)({ id: entry.id, body: trimmed });
                entry.body = trimmed;
                console.log(`kra-memory: body of '${entry.title}' updated.`);
                throw new menuChain_1.UserCancelled();
            }
            if (action === 'Change status') {
                const status = yield ui.searchSelectAndReturnFromArray({
                    itemsArray: [...types_1.MEMORY_STATUSES],
                    prompt: 'New status',
                });
                if (!status)
                    throw new menuChain_1.UserCancelled();
                yield (0, notes_1.updateMemory)({ id: entry.id, status: status });
                entry.status = status;
                console.log(`kra-memory: status of '${entry.title}' set to '${status}'`);
                throw new menuChain_1.UserCancelled();
            }
            if (action === 'Delete memory') {
                const ok = yield ui.promptUserYesOrNo(`Delete memory '${entry.title}'? This cannot be undone.`);
                if (!ok)
                    throw new menuChain_1.UserCancelled();
                yield (0, notes_1.deleteMemory)(entry.id);
                console.log(`kra-memory: deleted '${entry.title}'`);
            }
        }))
            .run()
            .catch((e) => { if (!(e instanceof menuChain_1.UserCancelled))
            throw e; });
    });
}
function addNewMemory() {
    return __awaiter(this, void 0, void 0, function* () {
        const result = yield (0, menuChain_1.menuChain)()
            .step('kind', () => __awaiter(this, void 0, void 0, function* () {
            const kind = yield ui.searchSelectAndReturnFromArray({
                itemsArray: [...types_1.MEMORY_KINDS],
                prompt: 'Memory kind',
            });
            if (!kind)
                throw new menuChain_1.UserCancelled();
            if (!(0, types_1.isFindingKind)(kind) && !(0, types_1.isRevisitKind)(kind)) {
                console.log(`kra-memory: unknown kind '${kind}'`);
                throw new menuChain_1.UserCancelled();
            }
            return kind;
        }))
            .step('title', () => __awaiter(this, void 0, void 0, function* () {
            const title = (yield ui.askUserForInput('Title (single line, required)')).trim();
            if (!title) {
                console.log('kra-memory: title required.');
                throw new menuChain_1.UserCancelled();
            }
            return title;
        }))
            .step('body', (_a) => __awaiter(this, [_a], void 0, function* ({ title }) {
            const placeholder = `# Body for: ${title}\n# Write the memory body below. Save and quit (:wq) to confirm, or quit without writing (:q!) to abort.\n\n`;
            const raw = yield editInVim(placeholder, '.md');
            const body = raw
                .split('\n')
                .filter((l) => !l.startsWith('#'))
                .join('\n')
                .trim();
            if (!body) {
                console.log('kra-memory: body required.');
                throw new menuChain_1.UserCancelled();
            }
            return body;
        }))
            .step('tags', () => __awaiter(this, void 0, void 0, function* () {
            const tagsRaw = (yield ui.askUserForInput('Tags (comma-separated, optional)')).trim();
            return tagsRaw ? tagsRaw.split(',').map((t) => t.trim()).filter(Boolean) : [];
        }))
            .run();
        const saved = yield (0, notes_1.remember)({
            kind: result.kind,
            title: result.title,
            body: result.body,
            tags: result.tags,
        });
        console.log(`kra-memory: created memory '${result.title}' (id ${saved.id})`);
    });
}
