"use strict";
/**
 * `kra ai index` — full reindex of the workspace into the kra-memory
 * code_chunks table. Streams progress to the terminal and updates the
 * central repo registry so future agent launches see the catch-up baseline.
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.indexCodebase = indexCodebase;
const indexer_1 = require("@/AI/AIAgent/shared/memory/indexer");
const settings_1 = require("@/AI/AIAgent/shared/memory/settings");
const db_1 = require("@/AI/AIAgent/shared/memory/db");
const registry_1 = require("@/AI/AIAgent/shared/memory/registry");
const bashHelper_1 = require("@/utils/bashHelper");
function safeHeadCommit(repoRoot) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const r = yield (0, bashHelper_1.execCommand)(`git -C '${repoRoot.replace(/'/g, `'\\''`)}' rev-parse HEAD`);
            return r.stdout.trim();
        }
        catch (_a) {
            return '';
        }
    });
}
function indexCodebase() {
    return __awaiter(this, void 0, void 0, function* () {
        const settings = yield (0, settings_1.loadMemorySettings)();
        if (!settings.enabled) {
            console.log('kra-memory is disabled in settings.toml ([ai.agent.memory] enabled = false). Aborting.');
            return;
        }
        console.log('kra-memory: starting full code index…');
        let lastPath = '';
        const result = yield (0, indexer_1.reindexAll)({
            onProgress: (p) => {
                if (p.phase === 'embedding' && p.currentPath && p.currentPath !== lastPath) {
                    lastPath = p.currentPath;
                    const pct = p.filesTotal > 0 ? Math.floor((p.filesDone / p.filesTotal) * 100) : 0;
                    process.stdout.write(`  [${pct.toString().padStart(3)}%] ${p.filesDone}/${p.filesTotal}  ${p.currentPath}\n`);
                }
                if (p.phase === 'scanning') {
                    console.log(`kra-memory: scanning workspace, ${p.filesTotal} indexable files found`);
                }
            },
        });
        const root = (0, indexer_1.workspaceRoot)();
        const identity = yield (0, registry_1.getRepoIdentity)(root);
        const totalChunks = yield (0, db_1.countCodeChunks)().catch(() => result.chunksWritten);
        yield (0, registry_1.upsertRegistryEntry)(identity.id, {
            alias: identity.alias,
            rootPath: identity.rootPath,
            lastIndexedCommit: yield safeHeadCommit(identity.rootPath),
            lastIndexedAt: Date.now(),
            chunksCount: totalChunks,
        });
        console.log('');
        console.log(`kra-memory: indexed ${result.filesScanned} files in ${(result.elapsedMs / 1000).toFixed(1)}s`);
        console.log(`            ${result.chunksWritten} chunks written, ${result.chunksSkipped} unchanged, ${result.chunksDeleted} stale removed`);
        console.log(`            registry updated for '${identity.alias}' (${totalChunks} total chunks)`);
    });
}
