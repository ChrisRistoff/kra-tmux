"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.startAgentChat = startAgentChat;
const ui = __importStar(require("@/UI/generalUI"));
const copilot_1 = require("@/AI/AIAgent/providers/copilot");
const byok_1 = require("@/AI/AIAgent/providers/byok");
const settings_1 = require("@/AI/AIAgent/shared/memory/settings");
const watcher_1 = require("@/AI/AIAgent/shared/memory/watcher");
function startAgentChat() {
    return __awaiter(this, void 0, void 0, function* () {
        const provider = yield ui.searchSelectAndReturnFromArray({
            itemsArray: ['copilot', 'byok'],
            prompt: 'Select agent provider',
        });
        const memorySettings = yield (0, settings_1.loadMemorySettings)();
        let watcher = null;
        if (memorySettings.enabled) {
            // The interactive Yes/No prompt + initial reindex is now handled inside
            // runStartupIndexingFlow (called from agentConversation). The legacy
            // unconditional `reindexAll()` was removed because it would silently
            // recreate the code_chunks table even after the user opted out.
            if (memorySettings.indexCodeOnSave) {
                try {
                    watcher = yield (0, watcher_1.startWatcher)();
                }
                catch (err) {
                    console.warn(`kra-memory: watcher failed to start: ${err instanceof Error ? err.message : String(err)}`);
                }
            }
        }
        try {
            if (provider === 'byok') {
                yield (0, byok_1.startByokFlow)();
                return;
            }
            yield (0, copilot_1.startCopilotFlow)();
        }
        finally {
            if (watcher)
                yield watcher.close();
        }
    });
}
