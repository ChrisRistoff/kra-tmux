"use strict";
/**
 * OpenAI-compatible BYOK session.
 *
 * Implements `AgentSession` (the provider-neutral contract used by
 * `agentConversation.ts` and the rest of `shared/`). Wraps an OpenAI Chat
 * Completions client (any base URL), drives the streaming tool-call loop, and
 * fires the events the shared UI layer subscribes to.
 *
 * Design notes:
 *   - One session = one OpenAI client + one MCP client pool.
 *   - `send()` runs until the model produces a turn with no tool calls, then
 *     emits `session.idle` and returns.
 *   - Tool calls go through `onPreToolUse`/`onPostToolUse` hooks (same shape
 *     as Copilot SDK), then to the MCP client. Tool denials are surfaced to
 *     the model as the tool result so it can react.
 *   - Reasoning deltas (deepseek-reasoner et al.) are detected via
 *     `delta.reasoning_content` / `delta.reasoning` and routed to
 *     `assistant.reasoning_delta`.
 *   - On context-length errors we compact the history once and retry.
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __asyncValues = (this && this.__asyncValues) || function (o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
    function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
    function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OpenAICompatibleSession = void 0;
const openai_1 = __importDefault(require("openai"));
const turnReminder_1 = require("@/AI/AIAgent/shared/main/turnReminder");
const mcpClientPool_1 = require("@/AI/AIAgent/providers/byok/mcpClientPool");
const executableToolBridge_1 = require("@/AI/AIAgent/mcp/executableToolBridge");
const byokCompactor_1 = require("@/AI/AIAgent/providers/byok/byokCompactor");
const DEFAULT_SYSTEM_PROMPT = [
    'You are an autonomous coding agent operating inside a proposal workspace.',
    'You may freely read, edit, and create files; the user reviews the resulting',
    'git diff at the end. Use the available tools — do not just describe what you',
    'would do. Always finish by calling confirm_task_complete.',
].join(' ');
class OpenAICompatibleSession {
    constructor(opts) {
        this.openaiTools = [];
        this.messages = [];
        this.listeners = {};
        this.compactedThisTurn = false;
        this.executableToolBridge = (0, executableToolBridge_1.createExecutableToolBridge)(() => this.mcp);
        this.on = (event, handler) => {
            var _a;
            var _b;
            const list = ((_a = (_b = this.listeners)[event]) !== null && _a !== void 0 ? _a : (_b[event] = []));
            list.push(handler);
        };
        this.send = (options) => __awaiter(this, void 0, void 0, function* () {
            this.compactedThisTurn = false;
            this.abortController = new AbortController();
            this.messages.push({
                role: 'user',
                content: `${options.prompt}\n\n${turnReminder_1.TURN_REMINDER}`,
            });
            try {
                yield this.runTurnLoop();
            }
            finally {
                this.emit('session.idle', undefined);
            }
        });
        this.abort = () => __awaiter(this, void 0, void 0, function* () {
            var _a;
            (_a = this.abortController) === null || _a === void 0 ? void 0 : _a.abort();
        });
        this.disconnect = () => __awaiter(this, void 0, void 0, function* () {
            var _a;
            (_a = this.abortController) === null || _a === void 0 ? void 0 : _a.abort();
            yield (0, executableToolBridge_1.disconnectPool)(this.mcp);
        });
        this.listExecutableTools = () => {
            return this.executableToolBridge.listExecutableTools();
        };
        this.executeTool = (title, args) => __awaiter(this, void 0, void 0, function* () {
            return this.executableToolBridge.executeTool(title, args);
        });
        this.opts = opts.sessionOptions;
        this.openai = new openai_1.default({ apiKey: opts.apiKey, baseURL: opts.baseURL });
    }
    emit(event, payload) {
        const list = this.listeners[event];
        if (!list) {
            return;
        }
        for (const handler of list) {
            try {
                handler(payload);
            }
            catch (_a) {
                // listener errors must not break the session loop
            }
        }
    }
    init() {
        return __awaiter(this, void 0, void 0, function* () {
            var _a;
            const mergedServers = Object.assign(Object.assign({}, this.opts.mcpServers), ((_a = this.opts.additionalMcpServers) !== null && _a !== void 0 ? _a : {}));
            this.mcp = yield (0, mcpClientPool_1.buildMcpClientPool)(Object.assign(Object.assign({ servers: mergedServers }, (this.opts.excludedTools ? { excludedTools: this.opts.excludedTools } : {})), { workingDirectory: this.opts.workingDirectory }));
            this.openaiTools = this.mcp.openaiTools;
            const sysContent = this.buildSystemMessage();
            this.messages.push({ role: 'system', content: sysContent });
        });
    }
    buildSystemMessage() {
        const sm = this.opts.systemMessage;
        if (!sm) {
            return DEFAULT_SYSTEM_PROMPT;
        }
        if (sm.mode === 'replace') {
            return sm.content;
        }
        return `${DEFAULT_SYSTEM_PROMPT}\n\n${sm.content}`;
    }
    maybeProactiveCompact() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.compactedThisTurn) {
                return;
            }
            const ctx = this.opts.contextWindow;
            if (!ctx || ctx <= 0) {
                return;
            }
            const thresholdEnv = Number(process.env['KRA_BYOK_COMPACT_THRESHOLD']);
            const threshold = Number.isFinite(thresholdEnv) && thresholdEnv > 0 && thresholdEnv < 1
                ? thresholdEnv
                : 0.70;
            const estimated = (0, byokCompactor_1.estimateTokens)(this.messages);
            if (estimated < ctx * threshold) {
                return;
            }
            if (process.env['KRA_BYOK_DEBUG'] === '1') {
                console.error(`[byok] proactive compaction: ~${estimated} tokens > ${Math.round(ctx * threshold)} (${Math.round(threshold * 100)}% of ${ctx})`);
            }
            this.compactedThisTurn = true;
            this.messages = yield (0, byokCompactor_1.compactMessages)({
                openai: this.openai,
                model: this.opts.model,
                messages: this.messages,
            });
        });
    }
    runTurnLoop() {
        return __awaiter(this, void 0, void 0, function* () {
            var _a;
            for (;;) {
                const toolCalls = yield this.streamOnePass();
                if (toolCalls.length === 0) {
                    return;
                }
                for (const call of toolCalls) {
                    yield this.executeToolCall(call);
                    if ((_a = this.abortController) === null || _a === void 0 ? void 0 : _a.signal.aborted) {
                        return;
                    }
                }
            }
        });
    }
    streamOnePass() {
        return __awaiter(this, void 0, void 0, function* () {
            var _a, e_1, _b, _c;
            var _d, _e, _f, _g, _h, _j, _k, _l, _m;
            yield this.maybeProactiveCompact();
            let stream;
            try {
                stream = yield this.openai.chat.completions.create(Object.assign({ model: this.opts.model, messages: this.messages, stream: true }, (this.openaiTools.length > 0 ? { tools: this.openaiTools } : {})), { signal: (_d = this.abortController) === null || _d === void 0 ? void 0 : _d.signal });
            }
            catch (error) {
                if (!this.compactedThisTurn && (0, byokCompactor_1.isContextLengthError)(error)) {
                    this.compactedThisTurn = true;
                    this.messages = yield (0, byokCompactor_1.compactMessages)({
                        openai: this.openai,
                        model: this.opts.model,
                        messages: this.messages,
                    });
                    return this.streamOnePass();
                }
                throw error;
            }
            const accumulatedToolCalls = new Map();
            let assistantText = '';
            const debug = process.env.KRA_BYOK_DEBUG === '1';
            let chunkCount = 0;
            try {
                for (var _o = true, stream_1 = __asyncValues(stream), stream_1_1; stream_1_1 = yield stream_1.next(), _a = stream_1_1.done, !_a; _o = true) {
                    _c = stream_1_1.value;
                    _o = false;
                    const chunk = _c;
                    chunkCount += 1;
                    const delta = chunk.choices[0].delta;
                    if (debug) {
                        process.stderr.write(`[byok] chunk #${chunkCount} content=${JSON.stringify((_e = delta.content) !== null && _e !== void 0 ? _e : null)} tool_calls=${(_g = (_f = delta.tool_calls) === null || _f === void 0 ? void 0 : _f.length) !== null && _g !== void 0 ? _g : 0} finish=${(_h = chunk.choices[0].finish_reason) !== null && _h !== void 0 ? _h : ''}\n`);
                    }
                    const reasoning = (_j = delta.reasoning_content) !== null && _j !== void 0 ? _j : delta.reasoning;
                    if (typeof reasoning === 'string' && reasoning.length > 0) {
                        this.emit('assistant.reasoning_delta', { data: { deltaContent: reasoning } });
                    }
                    if (typeof delta.content === 'string' && delta.content.length > 0) {
                        assistantText += delta.content;
                        this.emit('assistant.message_delta', { data: { deltaContent: delta.content } });
                    }
                    if (delta.tool_calls) {
                        for (const tc of delta.tool_calls) {
                            const existing = (_k = accumulatedToolCalls.get(tc.index)) !== null && _k !== void 0 ? _k : {
                                id: '',
                                name: '',
                                args: '',
                            };
                            if (tc.id)
                                existing.id = tc.id;
                            if ((_l = tc.function) === null || _l === void 0 ? void 0 : _l.name)
                                existing.name += tc.function.name;
                            if ((_m = tc.function) === null || _m === void 0 ? void 0 : _m.arguments)
                                existing.args += tc.function.arguments;
                            accumulatedToolCalls.set(tc.index, existing);
                        }
                    }
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (!_o && !_a && (_b = stream_1.return)) yield _b.call(stream_1);
                }
                finally { if (e_1) throw e_1.error; }
            }
            if (debug) {
                process.stderr.write(`[byok] stream done: chunks=${chunkCount} text_len=${assistantText.length} tool_calls=${accumulatedToolCalls.size}\n`);
            }
            const toolCalls = Array.from(accumulatedToolCalls.values()).filter((tc) => tc.id && tc.name);
            const assistantMessage = Object.assign({ role: 'assistant', content: assistantText || null }, (toolCalls.length > 0
                ? {
                    tool_calls: toolCalls.map((tc) => ({
                        id: tc.id,
                        type: 'function',
                        function: { name: tc.name, arguments: tc.args || '{}' },
                    })),
                }
                : {}));
            this.messages.push(assistantMessage);
            return toolCalls;
        });
    }
    executeToolCall(call) {
        return __awaiter(this, void 0, void 0, function* () {
            var _a, _b, _c, _d, _e;
            const tool = (_a = this.mcp) === null || _a === void 0 ? void 0 : _a.tools.get(call.name);
            if (!tool) {
                this.emitToolStart(call, '(unknown)', '(unknown tool)');
                this.appendToolResult(call.id, `Tool '${call.name}' is not registered.`);
                this.emitToolComplete(call, false, `Tool '${call.name}' is not registered.`);
                return;
            }
            let parsedArgs;
            try {
                parsedArgs = call.args ? JSON.parse(call.args) : {};
            }
            catch (error) {
                const msg = `Failed to parse tool arguments: ${error.message}`;
                this.emitToolStart(call, tool.server, tool.originalName);
                this.appendToolResult(call.id, msg);
                this.emitToolComplete(call, false, msg);
                return;
            }
            const preHook = yield this.opts.onPreToolUse({
                toolName: tool.originalName,
                toolArgs: parsedArgs,
            });
            if (preHook.permissionDecision === 'deny') {
                const reason = (_b = preHook.permissionDecisionReason) !== null && _b !== void 0 ? _b : 'Tool call denied by approval hook.';
                const msg = `Denied: ${reason}`;
                this.emitToolStart(call, tool.server, tool.originalName);
                this.appendToolResult(call.id, msg);
                this.emitToolComplete(call, false, msg);
                return;
            }
            const finalArgs = (_c = preHook.modifiedArgs) !== null && _c !== void 0 ? _c : parsedArgs;
            this.emitToolStart(call, tool.server, tool.originalName, finalArgs);
            let toolText;
            let isError = false;
            try {
                const result = yield tool.client.callTool({
                    name: tool.originalName,
                    arguments: finalArgs,
                });
                const contentArray = ((_d = result.content) !== null && _d !== void 0 ? _d : []);
                toolText = contentArray
                    .filter((p) => p.type === 'text' && typeof p.text === 'string')
                    .map((p) => p.text)
                    .join('\n');
                isError = Boolean(result.isError);
                if (preHook.additionalContext) {
                    toolText = `${preHook.additionalContext}\n\n${toolText}`;
                }
                const postHook = yield this.opts.onPostToolUse({
                    toolName: tool.originalName,
                    toolResult: { textResultForLlm: toolText, raw: result },
                });
                if ((_e = postHook === null || postHook === void 0 ? void 0 : postHook.modifiedResult) === null || _e === void 0 ? void 0 : _e.textResultForLlm) {
                    toolText = postHook.modifiedResult.textResultForLlm;
                }
            }
            catch (error) {
                toolText = `Tool execution failed: ${error.message}`;
                isError = true;
            }
            this.appendToolResult(call.id, toolText);
            this.emitToolComplete(call, !isError, toolText);
        });
    }
    emitToolStart(call, mcpServerName, mcpToolName, args) {
        let parsedArgs = args;
        if (parsedArgs === undefined) {
            try {
                parsedArgs = call.args ? JSON.parse(call.args) : {};
            }
            catch (_a) {
                parsedArgs = call.args;
            }
        }
        this.emit('tool.execution_start', {
            data: {
                toolCallId: call.id,
                toolName: mcpToolName,
                mcpServerName,
                mcpToolName,
                arguments: (parsedArgs !== null && parsedArgs !== void 0 ? parsedArgs : {}),
            },
        });
    }
    emitToolComplete(call, success, output) {
        this.emit('tool.execution_complete', {
            data: {
                toolCallId: call.id,
                success,
                result: { content: output },
            },
        });
    }
    appendToolResult(toolCallId, content) {
        this.messages.push({
            role: 'tool',
            tool_call_id: toolCallId,
            content,
        });
    }
}
exports.OpenAICompatibleSession = OpenAICompatibleSession;
