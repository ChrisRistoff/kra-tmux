"use strict";
/**
 * BYOK AgentClient — thin factory around OpenAICompatibleSession.
 *
 * One client per (provider, model, key) tuple. createSession() builds and
 * `init()`s a session; each session owns its own MCP client pool.
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OpenAICompatibleClient = void 0;
const byokSession_1 = require("@/AI/AIAgent/providers/byok/byokSession");
class OpenAICompatibleClient {
    constructor(options) {
        this.sessions = [];
        this.createSession = (options) => __awaiter(this, void 0, void 0, function* () {
            const session = new byokSession_1.OpenAICompatibleSession({
                sessionOptions: options,
                baseURL: this.baseURL,
                apiKey: this.apiKey,
            });
            yield session.init();
            this.sessions.push(session);
            return session;
        });
        this.stop = () => __awaiter(this, void 0, void 0, function* () {
            yield Promise.allSettled(this.sessions.map((s) => __awaiter(this, void 0, void 0, function* () { return s.disconnect(); })));
            this.sessions = [];
        });
        this.forceStop = () => __awaiter(this, void 0, void 0, function* () {
            yield this.stop();
        });
        this.baseURL = options.baseURL;
        this.apiKey = options.apiKey;
    }
}
exports.OpenAICompatibleClient = OpenAICompatibleClient;
