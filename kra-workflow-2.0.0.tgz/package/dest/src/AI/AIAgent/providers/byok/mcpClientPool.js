"use strict";
/**
 * MCP client pool for BYOK sessions.
 *
 * Spawns each configured local MCP server (via @modelcontextprotocol/sdk's
 * StdioClientTransport), lists its tools, and exposes a flat registry that
 * maps namespaced tool names ("<server>__<tool>") to:
 *   - the MCP client to invoke,
 *   - the original (un-namespaced) tool name,
 *   - the OpenAI-shaped function tool definition.
 *
 * Honors per-server `tools` allow-list and the session-level `excludedTools`
 * filter. Remote (http/sse) MCP servers are ignored — BYOK only deals with
 * local stdio servers (matches what the agent actually configures).
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildMcpClientPool = buildMcpClientPool;
const index_js_1 = require("@modelcontextprotocol/sdk/client/index.js");
const stdio_js_1 = require("@modelcontextprotocol/sdk/client/stdio.js");
function namespacedToolName(server, tool) {
    const safeServer = server.replace(/[^a-zA-Z0-9_-]/g, '_');
    const safeTool = tool.replace(/[^a-zA-Z0-9_-]/g, '_');
    return `${safeServer}__${safeTool}`;
}
function buildMcpClientPool(options) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c, _d, _e;
        const tools = new Map();
        const clients = [];
        const excluded = new Set((_a = options.excludedTools) !== null && _a !== void 0 ? _a : []);
        for (const [serverName, config] of Object.entries(options.servers)) {
            if (config.type !== 'local' && config.type !== 'stdio') {
                continue;
            }
            const env = Object.assign(Object.assign(Object.assign({}, Object.fromEntries(Object.entries(process.env).filter(([, value]) => value !== undefined))), ((_b = config.env) !== null && _b !== void 0 ? _b : {})), { WORKING_DIR: options.workingDirectory });
            const transport = new stdio_js_1.StdioClientTransport(Object.assign({ command: config.command, args: (_c = config.args) !== null && _c !== void 0 ? _c : [], env }, (config.cwd ? { cwd: config.cwd } : {})));
            const client = new index_js_1.Client({ name: 'kra-byok-agent', version: '1.0.0' }, { capabilities: {} });
            try {
                yield client.connect(transport);
            }
            catch (error) {
                const message = error instanceof Error ? error.message : String(error);
                throw new Error(`Failed to connect MCP server '${serverName}': ${message}`);
            }
            clients.push(client);
            const allowList = config.tools ? new Set(config.tools) : null;
            const listed = yield client.listTools();
            for (const tool of listed.tools) {
                if (allowList && !allowList.has(tool.name)) {
                    continue;
                }
                if (excluded.has(tool.name)) {
                    continue;
                }
                const namespaced = namespacedToolName(serverName, tool.name);
                tools.set(namespaced, {
                    server: serverName,
                    originalName: tool.name,
                    namespacedName: namespaced,
                    description: (_d = tool.description) !== null && _d !== void 0 ? _d : '',
                    inputSchema: (_e = tool.inputSchema) !== null && _e !== void 0 ? _e : {
                        type: 'object',
                        properties: {},
                    },
                    client,
                });
            }
        }
        const openaiTools = Array.from(tools.values()).map((t) => ({
            type: 'function',
            function: {
                name: t.namespacedName,
                description: t.description,
                parameters: t.inputSchema,
            },
        }));
        return {
            tools,
            openaiTools,
            disconnect: () => __awaiter(this, void 0, void 0, function* () {
                yield Promise.allSettled(clients.map((c) => __awaiter(this, void 0, void 0, function* () { return c.close(); })));
            }),
        };
    });
}
