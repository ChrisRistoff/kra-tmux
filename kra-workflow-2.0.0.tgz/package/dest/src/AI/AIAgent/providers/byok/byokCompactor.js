"use strict";
/**
 * Reactive context-window compactor for BYOK sessions.
 *
 * Strategy: when the LLM rejects a request with a context-length error (or when
 * an estimated token budget is exceeded), summarize the older half of the
 * message history into a single "system" message and replace those messages
 * with the summary. The most recent K messages and the system prompt are kept
 * verbatim so the agent never loses immediate context.
 *
 * Estimation is intentionally crude (chars / 4) — it's a fallback heuristic
 * for providers that don't report token usage on streaming responses.
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.estimateTokens = estimateTokens;
exports.isContextLengthError = isContextLengthError;
exports.compactMessages = compactMessages;
const KEEP_RECENT = 10;
const CHARS_PER_TOKEN = 4;
function estimateTokens(messages) {
    let total = 0;
    for (const msg of messages) {
        if (typeof msg.content === 'string') {
            total += msg.content.length;
        }
        else if (Array.isArray(msg.content)) {
            for (const part of msg.content) {
                if ('text' in part && typeof part.text === 'string') {
                    total += part.text.length;
                }
            }
        }
    }
    return Math.ceil(total / CHARS_PER_TOKEN);
}
function isContextLengthError(error) {
    if (!(error instanceof Error)) {
        return false;
    }
    const msg = error.message.toLowerCase();
    return (msg.includes('context length') ||
        msg.includes('context_length') ||
        msg.includes('maximum context') ||
        msg.includes('too many tokens') ||
        msg.includes('reduce the length'));
}
function compactMessages(options) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c;
        const { openai, model, messages } = options;
        if (messages.length <= KEEP_RECENT + 2) {
            return messages;
        }
        const systemMessages = messages.filter((m) => m.role === 'system');
        const nonSystem = messages.filter((m) => m.role !== 'system');
        const recent = nonSystem.slice(-KEEP_RECENT);
        const older = nonSystem.slice(0, -KEEP_RECENT);
        if (older.length === 0) {
            return messages;
        }
        const transcript = older
            .map((m) => {
            const content = typeof m.content === 'string'
                ? m.content
                : JSON.stringify(m.content);
            return `[${m.role}] ${content}`;
        })
            .join('\n\n');
        const summaryResponse = yield openai.chat.completions.create({
            model,
            stream: false,
            messages: [
                {
                    role: 'system',
                    content: 'You are a conversation compactor. Summarize the following agent transcript ' +
                        'into a concise but information-dense recap. Preserve: user goals, key decisions, ' +
                        'files touched, errors hit and their resolutions, outstanding TODOs, and any ' +
                        'facts the agent must remember. Use bullet points. Output ONLY the summary.',
                },
                { role: 'user', content: transcript },
            ],
        });
        const summary = (_c = (_b = (_a = summaryResponse.choices[0]) === null || _a === void 0 ? void 0 : _a.message) === null || _b === void 0 ? void 0 : _b.content) !== null && _c !== void 0 ? _c : '(compaction produced no content)';
        return [
            ...systemMessages,
            {
                role: 'system',
                content: `<compacted_history>\n${summary}\n</compacted_history>`,
            },
            ...recent,
        ];
    });
}
