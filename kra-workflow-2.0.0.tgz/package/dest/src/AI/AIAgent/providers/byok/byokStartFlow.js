"use strict";
/**
 * BYOK entry-point flow.
 *
 * 1. Pick a provider from the BYOK-supported set.
 *    via the shared modelCatalog and present a picker that surfaces context
 *    window and per-token pricing alongside each model.
 * 3. Resolve baseURL + API key (via the shared providers helper).
 * 4. Declare extra MCP servers (kra-bash + kra-web) via `additionalMcpServers`
 *    and hand off to the shared `converseAgent` runner, plumbing the chosen
 *    model's context window through so byokSession can compact proactively.
 *
 * Adding a new BYOK provider: extend `SUPPORTED_PROVIDERS` in
 * `src/AI/shared/data/providers.ts`, add a baseURL + key getter there, and
 * add a live fetcher branch in `src/AI/shared/data/modelCatalog.ts`.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.startByokFlow = startByokFlow;
const conversation = __importStar(require("@/AI/AIAgent/shared/main/agentConversation"));
const ui = __importStar(require("@/UI/generalUI"));
const serverConfig_1 = require("@/AI/AIAgent/mcp/serverConfig");
const providers_1 = require("@/AI/shared/data/providers");
const byokClient_1 = require("@/AI/AIAgent/providers/byok/byokClient");
const modelCatalog_1 = require("@/AI/shared/data/modelCatalog");
const menuChain_1 = require("@/UI/menuChain");
function pickProvider() {
    return __awaiter(this, void 0, void 0, function* () {
        const selected = yield ui.searchSelectAndReturnFromArray({
            itemsArray: [...providers_1.SUPPORTED_PROVIDERS],
            prompt: 'Select a BYOK provider',
        });
        return selected;
    });
}
function pickModel(provider) {
    return __awaiter(this, void 0, void 0, function* () {
        const models = yield (0, modelCatalog_1.getModelCatalog)(provider);
        if (models.length === 0) {
            throw new Error(`No models returned for provider '${provider}'.`);
        }
        const sorted = [...models].sort((a, b) => a.label.localeCompare(b.label));
        const labelToModel = new Map();
        for (const m of sorted) {
            labelToModel.set((0, modelCatalog_1.formatModelInfoForPicker)(m), m);
        }
        const selectedLabel = yield ui.searchSelectAndReturnFromArray({
            itemsArray: [...labelToModel.keys()],
            prompt: `Select a ${provider} model`,
        });
        const picked = labelToModel.get(selectedLabel);
        if (!picked) {
            throw new Error(`Model selection '${selectedLabel}' could not be resolved.`);
        }
        return picked;
    });
}
function startByokFlow() {
    return __awaiter(this, void 0, void 0, function* () {
        const { provider, model } = yield (0, menuChain_1.menuChain)()
            .step('provider', pickProvider)
            .step('model', (d) => __awaiter(this, void 0, void 0, function* () { return pickModel(d.provider); }))
            .run();
        const baseURL = (0, providers_1.getProviderBaseURL)(provider);
        const apiKey = (0, providers_1.getProviderApiKey)(provider);
        const client = new byokClient_1.OpenAICompatibleClient({ baseURL, apiKey });
        try {
            yield conversation.converseAgent(Object.assign({ client, model: model.id, additionalMcpServers: (0, serverConfig_1.buildByokExtraMcpServers)() }, (model.contextWindow > 0 ? { contextWindow: model.contextWindow } : {})));
        }
        catch (error) {
            yield client.forceStop();
            throw error;
        }
    });
}
