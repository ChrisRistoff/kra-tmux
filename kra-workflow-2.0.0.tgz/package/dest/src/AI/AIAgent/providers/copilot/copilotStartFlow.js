"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.startCopilotFlow = startCopilotFlow;
const conversation = __importStar(require("@/AI/AIAgent/shared/main/agentConversation"));
const agentSettings_1 = require("@/AI/AIAgent/shared/utils/agentSettings");
const ui = __importStar(require("@/UI/generalUI"));
const copilotClient_1 = require("@/AI/AIAgent/providers/copilot/copilotClient");
function sortModels(models) {
    return [...models].sort((left, right) => left.name.localeCompare(right.name));
}
function formatBillingMultiplier(model) {
    var _a;
    const multiplier = (_a = model.billing) === null || _a === void 0 ? void 0 : _a.multiplier;
    if (!multiplier) {
        return '';
    }
    return ` [x${multiplier}]`;
}
function pickReasoningEffort(model) {
    return __awaiter(this, void 0, void 0, function* () {
        const supported = model.supportedReasoningEfforts;
        if (!(supported === null || supported === void 0 ? void 0 : supported.length)) {
            return undefined;
        }
        const defaultEffort = model.defaultReasoningEffort;
        const itemsArray = supported.map((effort) => defaultEffort === effort ? `${effort} (default)` : effort);
        const selected = yield ui.searchSelectAndReturnFromArray({
            itemsArray,
            prompt: 'Select reasoning effort level',
        });
        return selected.replace(' (default)', '');
    });
}
function pickCopilotModel(client) {
    return __awaiter(this, void 0, void 0, function* () {
        const models = sortModels(yield client.listModels());
        const defaultModelId = yield (0, agentSettings_1.getAgentDefaultModel)();
        if (defaultModelId && models.some((model) => model.id === defaultModelId)) {
            const defaultModel = models.find((m) => m.id === defaultModelId);
            const reasoningEffort = yield pickReasoningEffort(defaultModel);
            return Object.assign({ modelId: defaultModelId }, (reasoningEffort ? { reasoningEffort } : {}));
        }
        const labelToModel = new Map();
        const itemsArray = models.map((model) => {
            var _a;
            const disabled = ((_a = model.policy) === null || _a === void 0 ? void 0 : _a.state) === 'disabled';
            const billing = formatBillingMultiplier(model);
            const label = disabled
                ? `[DISABLED] ${model.name} (${model.id})${billing}`
                : `${model.name} (${model.id})${billing}`;
            labelToModel.set(label, model);
            return label;
        });
        const selectedLabel = yield ui.searchSelectAndReturnFromArray({
            itemsArray,
            prompt: 'Select a Copilot model',
        });
        const selectedModel = labelToModel.get(selectedLabel);
        if (!selectedModel) {
            throw new Error('No Copilot model selected.');
        }
        const reasoningEffort = yield pickReasoningEffort(selectedModel);
        return Object.assign({ modelId: selectedModel.id }, (reasoningEffort ? { reasoningEffort } : {}));
    });
}
function startCopilotFlow() {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        const githubToken = (0, agentSettings_1.getGithubToken)();
        const client = new copilotClient_1.CopilotClientWrapper(Object.assign(Object.assign({}, (githubToken ? { githubToken } : {})), { useLoggedInUser: !githubToken }));
        try {
            yield client.start();
            const authStatus = yield client.getAuthStatus();
            if (!authStatus.isAuthenticated && !githubToken) {
                throw new Error((_a = authStatus.statusMessage) !== null && _a !== void 0 ? _a : 'GitHub Copilot SDK authentication is not configured.');
            }
            const { modelId, reasoningEffort } = yield pickCopilotModel(client);
            client.setReasoningEffort(reasoningEffort);
            yield conversation.converseAgent({
                client,
                model: modelId,
            });
        }
        catch (error) {
            yield client.forceStop();
            throw error;
        }
    });
}
