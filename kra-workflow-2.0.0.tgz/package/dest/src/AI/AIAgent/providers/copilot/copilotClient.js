"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CopilotClientWrapper = void 0;
const path_1 = __importDefault(require("path"));
const copilot_sdk_1 = require("@github/copilot-sdk");
const turnReminder_1 = require("@/AI/AIAgent/shared/main/turnReminder");
const executableToolBridge_1 = require("@/AI/AIAgent/mcp/executableToolBridge");
const mcpClientPool_1 = require("@/AI/AIAgent/providers/byok/mcpClientPool");
class CopilotClientWrapper {
    constructor(options) {
        var _a;
        const init = {
            useLoggedInUser: (_a = options.useLoggedInUser) !== null && _a !== void 0 ? _a : !options.githubToken,
        };
        if (options.githubToken) {
            init.githubToken = options.githubToken;
        }
        this.inner = new copilot_sdk_1.CopilotClient(init);
        if (options.reasoningEffort) {
            this.reasoningEffort = options.reasoningEffort;
        }
    }
    setReasoningEffort(effort) {
        this.reasoningEffort = effort;
    }
    start() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.inner.start();
        });
    }
    getAuthStatus() {
        return __awaiter(this, void 0, void 0, function* () {
            return this.inner.getAuthStatus();
        });
    }
    listModels() {
        return __awaiter(this, void 0, void 0, function* () {
            return this.inner.listModels();
        });
    }
    createSession(options) {
        return __awaiter(this, void 0, void 0, function* () {
            const skillsDir = path_1.default.join(__dirname, '..', '..', '..', '..', 'skills');
            const sdkSession = yield this.inner.createSession(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({ clientName: 'copilot-cli', model: options.model }, (this.reasoningEffort ? { reasoningEffort: this.reasoningEffort } : {})), { workingDirectory: options.workingDirectory, streaming: true, enableConfigDiscovery: true, skillDirectories: [skillsDir], mcpServers: options.mcpServers }), (options.excludedTools ? { excludedTools: options.excludedTools } : {})), { onPermissionRequest: () => ({ kind: 'approved' }), infiniteSessions: {
                    enabled: true,
                    backgroundCompactionThreshold: 0.70,
                    bufferExhaustionThreshold: 0.90,
                }, hooks: {
                    onPreToolUse: options.onPreToolUse,
                    onPostToolUse: options.onPostToolUse,
                    onUserPromptSubmitted: () => __awaiter(this, void 0, void 0, function* () {
                        return ({
                            additionalContext: turnReminder_1.TURN_REMINDER,
                        });
                    }),
                } }), (options.onUserInputRequest ? { onUserInputRequest: options.onUserInputRequest } : {})), (options.systemMessage ? { systemMessage: options.systemMessage } : {})));
            // Side channel MCP pool restricted to kra-* servers so the user can
            // re-execute our own tools from the agent UI even when the active
            // provider is Copilot (whose SDK does not expose its internal MCP
            // clients).
            const kraServers = {};
            for (const [name, cfg] of Object.entries(options.mcpServers)) {
                if (name.startsWith('kra-')) {
                    kraServers[name] = cfg;
                }
            }
            let sidePool;
            if (Object.keys(kraServers).length > 0) {
                try {
                    sidePool = yield (0, mcpClientPool_1.buildMcpClientPool)({
                        servers: kraServers,
                        workingDirectory: options.workingDirectory,
                    });
                }
                catch (_a) {
                    // Side pool is best-effort; failure just disables re-execution.
                    sidePool = undefined;
                }
            }
            const session = sdkSession;
            if (sidePool) {
                const bridge = (0, executableToolBridge_1.createExecutableToolBridge)(() => sidePool);
                session.listExecutableTools = bridge.listExecutableTools;
                session.executeTool = bridge.executeTool;
                const originalDisconnect = session.disconnect.bind(session);
                session.disconnect = () => __awaiter(this, void 0, void 0, function* () {
                    yield (0, executableToolBridge_1.disconnectPool)(sidePool, true);
                    yield originalDisconnect();
                });
            }
            return session;
        });
    }
    stop() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.inner.stop();
        });
    }
    forceStop() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.inner.forceStop();
        });
    }
}
exports.CopilotClientWrapper = CopilotClientWrapper;
