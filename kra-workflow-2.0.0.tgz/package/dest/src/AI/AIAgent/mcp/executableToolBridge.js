"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.listExecutableToolsFromPool = listExecutableToolsFromPool;
exports.executeToolFromPool = executeToolFromPool;
exports.createExecutableToolBridge = createExecutableToolBridge;
exports.disconnectPool = disconnectPool;
function listTools(pool) {
    return pool ? Array.from(pool.tools.values()) : [];
}
function findToolByTitle(pool, title) {
    return listTools(pool).find((tool) => `${tool.server}:${tool.originalName}` === title);
}
function listExecutableToolsFromPool(pool) {
    return listTools(pool).map((tool) => ({
        title: `${tool.server}:${tool.originalName}`,
        server: tool.server,
        name: tool.originalName,
    }));
}
function executeToolFromPool(pool_1, title_1, args_1) {
    return __awaiter(this, arguments, void 0, function* (pool, title, args, options = {}) {
        var _a, _b;
        if (!pool) {
            throw new Error((_a = options.uninitializedError) !== null && _a !== void 0 ? _a : 'MCP pool not initialized');
        }
        const tool = findToolByTitle(pool, title);
        if (!tool) {
            throw new Error(`Unknown tool: ${title}`);
        }
        const result = yield tool.client.callTool({ name: tool.originalName, arguments: args });
        const contentArray = ((_b = result.content) !== null && _b !== void 0 ? _b : []);
        return contentArray
            .filter((part) => part.type === 'text' && typeof part.text === 'string')
            .map((part) => part.text)
            .join('\n');
    });
}
function createExecutableToolBridge(getPool, options = {}) {
    return {
        listExecutableTools: () => listExecutableToolsFromPool(getPool()),
        executeTool: (title, args) => __awaiter(this, void 0, void 0, function* () { return executeToolFromPool(getPool(), title, args, options); }),
    };
}
function disconnectPool(pool_1) {
    return __awaiter(this, arguments, void 0, function* (pool, swallowErrors = false) {
        if (!pool) {
            return;
        }
        if (swallowErrors) {
            try {
                yield pool.disconnect();
            }
            catch (_a) {
                return;
            }
            return;
        }
        yield pool.disconnect();
    });
}
