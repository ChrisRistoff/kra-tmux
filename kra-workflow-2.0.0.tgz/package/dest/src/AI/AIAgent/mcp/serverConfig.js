"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildCoreMcpServers = buildCoreMcpServers;
exports.buildByokExtraMcpServers = buildByokExtraMcpServers;
const path_1 = __importDefault(require("path"));
const agentSettings_1 = require("@/AI/AIAgent/shared/utils/agentSettings");
function bundledServerScript(scriptName) {
    return path_1.default.join(__dirname, '..', 'shared', 'utils', scriptName);
}
function stdioServer(scriptName, tools) {
    return {
        type: 'stdio',
        command: process.execPath,
        args: [bundledServerScript(scriptName)],
        tools,
    };
}
function buildCoreMcpServers() {
    return __awaiter(this, void 0, void 0, function* () {
        const configuredServers = yield (0, agentSettings_1.getConfiguredMcpServers)();
        return Object.assign(Object.assign({}, configuredServers), { 'kra-session-complete': stdioServer('sessionCompleteMcpServer.js', ['confirm_task_complete']), 'kra-file-context': stdioServer('fileContextMcpServer.js', [
                'get_outline',
                'read_lines',
                'read_function',
                'edit_lines',
                'create_file',
                'search',
                'lsp_query',
            ]), 'kra-memory': stdioServer('memoryMcpServer.js', [
                'remember',
                'recall',
                'update_memory',
                'edit_memory',
                'semantic_search',
            ]) });
    });
}
function buildByokExtraMcpServers() {
    return {
        'kra-bash': stdioServer('bashMcpServer.js', ['bash']),
        'kra-web': stdioServer('webMcpServer.js', ['web_fetch', 'web_search']),
    };
}
