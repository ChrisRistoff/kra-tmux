"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.JsonRpcToolError = void 0;
exports.runStdioMcpServer = runStdioMcpServer;
const readline_1 = __importDefault(require("readline"));
class JsonRpcToolError extends Error {
    constructor(code, message) {
        super(message);
        this.code = code;
    }
}
exports.JsonRpcToolError = JsonRpcToolError;
function send(response) {
    process.stdout.write(JSON.stringify(response) + '\n');
}
function sendResult(id, result) {
    send({ jsonrpc: '2.0', id, result });
}
function sendError(id, code, message) {
    send({ jsonrpc: '2.0', id, error: { code, message } });
}
function runStdioMcpServer(options) {
    var _a, _b;
    const rl = readline_1.default.createInterface({ input: process.stdin, terminal: false });
    const serverVersion = (_a = options.serverVersion) !== null && _a !== void 0 ? _a : '1.0.0';
    const respondParseError = (_b = options.respondParseError) !== null && _b !== void 0 ? _b : true;
    let pending = 0;
    let inputClosed = false;
    const hasTool = (toolName) => options.tools.some((t) => t.name === toolName);
    function maybeExit() {
        if (inputClosed && pending === 0) {
            process.exit(0);
        }
    }
    rl.on('line', (line) => {
        var _a;
        const trimmed = line.trim();
        if (!trimmed)
            return;
        let request;
        try {
            request = JSON.parse(trimmed);
        }
        catch (_b) {
            if (respondParseError)
                sendError(null, -32700, 'Parse error');
            return;
        }
        const id = (_a = request.id) !== null && _a !== void 0 ? _a : null;
        pending++;
        void (() => __awaiter(this, void 0, void 0, function* () {
            var _a, _b;
            try {
                switch (request.method) {
                    case 'initialize':
                        sendResult(id, {
                            protocolVersion: '2024-11-05',
                            capabilities: { tools: {} },
                            serverInfo: { name: options.serverName, version: serverVersion },
                        });
                        return;
                    case 'notifications/initialized':
                        return;
                    case 'tools/list':
                        sendResult(id, { tools: options.tools });
                        return;
                    case 'tools/call': {
                        const params = ((_a = request.params) !== null && _a !== void 0 ? _a : {});
                        const toolName = typeof params.name === 'string' ? params.name : '';
                        if (!hasTool(toolName)) {
                            sendError(id, -32601, `Unknown tool: ${toolName || '(none)'}`);
                            return;
                        }
                        const result = yield options.handleToolCall({ toolName, params: (_b = request.params) !== null && _b !== void 0 ? _b : {}, id });
                        sendResult(id, result);
                        return;
                    }
                    case 'ping':
                        if (options.allowPing) {
                            sendResult(id, {});
                            return;
                        }
                        sendError(id, -32601, `Method not found: ${request.method}`);
                        return;
                    default:
                        sendError(id, -32601, `Method not found: ${request.method}`);
                        return;
                }
            }
            catch (error) {
                if (options.onInternalError) {
                    const mapped = options.onInternalError(error);
                    if (mapped.kind === 'error') {
                        sendError(id, mapped.code, mapped.message);
                    }
                    else {
                        sendResult(id, mapped.result);
                    }
                    return;
                }
                if (error instanceof JsonRpcToolError) {
                    sendError(id, error.code, error.message);
                    return;
                }
                const message = error instanceof Error ? error.message : String(error);
                sendError(id, -32603, `Internal error: ${message}`);
            }
            finally {
                pending--;
                maybeExit();
            }
        }))();
    });
    rl.on('close', () => {
        inputClosed = true;
        maybeExit();
    });
}
