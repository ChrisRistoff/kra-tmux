"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getErrorMessage = getErrorMessage;
exports.setupEventHandlers = setupEventHandlers;
const fs = __importStar(require("fs/promises"));
const agentUi_1 = require("@/AI/AIAgent/shared/utils/agentUi");
const chatHeaders_1 = require("@/AI/shared/utils/conversationUtils/chatHeaders");
const agentNeovimSetup_1 = require("@/AI/AIAgent/shared/main/agentNeovimSetup");
const conversation = __importStar(require("@/AI/shared/conversation"));
const agentToolHook_1 = require("@/AI/AIAgent/shared/utils/agentToolHook");
const agentSessionEvents_1 = require("@/AI/AIAgent/shared/utils/agentSessionEvents");
const agentPromptActionDispatch_1 = require("./agentPromptActionDispatch");
const fileContext = conversation;
function getErrorMessage(error) {
    if (error instanceof Error) {
        return error.message;
    }
    if (typeof error === 'string') {
        return error;
    }
    return 'Unknown error';
}
function createSelectionAttachment(context, displayName) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c, _d;
        const content = yield fs.readFile(context.filePath, 'utf8');
        const allLines = content.split('\n');
        const startLine = (_a = context.startLine) !== null && _a !== void 0 ? _a : 1;
        const endLine = (_b = context.endLine) !== null && _b !== void 0 ? _b : startLine;
        const selectedText = allLines.slice(startLine - 1, endLine).join('\n');
        return {
            type: 'selection',
            filePath: context.filePath,
            displayName,
            selection: {
                start: { line: startLine - 1, character: 0 },
                end: { line: endLine - 1, character: (_d = (_c = allLines[endLine - 1]) === null || _c === void 0 ? void 0 : _c.length) !== null && _d !== void 0 ? _d : 0 },
            },
            text: selectedText,
        };
    });
}
function buildAttachments() {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        const attachments = [];
        for (const context of fileContext.fileContexts) {
            const displayName = (_a = context.filePath.split('/').pop()) !== null && _a !== void 0 ? _a : context.filePath;
            if (!context.isPartial) {
                attachments.push({
                    type: 'file',
                    path: context.filePath,
                    displayName,
                });
                continue;
            }
            attachments.push(yield createSelectionAttachment(context, displayName));
        }
        return attachments;
    });
}
function handleSubmit(state) {
    return __awaiter(this, void 0, void 0, function* () {
        if (state.isStreaming) {
            yield state.nvim.command('echohl WarningMsg | echo "Agent is still responding" | echohl None');
            return;
        }
        const prompt = yield (0, agentNeovimSetup_1.getAgentPromptText)(state.nvim);
        if (!prompt) {
            yield state.nvim.command('echohl WarningMsg | echo "Type a prompt before submitting" | echohl None');
            return;
        }
        const turnTimestamp = new Date().toISOString();
        yield (0, chatHeaders_1.materializeUserDraft)(state.chatFile, turnTimestamp);
        yield (0, agentToolHook_1.appendToChat)(state.chatFile, (0, agentUi_1.formatSubmittedAgentPrompt)(prompt));
        yield (0, agentNeovimSetup_1.clearAgentPrompt)(state.nvim);
        state.isStreaming = true;
        yield (0, agentSessionEvents_1.updateAgentUi)(state.nvim, 'start_turn', [state.model]);
        yield (0, agentToolHook_1.appendToChat)(state.chatFile, (0, chatHeaders_1.formatAssistantHeader)(state.model, turnTimestamp));
        yield (0, agentNeovimSetup_1.refreshAgentLayout)(state.nvim);
        yield (0, agentNeovimSetup_1.focusAgentPrompt)(state.nvim);
        const attachments = yield buildAttachments();
        yield state.session.send({
            prompt,
            attachments,
            mode: 'immediate',
        });
    });
}
function setupEventHandlers(state) {
    return __awaiter(this, void 0, void 0, function* () {
        state.nvim.on('notification', (method, args) => {
            void (() => __awaiter(this, void 0, void 0, function* () {
                if (method !== 'prompt_action') {
                    return;
                }
                const action = typeof args[0] === 'string' ? args[0] : '';
                try {
                    if (action === 'submit_pressed') {
                        yield handleSubmit(state);
                    }
                    else {
                        yield (0, agentPromptActionDispatch_1.dispatchPromptAction)(state, action, args);
                    }
                }
                catch (error) {
                    yield (0, agentSessionEvents_1.updateAgentUi)(state.nvim, 'show_error', [
                        `Action failed: ${action}`,
                        getErrorMessage(error),
                    ]);
                }
            }))();
        });
    });
}
