"use strict";
/**
 * Startup indexing flow: prompt the user whether to enable code search,
 * bring the local index up to date if so, stream progress to the Neovim
 * modal, and report whether `semantic_search` should be exposed for this
 * agent session.
 *
 * Sequence on launch:
 *   1. Identify the repo (git origin / top-level path).
 *   2. Show a Yes/No modal in Neovim.
 *   3. If "no" — return `{ semanticSearchEnabled: false }`. The agent will
 *      drop `semantic_search` from its tool list and from the MCP exposure.
 *   4. If "yes" — load the registry entry. If no entry exists or the repo
 *      has never been indexed, run a full `reindexAll`. Otherwise compute
 *      a catch-up plan (git diff vs `lastIndexedCommit`, or mtime fallback)
 *      and reindex only the changed files. Above
 *      `CATCHUP_FULL_REINDEX_THRESHOLD` ask whether to fall back to a full
 *      reindex.
 *   5. Show progress in a Neovim floating tab. Each indexed file is
 *      appended live. The modal stays open until the user dismisses it.
 *   6. Persist the new `lastIndexedCommit` / `lastIndexedAt` /
 *      `chunksCount` to the registry.
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.runStartupIndexingFlow = runStartupIndexingFlow;
const catchup_1 = require("@/AI/AIAgent/shared/memory/catchup");
const registry_1 = require("@/AI/AIAgent/shared/memory/registry");
const indexer_1 = require("@/AI/AIAgent/shared/memory/indexer");
const db_1 = require("@/AI/AIAgent/shared/memory/db");
const settings_1 = require("@/AI/AIAgent/shared/memory/settings");
const bashHelper_1 = require("@/utils/bashHelper");
const agentToolHook_1 = require("@/AI/AIAgent/shared/utils/agentToolHook");
const agentSessionEvents_1 = require("@/AI/AIAgent/shared/utils/agentSessionEvents");
function safeHeadCommit(repoRoot) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const result = yield (0, bashHelper_1.execCommand)(`git -C '${repoRoot.replace(/'/g, `'\\''`)}' rev-parse HEAD`);
            return result.stdout.trim();
        }
        catch (_a) {
            return '';
        }
    });
}
function waitForModalDismiss(nvimClient) {
    return __awaiter(this, void 0, void 0, function* () {
        return new Promise((resolve) => {
            const handler = (method) => {
                if (method !== 'index_progress_dismissed')
                    return;
                nvimClient.removeListener('notification', handler);
                resolve();
            };
            nvimClient.on('notification', handler);
        });
    });
}
function showProgressModal(ctx, alias, totalFiles, mode) {
    return __awaiter(this, void 0, void 0, function* () {
        const channelId = yield ctx.nvimClient.channelId;
        yield (0, agentSessionEvents_1.updateAgentUi)(ctx.nvimClient, 'show_index_progress_modal', [
            { channel_id: channelId, alias, total_files: totalFiles, mode },
        ]);
    });
}
function appendProgress(ctx, line, filesDone, filesTotal) {
    return __awaiter(this, void 0, void 0, function* () {
        yield (0, agentSessionEvents_1.updateAgentUi)(ctx.nvimClient, 'append_index_progress', [{ line, files_done: filesDone, files_total: filesTotal }]);
    });
}
function formatProgressLine(filesDone, filesTotal, suffix) {
    const pct = filesTotal > 0 ? Math.floor((filesDone / filesTotal) * 100) : 0;
    return `[${pct.toString().padStart(3)}%] ${filesDone}/${filesTotal}  ${suffix}`;
}
function markDone(ctx, summary) {
    return __awaiter(this, void 0, void 0, function* () {
        yield (0, agentSessionEvents_1.updateAgentUi)(ctx.nvimClient, 'set_index_progress_done', [{ summary }]);
    });
}
function appendLine(ctx, line) {
    return __awaiter(this, void 0, void 0, function* () {
        yield (0, agentSessionEvents_1.updateAgentUi)(ctx.nvimClient, 'append_index_progress', [{ line }]);
    });
}
function runFullReindex(ctx, alias) {
    return __awaiter(this, void 0, void 0, function* () {
        let lastFilesTotal = 0;
        let lastPath = '';
        yield showProgressModal(ctx, alias, 0, 'initial');
        const result = yield (0, indexer_1.reindexAll)({
            onProgress: (p) => {
                lastFilesTotal = p.filesTotal;
                if (p.phase === 'embedding' && p.currentPath && p.currentPath !== lastPath) {
                    lastPath = p.currentPath;
                    void appendProgress(ctx, formatProgressLine(p.filesDone + 1, p.filesTotal, `✓ ${p.currentPath}`), p.filesDone + 1, p.filesTotal);
                }
                if (p.phase === 'scanning') {
                    void (0, agentSessionEvents_1.updateAgentUi)(ctx.nvimClient, 'set_index_progress_total', [{ total_files: p.filesTotal }]);
                }
            },
        });
        void lastFilesTotal;
        return { chunksWritten: result.chunksWritten, filesScanned: result.filesScanned, elapsedMs: result.elapsedMs };
    });
}
function runCatchup(ctx, alias, changes) {
    return __awaiter(this, void 0, void 0, function* () {
        const started = Date.now();
        const total = changes.length;
        yield showProgressModal(ctx, alias, total, 'catchup');
        const settings = yield (0, settings_1.loadMemorySettings)();
        const root = (0, indexer_1.workspaceRoot)();
        let chunksWritten = 0;
        let filesScanned = 0;
        if (total === 0) {
            yield appendProgress(ctx, '— Nothing to catch up. Index is current.', 0, 0);
            return { chunksWritten: 0, filesScanned: 0, elapsedMs: Date.now() - started };
        }
        for (let i = 0; i < changes.length; i++) {
            const change = changes[i];
            try {
                if (change.kind === 'delete') {
                    const removed = yield (0, indexer_1.removeFile)(change.relPath);
                    yield appendProgress(ctx, formatProgressLine(i + 1, total, `🗑  ${change.relPath} (${removed} chunks removed)`), i + 1, total);
                }
                else {
                    const r = yield (0, indexer_1.indexFile)(change.relPath, { settings, root });
                    chunksWritten += r.chunksWritten;
                    filesScanned += 1;
                    yield appendProgress(ctx, formatProgressLine(i + 1, total, `✓ ${change.relPath} (+${r.chunksWritten} chunks)`), i + 1, total);
                }
            }
            catch (err) {
                const msg = err instanceof Error ? err.message : String(err);
                yield appendProgress(ctx, formatProgressLine(i + 1, total, `✗ ${change.relPath}: ${msg}`), i + 1, total);
            }
        }
        return { chunksWritten, filesScanned, elapsedMs: Date.now() - started };
    });
}
function runStartupIndexingFlow(nvimClient, cwd) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b;
        const settings = yield (0, settings_1.loadMemorySettings)();
        if (!settings.enabled) {
            return { semanticSearchEnabled: false };
        }
        const identity = yield (0, registry_1.getRepoIdentity)(cwd);
        const existing = yield (0, registry_1.getRegistryEntry)(identity.id);
        const aliasLabel = (_a = existing === null || existing === void 0 ? void 0 : existing.alias) !== null && _a !== void 0 ? _a : identity.alias;
        const prompt = yield (0, agentToolHook_1.handleAgentUserInput)(nvimClient, `Enable code semantic_search for '${aliasLabel}'? This will ${existing ? 'catch the index up' : 'index the repo for the first time'}.`, ['Yes', 'No'], false);
        const answer = prompt.answer.trim().toLowerCase();
        if (answer !== 'yes' && answer !== 'y') {
            return { semanticSearchEnabled: false };
        }
        const ctx = { nvimClient };
        let summary = '';
        const dbChunkCount = yield (0, db_1.countCodeChunks)().catch(() => 0);
        const needsFreshIndex = !(existing === null || existing === void 0 ? void 0 : existing.lastIndexedAt) || dbChunkCount === 0;
        if (needsFreshIndex) {
            const r = yield runFullReindex(ctx, aliasLabel);
            const total = yield (0, db_1.countCodeChunks)().catch(() => r.chunksWritten);
            yield (0, registry_1.upsertRegistryEntry)(identity.id, {
                alias: identity.alias,
                rootPath: identity.rootPath,
                lastIndexedCommit: yield safeHeadCommit(identity.rootPath),
                lastIndexedAt: Date.now(),
                chunksCount: total,
            });
            yield appendLine(ctx, '');
            yield appendLine(ctx, `indexed ${r.filesScanned} files in ${(r.elapsedMs / 1000).toFixed(1)}s`);
            yield appendLine(ctx, `${r.chunksWritten} chunks written`);
            yield appendLine(ctx, `registry updated for '${identity.alias}' (${total} total chunks)`);
            summary = 'Done.';
        }
        else {
            const plan = yield (0, catchup_1.computeChangedFiles)({
                repoRoot: identity.rootPath,
                lastIndexedCommit: existing.lastIndexedCommit,
                lastIndexedAt: existing.lastIndexedAt,
            });
            let useFullReindex = false;
            if (plan.exceedsThreshold) {
                const confirm = yield (0, agentToolHook_1.handleAgentUserInput)(nvimClient, `Catch-up would reindex ${plan.changes.length} files (>${catchup_1.CATCHUP_FULL_REINDEX_THRESHOLD}). Run a full reindex instead?`, ['Yes', 'No'], false);
                const a = confirm.answer.trim().toLowerCase();
                useFullReindex = a === 'yes' || a === 'y';
            }
            if (useFullReindex) {
                const r = yield runFullReindex(ctx, aliasLabel);
                const total = yield (0, db_1.countCodeChunks)().catch(() => r.chunksWritten);
                yield (0, registry_1.upsertRegistryEntry)(identity.id, {
                    alias: identity.alias,
                    rootPath: identity.rootPath,
                    lastIndexedCommit: yield safeHeadCommit(identity.rootPath),
                    lastIndexedAt: Date.now(),
                    chunksCount: total,
                });
                yield appendLine(ctx, '');
                yield appendLine(ctx, `indexed ${r.filesScanned} files in ${(r.elapsedMs / 1000).toFixed(1)}s`);
                yield appendLine(ctx, `${r.chunksWritten} chunks written`);
                yield appendLine(ctx, `registry updated for '${identity.alias}' (${total} total chunks)`);
                summary = 'Done.';
            }
            else {
                const r = yield runCatchup(ctx, aliasLabel, plan.changes);
                const total = yield (0, db_1.countCodeChunks)().catch(() => existing.chunksCount + r.chunksWritten);
                yield (0, registry_1.upsertRegistryEntry)(identity.id, {
                    alias: identity.alias,
                    rootPath: identity.rootPath,
                    lastIndexedCommit: (_b = plan.headCommit) !== null && _b !== void 0 ? _b : existing.lastIndexedCommit,
                    lastIndexedAt: Date.now(),
                    chunksCount: total,
                });
                yield appendLine(ctx, '');
                yield appendLine(ctx, `catch-up: reindexed ${r.filesScanned} files in ${(r.elapsedMs / 1000).toFixed(1)}s`);
                yield appendLine(ctx, `${r.chunksWritten} chunks written`);
                yield appendLine(ctx, `registry updated for '${identity.alias}' (${total} total chunks)`);
                summary = 'Done.';
            }
        }
        yield markDone(ctx, summary);
        yield waitForModalDismiss(nvimClient);
        return { semanticSearchEnabled: true };
    });
}
