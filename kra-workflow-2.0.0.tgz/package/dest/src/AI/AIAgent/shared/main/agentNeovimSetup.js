"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createAgentChatFile = createAgentChatFile;
exports.addAgentCommands = addAgentCommands;
exports.addAgentFunctions = addAgentFunctions;
exports.setupAgentSplitLayout = setupAgentSplitLayout;
exports.getAgentPromptText = getAgentPromptText;
exports.clearAgentPrompt = clearAgentPrompt;
exports.focusAgentPrompt = focusAgentPrompt;
exports.refreshAgentLayout = refreshAgentLayout;
exports.openAgentNeovim = openAgentNeovim;
const fs = __importStar(require("fs/promises"));
const neovim = __importStar(require("neovim"));
const agentTmux_1 = require("@/AI/AIAgent/shared/utils/agentTmux");
const bash = __importStar(require("@/utils/bashHelper"));
const neovimHelper_1 = require("@/utils/neovimHelper");
const filePaths_1 = require("@/filePaths");
const aiNeovimHelper = __importStar(require("@/AI/shared/conversation"));
const chatHeaders_1 = require("@/AI/shared/utils/conversationUtils/chatHeaders");
const AGENT_PROMPT_ACTIONS = [
    ['ReviewProposal', 'review_proposal'],
    ['OpenProposalFile', 'open_proposal_file'],
    ['ApplyProposal', 'apply_proposal'],
    ['RejectProposal', 'reject_proposal'],
];
function createAgentChatFile(chatFile) {
    return __awaiter(this, void 0, void 0, function* () {
        const initialContent = `# Copilot Agent Chat

            This session runs the Copilot SDK against a proposal workspace. Proposed edits are reviewed in Neovim before they are applied to the repository.

            # Controls / Shortcuts:
            #   Enter        -> Submit prompt
            #   Tab / S-Tab  -> Switch between transcript and prompt
            #   Ctrl+c       -> Stop current agent turn
            #   @            -> Add file context(s) (<Tab> multi-select, + marks selections, <CR> confirm, <Esc> cancel)
            #   r            -> Remove file from context
            #   f            -> Show active file contexts
            #   Ctrl+x       -> Clear all contexts
            #   <leader>t    -> Toggle popups for tools and agent current actions on/off
            #
            # Proposal controls (shown automatically after each turn with changes):
            #   <leader>o    -> Open a changed proposal file
            #   <leader>a    -> Apply proposal to the repository
            #   <leader>r    -> Reject proposal
            #
            # Agent controls:
            #   <leader>y    -> Toggle YOLO mode (auto-approve all tools)
            #   <leader>P    -> Reset remembered tool approvals
            #   <leader>h    -> Browse recent tool calls
            #   <leader>s    -> Browse session diff history (all AI write diffs)
            #   <leader>m    -> Browse kra-memory (<Tab> view, a add, dd del; <CR> opens entry buffer: <leader>w save / d del / r resolve / x dismiss / q close)
            #   <leader>i    -> Reopen the kra-memory index-progress modal
            #   <leader>?    -> Show all keymaps
            #
            # 💡 Type your prompt in the bottom split.`;
        yield fs.writeFile(chatFile, `${initialContent}${(0, chatHeaders_1.formatUserDraftHeader)()}`, 'utf8');
    });
}
function addAgentCommands(nvimClient) {
    return __awaiter(this, void 0, void 0, function* () {
        for (const [commandName] of AGENT_PROMPT_ACTIONS) {
            yield nvimClient.command(`command! -nargs=0 ${commandName} call ${commandName}()`);
        }
        yield nvimClient.command(`command! -nargs=0 AgentToolHistory lua require('kra_agent_ui').show_history()`);
        yield nvimClient.command(`command! -nargs=0 AgentCommands lua require('which-key').show({ global = false })`);
    });
}
function addAgentFunctions(nvimClient, channelId) {
    return __awaiter(this, void 0, void 0, function* () {
        for (const [functionName, actionName] of AGENT_PROMPT_ACTIONS) {
            yield nvimClient.command(`
            function! ${functionName}()
                call rpcnotify(${channelId}, 'prompt_action', '${actionName}')
            endfunction
        `);
        }
    });
}
function setupAgentSplitLayout(nvimClient, channelId) {
    return __awaiter(this, void 0, void 0, function* () {
        yield nvimClient.executeLua(`require('kra_agent_layout').setup(...)`, [channelId]);
    });
}
function getAgentPromptText(nvimClient) {
    return __awaiter(this, void 0, void 0, function* () {
        const prompt = yield nvimClient.executeLua(`return require('kra_agent_layout').get_prompt_text()`, []);
        return typeof prompt === 'string' ? prompt : '';
    });
}
function clearAgentPrompt(nvimClient) {
    return __awaiter(this, void 0, void 0, function* () {
        yield nvimClient.executeLua(`require('kra_agent_layout').clear_prompt()`, []);
    });
}
function focusAgentPrompt(nvimClient) {
    return __awaiter(this, void 0, void 0, function* () {
        yield nvimClient.executeLua(`require('kra_agent_layout').focus_prompt()`, []);
    });
}
function refreshAgentLayout(nvimClient) {
    return __awaiter(this, void 0, void 0, function* () {
        yield nvimClient.executeLua(`require('kra_agent_layout').refresh()`, []);
    });
}
function openAgentNeovim(chatFile) {
    return __awaiter(this, void 0, void 0, function* () {
        const socketPath = yield aiNeovimHelper.generateSocketPath();
        if (process.env.TMUX) {
            yield bash.execCommand((0, agentTmux_1.buildAgentTmuxCommand)(chatFile, socketPath));
        }
        else {
            void (0, neovimHelper_1.openVim)(chatFile, '-u', filePaths_1.neovimConfig, '--listen', socketPath);
        }
        yield aiNeovimHelper.waitForSocket(socketPath);
        return neovim.attach({ socket: socketPath });
    });
}
