"use strict";
/**
 * Bridge between the Neovim chat buffer (<leader>m) and the kra-memory store.
 *
 * The agent prompt-action handler dispatches `browse_memory` / `add_memory`
 * / `delete_memory` here. We talk to LanceDB via the same `notes.ts` helpers
 * the MCP server uses, then drive a Telescope picker in `kra_agent_ui.lua`
 * via `executeLua`.
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.pickMemories = pickMemories;
exports.openMemoryBrowser = openMemoryBrowser;
exports.handleAddMemory = handleAddMemory;
exports.handleDeleteMemory = handleDeleteMemory;
exports.handleEditMemory = handleEditMemory;
exports.handleSetMemoryStatus = handleSetMemoryStatus;
const notes_1 = require("@/AI/AIAgent/shared/memory/notes");
const types_1 = require("@/AI/AIAgent/shared/memory/types");
function parseView(raw) {
    const v = String(raw !== null && raw !== void 0 ? raw : 'all');
    return v === 'findings' || v === 'revisits' ? v : 'all';
}
function toMemoryPayload(entry) {
    return {
        id: entry.id,
        kind: entry.kind,
        title: entry.title,
        body: entry.body,
        tags: entry.tags,
        paths: entry.paths,
        status: entry.status,
        createdAt: entry.createdAt,
    };
}
function pickMemories(nvim_1, entries_1) {
    return __awaiter(this, arguments, void 0, function* (nvim, entries, options = {}) {
        const channelId = yield nvim.channelId;
        const payload = entries.map(toMemoryPayload);
        return new Promise((resolve) => {
            var _a;
            const handler = (method, args) => {
                if (method !== 'memory_picker_selection') {
                    return;
                }
                nvim.removeListener('notification', handler);
                if (typeof args[0] !== 'string') {
                    resolve(null);
                    return;
                }
                try {
                    const rawIds = JSON.parse(args[0]);
                    if (!Array.isArray(rawIds)) {
                        resolve(null);
                        return;
                    }
                    const byId = new Map(entries.map((entry) => [entry.id, entry]));
                    resolve(rawIds
                        .map((id) => byId.get(String(id)))
                        .filter((entry) => entry !== undefined));
                }
                catch (_a) {
                    resolve(null);
                }
            };
            nvim.on('notification', handler);
            void nvim.executeLua(`require('kra_agent_ui').pick_memories(...)`, [
                channelId,
                payload,
                { title: (_a = options.title) !== null && _a !== void 0 ? _a : 'Select memories' },
            ]).catch(() => {
                nvim.removeListener('notification', handler);
                resolve(null);
            });
        });
    });
}
function openMemoryBrowser(nvim_1) {
    return __awaiter(this, arguments, void 0, function* (nvim, view = 'all') {
        const entries = yield (0, notes_1.listMemories)({ scope: view, limit: 200 });
        const payload = entries.map(toMemoryPayload);
        yield nvim.executeLua(`require('kra_agent_ui').show_memory_browser(...)`, [payload, view]);
    });
}
function handleAddMemory(nvim, args) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c, _d;
        const kindRaw = String((_a = args['kind']) !== null && _a !== void 0 ? _a : 'note').trim();
        const kind = types_1.MEMORY_KINDS.includes(kindRaw)
            ? kindRaw
            : 'note';
        const title = String((_b = args['title']) !== null && _b !== void 0 ? _b : '').trim();
        const body = String((_c = args['body']) !== null && _c !== void 0 ? _c : '').trim();
        const view = parseView(args['view']);
        if (!title || !body) {
            yield nvim.executeLua(`vim.notify('Memory: title and body are required', vim.log.levels.WARN, { title = 'kra-memory' })`, []);
            return;
        }
        const tagsRaw = String((_d = args['tags']) !== null && _d !== void 0 ? _d : '').trim();
        const tags = tagsRaw ? tagsRaw.split(',').map((t) => t.trim()).filter(Boolean) : [];
        const { id } = yield (0, notes_1.remember)({ kind, title, body, tags, source: 'user' });
        yield nvim.executeLua(`local id = select(1, ...); vim.notify('Saved memory ' .. tostring(id), vim.log.levels.INFO, { title = 'kra-memory' })`, [id]);
        yield openMemoryBrowser(nvim, view);
    });
}
function handleDeleteMemory(nvim, args) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        const id = String((_a = args['id']) !== null && _a !== void 0 ? _a : '').trim();
        const view = parseView(args['view']);
        if (!id) {
            return;
        }
        yield (0, notes_1.deleteMemory)(id);
        yield nvim.executeLua(`local id = select(1, ...); vim.notify('Deleted memory ' .. tostring(id), vim.log.levels.INFO, { title = 'kra-memory' })`, [id]);
        yield openMemoryBrowser(nvim, view);
    });
}
function handleEditMemory(nvim, args) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        const id = String((_a = args['id']) !== null && _a !== void 0 ? _a : '').trim();
        const view = parseView(args['view']);
        if (!id) {
            return;
        }
        const patch = { id };
        if (typeof args['title'] === 'string') {
            patch.title = (args['title']).trim();
        }
        if (typeof args['body'] === 'string') {
            patch.body = (args['body']).trim();
        }
        if (typeof args['tags'] === 'string') {
            const t = (args['tags']).trim();
            patch.tags = t ? t.split(',').map((x) => x.trim()).filter(Boolean) : [];
        }
        else if (Array.isArray(args['tags'])) {
            patch.tags = args['tags'].map((x) => String(x));
        }
        if (typeof args['paths'] === 'string') {
            const p = (args['paths']).trim();
            patch.paths = p ? p.split(',').map((x) => x.trim()).filter(Boolean) : [];
        }
        else if (Array.isArray(args['paths'])) {
            patch.paths = args['paths'].map((x) => String(x));
        }
        yield (0, notes_1.editMemory)(patch);
        yield nvim.executeLua(`local id = select(1, ...); vim.notify('Edited memory ' .. tostring(id), vim.log.levels.INFO, { title = 'kra-memory' })`, [id]);
        yield openMemoryBrowser(nvim, view);
    });
}
function handleSetMemoryStatus(nvim, args) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b;
        const id = String((_a = args['id']) !== null && _a !== void 0 ? _a : '').trim();
        const statusRaw = String((_b = args['status']) !== null && _b !== void 0 ? _b : '').trim();
        const view = parseView(args['view']);
        if (!id || (statusRaw !== 'resolved' && statusRaw !== 'dismissed' && statusRaw !== 'open')) {
            return;
        }
        const resolution = typeof args['resolution'] === 'string' ? (args['resolution']) : undefined;
        const updateInput = resolution !== undefined
            ? { id, status: statusRaw, resolution }
            : { id, status: statusRaw };
        yield (0, notes_1.updateMemory)(updateInput);
        yield openMemoryBrowser(nvim, view);
    });
}
