"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TURN_REMINDER = void 0;
/**
 * Cross-provider turn reminder. Inject after every user prompt (or as the
 * first hint of every assistant turn) to keep the agent disciplined about
 * calling `confirm_task_complete` before ending its turn.
 *
 * Lives in `shared/` so both Copilot and BYOK providers reference the same
 * string — no duplication, no drift.
 */
exports.TURN_REMINDER = 'REMINDER: Call confirm_task_complete before ending your turn — whether you are done, need clarification, or want to ask the user anything.';
