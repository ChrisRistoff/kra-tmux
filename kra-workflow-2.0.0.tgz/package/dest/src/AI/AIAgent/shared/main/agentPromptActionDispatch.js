"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.dispatchPromptAction = dispatchPromptAction;
const fileContext = __importStar(require("@/AI/shared/conversation"));
const agentSessionEvents_1 = require("@/AI/AIAgent/shared/utils/agentSessionEvents");
const agentMemoryActions_1 = require("@/AI/AIAgent/shared/main/agentMemoryActions");
function getErrorMessage(error) {
    if (error instanceof Error) {
        return error.message;
    }
    if (typeof error === 'string') {
        return error;
    }
    return 'Unknown error';
}
function dispatchPromptAction(state, action, args) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j;
        switch (action) {
            case 'add_file_context':
                yield fileContext.handleAddFileContext(state.nvim, state.chatFile, { agentMode: true });
                break;
            case 'stop_stream':
                yield state.session.abort();
                state.isStreaming = false;
                yield (0, agentSessionEvents_1.updateAgentUi)(state.nvim, 'stop_turn', ['Stopped current agent turn']);
                break;
            case 'show_contexts_popup':
                yield fileContext.showFileContextsPopup(state.nvim);
                break;
            case 'remove_file_context':
                yield fileContext.handleRemoveFileContext(state.nvim, state.chatFile, { agentMode: true });
                break;
            case 'clear_contexts':
                yield fileContext.clearAllFileContexts(state.nvim, state.chatFile, { agentMode: true });
                break;
            case 'review_proposal':
                yield (0, agentSessionEvents_1.showProposalReview)(state.nvim, state);
                break;
            case 'open_proposal_file':
                yield (0, agentSessionEvents_1.openChangedProposalFile)(state);
                break;
            case 'apply_proposal':
                yield (0, agentSessionEvents_1.applyProposal)(state);
                break;
            case 'reject_proposal':
                yield (0, agentSessionEvents_1.rejectCurrentProposal)(state);
                break;
            case 'toggle_yolo_mode':
                state.approvalMode = state.approvalMode === 'yolo' ? 'strict' : 'yolo';
                state.allowedToolFamilies.clear();
                yield (0, agentSessionEvents_1.updateAgentUi)(state.nvim, 'show_error', ['Approval mode', state.approvalMode === 'yolo' ? 'YOLO mode enabled.' : 'Strict approval mode enabled.']);
                break;
            case 'reset_tool_approvals':
                state.approvalMode = 'strict';
                state.allowedToolFamilies.clear();
                yield (0, agentSessionEvents_1.updateAgentUi)(state.nvim, 'show_error', ['Approval mode', 'Reset remembered approvals.']);
                break;
            case 'browse_memory': {
                const params = ((_a = args[1]) !== null && _a !== void 0 ? _a : {});
                const v = String((_b = params.view) !== null && _b !== void 0 ? _b : 'all');
                const view = v === 'findings' || v === 'revisits' ? v : 'all';
                yield (0, agentMemoryActions_1.openMemoryBrowser)(state.nvim, view);
                break;
            }
            case 'add_memory':
                yield (0, agentMemoryActions_1.handleAddMemory)(state.nvim, ((_c = args[1]) !== null && _c !== void 0 ? _c : {}));
                break;
            case 'delete_memory':
                yield (0, agentMemoryActions_1.handleDeleteMemory)(state.nvim, ((_d = args[1]) !== null && _d !== void 0 ? _d : {}));
                break;
            case 'edit_memory':
                yield (0, agentMemoryActions_1.handleEditMemory)(state.nvim, ((_e = args[1]) !== null && _e !== void 0 ? _e : {}));
                break;
            case 'set_memory_status':
                yield (0, agentMemoryActions_1.handleSetMemoryStatus)(state.nvim, ((_f = args[1]) !== null && _f !== void 0 ? _f : {}));
                break;
            case 'execute_tool': {
                const payload = ((_g = args[1]) !== null && _g !== void 0 ? _g : {});
                const title = String((_h = payload.title) !== null && _h !== void 0 ? _h : '');
                const argsJson = String((_j = payload.args_json) !== null && _j !== void 0 ? _j : '{}');
                if (!title) {
                    yield (0, agentSessionEvents_1.updateAgentUi)(state.nvim, 'show_tool_execution_result', ['', 'Missing tool title', '']);
                    break;
                }
                if (!state.session.executeTool) {
                    yield (0, agentSessionEvents_1.updateAgentUi)(state.nvim, 'show_tool_execution_result', ['', 'Tool re-execution not supported by current provider', title]);
                    break;
                }
                let parsedArgs;
                try {
                    parsedArgs = JSON.parse(argsJson);
                }
                catch (err) {
                    yield (0, agentSessionEvents_1.updateAgentUi)(state.nvim, 'show_tool_execution_result', ['', `Invalid JSON: ${getErrorMessage(err)}`, title]);
                    break;
                }
                try {
                    const result = yield state.session.executeTool(title, parsedArgs);
                    yield (0, agentSessionEvents_1.updateAgentUi)(state.nvim, 'show_tool_execution_result', [result, '', title]);
                }
                catch (err) {
                    yield (0, agentSessionEvents_1.updateAgentUi)(state.nvim, 'show_tool_execution_result', ['', getErrorMessage(err), title]);
                }
                break;
            }
            default:
                console.log('Unknown action:', action);
        }
    });
}
