"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.converseAgent = converseAgent;
const fs = __importStar(require("fs/promises"));
const bashHelper_1 = require("@/utils/bashHelper");
const agentHistory_1 = require("@/AI/AIAgent/shared/utils/agentHistory");
const serverConfig_1 = require("@/AI/AIAgent/mcp/serverConfig");
const conversation = __importStar(require("@/AI/shared/conversation"));
const agentToolHook_1 = require("@/AI/AIAgent/shared/utils/agentToolHook");
const agentIndexingFlow_1 = require("@/AI/AIAgent/shared/main/agentIndexingFlow");
const agentSessionEvents_1 = require("@/AI/AIAgent/shared/utils/agentSessionEvents");
const agentNeovimSetup_1 = require("@/AI/AIAgent/shared/main/agentNeovimSetup");
const agentPromptActions_1 = require("@/AI/AIAgent/shared/main/agentPromptActions");
const aiNeovimHelper = conversation;
const fileContext = conversation;
function cleanup(state) {
    return __awaiter(this, void 0, void 0, function* () {
        fileContext.clearFileContexts();
        yield (0, agentSessionEvents_1.updateAgentUi)(state.nvim, 'finish_turn');
        const changedCount = state.history.listChangedPaths().length;
        if (changedCount > 0) {
            console.log(`${changedCount} file(s) touched by agent (run rejectProposal to revert).`);
        }
        yield fs.rm(state.chatFile, { force: true });
        yield state.session.disconnect();
        yield state.client.stop();
        process.exit(0);
    });
}
function converseAgent(options) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c, _d;
        fileContext.clearFileContexts();
        const cwd = (yield (0, bashHelper_1.execCommand)('git rev-parse --show-toplevel')).stdout.trim();
        const history = (0, agentHistory_1.createAgentHistory)(cwd);
        const chatFile = `/tmp/kra-agent-chat-${Date.now()}.md`;
        yield (0, agentNeovimSetup_1.createAgentChatFile)(chatFile);
        const nvimClient = yield (0, agentNeovimSetup_1.openAgentNeovim)(chatFile);
        yield (0, agentIndexingFlow_1.runStartupIndexingFlow)(nvimClient, cwd);
        const mcpServers = yield (0, serverConfig_1.buildCoreMcpServers)();
        const stateRef = {};
        const mergedMcpServers = Object.assign(Object.assign({}, mcpServers), ((_a = options.additionalMcpServers) !== null && _a !== void 0 ? _a : {}));
        const session = yield options.client.createSession(Object.assign(Object.assign({ model: options.model, workingDirectory: cwd, mcpServers: mergedMcpServers, excludedTools: ['str_replace_editor', 'write_file', 'read_file', 'edit', 'view', 'grep', 'glob', 'create', 'apply_patch'] }, (options.contextWindow !== undefined ? { contextWindow: options.contextWindow } : {})), { onPreToolUse: (input) => __awaiter(this, void 0, void 0, function* () {
                if (!stateRef.current) {
                    return {
                        permissionDecision: 'deny',
                        permissionDecisionReason: 'Agent UI is not ready yet.',
                    };
                }
                try {
                    return yield (0, agentToolHook_1.handlePreToolUse)(stateRef.current, input);
                }
                catch (error) {
                    yield (0, agentSessionEvents_1.updateAgentUi)(stateRef.current.nvim, 'show_error', [
                        `Pre-tool approval failed: ${input.toolName}`,
                        (0, agentPromptActions_1.getErrorMessage)(error),
                    ]);
                    return {
                        permissionDecision: 'deny',
                        permissionDecisionReason: `Pre-tool approval failed: ${(0, agentPromptActions_1.getErrorMessage)(error)}`,
                    };
                }
            }), onPostToolUse: (input) => __awaiter(this, void 0, void 0, function* () {
                var _a;
                // Bash/shell output: errors and summaries land at the tail, so bias
                // toward keeping more of the end.  All other tools use a 50/50 split.
                const isBashLike = ['bash', 'shell', 'execute', 'run_terminal', 'computer'].some((fragment) => input.toolName.toLowerCase().includes(fragment));
                // Run bash post-snapshot if pre-snapshot was taken.
                if (isBashLike && ((_a = stateRef.current) === null || _a === void 0 ? void 0 : _a.pendingBashSnapshot)) {
                    const snapshot = stateRef.current.pendingBashSnapshot;
                    delete stateRef.current.pendingBashSnapshot;
                    yield stateRef.current.history.bashSnapshotAfter(snapshot).catch(() => { });
                }
                const HEAD_CHARS = isBashLike ? 2000 : 4000;
                const TAIL_CHARS = isBashLike ? 6000 : 4000;
                const text = input.toolResult.textResultForLlm;
                if (text.length <= HEAD_CHARS + TAIL_CHARS)
                    return {};
                const omitted = text.length - HEAD_CHARS - TAIL_CHARS;
                return {
                    modifiedResult: Object.assign(Object.assign({}, input.toolResult), { textResultForLlm: [
                            text.slice(0, HEAD_CHARS),
                            `\n…[${omitted} chars omitted]…\n`,
                            text.slice(text.length - TAIL_CHARS),
                        ].join('') }),
                };
            }), onUserInputRequest: (request) => __awaiter(this, void 0, void 0, function* () {
                var _a;
                return (0, agentToolHook_1.handleAgentUserInput)(nvimClient, request.question, request.choices, (_a = request.allowFreeform) !== null && _a !== void 0 ? _a : true);
            }), systemMessage: {
                mode: 'append',
                content: `<turn_completion priority="critical">
End every turn by calling \`confirm_task_complete\` with a concise summary and 2–4 concrete choices. This applies whether you finished, are blocked, need clarification, or are unsure what to do next. Never end a turn with plain text or without calling \`confirm_task_complete\` — the user relies on this signal to know when you are done and to respond appropriately.
</turn_completion>

<workspace>
You are in a detached proposal workspace. Edits land in the real repository only after the user reviews the resulting git diff in Neovim, so edit files freely.
</workspace>

<reading_code>
**Default to get_outline when you need a feel for a file. Only read raw lines once you know the exact range.**

Workflow:
  1. If you already know the exact range you need (e.g. from a previous outline, search hit, or LSP result) and it's ≤150 lines, call read_lines directly on that range.
  2. Otherwise call get_outline first to find the smallest range that contains what you need, then read_lines on that range.
  3. Small files (≤150 lines) you can just read whole — no outline step needed.

Hard rule: read_lines bounces any single call requesting >200 lines back to the outline, but only when the file has a meaningful outline (entries from the LSP or regex fallback). Truly unstructured files (txt, csv, log, plain markdown without headings, …) are never gated — read whatever range you need (subject to the 500-line hard cap). Don't try to bypass the gate on structured files with multiple calls — narrow your range instead.

**Why this matters:** Reading more than you need wastes tokens. The outline tells you exactly where to look, so use it to find the minimal range, then read only that range.

Reading data files (JSON/YAML/TOML/MD/.env/logs):
  - Use get_outline first to see line count and structure
  - Then read_lines on a targeted range, not the whole file

Searching:
  Use \`kra-file-context:search\` (replaces grep/glob, both disabled).
  Use \`name_pattern\` (glob) for file names, \`content_pattern\` (regex) for content.
  Results show line count — use that to decide if you need get_outline before read_lines.
</reading_code>

<surgical_edits>
**Goal: Edit ONLY the lines that must change. Do not rewrite surrounding context.**

Workflow:
  1. Call get_outline to find what you need
  2. Call read_lines on the EXACT range containing your change
  ⚠ You MUST read the target lines before editing — the tool rejects edits without a prior read.
  3. read_lines prefixes every line like \`  142: code here\` — use those numbers directly as startLine/endLine
  4. Call edit_lines with startLine and endLine as tight as possible

**Before calling edit_lines — declare your ranges:**
Output \`Editing: L14-15, L88-88, L142-145\`. **Every line in each range must change** — if a line is only there to preserve context, remove it from the range entirely (the tool keeps untouched lines automatically). If any range spans a whole function but only 1-2 lines change inside it, split into tight sub-ranges.


Critical rule: Every line between startLine and endLine will be REPLACED with your newContent.
  - If you read lines 100–180 and need to change only lines 142–145, call edit_lines with startLine:142 endLine:145
  - Do NOT include unchanged lines 100–141 and 146–180 in your newContent
  - If only line 88 changes, use startLine:88 endLine:88 (single-line range: 88–88)
  - Do NOT pass the whole 100-line range just because you read it
  - Do NOT use any other tool except edit_lines to change code in a file

For multiple changes in the same file:
  - Use the multi-edit array form with several tight ranges
  - Example: lines 12–12, lines 47–49, lines 88–88 all in one call
  - Do NOT combine them into a single large range

**Why this matters:** Every line in the range is replaced verbatim. Stale surrounding context silently overwrites newer code you didn't intend to change.
</surgical_edits>

<creating_files>
Use \`create_file\` for new files only. It refuses if the file already exists. For existing files, use edit_lines.
</creating_files>

<long_term_memory priority="high">
Long-term memory (kra-memory) is your persistent vector store across sessions. It is split into TWO physical tables, and you MUST pass the correct \`kind\` on every call — there is no implicit cross-table query.

**Findings table** — \`kind\` ∈ { \`note\`, \`bug-fix\`, \`gotcha\`, \`decision\`, \`investigation\` }
Things YOU discover while working that a future session will want to know. Status is irrelevant.
  - \`bug-fix\`     — root cause + fix you found for a non-obvious bug
  - \`gotcha\`      — repo-specific trap, surprising behavior, hidden coupling
  - \`decision\`    — design choice + the rationale ("we picked X over Y because…")
  - \`investigation\` — result of digging through code/docs to answer a question
  - \`note\`        — anything else worth preserving that doesn't fit above

**Revisits table** — \`kind\` = \`revisit\` only
Ideas discussed and intentionally deferred, awaiting human input. Have status \`open\` / \`resolved\` / \`dismissed\`. Update via \`update_memory\` (revisits only).

**When to write (be proactive, not stingy):**
- After fixing a non-obvious bug → \`remember({ kind: 'bug-fix', … })\`
- After hitting a gotcha that cost you time → \`remember({ kind: 'gotcha', … })\`
- After making a design decision a future session would re-derive → \`remember({ kind: 'decision', … })\`
- After non-trivial investigation whose result is reusable → \`remember({ kind: 'investigation', … })\`
- When the user defers an idea → \`remember({ kind: 'revisit', … })\`
Include enough detail in \`body\` that a future session can act without re-investigating. Always set \`paths\` when relevant.

**Discovery-first rule:**
- For any new non-trivial bug, feature, investigation, or unfamiliar request, start with \`semantic_search({ query: <problem>, scope: 'both', memoryKind: 'findings' })\`.
- Skip that kickoff only when the user already gave an exact file, exact symbol, exact path, or literal string, or when the task is a tiny local edit.
- Do **not** start with \`kra-file-context:search\` for a new conceptual problem. Use \`search\` for exact symbol/string/path lookups; use \`semantic_search\` for questions like "where does this happen?", "what handles this?", or "what code path matches this behavior?".
- Do one broad semantic pass first. If it returns weak or noisy results, move on to targeted \`search\` / \`lsp_query\` instead of repeating broad semantic queries.

**When to read memory:**
- \`recall({ kind, query?, tagsAny?, status? })\` — \`kind\` is **required**. Use \`kind: 'findings'\` for long-term memories, \`kind: 'revisit'\` for parked discussions, or a specific finding kind to narrow the findings table. With \`query\`, it runs vector search. Without \`query\`, it uses list mode (newest first).
- Use \`recall\` mainly for listing/filtering or revisits — not as the first step for conceptual discovery when \`semantic_search\` fits.

**\`semantic_search\` — conceptual search across the codebase (and optionally memory):**
- \`semantic_search({ query, scope?, memoryKind?, pathGlob?, k? })\`
- \`scope\` is \`code\` (default), \`memory\`, or \`both\`. When \`scope\` includes memory, pass \`memoryKind: 'findings'\` for long-term memories, \`memoryKind: 'revisit'\` for parked discussions, or a specific finding kind to narrow the findings table.
- Prefer it as the **first-step discovery tool** for unfamiliar codebase questions and prior-memory retrieval.

**Editing & lifecycle:**
- \`edit_memory({ id, title?, body?, tags?, paths? })\` — refine an existing entry in place. Re-embeds the vector when \`title\` or \`body\` changes. Use this instead of creating a near-duplicate.
- \`update_memory({ id, status, resolution? })\` — close out a revisit (\`resolved\` or \`dismissed\`) once acted on.
</long_term_memory>

Reminder: Always call confirm_task_complete before ending your turn.`,
            } }));
        const state = {
            chatFile,
            model: options.model,
            client: options.client,
            session,
            nvim: nvimClient,
            cwd,
            history,
            isStreaming: false,
            approvalMode: 'strict',
            allowedToolFamilies: new Set(),
        };
        stateRef.current = state;
        const channelId = yield nvimClient.channelId;
        try {
            yield aiNeovimHelper.addNeovimFunctions(nvimClient, channelId);
            yield aiNeovimHelper.addCommands(nvimClient);
            yield aiNeovimHelper.setupKeyBindings(nvimClient);
            yield (0, agentNeovimSetup_1.addAgentFunctions)(nvimClient, channelId);
            yield (0, agentNeovimSetup_1.addAgentCommands)(nvimClient);
            yield nvimClient.command(`edit ${chatFile}`);
            // Enable fold markers for the tool-call log blocks (uses default {{{/}}} markers).
            // foldlevel=99 keeps all folds open by default; user can fold with zc/za.
            yield nvimClient.command('setlocal foldmethod=marker foldlevel=99');
            yield (0, agentNeovimSetup_1.setupAgentSplitLayout)(nvimClient, channelId);
            yield (0, agentNeovimSetup_1.refreshAgentLayout)(nvimClient);
            yield (0, agentNeovimSetup_1.focusAgentPrompt)(nvimClient);
            yield (0, agentSessionEvents_1.setupSessionEventHandlers)(state);
            yield (0, agentPromptActions_1.setupEventHandlers)(state);
            const executableTools = (_d = (_c = (_b = state.session).listExecutableTools) === null || _c === void 0 ? void 0 : _c.call(_b)) !== null && _d !== void 0 ? _d : [];
            yield (0, agentSessionEvents_1.updateAgentUi)(nvimClient, 'set_executable_tools', [executableTools]);
            let cleaningUp = false;
            const runCleanup = () => {
                if (cleaningUp)
                    return;
                cleaningUp = true;
                cleanup(state).catch(() => process.exit(1));
            };
            nvimClient.on('disconnect', runCleanup);
            process.once('SIGINT', runCleanup);
            process.once('SIGTERM', runCleanup);
        }
        catch (error) {
            yield cleanup(state);
            throw error;
        }
    });
}
