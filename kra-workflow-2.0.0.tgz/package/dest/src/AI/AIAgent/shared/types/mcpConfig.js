"use strict";
/**
 * Local MCP server config — replaces `MCPServerConfig` from `@github/copilot-sdk`
 * so `shared/` has no SDK dependency. Mirrors the SDK shape.
 */
Object.defineProperty(exports, "__esModule", { value: true });
