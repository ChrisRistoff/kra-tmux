"use strict";
/**
 * Shared file-safety utilities used by the file-context MCP server and the
 * agent tool-hook layer. Centralises:
 *   - atomic writes (temp file in same dir + rename)
 *   - binary-file detection (refuse to dump non-text into the agent context)
 *   - per-call line caps for read_lines
 *   - unified-diff patch parsing and application
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MAX_LINES_PER_CALL = void 0;
exports.looksBinary = looksBinary;
exports.isBinaryFile = isBinaryFile;
exports.atomicWriteFile = atomicWriteFile;
const fs = __importStar(require("fs/promises"));
const path_1 = __importDefault(require("path"));
// Cap how many lines a single read_lines call may return. A buggy `end: 999999`
// would otherwise dump the entire file and defeat the whole point of the
// outline-based workflow.
exports.MAX_LINES_PER_CALL = 500;
// First-N-bytes binary heuristic. A NUL byte in the first 8 KiB is a strong
// signal that the file is not utf-8 source code.
const BINARY_PROBE_BYTES = 8000;
function looksBinary(buf) {
    const limit = Math.min(buf.length, BINARY_PROBE_BYTES);
    for (let i = 0; i < limit; i++) {
        if (buf[i] === 0)
            return true;
    }
    return false;
}
function isBinaryFile(filePath) {
    return __awaiter(this, void 0, void 0, function* () {
        const fh = yield fs.open(filePath, 'r');
        try {
            const buf = Buffer.alloc(BINARY_PROBE_BYTES);
            const { bytesRead } = yield fh.read(buf, 0, BINARY_PROBE_BYTES, 0);
            return looksBinary(buf.subarray(0, bytesRead));
        }
        finally {
            yield fh.close();
        }
    });
}
// Atomic write: stage to a sibling temp file, then rename. fs.rename is atomic
// on POSIX within the same filesystem, so a crash mid-write never leaves a
// half-written destination.
function atomicWriteFile(filePath, content) {
    return __awaiter(this, void 0, void 0, function* () {
        const dir = path_1.default.dirname(filePath);
        yield fs.mkdir(dir, { recursive: true });
        const base = path_1.default.basename(filePath);
        const suffix = `${process.pid}-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
        const tmp = path_1.default.join(dir, `.${base}.kra-tmp-${suffix}`);
        try {
            yield fs.writeFile(tmp, content, 'utf8');
            yield fs.rename(tmp, filePath);
        }
        catch (err) {
            try {
                yield fs.unlink(tmp);
            }
            catch ( /* tmp may not exist */_a) { /* tmp may not exist */ }
            throw err;
        }
    });
}
