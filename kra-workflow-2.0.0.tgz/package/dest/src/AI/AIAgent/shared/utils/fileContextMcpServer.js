#!/usr/bin/env node
"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Stdio MCP server exposing file-context tools for the agent:
 *
 *   lsp_query(file_path, op, ...)        — LSP-backed hover / definition / etc.
 *   search(name_pattern?, content_pattern?, ...) — ripgrep wrapper
 *   get_outline(file_path)               — list functions/classes + line numbers
 *   read_lines(file_path, start, end)    — return a specific line range (1-indexed)
 *   read_function(file_path, name)       — return the body of a named symbol
 *   edit_lines(file_path, ...)           — replace one or more line ranges
 *   create_file(file_path, content)      — create a NEW file (refuses if exists)
 *
 * The agent is directed to use these tools instead of the built-in
 * str_replace_editor, write_file, and read_file tools (which are excluded
 * from the session).
 *
 * Run directly:
 *   node dest/src/AI/AIAgent/shared/utils/fileContextMcpServer.js
 *
 * Implementation note: this file is intentionally a thin JSON-RPC adapter.
 * All tool logic lives in `../fileContext/` so each handler can be tested
 * (and edited) in isolation. Mirrors the layout of `memoryMcpServer.ts` +
 * `shared/memory/`.
 */
require("module-alias/register");
const stdioServer_1 = require("../../mcp/stdioServer");
const dispatch_1 = require("../fileContext/dispatch");
const tools_1 = require("../fileContext/tools");
const fileContext_1 = require("../fileContext");
// Belt-and-suspenders: never let an unhandled error from a spawned LSP child
// (or any other async chain) tear down the MCP server. Without these, a single
// unhandled rejection or uncaught exception kills the stdio server with no
// chance for the parent CLI to reconnect, leaving the agent without file tools.
process.on('uncaughtException', (err) => {
    var _a;
    process.stderr.write(`[mcp] uncaughtException: ${err instanceof Error ? (_a = err.stack) !== null && _a !== void 0 ? _a : err.message : String(err)}\n`);
});
process.on('unhandledRejection', (reason) => {
    var _a;
    process.stderr.write(`[mcp] unhandledRejection: ${reason instanceof Error ? (_a = reason.stack) !== null && _a !== void 0 ? _a : reason.message : String(reason)}\n`);
});
(0, stdioServer_1.runStdioMcpServer)({
    serverName: 'kra-file-context',
    tools: tools_1.TOOLS,
    allowPing: true,
    respondParseError: false,
    handleToolCall: (_a) => __awaiter(void 0, [_a], void 0, function* ({ toolName, params }) {
        const toolArgs = (0, fileContext_1.getArgs)(params);
        try {
            return yield (0, dispatch_1.dispatchFileContextTool)(toolName, toolArgs);
        }
        catch (err) {
            return (0, fileContext_1.errorContent)(String(err));
        }
    }),
    onInternalError: (error) => ({
        kind: 'result',
        result: (0, fileContext_1.errorContent)(String(error)),
    }),
});
