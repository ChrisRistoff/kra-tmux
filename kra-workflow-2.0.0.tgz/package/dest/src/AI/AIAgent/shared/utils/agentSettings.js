"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getGithubToken = getGithubToken;
exports.getAgentDefaultModel = getAgentDefaultModel;
exports.getConfiguredMcpServers = getConfiguredMcpServers;
const common_1 = require("@/utils/common");
function getGithubToken() {
    var _a, _b;
    return (_b = (_a = process.env.GITHUB_TOKEN) !== null && _a !== void 0 ? _a : process.env.GH_TOKEN) !== null && _b !== void 0 ? _b : process.env.GITHUB_API;
}
function isRemoteServer(server) {
    return server.type === 'http' || server.type === 'sse';
}
function mapServerConfig(server) {
    if (isRemoteServer(server)) {
        const remoteConfig = {
            type: server.type,
            url: server.url,
            tools: server.tools,
        };
        if (server.headers) {
            remoteConfig.headers = server.headers;
        }
        if (typeof server.timeoutMs === 'number') {
            remoteConfig.timeout = server.timeoutMs;
        }
        return remoteConfig;
    }
    const localConfig = {
        type: server.type,
        command: server.command,
        args: server.args,
        tools: server.tools,
    };
    if (server.env) {
        localConfig.env = server.env;
    }
    if (server.cwd) {
        localConfig.cwd = server.cwd;
    }
    if (typeof server.timeoutMs === 'number') {
        localConfig.timeout = server.timeoutMs;
    }
    return localConfig;
}
function getAgentDefaultModel() {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b;
        const settings = yield (0, common_1.loadSettings)();
        return (_b = (_a = settings.ai) === null || _a === void 0 ? void 0 : _a.agent) === null || _b === void 0 ? void 0 : _b.defaultModel;
    });
}
function getConfiguredMcpServers() {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c;
        const settings = yield (0, common_1.loadSettings)();
        const configuredServers = (_c = (_b = (_a = settings.ai) === null || _a === void 0 ? void 0 : _a.agent) === null || _b === void 0 ? void 0 : _b.mcpServers) !== null && _c !== void 0 ? _c : {};
        return Object.entries(configuredServers).reduce((servers, [name, server]) => {
            if (!server.active) {
                return servers;
            }
            servers[name] = mapServerConfig(server);
            return servers;
        }, {});
    });
}
