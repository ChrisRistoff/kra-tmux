#!/usr/bin/env node
"use strict";
/**
 * kra-web MCP server — exposes `web_fetch` and `web_search` to BYOK agents.
 *
 * Mirrors the JSON-RPC stdio pattern used by bashMcpServer.ts so we have no
 * extra runtime dependency. Uses Node 18+ built-in `fetch`.
 *
 *   web_fetch(url, max_length?)        → fetches a URL and returns text
 *                                        (HTML stripped to plain text).
 *   web_search(query, max_results?)    → scrapes DuckDuckGo's HTML endpoint
 *                                        and returns a markdown list of hits.
 *
 * DuckDuckGo's HTML endpoint (https://html.duckduckgo.com/html/) is more
 * lenient than the JSON instant-answer API used by `duck-duck-scrape`, but it
 * can still rate-limit. We send a realistic browser User-Agent to reduce that.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const cheerio = __importStar(require("cheerio"));
const html_to_text_1 = require("html-to-text");
const stdioServer_1 = require("../../mcp/stdioServer");
const DEFAULT_MAX_LENGTH = 8000;
const HARD_MAX_LENGTH = 50000;
const DEFAULT_MAX_RESULTS = 5;
const HARD_MAX_RESULTS = 15;
const FETCH_TIMEOUT_MS = 20000;
const USER_AGENT = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 ' +
    '(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';
const WEB_FETCH_TOOL = {
    name: 'web_fetch',
    description: [
        'Fetch a URL over HTTPS/HTTP and return the response body as text.',
        'HTML responses are stripped of nav/footer/scripts/styles so the model',
        `sees mostly main content. Default cap ${DEFAULT_MAX_LENGTH} chars (hard cap ${HARD_MAX_LENGTH});`,
        'increase max_length only when you need more.',
    ].join(' '),
    inputSchema: {
        type: 'object',
        properties: {
            url: {
                type: 'string',
                description: 'Absolute URL to fetch (http or https).',
            },
            max_length: {
                type: 'number',
                description: `Maximum number of characters to return. Default ${DEFAULT_MAX_LENGTH}, hard cap ${HARD_MAX_LENGTH}.`,
            },
        },
        required: ['url'],
    },
};
const WEB_SEARCH_TOOL = {
    name: 'web_search',
    description: [
        'Run a web search via DuckDuckGo and return a ranked list of results',
        '(title, URL, snippet) as markdown. Best for finding pages to follow up',
        'on with `web_fetch`. May rate-limit if called repeatedly in quick',
        'succession.',
    ].join(' '),
    inputSchema: {
        type: 'object',
        properties: {
            query: {
                type: 'string',
                description: 'Search query string.',
            },
            max_results: {
                type: 'number',
                description: `Maximum number of results to return. Default ${DEFAULT_MAX_RESULTS}, hard cap ${HARD_MAX_RESULTS}.`,
            },
        },
        required: ['query'],
    },
};
function htmlToText(html) {
    return (0, html_to_text_1.convert)(html, {
        wordwrap: false,
        selectors: [
            { selector: 'a', options: { ignoreHref: true } },
            { selector: 'img', format: 'skip' },
            { selector: 'script', format: 'skip' },
            { selector: 'style', format: 'skip' },
            { selector: 'noscript', format: 'skip' },
        ],
    });
}
const CHROME_SELECTORS = [
    'nav',
    'footer',
    'header',
    'aside',
    'form',
    'button',
    'svg',
    '[role="navigation"]',
    '[role="banner"]',
    '[role="contentinfo"]',
    '[role="search"]',
    '[role="complementary"]',
    '[aria-hidden="true"]',
    '.nav',
    '.navbar',
    '.menu',
    '.sidebar',
    '.header',
    '.footer',
    '.cookie',
    '.cookies',
    '.consent',
    '.advertisement',
    '.ads',
    '.ad',
    '.banner',
    '.breadcrumb',
    '.breadcrumbs',
    '.social',
    '.share',
    '.newsletter',
    '.subscribe',
    '.related',
    '.recommended',
    '.popup',
    '.modal',
    '.toolbar',
    '#nav',
    '#header',
    '#footer',
    '#sidebar',
    '#menu',
].join(', ');
function extractMainContent(html) {
    var _a;
    const $ = cheerio.load(html);
    $(CHROME_SELECTORS).remove();
    const main = $('main, article, [role="main"], #main, #content, .content, .main').first();
    const root = main.length > 0 ? main : $('body');
    return (_a = root.html()) !== null && _a !== void 0 ? _a : html;
}
function fetchWithTimeout(url, init) {
    return __awaiter(this, void 0, void 0, function* () {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
        try {
            return yield fetch(url, Object.assign(Object.assign({}, init), { signal: controller.signal }));
        }
        finally {
            clearTimeout(timer);
        }
    });
}
function runWebFetch(args) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b;
        if (!/^https?:\/\//i.test(args.url)) {
            return { output: `Invalid URL (must be http/https): ${args.url}`, isError: true };
        }
        const maxLength = Math.min((_a = args.max_length) !== null && _a !== void 0 ? _a : DEFAULT_MAX_LENGTH, HARD_MAX_LENGTH);
        try {
            const response = yield fetchWithTimeout(args.url, {
                redirect: 'follow',
                headers: {
                    'User-Agent': USER_AGENT,
                    Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                },
            });
            const contentType = (_b = response.headers.get('content-type')) !== null && _b !== void 0 ? _b : '';
            const raw = yield response.text();
            const body = contentType.includes('html') ? htmlToText(extractMainContent(raw)) : raw;
            const truncated = body.length > maxLength;
            const output = [
                `URL: ${response.url}`,
                `Status: ${response.status} ${response.statusText}`,
                `Content-Type: ${contentType || '(unknown)'}`,
                truncated ? `Truncated: showing first ${maxLength} of ${body.length} chars` : '',
                '',
                body.slice(0, maxLength),
            ]
                .filter(Boolean)
                .join('\n');
            return { output, isError: !response.ok };
        }
        catch (error) {
            const message = error instanceof Error ? error.message : String(error);
            return { output: `Fetch failed: ${message}`, isError: true };
        }
    });
}
function parseDuckDuckGoHtml(html, limit) {
    const $ = cheerio.load(html);
    const results = [];
    $('div.result, div.web-result, .results_links').each((_, el) => {
        var _a;
        if (results.length >= limit) {
            return false;
        }
        const $el = $(el);
        const $a = $el.find('a.result__a').first();
        const title = $a.text().trim();
        let url = ((_a = $a.attr('href')) !== null && _a !== void 0 ? _a : '').trim();
        const snippet = $el.find('.result__snippet').text().trim();
        const redirectMatch = /[?&]uddg=([^&]+)/.exec(url);
        if (redirectMatch === null || redirectMatch === void 0 ? void 0 : redirectMatch[1]) {
            try {
                url = decodeURIComponent(redirectMatch[1]);
            }
            catch (_b) {
                // keep original
            }
        }
        if (url.startsWith('//')) {
            url = 'https:' + url;
        }
        if (!url || !title) {
            return;
        }
        results.push({ title, url, snippet });
        return;
    });
    return results;
}
function formatResults(query, results) {
    if (results.length === 0) {
        return `No results found for: ${query}`;
    }
    const lines = [`Search results for: ${query}`, ''];
    results.forEach((r, i) => {
        lines.push(`${i + 1}. ${r.title}`);
        lines.push(`   ${r.url}`);
        if (r.snippet) {
            lines.push(`   ${r.snippet}`);
        }
        lines.push('');
    });
    return lines.join('\n').trim();
}
function runWebSearch(args) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        const query = args.query.trim();
        if (!query) {
            return { output: 'Missing required argument: query', isError: true };
        }
        const limit = Math.min((_a = args.max_results) !== null && _a !== void 0 ? _a : DEFAULT_MAX_RESULTS, HARD_MAX_RESULTS);
        try {
            const body = new URLSearchParams({ q: query, kl: 'wt-wt' }).toString();
            const response = yield fetchWithTimeout('https://html.duckduckgo.com/html/', {
                method: 'POST',
                redirect: 'follow',
                headers: {
                    'User-Agent': USER_AGENT,
                    'Content-Type': 'application/x-www-form-urlencoded',
                    Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'en-US,en;q=0.9',
                },
                body,
            });
            if (!response.ok) {
                return {
                    output: `Search request failed: HTTP ${response.status} ${response.statusText}`,
                    isError: true,
                };
            }
            const html = yield response.text();
            if (/anomaly|unusual traffic|blocked/i.test(html) && !/result__a/i.test(html)) {
                return {
                    output: 'DuckDuckGo rate-limited the request. Retry in a minute, or fall back to ' +
                        '`bash` + curl on a specific URL via `web_fetch`.',
                    isError: true,
                };
            }
            const results = parseDuckDuckGoHtml(html, limit);
            return { output: formatResults(query, results), isError: false };
        }
        catch (error) {
            const message = error instanceof Error ? error.message : String(error);
            return { output: `Search failed: ${message}`, isError: true };
        }
    });
}
const TOOLS = [WEB_FETCH_TOOL, WEB_SEARCH_TOOL];
(0, stdioServer_1.runStdioMcpServer)({
    serverName: 'kra-web',
    tools: TOOLS,
    handleToolCall: (_a) => __awaiter(void 0, [_a], void 0, function* ({ toolName, params }) {
        const callParams = (params !== null && params !== void 0 ? params : {});
        const rawArgs = callParams.arguments;
        const args = (typeof rawArgs === 'object' && rawArgs !== null ? rawArgs : {});
        if (toolName === 'web_fetch') {
            if (typeof args.url !== 'string') {
                throw new stdioServer_1.JsonRpcToolError(-32602, 'Missing required argument: url');
            }
            const { output, isError } = yield runWebFetch(Object.assign({ url: args.url }, (args.max_length !== undefined ? { max_length: args.max_length } : {})));
            return {
                content: [{ type: 'text', text: output }],
                isError,
            };
        }
        if (toolName === 'web_search') {
            if (typeof args.query !== 'string') {
                throw new stdioServer_1.JsonRpcToolError(-32602, 'Missing required argument: query');
            }
            const { output, isError } = yield runWebSearch(Object.assign({ query: args.query }, (args.max_results !== undefined ? { max_results: args.max_results } : {})));
            return {
                content: [{ type: 'text', text: output }],
                isError,
            };
        }
        throw new stdioServer_1.JsonRpcToolError(-32601, `Unknown tool: ${toolName || '(none)'}`);
    }),
});
