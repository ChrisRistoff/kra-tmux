#!/usr/bin/env node
"use strict";
/**
 * kra-bash MCP server — exposes a single `bash` tool to BYOK agents.
 *
 * Mirrors the JSON-RPC stdio pattern used by sessionCompleteMcpServer.ts so we
 * have no extra runtime dependency. Commands run in `process.env.WORKING_DIR`
 * (set by the spawning provider) so the agent stays inside its proposal
 * workspace.
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const child_process_1 = require("child_process");
const stdioServer_1 = require("../../mcp/stdioServer");
const TOOL_DEFINITION = {
    name: 'bash',
    description: [
        'Execute a shell command and return its combined stdout/stderr.',
        'Runs in the agent working directory with a 120s default timeout and 10MB output cap.',
        'Output longer than ~8000 chars is truncated to first 2000 + last 6000 chars (middle elided).',
        'Use this for builds, tests, linting, file inspection, git, etc.',
    ].join(' '),
    inputSchema: {
        type: 'object',
        properties: {
            command: {
                type: 'string',
                description: 'Shell command to execute (interpreted by /bin/sh -c).',
            },
            timeoutMs: {
                type: 'number',
                description: 'Optional timeout override in milliseconds. Defaults to 120000.',
            },
        },
        required: ['command'],
    },
};
const DEFAULT_TIMEOUT_MS = 120000;
const MAX_BUFFER = 10 * 1024 * 1024;
const HEAD_KEEP = 2000;
const TAIL_KEEP = 6000;
function truncateMiddle(text) {
    if (text.length <= HEAD_KEEP + TAIL_KEEP) {
        return text;
    }
    const droppedChars = text.length - HEAD_KEEP - TAIL_KEEP;
    const head = text.slice(0, HEAD_KEEP);
    const tail = text.slice(text.length - TAIL_KEEP);
    return `${head}\n\n... [truncated ${droppedChars} chars from middle] ...\n\n${tail}`;
}
function runBash(args) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b;
        const cwd = (_a = process.env['WORKING_DIR']) !== null && _a !== void 0 ? _a : process.cwd();
        const timeout = (_b = args.timeoutMs) !== null && _b !== void 0 ? _b : DEFAULT_TIMEOUT_MS;
        return new Promise((resolve) => {
            (0, child_process_1.exec)(args.command, { cwd, timeout, maxBuffer: MAX_BUFFER, shell: '/bin/sh' }, (error, stdout, stderr) => {
                var _a;
                const output = [
                    stdout ? `stdout:\n${truncateMiddle(stdout)}` : '',
                    stderr ? `stderr:\n${truncateMiddle(stderr)}` : '',
                    error ? `exit: ${(_a = error.code) !== null && _a !== void 0 ? _a : 'error'} — ${error.message}` : '',
                ]
                    .filter(Boolean)
                    .join('\n\n') || '(no output)';
                resolve({ output, isError: Boolean(error) });
            });
        });
    });
}
(0, stdioServer_1.runStdioMcpServer)({
    serverName: 'kra-bash',
    tools: [TOOL_DEFINITION],
    handleToolCall: (_a) => __awaiter(void 0, [_a], void 0, function* ({ params }) {
        const rawArgs = params.arguments;
        const args = (rawArgs !== null && rawArgs !== void 0 ? rawArgs : {});
        if (typeof args.command !== 'string') {
            throw new stdioServer_1.JsonRpcToolError(-32602, 'Missing required argument: command');
        }
        const { output, isError } = yield runBash(Object.assign({ command: args.command }, (typeof args.timeoutMs === 'number' ? { timeoutMs: args.timeoutMs } : {})));
        return {
            content: [{ type: 'text', text: output }],
            isError,
        };
    }),
});
