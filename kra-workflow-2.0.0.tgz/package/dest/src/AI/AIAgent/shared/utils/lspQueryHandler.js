"use strict";
/**
 * Handler for the `lsp_query` MCP tool.
 *
 * Dispatches one of a small set of LSP requests (hover, definition,
 * references, implementation, type_definition, document_symbols) at a target
 * position in a file. The position can be given directly as (line, col) or
 * resolved by scanning a line for an occurrence of `symbol`.
 *
 * Results are formatted as plain text — short locations, hover markdown, or
 * a flattened symbol tree — so the agent can read them directly without an
 * extra parsing step.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.isValidOp = isValidOp;
exports.runLspQuery = runLspQuery;
const path = __importStar(require("path"));
const lspRegistry_1 = require("./lspRegistry");
const lspClient_1 = require("./lspClient");
const node_js_1 = require("vscode-languageserver-protocol/node.js");
const OPS = new Set([
    'hover', 'definition', 'references', 'implementation', 'type_definition', 'document_symbols',
]);
function isValidOp(op) {
    return typeof op === 'string' && OPS.has(op);
}
const KIND_NAME = Object.fromEntries(Object.entries(node_js_1.SymbolKind).map(([name, num]) => [num, name]));
function symbolKindName(kind) {
    var _a;
    return (_a = KIND_NAME[kind]) !== null && _a !== void 0 ? _a : `Kind(${kind})`;
}
function fmtRange(r) {
    return `${r.start.line + 1}:${r.start.character + 1}`;
}
function fmtLocation(loc) {
    return `${(0, lspClient_1.uriToPath)(loc.uri)}:${fmtRange(loc.range)}`;
}
function fmtLocationLink(link) {
    var _a;
    return `${(0, lspClient_1.uriToPath)(link.targetUri)}:${fmtRange((_a = link.targetSelectionRange) !== null && _a !== void 0 ? _a : link.targetRange)}`;
}
function fmtLocations(result) {
    if (!result)
        return '(no results)';
    const list = Array.isArray(result) ? result : [result];
    if (list.length === 0)
        return '(no results)';
    return list.map(item => {
        if ('targetUri' in item)
            return fmtLocationLink(item);
        return fmtLocation(item);
    }).join('\n');
}
function fmtHoverContents(content) {
    if (Array.isArray(content)) {
        return content.map(c => typeof c === 'string' ? c : c.value).join('\n\n');
    }
    if (typeof content === 'string')
        return content;
    if (content.kind !== undefined)
        return content.value;
    return content.value;
}
function flattenDocumentSymbols(symbols, depth = 0, out = []) {
    for (const s of symbols) {
        const indent = '  '.repeat(depth);
        out.push(`${indent}${symbolKindName(s.kind)} ${s.name}  ${fmtRange(s.range)}`);
        if (s.children && s.children.length > 0) {
            flattenDocumentSymbols(s.children, depth + 1, out);
        }
    }
    return out;
}
function fmtSymbolInformation(items) {
    return items.map(s => `${symbolKindName(s.kind)} ${s.name}  ${fmtLocation(s.location)}`).join('\n');
}
function isDocumentSymbolArray(value) {
    return Array.isArray(value) && (value.length === 0 || (value[0] !== null && typeof value[0] === 'object' && 'range' in value[0]));
}
function resolvePosition(args, openText) {
    var _a, _b;
    const lineNum = typeof args.line === 'number' ? args.line : undefined;
    if (lineNum === undefined || lineNum < 1) {
        return { error: 'line is required (1-indexed) for this op' };
    }
    const lineIndex = lineNum - 1;
    if (typeof args.col === 'number' && args.col >= 1) {
        return { line: lineIndex, character: args.col - 1 };
    }
    if (typeof args.symbol === 'string' && args.symbol.length > 0) {
        if (!openText)
            return { error: 'cannot resolve symbol: file content unavailable' };
        const lines = openText.split('\n');
        if (lineIndex >= lines.length)
            return { error: `line ${lineNum} is past end of file (${lines.length} lines)` };
        const text = (_a = lines[lineIndex]) !== null && _a !== void 0 ? _a : '';
        const occurrence = Math.max(1, (_b = args.occurrence) !== null && _b !== void 0 ? _b : 1);
        let from = 0;
        let found = -1;
        for (let i = 0; i < occurrence; i++) {
            found = text.indexOf(args.symbol, from);
            if (found < 0)
                return { error: `symbol "${args.symbol}" not found on line ${lineNum} (occurrence ${occurrence})` };
            from = found + args.symbol.length;
        }
        return { line: lineIndex, character: found };
    }
    return { error: 'must supply col or symbol' };
}
/**
 * Run an LSP op and return a plain-text payload suitable for the MCP
 * `text` content block.
 */
function runLspQuery(args) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        if (!args.file_path || typeof args.file_path !== 'string') {
            return 'Error: file_path is required.';
        }
        if (!isValidOp(args.op)) {
            return `Error: op must be one of: ${Array.from(OPS).join(', ')}`;
        }
        const absPath = path.resolve(args.file_path);
        const registry = yield (0, lspRegistry_1.getLspRegistry)();
        if (!registry.hasServerFor(absPath)) {
            const exts = registry.listConfiguredExtensions();
            const ext = path.extname(absPath).toLowerCase();
            const hint = exts.length > 0
                ? `Configured: ${exts.join(', ')}.`
                : 'No LSP servers configured under [lsp.*] in settings.toml.';
            return `No LSP server is configured for ${ext || '(no extension)'}. ${hint}`;
        }
        let client;
        try {
            client = yield registry.getClientFor(absPath);
        }
        catch (err) {
            return `Failed to start LSP server: ${err instanceof Error ? err.message : String(err)}`;
        }
        if (!client)
            return 'No LSP server matched this file.';
        try {
            yield client.openFile(absPath);
        }
        catch (err) {
            return `Failed to open ${absPath} in LSP: ${err instanceof Error ? err.message : String(err)}`;
        }
        const uri = (0, lspClient_1.fileUri)(absPath);
        if (args.op === 'document_symbols') {
            try {
                const result = yield client.sendRequest(node_js_1.DocumentSymbolRequest.type, { textDocument: { uri } });
                if (!result || (Array.isArray(result) && result.length === 0))
                    return '(no symbols)';
                if (isDocumentSymbolArray(result))
                    return flattenDocumentSymbols(result).join('\n');
                return fmtSymbolInformation(result);
            }
            catch (err) {
                return `LSP document_symbols failed: ${err instanceof Error ? err.message : String(err)}`;
            }
        }
        const pos = resolvePosition(args, client.getOpenText(absPath));
        if ('error' in pos)
            return `Error: ${pos.error}`;
        try {
            switch (args.op) {
                case 'hover': {
                    const result = yield client.sendRequest(node_js_1.HoverRequest.type, { textDocument: { uri }, position: pos });
                    if (!(result === null || result === void 0 ? void 0 : result.contents))
                        return '(no hover info)';
                    return fmtHoverContents(result.contents);
                }
                case 'definition': {
                    const result = yield client.sendRequest(node_js_1.DefinitionRequest.type, { textDocument: { uri }, position: pos });
                    return fmtLocations(result);
                }
                case 'references': {
                    const result = yield client.sendRequest(node_js_1.ReferencesRequest.type, {
                        textDocument: { uri },
                        position: pos,
                        context: { includeDeclaration: (_a = args.include_declaration) !== null && _a !== void 0 ? _a : true },
                    });
                    return fmtLocations(result);
                }
                case 'implementation': {
                    const result = yield client.sendRequest(node_js_1.ImplementationRequest.type, { textDocument: { uri }, position: pos });
                    return fmtLocations(result);
                }
                case 'type_definition': {
                    const result = yield client.sendRequest(node_js_1.TypeDefinitionRequest.type, { textDocument: { uri }, position: pos });
                    return fmtLocations(result);
                }
            }
        }
        catch (err) {
            return `LSP ${args.op} failed: ${err instanceof Error ? err.message : String(err)}`;
        }
        return '(unhandled op)';
    });
}
