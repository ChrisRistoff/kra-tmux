"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildAgentTmuxCommand = buildAgentTmuxCommand;
const filePaths_1 = require("@/filePaths");
function buildAgentTmuxCommand(chatFile, socketPath) {
    return `tmux split-window -v -p 90 -c "#{pane_current_path}" \\; send-keys -t :. 'sh -c "trap \\"exit 0\\" TERM; nvim -u \\"${filePaths_1.neovimConfig}\\" --listen \\"${socketPath}\\" \\"${chatFile}\\"; tmux send-keys exit C-m"' C-m`;
}
