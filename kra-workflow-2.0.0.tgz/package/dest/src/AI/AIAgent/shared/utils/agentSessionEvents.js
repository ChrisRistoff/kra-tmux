"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateAgentUi = updateAgentUi;
exports.showProposalReview = showProposalReview;
exports.openChangedProposalFile = openChangedProposalFile;
exports.applyProposal = applyProposal;
exports.rejectCurrentProposal = rejectCurrentProposal;
exports.setupSessionEventHandlers = setupSessionEventHandlers;
const agentUi_1 = require("@/AI/AIAgent/shared/utils/agentUi");
const chatHeaders_1 = require("@/AI/shared/utils/conversationUtils/chatHeaders");
const agentNeovimSetup_1 = require("@/AI/AIAgent/shared/main/agentNeovimSetup");
const bash = __importStar(require("@/utils/bashHelper"));
const agentToolHook_1 = require("@/AI/AIAgent/shared/utils/agentToolHook");
const agentQuotaTracker_1 = require("@/AI/AIAgent/shared/utils/agentQuotaTracker");
function quote(value) {
    return `'${value.replace(/'/g, `'\\''`)}'`;
}
function listProposalChanges(cwd) {
    return __awaiter(this, void 0, void 0, function* () {
        const [modified, untracked] = yield Promise.all([
            bash.execCommand(`git -C ${quote(cwd)} diff --name-only HEAD`)
                .then(r => r.stdout.trim().split('\n').filter(Boolean)),
            bash.execCommand(`git -C ${quote(cwd)} ls-files --others --exclude-standard`)
                .then(r => r.stdout.trim().split('\n').filter(Boolean)),
        ]);
        return [...new Set([...modified, ...untracked])];
    });
}
function readProposalDiff(cwd) {
    return __awaiter(this, void 0, void 0, function* () {
        const savedTree = (yield bash.execCommand(`git -C ${quote(cwd)} write-tree`)).stdout.trim();
        try {
            yield bash.execCommand(`git -C ${quote(cwd)} add -A`);
            const result = yield bash.execCommand(`git --no-pager -C ${quote(cwd)} diff --cached HEAD`);
            return result.stdout;
        }
        finally {
            yield bash.execCommand(`git -C ${quote(cwd)} read-tree ${quote(savedTree)}`);
        }
    });
}
function escapeForSingleQuotes(s) {
    return s.replace(/'/g, `'\\''`);
}
function escapeForVimPath(s) {
    return s.replace(/[\\% #]/g, '\\$&');
}
function updateAgentUi(nvimClient_1, method_1) {
    return __awaiter(this, arguments, void 0, function* (nvimClient, method, args = []) {
        try {
            yield nvimClient.executeLua(`require('kra_agent_ui').${method}(...)`, args);
        }
        catch (_a) {
            // Ignore UI update failures during startup/shutdown so the session itself can continue.
        }
    });
}
function showProposalReview(nvimClient, state) {
    return __awaiter(this, void 0, void 0, function* () {
        yield state.nvim.command('silent! wall');
        const diff = yield readProposalDiff(state.cwd);
        if (!diff.trim()) {
            yield nvimClient.command('echohl WarningMsg | echo "No proposal changes to review" | echohl None');
            return;
        }
        const lines = [
            '# Proposal review',
            '# a: apply  r: reject  o: open changed file  R: refresh  q: close',
            '',
            ...diff.split('\n'),
        ];
        yield nvimClient.executeLua(`
        local content = ...
        local buf = vim.api.nvim_create_buf(false, true)
        vim.cmd('tabnew')
        vim.api.nvim_win_set_buf(0, buf)
        vim.api.nvim_buf_set_lines(buf, 0, -1, false, content)
        vim.api.nvim_buf_set_name(buf, 'kra-agent-review.diff')
        vim.bo[buf].buftype = 'nofile'
        vim.bo[buf].bufhidden = 'wipe'
        vim.bo[buf].swapfile = false
        vim.bo[buf].filetype = 'diff'
        vim.keymap.set('n', 'q', function() vim.cmd('close') end, { buffer = buf, silent = true })
        vim.keymap.set('n', 'a', function() vim.fn.rpcnotify(${yield nvimClient.channelId}, 'prompt_action', 'apply_proposal') end, { buffer = buf, silent = true })
        vim.keymap.set('n', 'r', function() vim.fn.rpcnotify(${yield nvimClient.channelId}, 'prompt_action', 'reject_proposal') end, { buffer = buf, silent = true })
        vim.keymap.set('n', 'o', function() vim.fn.rpcnotify(${yield nvimClient.channelId}, 'prompt_action', 'open_proposal_file') end, { buffer = buf, silent = true })
        vim.keymap.set('n', 'R', function() vim.fn.rpcnotify(${yield nvimClient.channelId}, 'prompt_action', 'review_proposal') end, { buffer = buf, silent = true })
    `, [lines]);
    });
}
function selectChangedProposalFile(nvimClient, proposalFiles) {
    return __awaiter(this, void 0, void 0, function* () {
        const channelId = yield nvimClient.channelId;
        return new Promise((resolve) => {
            const handler = (method, args) => {
                if (method !== 'proposal_file_selected') {
                    return;
                }
                nvimClient.removeListener('notification', handler);
                resolve(args[0] || null);
            };
            nvimClient.on('notification', handler);
            nvimClient.executeLua(`
            local files = ...
            local actions = require('telescope.actions')
            local action_state = require('telescope.actions.state')

            require('telescope.pickers').new({}, {
                prompt_title = 'Open proposal file',
                finder = require('telescope.finders').new_table(files),
                sorter = require('telescope.sorters').get_generic_fuzzy_sorter(),
                attach_mappings = function(prompt_bufnr, map)
                    actions.select_default:replace(function()
                        local selection = action_state.get_selected_entry()
                        actions.close(prompt_bufnr)
                        vim.fn.rpcnotify(${channelId}, 'proposal_file_selected', selection and (selection.value or selection[1]) or nil)
                    end)

                    map('i', '<Esc>', function()
                        actions.close(prompt_bufnr)
                        vim.fn.rpcnotify(${channelId}, 'proposal_file_selected', nil)
                    end)

                    return true
                end
            }):find()
        `, [proposalFiles]).catch(() => {
                nvimClient.removeListener('notification', handler);
                resolve(null);
            });
        });
    });
}
function openChangedProposalFile(state) {
    return __awaiter(this, void 0, void 0, function* () {
        yield state.nvim.command('silent! wall');
        const changedFiles = yield listProposalChanges(state.cwd);
        if (!changedFiles.length) {
            yield state.nvim.command('echohl WarningMsg | echo "No changed proposal files" | echohl None');
            return;
        }
        const selectedFile = yield selectChangedProposalFile(state.nvim, changedFiles);
        if (!selectedFile) {
            yield state.nvim.command('echohl WarningMsg | echo "No proposal file selected" | echohl None');
            return;
        }
        yield state.nvim.command(`tabedit ${escapeForVimPath(`${state.cwd}/${selectedFile}`)}`);
    });
}
function applyProposal(state) {
    return __awaiter(this, void 0, void 0, function* () {
        yield state.nvim.command('silent! wall');
        const message = 'Changes are already written to the repository.';
        yield state.nvim.command(`echohl MoreMsg | echo '${escapeForSingleQuotes(message)}' | echohl None`);
    });
}
function rejectCurrentProposal(state) {
    return __awaiter(this, void 0, void 0, function* () {
        yield state.history.revertAll(state.nvim);
        yield state.nvim.command('echohl WarningMsg | echo "Rejected current proposal changes" | echohl None');
    });
}
function setupSessionEventHandlers(state) {
    return __awaiter(this, void 0, void 0, function* () {
        const FLUSH_INTERVAL_MS = 50;
        let pendingBuffer = '';
        let activeToolCount = 0;
        let currentToolLabel = 'tool';
        let assistantStatusVisible = true;
        let firstToolThisTurn = true;
        let reasoningStarted = false;
        const toolLabels = new Map();
        const toolStartLabels = new Map();
        // Serialised write chain — all disk writes queue here so order is guaranteed
        // and concurrent writes cannot corrupt the file.
        let writeChain = Promise.resolve();
        const enqueue = (fn) => {
            writeChain = writeChain.then(fn).catch(() => { });
        };
        const nvimRefresh = () => __awaiter(this, void 0, void 0, function* () { return (0, agentNeovimSetup_1.refreshAgentLayout)(state.nvim).catch(() => { }); });
        // Write text to the chat file and refresh neovim (through the queue).
        const write = (content, refresh = true) => {
            enqueue(() => __awaiter(this, void 0, void 0, function* () {
                yield (0, agentToolHook_1.appendToChat)(state.chatFile, content);
                if (refresh) {
                    yield nvimRefresh();
                }
            }));
        };
        // Drain the pending AI text buffer (called before each tool and at idle).
        const flushBuffer = () => {
            if (!pendingBuffer) {
                return;
            }
            const text = pendingBuffer;
            pendingBuffer = '';
            write(text);
        };
        // Flush AI text every FLUSH_INTERVAL_MS so streaming is visible.
        // Uses a self-scheduling setTimeout rather than setInterval so the timer
        // goes completely dormant when there is nothing to flush (e.g. while the
        // agent is paused waiting for user input). An active setInterval keeps the
        // event loop alive and prevents V8 from running a full GC cycle.
        let flushTimerHandle = null;
        const scheduleFlush = () => {
            if (flushTimerHandle !== null)
                return;
            flushTimerHandle = setTimeout(() => {
                flushTimerHandle = null;
                if (pendingBuffer && activeToolCount === 0) {
                    flushBuffer();
                }
                // Keep rescheduling only while there is content waiting.
                if (pendingBuffer) {
                    scheduleFlush();
                }
            }, FLUSH_INTERVAL_MS);
        };
        const clearFlushTimer = () => {
            if (flushTimerHandle !== null) {
                clearTimeout(flushTimerHandle);
                flushTimerHandle = null;
            }
        };
        // ============================================================================
        // REASONING & CONTENT STREAMING
        // ============================================================================
        state.session.on('assistant.reasoning_delta', (event) => {
            const isFirst = !reasoningStarted;
            reasoningStarted = true;
            enqueue(() => __awaiter(this, void 0, void 0, function* () {
                // Replace newlines so continuation lines stay inside the blockquote.
                // Only the very first delta gets the opening '> 💭 ' prefix.
                const content = event.data.deltaContent.replace(/\n/g, '\n> ');
                const prefix = isFirst ? '> 💭 ' : '';
                yield (0, agentToolHook_1.appendToChat)(state.chatFile, `${prefix}${content}`);
                yield nvimRefresh();
            }));
        });
        state.session.on('assistant.message_delta', (event) => {
            if (reasoningStarted) {
                // Reasoning just ended — close the blockquote with a blank line
                enqueue(() => __awaiter(this, void 0, void 0, function* () {
                    yield (0, agentToolHook_1.appendToChat)(state.chatFile, '\n\n');
                    yield nvimRefresh();
                }));
                reasoningStarted = false;
            }
            pendingBuffer += event.data.deltaContent;
            scheduleFlush();
            if (activeToolCount === 0 && !assistantStatusVisible) {
                assistantStatusVisible = true;
                void updateAgentUi(state.nvim, 'start_turn', [state.model]);
            }
        });
        // ============================================================================
        // TOOL EXECUTION HANDLERS
        // ============================================================================
        state.session.on('tool.execution_start', (event) => {
            var _a;
            activeToolCount += 1;
            const toolName = (0, agentUi_1.formatToolDisplayName)(event.data.toolName, event.data.mcpServerName, event.data.mcpToolName);
            currentToolLabel = toolName;
            assistantStatusVisible = false;
            toolLabels.set(event.data.toolCallId, toolName);
            toolStartLabels.set(event.data.toolCallId, (0, agentUi_1.summarizeToolCall)(toolName, event.data.arguments));
            // Flush any buffered AI text before the first tool of this group.
            if (firstToolThisTurn) {
                firstToolThisTurn = false;
                flushBuffer();
            }
            const details = `Running ${toolName}\n\nArguments:\n${(0, agentUi_1.formatToolArguments)(event.data.arguments)}`;
            const argsJson = JSON.stringify((_a = event.data.arguments) !== null && _a !== void 0 ? _a : {}, null, 2);
            void updateAgentUi(state.nvim, 'start_tool', [toolName, details, argsJson]);
        });
        state.session.on('tool.execution_progress', (event) => {
            var _a;
            currentToolLabel = (_a = toolLabels.get(event.data.toolCallId)) !== null && _a !== void 0 ? _a : currentToolLabel;
            const details = `Running tool\n\n${(0, agentUi_1.formatToolProgress)(event.data.progressMessage)}`;
            void updateAgentUi(state.nvim, 'update_tool', [currentToolLabel, details]);
        });
        state.session.on('tool.execution_partial_result', (event) => {
            var _a;
            currentToolLabel = (_a = toolLabels.get(event.data.toolCallId)) !== null && _a !== void 0 ? _a : currentToolLabel;
            const details = `Streaming tool output\n\n${(0, agentUi_1.formatToolProgress)(event.data.partialOutput)}`;
            void updateAgentUi(state.nvim, 'update_tool', [currentToolLabel, details]);
        });
        state.session.on('tool.execution_complete', (event) => {
            var _a, _b, _c, _d, _e, _f;
            activeToolCount = Math.max(0, activeToolCount - 1);
            const toolName = (_a = toolLabels.get(event.data.toolCallId)) !== null && _a !== void 0 ? _a : currentToolLabel;
            const toolSummary = (_b = toolStartLabels.get(event.data.toolCallId)) !== null && _b !== void 0 ? _b : toolName;
            toolLabels.delete(event.data.toolCallId);
            toolStartLabels.delete(event.data.toolCallId);
            currentToolLabel = toolName;
            assistantStatusVisible = activeToolCount === 0;
            // After all tools finish, re-enable timer so next AI text is flushed.
            if (activeToolCount === 0) {
                firstToolThisTurn = true;
                reasoningStarted = false;
            }
            write((0, agentUi_1.formatToolLine)(toolSummary, event.data.success));
            const details = (0, agentUi_1.formatToolCompletion)(event.data.success, event.data.result, event.data.error);
            const fullResult = event.data.success
                ? ((_f = (_d = (_c = event.data.result) === null || _c === void 0 ? void 0 : _c.detailedContent) !== null && _d !== void 0 ? _d : (_e = event.data.result) === null || _e === void 0 ? void 0 : _e.content) !== null && _f !== void 0 ? _f : '')
                : (event.data.error ? String(event.data.error) : '');
            void updateAgentUi(state.nvim, 'complete_tool', [
                toolName,
                details,
                event.data.success,
                fullResult,
            ]);
            // Notify the diff module so any pending diff entry queued by an approved
            // (possibly user-edited) write tool is either committed to the diff
            // history (success) or discarded (failure / intercepted deny). Tools
            // that never opened a diff editor have no pending entry, so this is a
            // no-op for them.
            state.nvim
                .executeLua(`require('kra_agent_diff').finalize_pending_diff(...)`, [event.data.success])
                .catch(() => { });
        });
        // ============================================================================
        // SESSION STATE
        // ============================================================================
        state.session.on('session.idle', () => {
            void (() => __awaiter(this, void 0, void 0, function* () {
                clearFlushTimer();
                flushBuffer();
                // Wait for all in-flight writes to finish before marking the session ready.
                yield writeChain;
                activeToolCount = 0;
                assistantStatusVisible = false;
                state.isStreaming = false;
                yield (0, agentToolHook_1.appendToChat)(state.chatFile, (0, chatHeaders_1.formatUserDraftHeader)());
                yield (0, agentNeovimSetup_1.refreshAgentLayout)(state.nvim);
                yield updateAgentUi(state.nvim, 'ready_for_next_prompt');
                yield (0, agentNeovimSetup_1.focusAgentPrompt)(state.nvim);
            }))();
        });
        (0, agentQuotaTracker_1.setupQuotaTracking)(state);
    });
}
