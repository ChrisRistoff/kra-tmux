"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createAgentHistory = createAgentHistory;
const fs = __importStar(require("fs/promises"));
const path = __importStar(require("path"));
const bashHelper_1 = require("@/utils/bashHelper");
const MAX_FILE_SIZE = 2 * 1024 * 1024; // 2 MB
const BINARY_CHECK_BYTES = 8 * 1024; // 8 KB
function quoteForShell(value) {
    return `'${value.replace(/'/g, `'\\''`)}'`;
}
function isBinaryBuffer(buf) {
    const limit = Math.min(buf.length, BINARY_CHECK_BYTES);
    for (let i = 0; i < limit; i++) {
        if (buf[i] === 0)
            return true;
    }
    return false;
}
function gitStatus(cwd) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const result = yield (0, bashHelper_1.execCommand)(`git -C ${quoteForShell(cwd)} status --porcelain=v1 -uall -z`);
            const map = new Map();
            const raw = result.stdout;
            let i = 0;
            while (i < raw.length) {
                // Each entry: "XY filename\0"  (3-char prefix + NUL-terminated path).
                // Renames produce two NUL-terminated tokens; skip the second.
                if (i + 3 > raw.length)
                    break;
                const status = raw.slice(i, i + 2).trim();
                i += 3; // skip "XY "
                const end = raw.indexOf('\0', i);
                if (end === -1)
                    break;
                const filePath = raw.slice(i, end);
                map.set(filePath, status);
                i = end + 1;
                if (status === 'R' || status === 'C') {
                    // Rename/copy: skip the old name
                    const end2 = raw.indexOf('\0', i);
                    if (end2 !== -1)
                        i = end2 + 1;
                }
            }
            return map;
        }
        catch (_a) {
            return new Map();
        }
    });
}
function createAgentHistory(cwd) {
    // First-seen "before" per absolute path — the pre-session original.
    const originalContent = new Map();
    const entries = [];
    function recordMutation(opts) {
        if (!originalContent.has(opts.path)) {
            originalContent.set(opts.path, opts.beforeContent);
        }
        entries.push(opts);
    }
    function getOriginalContent(filePath) {
        var _a;
        if (!originalContent.has(filePath))
            return undefined;
        return (_a = originalContent.get(filePath)) !== null && _a !== void 0 ? _a : null;
    }
    function revertAll(nvim) {
        return __awaiter(this, void 0, void 0, function* () {
            const paths = new Set(entries.map(e => e.path));
            let reverted = 0;
            let failed = 0;
            for (const filePath of paths) {
                try {
                    const original = originalContent.get(filePath);
                    if (original === undefined)
                        continue;
                    if (original === null) {
                        // File didn't exist originally → delete it.
                        yield fs.rm(filePath, { force: true });
                    }
                    else {
                        // File existed → restore its original content.
                        yield fs.mkdir(path.dirname(filePath), { recursive: true });
                        yield fs.writeFile(filePath, original, 'utf8');
                    }
                    reverted++;
                }
                catch (_a) {
                    failed++;
                }
            }
            const msg = failed > 0
                ? `Reverted ${reverted} file(s); ${failed} failed.`
                : `Reverted ${reverted} file(s).`;
            try {
                yield nvim.command(`echo '${msg.replace(/'/g, `'\\''`)}'`);
            }
            catch ( /* nvim may be disconnecting */_b) { /* nvim may be disconnecting */ }
        });
    }
    function listChangedPaths() {
        return [...new Set(entries.map(e => e.path))];
    }
    function bashSnapshotBefore() {
        return __awaiter(this, void 0, void 0, function* () {
            const statusByPath = yield gitStatus(cwd);
            return { statusByPath, cwd };
        });
    }
    function bashSnapshotAfter(before) {
        return __awaiter(this, void 0, void 0, function* () {
            var _a;
            const after = yield gitStatus(cwd);
            const changedRelPaths = new Set();
            for (const [p, status] of after) {
                if (!before.statusByPath.has(p) || before.statusByPath.get(p) !== status) {
                    changedRelPaths.add(p);
                }
            }
            // Paths that were dirty before but are now clean (e.g. reverted by bash).
            for (const [p] of before.statusByPath) {
                if (!after.has(p))
                    changedRelPaths.add(p);
            }
            for (const relPath of changedRelPaths) {
                const absPath = path.join(cwd, relPath);
                // Determine beforeContent (pre-bash state).
                let beforeContent;
                if (originalContent.has(absPath)) {
                    // Already tracked — original is already correct in the map; pass it
                    // again so the entry is still meaningful but won't overwrite the map.
                    beforeContent = (_a = originalContent.get(absPath)) !== null && _a !== void 0 ? _a : null;
                }
                else {
                    try {
                        const result = yield (0, bashHelper_1.execCommand)(`git -C ${quoteForShell(cwd)} show HEAD:${quoteForShell(relPath)}`);
                        beforeContent = result.stdout;
                    }
                    catch (_b) {
                        beforeContent = null; // new untracked file
                    }
                }
                // Determine afterContent (post-bash state on disk).
                let afterContent;
                try {
                    const stat = yield fs.stat(absPath);
                    if (stat.size > MAX_FILE_SIZE)
                        continue; // skip very large files
                    const raw = yield fs.readFile(absPath);
                    afterContent = isBinaryBuffer(raw) ? null : raw.toString('utf8');
                }
                catch (_c) {
                    afterContent = null; // file was deleted
                }
                recordMutation({ path: absPath, beforeContent, afterContent, source: 'bash' });
            }
        });
    }
    return {
        recordMutation,
        getOriginalContent,
        revertAll,
        listChangedPaths,
        bashSnapshotBefore,
        bashSnapshotAfter,
    };
}
