"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.formatToolLine = formatToolLine;
exports.formatConfirmQuestion = formatConfirmQuestion;
exports.formatConfirmAnswer = formatConfirmAnswer;
exports.formatSubmittedAgentPrompt = formatSubmittedAgentPrompt;
exports.summarizeToolCall = summarizeToolCall;
exports.formatToolDisplayName = formatToolDisplayName;
exports.formatToolArguments = formatToolArguments;
exports.formatToolProgress = formatToolProgress;
exports.formatToolCompletion = formatToolCompletion;
const TOOL_TEXT_MAX_LINES = 14;
const TOOL_TEXT_MAX_LENGTH = 1200;
const chatHeaders_1 = require("@/AI/shared/utils/conversationUtils/chatHeaders");
/** One line written to the chat file when a tool finishes. */
function formatToolLine(toolSummary, success) {
    const icon = success ? '✓' : '✗';
    return `\n\`${icon} ${toolSummary}\`\n`;
}
/**
 * Written to the chat file when confirm_task_complete fires so the user can
 * see what the AI is asking before and after they answer the popup.
 */
function formatConfirmQuestion(question, choices) {
    const choiceLines = choices.map((c) => `- ${c}`).join('\n');
    return `\n\n---\n**💬 ${question}**\n\n${choiceLines}\n\n`;
}
function formatConfirmAnswer(answer) {
    return `${(0, chatHeaders_1.formatUserHeader)()}${answer}\n\n`;
}
function truncateMultiline(value) {
    const lines = value.trim().split('\n');
    const clippedLines = lines.slice(0, TOOL_TEXT_MAX_LINES);
    let truncated = clippedLines.join('\n');
    if (lines.length > TOOL_TEXT_MAX_LINES) {
        truncated += '\n…';
    }
    if (truncated.length > TOOL_TEXT_MAX_LENGTH) {
        truncated = `${truncated.slice(0, TOOL_TEXT_MAX_LENGTH - 1)}…`;
    }
    return truncated;
}
function extractErrorMessage(error) {
    if (error instanceof Error) {
        return error.message;
    }
    if (typeof error === 'string') {
        return error;
    }
    if (error && typeof error === 'object' && 'message' in error) {
        const message = error.message;
        if (typeof message === 'string') {
            return message;
        }
    }
    return 'Tool failed.';
}
function formatSubmittedAgentPrompt(prompt) {
    const normalizedPrompt = prompt.trim();
    return normalizedPrompt ? `${normalizedPrompt}\n` : '';
}
function summarizeToolCall(toolName, argumentsData) {
    const summaryValue = (typeof (argumentsData === null || argumentsData === void 0 ? void 0 : argumentsData.query) === 'string' && argumentsData.query) ||
        (typeof (argumentsData === null || argumentsData === void 0 ? void 0 : argumentsData.command) === 'string' && argumentsData.command) ||
        (typeof (argumentsData === null || argumentsData === void 0 ? void 0 : argumentsData.path) === 'string' && argumentsData.path) ||
        (typeof (argumentsData === null || argumentsData === void 0 ? void 0 : argumentsData.url) === 'string' && argumentsData.url) ||
        (typeof (argumentsData === null || argumentsData === void 0 ? void 0 : argumentsData.prompt) === 'string' && argumentsData.prompt);
    if (!summaryValue) {
        return toolName;
    }
    const compact = summaryValue.replace(/\s+/g, ' ').trim();
    const truncated = compact.length > 60 ? `${compact.slice(0, 59)}…` : compact;
    return `${toolName}: ${truncated}`;
}
function formatToolDisplayName(toolName, mcpServerName, mcpToolName) {
    return mcpServerName
        ? `${mcpServerName}:${mcpToolName !== null && mcpToolName !== void 0 ? mcpToolName : toolName}`
        : toolName;
}
function formatToolArguments(argumentsData) {
    if (!argumentsData || !Object.keys(argumentsData).length) {
        return 'No arguments.';
    }
    return truncateMultiline(JSON.stringify(argumentsData, null, 2));
}
function formatToolProgress(progressMessage) {
    return truncateMultiline(progressMessage);
}
function formatToolCompletion(success, result, error) {
    var _a, _b;
    if (!success) {
        return truncateMultiline(extractErrorMessage(error));
    }
    const resultText = (_b = (_a = result === null || result === void 0 ? void 0 : result.detailedContent) !== null && _a !== void 0 ? _a : result === null || result === void 0 ? void 0 : result.content) !== null && _b !== void 0 ? _b : 'Completed successfully.';
    return truncateMultiline(resultText);
}
