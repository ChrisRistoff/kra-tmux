#!/usr/bin/env node
"use strict";
/**
 * kra-memory MCP server — exposes the Phase 1 memory tools to agents.
 *
 * Mirrors the JSON-RPC stdio pattern used by `bashMcpServer.ts` and
 * `webMcpServer.ts`. All operations resolve `<repo>` from
 * `process.env.WORKING_DIR` (set by the spawning provider) so memory is
 * scoped per agent workspace.
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const stdioServer_1 = require("../../mcp/stdioServer");
require("module-alias/register");
const notes_1 = require("../memory/notes");
const search_1 = require("../memory/search");
const types_1 = require("../memory/types");
const REMEMBER_TOOL = {
    name: 'remember',
    description: [
        'Persist a long-term note about this repo so the next session has it.',
        'Use for non-obvious bug fixes, gotchas, design decisions, investigation results,',
        'or to PARK an idea you want to revisit later (kind="revisit" → stays open until you call update_memory).',
        'Include enough detail in body that a future session can act on it without re-investigating.',
    ].join(' '),
    inputSchema: {
        type: 'object',
        properties: {
            kind: { type: 'string', enum: [...types_1.MEMORY_KINDS], description: 'Category of memory entry. Use "revisit" to park an idea for later (filterable via recall(kind="revisit", status="open")).' },
            title: { type: 'string', description: 'Short headline (1 line).' },
            body: { type: 'string', description: 'Full content. For revisits, include both what to revisit and why we deferred.' },
            tags: { type: 'array', items: { type: 'string' }, description: 'Optional tags for filtering.' },
            paths: { type: 'array', items: { type: 'string' }, description: 'Related file paths.' },
            branch: { type: 'string', description: 'Optional branch name this entry pertains to.' },
        },
        required: ['kind', 'title', 'body'],
    },
};
const RECALL_TOOL = {
    name: 'recall',
    description: [
        'Look up memory entries. With `query`, runs vector search and returns the top-k most semantically similar entries.',
        'Primary use: listing/filtering stored entries, checking revisits, or narrowing to a specific memory kind.',
        'For first-step conceptual discovery across long-term memories, prefer `semantic_search({ scope: "memory" | "both", memoryKind: "findings" })` instead of brute-forcing `recall` queries.',
        'WITHOUT `query`, runs in list mode (newest-first). Use `kind: "findings"` to search long-term findings memories,',
        '`kind: "revisit"` for parked discussions, or a specific finding kind to narrow the findings table.',
        'All filters (kind / tagsAny / status) compose with both modes.',
    ].join(' '),
    inputSchema: {
        type: 'object',
        properties: {
            query: { type: 'string', description: 'Optional natural-language query. Omit for list mode (no embedding).' },
            k: { type: 'number', description: 'Max results (default 5 for search mode, 50 for list mode, hard cap 200).' },
            kind: { type: 'string', enum: [...types_1.MEMORY_LOOKUP_KINDS], description: 'REQUIRED. `findings` queries the findings table, `revisit` queries parked discussions, and specific finding kinds narrow the findings table.' },
            selectedIds: { type: 'array', items: { type: 'string' }, description: 'Optional pre-approved memory ids to limit the result set.' },
            tagsAny: { type: 'array', items: { type: 'string' }, description: 'Match if entry has any of these tags.' },
            status: { type: 'string', enum: [...types_1.MEMORY_STATUSES], description: 'Filter by status (typically "open" for revisit listings).' },
        },
        required: ['kind'],
    },
};
const UPDATE_MEMORY_TOOL = {
    name: 'update_memory',
    description: [
        'Mark a memory entry as resolved (acted on) or dismissed (no longer planning to do it).',
        'Primarily used to close out kind="revisit" entries returned by recall.',
    ].join(' '),
    inputSchema: {
        type: 'object',
        properties: {
            id: { type: 'string', description: 'Memory entry id (returned by remember / recall).' },
            status: { type: 'string', enum: ['resolved', 'dismissed'], description: '"resolved" if we acted on it, "dismissed" if abandoned.' },
            resolution: { type: 'string', description: 'Optional notes on how it was resolved or why it was dismissed.' },
        },
        required: ['id', 'status'],
    },
};
const SEMANTIC_SEARCH_TOOL = {
    name: 'semantic_search',
    description: [
        'Conceptual vector search over the indexed codebase (and optionally memory entries).',
        'Preferred first-step discovery tool for conceptual codebase lookup and prior-memory retrieval.',
        'Use this before text search when you do not already know the exact symbol, file, path, or literal string.',
        'For new non-trivial tasks, start with `scope: "both", memoryKind: "findings"` unless the task is a tiny exact lookup.',
        'For known string/symbol/path lookups prefer the file-context `search` tool or `lsp_query` — they are complementary.',
        'Returns ONE entry per matched file (deduped) with parallel `startLines` / `endLines` arrays of the matched ranges (already merged), plus an annotated `outline` whose entries carry a `matched` flag indicating which symbols overlap those ranges. No source code is returned — follow up with `read_lines` (you can pass `startLines`/`endLines` straight from the response) or `read_function` for the actual content.',
        'When scope includes "memory", pass `memoryKind: "findings"` for long-term memories, `memoryKind: "revisit"` for parked discussions, or a specific finding kind to narrow the findings table.',
    ].join(' '),
    inputSchema: {
        type: 'object',
        properties: {
            query: { type: 'string', description: 'Natural-language description of what you are looking for.' },
            k: { type: 'number', description: 'Max results (default 10, hard cap 100).' },
            scope: { type: 'string', enum: ['code', 'memory', 'both'], description: 'Where to search (default "code").' },
            pathGlob: { type: 'string', description: 'Optional glob to restrict code results by path (e.g. "src/AI/**").' },
            memoryKind: { type: 'string', enum: [...types_1.MEMORY_LOOKUP_KINDS], description: 'Required when scope is "memory" or "both". Use `findings` for long-term memories, `revisit` for parked discussions, or a specific finding kind to narrow the findings table.' },
            selectedIds: { type: 'array', items: { type: 'string' }, description: 'Optional pre-approved memory ids to limit returned memory hits.' },
        },
        required: ['query'],
    },
};
const EDIT_MEMORY_TOOL = {
    name: 'edit_memory',
    description: [
        'Edit an existing memory entry in place: title, body, tags, paths, or branch.',
        'Re-embeds the vector when title or body change. Works for both findings and revisits.',
    ].join(' '),
    inputSchema: {
        type: 'object',
        properties: {
            id: { type: 'string', description: 'Memory entry id (returned by remember / recall).' },
            title: { type: 'string', description: 'New short headline.' },
            body: { type: 'string', description: 'New full content.' },
            tags: { type: 'array', items: { type: 'string' }, description: 'Replacement tag list.' },
            paths: { type: 'array', items: { type: 'string' }, description: 'Replacement paths list.' },
            branch: { type: 'string', description: 'Replacement branch (use empty string to clear).' },
        },
        required: ['id'],
    },
};
const TOOLS = [
    REMEMBER_TOOL,
    RECALL_TOOL,
    UPDATE_MEMORY_TOOL,
    EDIT_MEMORY_TOOL,
    SEMANTIC_SEARCH_TOOL,
];
function dispatchTool(name, args) {
    return __awaiter(this, void 0, void 0, function* () {
        switch (name) {
            case 'remember':
                return (0, notes_1.remember)(args);
            case 'recall':
                return (0, notes_1.recall)(args);
            case 'update_memory':
                return (0, notes_1.updateMemory)(args);
            case 'edit_memory':
                return (0, notes_1.editMemory)(args);
            case 'semantic_search':
                return (0, search_1.semanticSearch)(args);
            default:
                throw new Error(`Unknown tool: ${name}`);
        }
    });
}
(0, stdioServer_1.runStdioMcpServer)({
    serverName: 'kra-memory',
    tools: TOOLS,
    handleToolCall: (_a) => __awaiter(void 0, [_a], void 0, function* ({ toolName, params }) {
        const callParams = (params !== null && params !== void 0 ? params : {});
        const rawArgs = callParams.arguments;
        const args = (typeof rawArgs === 'object' && rawArgs !== null ? rawArgs : {});
        const result = yield dispatchTool(toolName, args);
        return {
            content: [{ type: 'text', text: JSON.stringify(result, null, 2) }],
            isError: false,
        };
    }),
    onInternalError: (error) => {
        const message = error instanceof Error ? error.message : String(error);
        return {
            kind: 'result',
            result: {
                content: [{ type: 'text', text: `Error: ${message}` }],
                isError: true,
            },
        };
    },
});
