"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.appendToChat = appendToChat;
exports.handleAgentUserInput = handleAgentUserInput;
exports.buildWritePreview = buildWritePreview;
exports.buildToolApprovalDetails = buildToolApprovalDetails;
exports.promptToolApproval = promptToolApproval;
exports.applyStrReplaceEditorDirectly = applyStrReplaceEditorDirectly;
exports.handleConfirmTaskComplete = handleConfirmTaskComplete;
exports.extractFileReadPath = extractFileReadPath;
exports.handlePreToolUse = handlePreToolUse;
const fs = __importStar(require("fs/promises"));
const os_1 = __importDefault(require("os"));
const path_1 = __importDefault(require("path"));
const agentToolApproval_1 = require("@/AI/AIAgent/shared/utils/agentToolApproval");
const agentUi_1 = require("@/AI/AIAgent/shared/utils/agentUi");
const chatHeaders_1 = require("@/AI/shared/utils/conversationUtils/chatHeaders");
const fileOutline_1 = require("@/AI/AIAgent/shared/utils/fileOutline");
const agentMemoryActions_1 = require("@/AI/AIAgent/shared/main/agentMemoryActions");
const notes_1 = require("@/AI/AIAgent/shared/memory/notes");
const search_1 = require("@/AI/AIAgent/shared/memory/search");
const types_1 = require("@/AI/AIAgent/shared/memory/types");
const bash = __importStar(require("@/utils/bashHelper"));
const fileSafety_1 = require("@/AI/AIAgent/shared/utils/fileSafety");
const EDIT_LINES_HARD_CAP = 100;
function quoteForShell(value) {
    return `'${value.replace(/'/g, `'\\''`)}'`;
}
function readFileOrEmpty(filePath) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            return yield fs.readFile(filePath, 'utf8');
        }
        catch (err) {
            if (err.code === 'ENOENT') {
                return '';
            }
            throw err;
        }
    });
}
// Run `git diff --no-index` on two strings via temp files. Always cleans up.
function computeDiff(currentContent, proposedContent) {
    return __awaiter(this, void 0, void 0, function* () {
        const tempSuffix = `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
        const currentPath = path_1.default.join(os_1.default.tmpdir(), `kra-agent-current-${tempSuffix}`);
        const proposedPath = path_1.default.join(os_1.default.tmpdir(), `kra-agent-proposed-${tempSuffix}`);
        yield fs.writeFile(currentPath, currentContent, 'utf8');
        yield fs.writeFile(proposedPath, proposedContent, 'utf8');
        try {
            const result = yield bash.execCommand(`git --no-pager diff --no-index -- ${quoteForShell(currentPath)} ${quoteForShell(proposedPath)} || true`);
            return result.stdout.trim();
        }
        finally {
            yield fs.rm(currentPath, { force: true });
            yield fs.rm(proposedPath, { force: true });
        }
    });
}
function appendToChat(file, content) {
    return __awaiter(this, void 0, void 0, function* () {
        yield fs.appendFile(file, content, 'utf-8');
    });
}
function handleAgentUserInput(nvimClient_1, question_1, choices_1) {
    return __awaiter(this, arguments, void 0, function* (nvimClient, question, choices, allowFreeform = true) {
        const channelId = yield nvimClient.channelId;
        return new Promise((resolve) => {
            const handler = (method, args) => {
                if (method !== 'user_input_response') {
                    return;
                }
                nvimClient.removeListener('notification', handler);
                const answer = typeof args[0] === 'string' ? args[0] : '';
                const wasFreeform = args[1] === true || !(choices === null || choices === void 0 ? void 0 : choices.includes(answer));
                resolve({ answer, wasFreeform });
            };
            nvimClient.on('notification', handler);
            void nvimClient.executeLua(`require('kra_agent_ui').request_user_input(...)`, [channelId, question, choices !== null && choices !== void 0 ? choices : [], allowFreeform]).catch(() => {
                nvimClient.removeListener('notification', handler);
                resolve({ answer: '', wasFreeform: true });
            });
        });
    });
}
// Build preview for content-field write tools (write_file etc.)
function buildWritePreviewForWrite(toolArgs, workspacePath) {
    return __awaiter(this, void 0, void 0, function* () {
        const request = (0, agentToolApproval_1.extractWriteRequest)(toolArgs, workspacePath);
        if (!request)
            return undefined;
        const currentContent = yield readFileOrEmpty(request.targetPath);
        const diff = yield computeDiff(currentContent, request.nextContent);
        return {
            applyStrategy: 'content-field',
            contentField: request.contentField,
            currentContent,
            diff,
            displayPath: request.displayPath,
            proposedContent: request.nextContent,
            proposedEndsWithNewline: request.nextContent.endsWith('\n'),
        };
    });
}
// Build preview for the edit_lines MCP tool (single- or multi-edit form).
function buildWritePreviewForEditLines(toolArgs, workspacePath) {
    return __awaiter(this, void 0, void 0, function* () {
        const request = (0, agentToolApproval_1.extractEditLinesRequest)(toolArgs, workspacePath);
        if (!request)
            return undefined;
        const currentContent = yield readFileOrEmpty(request.targetPath);
        let proposedContent;
        let note;
        if (request.startLines && request.endLines && request.newContents) {
            // Multi-edit (array) form — apply edits bottom-to-top, same as the MCP server.
            const { startLines, endLines, newContents } = request;
            let lines = currentContent.split('\n');
            const indices = Array.from({ length: startLines.length }, (_, i) => i)
                .sort((a, b) => startLines[b] - startLines[a]);
            for (const i of indices) {
                const start = startLines[i];
                const clampedEnd = Math.min(endLines[i], lines.length);
                const insertLines = newContents[i] === '' ? [] : newContents[i].split('\n');
                lines = [...lines.slice(0, start - 1), ...insertLines, ...lines.slice(clampedEnd)];
            }
            proposedContent = lines.join('\n');
            note = `Applies ${startLines.length} edit${startLines.length === 1 ? '' : 's'} across the file. Approved edits are applied as a full-file replacement.`;
        }
        else if (typeof request.startLine === 'number'
            && typeof request.endLine === 'number'
            && typeof request.newContent === 'string') {
            const { startLine, endLine, newContent } = request;
            const lines = currentContent.split('\n');
            const clampedEnd = Math.min(endLine, lines.length);
            const insertLines = newContent === '' ? [] : newContent.split('\n');
            const resultLines = [
                ...lines.slice(0, startLine - 1),
                ...insertLines,
                ...lines.slice(clampedEnd),
            ];
            proposedContent = resultLines.join('\n');
            note = newContent === ''
                ? `Deletes lines ${startLine}–${clampedEnd}. Edit the middle pane before approving.`
                : `Replaces lines ${startLine}–${clampedEnd} with ${insertLines.length} line${insertLines.length === 1 ? '' : 's'}. Approved edits are applied as a full-file replacement.`;
        }
        else {
            return undefined;
        }
        const diff = yield computeDiff(currentContent, proposedContent);
        return {
            applyStrategy: 'edit-tool',
            currentContent,
            diff,
            displayPath: request.displayPath,
            note,
            proposedContent,
            proposedEndsWithNewline: proposedContent.endsWith('\n'),
        };
    });
}
function buildWritePreviewForEdit(toolArgs, workspacePath) {
    return __awaiter(this, void 0, void 0, function* () {
        const editRequest = (0, agentToolApproval_1.extractEditRequest)(toolArgs, workspacePath);
        if (!editRequest)
            return undefined;
        const currentContent = yield readFileOrEmpty(editRequest.targetPath);
        let proposedContent = currentContent;
        let note = 'Approved edits will be converted into a full-file edit so they still apply reliably.';
        if (!editRequest.oldString) {
            if (!currentContent.length) {
                proposedContent = editRequest.newString;
                note = 'New file — the middle pane shows what will be written. Edit before approving.';
            }
            else {
                // Whole-file replacement (no old_str). Middle = full new content.
                proposedContent = editRequest.newString;
                note = 'No old_str supplied — the middle pane shows the full replacement. Edit before approving.';
            }
        }
        else if (editRequest.oldString === editRequest.newString) {
            proposedContent = currentContent;
            note = 'old_str and new_str are identical; approving keeps the file unchanged.';
        }
        else {
            const firstIndex = currentContent.indexOf(editRequest.oldString);
            const lastIndex = currentContent.lastIndexOf(editRequest.oldString);
            if (firstIndex !== -1 && firstIndex === lastIndex) {
                proposedContent = currentContent.replace(editRequest.oldString, editRequest.newString);
            }
            else if (firstIndex === -1) {
                if (!currentContent.length) {
                    proposedContent = editRequest.newString;
                    note = 'New file — the middle pane shows what will be written. Edit before approving.';
                }
                else {
                    // old_str not in file — append as best-effort (same as yolo path).
                    // Middle shows a full file so the diff doesn't look like "delete everything".
                    proposedContent = `${currentContent}\n${editRequest.newString}`;
                    note = 'old_str not found — change appended at end as best-effort. Edit the middle pane to place it correctly.';
                }
            }
            else {
                note = 'old_str appears multiple times — first occurrence replaced. Edit the middle pane if needed.';
                proposedContent = currentContent.replace(editRequest.oldString, editRequest.newString);
            }
        }
        const diff = yield computeDiff(currentContent, proposedContent);
        return {
            applyStrategy: 'edit-tool',
            currentContent,
            diff,
            displayPath: editRequest.displayPath,
            note,
            proposedContent,
            proposedEndsWithNewline: proposedContent.endsWith('\n'),
        };
    });
}
function buildWritePreview(toolArgs, workspacePath) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b;
        return ((_b = (_a = yield buildWritePreviewForWrite(toolArgs, workspacePath)) !== null && _a !== void 0 ? _a : yield buildWritePreviewForEditLines(toolArgs, workspacePath)) !== null && _b !== void 0 ? _b : yield buildWritePreviewForEdit(toolArgs, workspacePath));
    });
}
// Builds a compact "File: ... / Line ranges: ..." summary for the file-context
// `read_lines` and `edit_lines` tool calls so the permission popup shows the
// targeted ranges at a glance instead of an opaque "Arguments:" placeholder.
function summarizeLineRanges(args) {
    if (!args)
        return undefined;
    const filePath = typeof args.file_path === 'string' ? args.file_path : undefined;
    const startArr = (0, agentToolApproval_1.coerceNumberArray)(args.startLines);
    const endArr = (0, agentToolApproval_1.coerceNumberArray)(args.endLines);
    const ranges = [];
    if (startArr && endArr && startArr.length === endArr.length && startArr.length > 0) {
        for (let i = 0; i < startArr.length; i++)
            ranges.push([startArr[i], endArr[i]]);
    }
    else {
        const s = (0, agentToolApproval_1.coerceNumber)(args.start_line);
        const e = (0, agentToolApproval_1.coerceNumber)(args.end_line);
        if (s !== undefined && e !== undefined)
            ranges.push([s, e]);
    }
    if (!filePath && ranges.length === 0)
        return undefined;
    const out = [];
    if (filePath)
        out.push(`File: ${filePath}`);
    if (ranges.length > 0) {
        const total = ranges.reduce((acc, [s, e]) => acc + Math.max(0, e - s + 1), 0);
        const list = ranges
            .map(([s, e]) => (s === e ? `${s}` : `${s}\u2013${e}`))
            .join(', ');
        out.push(`Line ranges: ${list}  (${ranges.length} range${ranges.length === 1 ? '' : 's'}, ${total} line${total === 1 ? '' : 's'})`);
    }
    return out.join('\n');
}
function buildToolApprovalDetails(input, workspacePath) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        // If toolArgs is already a JSON string (as sent by some SDK versions), use it
        // directly — re-encoding would double-escape it and break Lua's json.decode.
        const argsJson = typeof input.toolArgs === 'string'
            ? input.toolArgs
            : JSON.stringify((_a = input.toolArgs) !== null && _a !== void 0 ? _a : {}, null, 2);
        const argsRecord = (0, agentToolApproval_1.getToolArgsRecord)(input.toolArgs);
        const isLineRangeTool = input.toolName.includes('read_lines') || input.toolName.includes('edit_lines');
        const lineRangeSummary = isLineRangeTool ? summarizeLineRanges(argsRecord) : undefined;
        const summary = lineRangeSummary !== null && lineRangeSummary !== void 0 ? lineRangeSummary : (typeof (argsRecord === null || argsRecord === void 0 ? void 0 : argsRecord.command) === 'string'
            ? `Command:\n${argsRecord.command}`
            : typeof (argsRecord === null || argsRecord === void 0 ? void 0 : argsRecord.query) === 'string'
                ? `Query:\n${argsRecord.query}`
                : typeof (argsRecord === null || argsRecord === void 0 ? void 0 : argsRecord.path) === 'string'
                    ? `Path:\n${argsRecord.path}`
                    : 'Arguments:');
        const writePreview = yield buildWritePreview(input.toolArgs, workspacePath);
        const sections = [
            `Tool: ${input.toolName}`,
            '',
            summary,
        ];
        if (writePreview) {
            sections.push('', `Write target:\n${writePreview.displayPath}`, ...(writePreview.note ? ['', `Review note:\n${writePreview.note}`] : []), '', 'Diff preview:', (0, agentUi_1.formatToolProgress)(writePreview.diff || 'Open the diff editor to inspect the proposed change side by side.'), '', 'Press e to inspect and edit the proposed write in a real diff view.');
        }
        sections.push('', typeof (argsRecord === null || argsRecord === void 0 ? void 0 : argsRecord.command) === 'string'
            ? 'Press e to review/edit this command before it runs.'
            : 'Press e to review/edit the actual tool arguments before approval.');
        return writePreview
            ? {
                argsJson,
                details: sections.join('\n'),
                writePreview,
            }
            : {
                argsJson,
                details: sections.join('\n'),
            };
    });
}
function writePreviewToTempFiles(preview) {
    return __awaiter(this, void 0, void 0, function* () {
        const suffix = `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
        const currentPath = path_1.default.join(os_1.default.tmpdir(), `kra-agent-diff-current-${suffix}`);
        const proposedPath = path_1.default.join(os_1.default.tmpdir(), `kra-agent-diff-proposed-${suffix}`);
        yield fs.writeFile(currentPath, preview.currentContent, 'utf8');
        yield fs.writeFile(proposedPath, preview.proposedContent, 'utf8');
        return { currentPath, proposedPath };
    });
}
function promptToolApproval(nvimClient, input, workspacePath) {
    return __awaiter(this, void 0, void 0, function* () {
        const channelId = yield nvimClient.channelId;
        const payload = yield buildToolApprovalDetails(input, workspacePath);
        let tempFiles;
        if (payload.writePreview) {
            tempFiles = yield writePreviewToTempFiles(payload.writePreview);
        }
        const decision = yield new Promise((resolve) => {
            var _a, _b, _c, _d;
            const cleanup = () => __awaiter(this, void 0, void 0, function* () {
                if (tempFiles) {
                    yield fs.rm(tempFiles.currentPath, { force: true });
                    yield fs.rm(tempFiles.proposedPath, { force: true });
                }
            });
            const handler = (method, args) => {
                if (method !== 'tool_permission_decision') {
                    return;
                }
                nvimClient.removeListener('notification', handler);
                void cleanup();
                const action = args[0];
                const modifiedArgsJson = args[1];
                if (action === 'edited' && typeof modifiedArgsJson === 'string') {
                    resolve({
                        action: 'allow',
                        modifiedArgs: JSON.parse(modifiedArgsJson),
                    });
                    return;
                }
                if (action === 'allow-family' || action === 'yolo' || action === 'allow') {
                    resolve({ action: action });
                    return;
                }
                resolve({ action: 'deny' });
            };
            nvimClient.on('notification', handler);
            void nvimClient.executeLua(`require('kra_agent_ui').request_permission(...)`, [
                channelId,
                {
                    details: payload.details,
                    title: `Approve tool · ${input.toolName}`,
                    toolName: input.toolName,
                    argsJson: payload.argsJson,
                    hasWritePreview: !!payload.writePreview,
                    previewCurrentPath: tempFiles === null || tempFiles === void 0 ? void 0 : tempFiles.currentPath,
                    previewProposedPath: tempFiles === null || tempFiles === void 0 ? void 0 : tempFiles.proposedPath,
                    previewDisplayPath: (_a = payload.writePreview) === null || _a === void 0 ? void 0 : _a.displayPath,
                    previewApplyStrategy: (_b = payload.writePreview) === null || _b === void 0 ? void 0 : _b.applyStrategy,
                    previewEndsWithNewline: (_c = payload.writePreview) === null || _c === void 0 ? void 0 : _c.proposedEndsWithNewline,
                    previewNote: (_d = payload.writePreview) === null || _d === void 0 ? void 0 : _d.note,
                },
            ]).catch(() => {
                nvimClient.removeListener('notification', handler);
                void cleanup();
                resolve({ action: 'deny' });
            });
        });
        return { decision, preview: payload.writePreview };
    });
}
// str_replace and edit both invoke the same Dts handler in the CLI binary.
const EDIT_COMMANDS = new Set(['str_replace', 'edit']);
function applyStrReplaceEditorDirectly(input, workspacePath, userNewStr, state) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        const EDIT_TOOL_NAMES = new Set(['str_replace_editor', 'edit']);
        if (!EDIT_TOOL_NAMES.has(input.toolName)) {
            return undefined;
        }
        const args = (0, agentToolApproval_1.getToolArgsRecord)(input.toolArgs);
        if (!args) {
            return undefined;
        }
        // 'command' may be omitted entirely for the standalone "edit" tool.
        // Fall back to 'create' when file_text is present, otherwise str_replace.
        const command = (_a = args.command) !== null && _a !== void 0 ? _a : (typeof args.file_text === 'string' ? 'create' : 'str_replace');
        const rawPath = typeof args.path === 'string' ? args.path : undefined;
        if (!rawPath) {
            return undefined;
        }
        const filePath = path_1.default.isAbsolute(rawPath) ? rawPath : path_1.default.join(workspacePath, rawPath);
        yield fs.mkdir(path_1.default.dirname(filePath), { recursive: true });
        if (command === 'create') {
            const fileText = typeof args.file_text === 'string' ? args.file_text : '';
            const existingContent = yield readFileOrEmpty(filePath);
            // Remove any existing file so the SDK's create handler doesn't error on "already exists".
            try {
                yield fs.unlink(filePath);
            }
            catch ( /* file may not exist */_b) { /* file may not exist */ }
            state === null || state === void 0 ? void 0 : state.history.recordMutation({
                path: filePath,
                beforeContent: existingContent || null,
                afterContent: fileText,
                source: 'str_replace_editor:create',
            });
            return { permissionDecision: 'allow', modifiedArgs: Object.assign(Object.assign({}, args), { file_text: fileText }) };
        }
        if (!EDIT_COMMANDS.has(command)) {
            return undefined;
        }
        // Compute the desired final file content.
        let currentContent = '';
        try {
            currentContent = yield fs.readFile(filePath, 'utf8');
        }
        catch ( /* new file */_c) { /* new file */ }
        let finalContent;
        if (typeof userNewStr === 'string') {
            finalContent = userNewStr;
        }
        else {
            const oldStr = typeof args.old_str === 'string' ? args.old_str : '';
            const newStr = typeof args.new_str === 'string' ? args.new_str : '';
            if (oldStr && currentContent.includes(oldStr)) {
                finalContent = currentContent.replace(oldStr, newStr);
            }
            else {
                // old_str not found — agent has stale context; append the new content.
                finalContent = currentContent ? currentContent + '\n' + newStr : newStr;
            }
        }
        // Atomically write the final content ourselves, then return a no-op str_replace
        // (full-content match is trivially unique) so the SDK's handler succeeds without
        // mutating the file further.
        yield (0, fileSafety_1.atomicWriteFile)(filePath, finalContent);
        state === null || state === void 0 ? void 0 : state.history.recordMutation({
            path: filePath,
            beforeContent: currentContent || null,
            afterContent: finalContent,
            source: 'str_replace_editor',
        });
        return {
            permissionDecision: 'allow',
            modifiedArgs: Object.assign(Object.assign({}, args), { old_str: finalContent, new_str: finalContent }),
        };
    });
}
function handleConfirmTaskComplete(state, input) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        const args = (_a = (0, agentToolApproval_1.getToolArgsRecord)(input.toolArgs)) !== null && _a !== void 0 ? _a : {};
        const summary = typeof args.summary === 'string' ? args.summary : 'Ready to hear from you.';
        const rawChoices = Array.isArray(args.choices) ? args.choices : [];
        const aiChoices = rawChoices.filter((c) => typeof c === 'string');
        // Always append "End session" so the user has an explicit exit path.
        const choices = [...aiChoices, 'End session'];
        // Write the AI's question + choices into the chat file before showing the popup.
        yield appendToChat(state.chatFile, (0, agentUi_1.formatConfirmQuestion)(summary, choices));
        try {
            yield state.nvim.command('edit!');
        }
        catch ( /* nvim busy */_b) { /* nvim busy */ }
        try {
            yield state.nvim.command('redraw!');
        }
        catch ( /* nvim busy */_c) { /* nvim busy */ }
        const { answer } = yield handleAgentUserInput(state.nvim, summary, choices, true);
        if (!answer || answer.trim() === '') {
            // Dismissed — deny so AI stays in the turn and can ask again.
            yield appendToChat(state.chatFile, (0, agentUi_1.formatConfirmAnswer)('(dismissed)'));
            return {
                permissionDecision: 'deny',
                permissionDecisionReason: 'User dismissed the prompt without answering. Ask again or continue working.',
            };
        }
        // Write the user's answer into the chat file.
        yield appendToChat(state.chatFile, (0, agentUi_1.formatConfirmAnswer)(answer));
        // Write a new ASSISTANT header so the AI's continuation is visually separated.
        yield appendToChat(state.chatFile, (0, chatHeaders_1.formatAssistantHeader)(state.model));
        try {
            yield state.nvim.command('edit!');
        }
        catch ( /* nvim busy */_d) { /* nvim busy */ }
        try {
            yield state.nvim.command('redraw!');
        }
        catch ( /* nvim busy */_e) { /* nvim busy */ }
        if (answer === 'End session') {
            // User is done — allow the tool so the AI ends the turn naturally.
            return { permissionDecision: 'allow' };
        }
        // User wants to continue — deny the tool so the AI stays in the same turn
        // (free, no extra credit) and acts on the user's reply.
        return {
            permissionDecision: 'deny',
            permissionDecisionReason: `User says: "${answer}". Continue based on this reply. Do not end your turn — call confirm_task_complete again only when you need the user again.`,
        };
    });
}
// Large-file threshold in lines — above this the agent gets an outline instead of raw content.
const LARGE_FILE_LINE_THRESHOLD = 300;
// Tool names (or name fragments) that do full file reads.
const FILE_READ_TOOLS = new Set(['read_file', 'view']);
function extractFileReadPath(input, workspacePath) {
    const args = (0, agentToolApproval_1.getToolArgsRecord)(input.toolArgs);
    if (!args)
        return undefined;
    const rawPath = typeof args.path === 'string'
        ? args.path
        : typeof args.file_path === 'string'
            ? args.file_path
            : typeof args.filename === 'string'
                ? args.filename
                : Array.isArray(args.paths) && typeof args.paths[0] === 'string'
                    ? args.paths[0]
                    : undefined;
    if (!rawPath)
        return undefined;
    // str_replace_editor doubles as a viewer — only intercept the 'view' command.
    if (input.toolName === 'str_replace_editor') {
        const command = typeof args.command === 'string' ? args.command : undefined;
        if (command !== 'view')
            return undefined;
    }
    else if (!FILE_READ_TOOLS.has(input.toolName)) {
        return undefined;
    }
    return path_1.default.isAbsolute(rawPath) ? rawPath : path_1.default.join(workspacePath, rawPath);
}
function toolNameMatches(toolName, expected) {
    const lower = toolName.toLowerCase();
    return lower === expected
        || lower.endsWith(`:${expected}`)
        || lower.endsWith(`_${expected}`)
        || lower.endsWith(`-${expected}`);
}
function coerceStringList(value) {
    if (!Array.isArray(value)) {
        return undefined;
    }
    const out = value
        .filter((item) => typeof item === 'string')
        .map((item) => item.trim())
        .filter(Boolean);
    return out;
}
function maybeInterceptMemoryRead(state, input) {
    return __awaiter(this, void 0, void 0, function* () {
        const args = (0, agentToolApproval_1.getToolArgsRecord)(input.toolArgs);
        if (!args) {
            return undefined;
        }
        if (toolNameMatches(input.toolName, 'recall')) {
            const kind = typeof args.kind === 'string' ? args.kind : undefined;
            if (!kind || !(0, types_1.isMemoryLookupKind)(kind)) {
                return undefined;
            }
            const candidateInput = { kind };
            if (typeof args.query === 'string')
                candidateInput.query = args.query;
            if (typeof args.k === 'number')
                candidateInput.k = args.k;
            if (args.status === 'open' || args.status === 'resolved' || args.status === 'dismissed')
                candidateInput.status = args.status;
            const tagsAny = coerceStringList(args.tagsAny);
            if (tagsAny !== undefined)
                candidateInput.tagsAny = tagsAny;
            const candidates = yield (0, notes_1.recall)(candidateInput);
            if (candidates.length === 0) {
                return { permissionDecision: 'allow' };
            }
            const picked = yield (0, agentMemoryActions_1.pickMemories)(state.nvim, candidates, {
                title: kind === 'revisit' ? 'Select revisits for recall' : 'Select memories for recall',
            });
            if (!picked || picked.length === 0) {
                return {
                    permissionDecision: 'deny',
                    permissionDecisionReason: 'No memories were selected. Continue without memory context and do not repeat this recall unless the user asks.',
                };
            }
            return {
                permissionDecision: 'allow',
                modifiedArgs: Object.assign(Object.assign({}, args), { selectedIds: picked.map((entry) => entry.id) }),
                additionalContext: `User selected ${picked.length} ${picked.length === 1 ? 'memory' : 'memories'} from the picker. Use only the selected memory results below.`,
            };
        }
        if (toolNameMatches(input.toolName, 'semantic_search')) {
            const scope = typeof args.scope === 'string' ? args.scope : 'code';
            const memoryKind = typeof args.memoryKind === 'string' ? args.memoryKind : undefined;
            const query = typeof args.query === 'string' ? args.query.trim() : '';
            if ((scope !== 'memory' && scope !== 'both') || !memoryKind || !(0, types_1.isMemoryLookupKind)(memoryKind) || query.length === 0) {
                return undefined;
            }
            const candidateInput = { query, scope: 'memory', memoryKind };
            if (typeof args.k === 'number')
                candidateInput.k = args.k;
            const candidates = (yield (0, search_1.semanticSearch)(candidateInput))
                .flatMap((hit) => (hit.memory ? [hit.memory] : []));
            if (candidates.length === 0) {
                return { permissionDecision: 'allow' };
            }
            const picked = yield (0, agentMemoryActions_1.pickMemories)(state.nvim, candidates, {
                title: memoryKind === 'revisit' ? 'Select revisits for semantic search' : 'Select memories for semantic search',
            });
            if (!picked || picked.length === 0) {
                return {
                    permissionDecision: 'deny',
                    permissionDecisionReason: 'No memories were selected. Continue without memory context and do not repeat this semantic search unless the user asks.',
                };
            }
            return {
                permissionDecision: 'allow',
                modifiedArgs: Object.assign(Object.assign({}, args), { selectedIds: picked.map((entry) => entry.id) }),
                additionalContext: `User selected ${picked.length} ${picked.length === 1 ? 'memory' : 'memories'} from the picker. Use only the selected memory results below.`,
            };
        }
        return undefined;
    });
}
function handlePreToolUse(state, input) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c, _d;
        const toolFamily = (0, agentToolApproval_1.getToolFamily)(input.toolName);
        const workspacePath = state.cwd;
        // `confirm_task_complete` can arrive as bare name or MCP-prefixed
        // (e.g. "kra-session-complete:confirm_task_complete", or with underscores
        // depending on SDK version). Use includes() so any format matches.
        if (input.toolName.includes('confirm_task_complete')) {
            return handleConfirmTaskComplete(state, input);
        }
        if ((0, agentToolApproval_1.shouldAutoApproveTool)(input.toolName)) {
            return { permissionDecision: 'allow' };
        }
        const memoryIntercept = yield maybeInterceptMemoryRead(state, input);
        if (memoryIntercept) {
            return memoryIntercept;
        }
        // Intercept large file reads: return an outline and direct the model to the
        // kra-file-context tools (get_outline, read_lines, read_function) instead.
        const fileReadPath = extractFileReadPath(input, workspacePath);
        if (fileReadPath) {
            try {
                const outline = yield (0, fileOutline_1.getFileOutline)(fileReadPath);
                if (outline.lineCount > LARGE_FILE_LINE_THRESHOLD) {
                    return {
                        permissionDecision: 'deny',
                        permissionDecisionReason: [
                            `File has ${outline.lineCount} lines — reading it in full wastes context.`,
                            `Use the kra-file-context MCP tools instead:\n`,
                            (0, fileOutline_1.formatOutline)(fileReadPath, outline),
                            `\nAvailable tools: get_outline(file_path), read_lines(file_path, start_line, end_line) or read_lines(file_path, startLines, endLines), read_function(file_path, function_name)`,
                        ].join('\n'),
                    };
                }
            }
            catch (_e) {
                // File unreadable or not a text file — let the tool proceed normally.
            }
        }
        // Upfront cap check for edit_lines: reject ranges >100 lines BEFORE building
        // the diff or asking for approval. Saves the round-trip and gives the agent
        // an actionable error in one turn (with concrete split suggestions).
        if (input.toolName.includes('edit_lines')) {
            const editReq = (0, agentToolApproval_1.extractEditLinesRequest)(input.toolArgs, workspacePath);
            if (editReq) {
                const starts = (_a = editReq.startLines) !== null && _a !== void 0 ? _a : (editReq.startLine !== undefined ? [editReq.startLine] : []);
                const ends = (_b = editReq.endLines) !== null && _b !== void 0 ? _b : (editReq.endLine !== undefined ? [editReq.endLine] : []);
                const violations = [];
                for (let i = 0; i < starts.length; i++) {
                    const span = ends[i] - starts[i] + 1;
                    if (span > EDIT_LINES_HARD_CAP) {
                        const where = starts.length > 1 ? ` (range ${i})` : '';
                        const splitCount = Math.ceil(span / EDIT_LINES_HARD_CAP);
                        violations.push(`${starts[i]}–${ends[i]} = ${span} lines${where}; split into ${splitCount} ranges of <=${EDIT_LINES_HARD_CAP} lines each`);
                    }
                }
                if (violations.length > 0) {
                    return {
                        permissionDecision: 'deny',
                        permissionDecisionReason: [
                            `edit_lines hard cap is ${EDIT_LINES_HARD_CAP} lines per range. The following range(s) exceed it:`,
                            ...violations.map(v => `  - ${v}`),
                            '',
                            'Use the multi-edit form (startLines/endLines/newContents arrays) so non-overlapping regions go in a single call.',
                            'For a near-total file rewrite, split into multiple non-overlapping ranges that each cover <=100 lines of the original file.',
                            'Do NOT attempt to bypass this cap.',
                        ].join('\n'),
                    };
                }
            }
        }
        // Snapshot git state before any bash-family tool runs for mutation tracking.
        const isBashLikeTool = ['bash', 'shell', 'execute', 'run_terminal', 'computer'].some((fragment) => input.toolName.toLowerCase().includes(fragment));
        if (isBashLikeTool) {
            try {
                state.pendingBashSnapshot = yield state.history.bashSnapshotBefore();
            }
            catch ( /* non-fatal */_f) { /* non-fatal */ }
        }
        // Pre-read file content for edit_lines / create_file so we have an accurate
        // "before" snapshot in history regardless of approval mode.
        let preReadTargetPath;
        let preReadBeforeContent;
        if (input.toolName.includes('edit_lines')) {
            const req = (0, agentToolApproval_1.extractEditLinesRequest)(input.toolArgs, workspacePath);
            if (req === null || req === void 0 ? void 0 : req.targetPath) {
                preReadTargetPath = req.targetPath;
                preReadBeforeContent = yield readFileOrEmpty(req.targetPath);
            }
        }
        else if (input.toolName.includes('create_file')) {
            const cfArgs = (0, agentToolApproval_1.getToolArgsRecord)(input.toolArgs);
            const rawCfPath = typeof (cfArgs === null || cfArgs === void 0 ? void 0 : cfArgs.file_path) === 'string' ? cfArgs.file_path : undefined;
            if (rawCfPath) {
                preReadTargetPath = path_1.default.isAbsolute(rawCfPath) ? rawCfPath : path_1.default.join(workspacePath, rawCfPath);
                preReadBeforeContent = yield readFileOrEmpty(preReadTargetPath);
            }
        }
        if (state.approvalMode === 'yolo' || state.allowedToolFamilies.has(toolFamily)) {
            if (preReadTargetPath !== undefined && preReadBeforeContent !== undefined) {
                const cfArgs = input.toolName.includes('create_file') ? (0, agentToolApproval_1.getToolArgsRecord)(input.toolArgs) : undefined;
                state.history.recordMutation({
                    path: preReadTargetPath,
                    beforeContent: preReadBeforeContent || null,
                    afterContent: cfArgs && typeof cfArgs.content === 'string' ? cfArgs.content : null,
                    source: input.toolName.includes('edit_lines') ? 'edit_lines' : 'create_file',
                });
            }
            return (_c = (yield applyStrReplaceEditorDirectly(input, workspacePath, undefined, state))) !== null && _c !== void 0 ? _c : { permissionDecision: 'allow' };
        }
        const { decision, preview } = yield promptToolApproval(state.nvim, input, workspacePath);
        if (decision.action === 'allow-family') {
            state.allowedToolFamilies.add(toolFamily);
        }
        else if (decision.action === 'yolo') {
            state.approvalMode = 'yolo';
        }
        if (decision.action === 'deny') {
            return {
                permissionDecision: 'deny',
                permissionDecisionReason: 'Denied by user. Do not retry this tool call. Call confirm_task_complete immediately to explain what you were trying to do and ask the user what they want instead.',
            };
        }
        // For str_replace_editor: write the file ourselves so the SDK never has to match
        // old_str against disk — a mismatch-prone operation.  The diff-editor path puts
        // the user-approved final content in modifiedArgs.new_str; all other paths let
        // applyStrReplaceEditorDirectly reapply the agent's intended replacement.
        const modifiedArgs = decision.modifiedArgs;
        const userNewStr = typeof (modifiedArgs === null || modifiedArgs === void 0 ? void 0 : modifiedArgs.new_str) === 'string' ? modifiedArgs.new_str : undefined;
        const strReplaceResult = yield applyStrReplaceEditorDirectly(input, workspacePath, userNewStr, state);
        if (strReplaceResult) {
            return strReplaceResult;
        }
        // For content-field write tools (write_file etc.) approved via diff editor, keep
        // modifiedArgs so the SDK receives the user-reviewed content.
        if ((preview === null || preview === void 0 ? void 0 : preview.applyStrategy) === 'content-field' && modifiedArgs) {
            return { permissionDecision: 'allow', modifiedArgs };
        }
        // For kra-file-context create_file: record the mutation before MCP applies it.
        if (input.toolName.includes('create_file') && preReadTargetPath !== undefined && preReadBeforeContent !== undefined) {
            const cfArgs = (0, agentToolApproval_1.getToolArgsRecord)(input.toolArgs);
            state.history.recordMutation({
                path: preReadTargetPath,
                beforeContent: preReadBeforeContent || null,
                afterContent: typeof (cfArgs === null || cfArgs === void 0 ? void 0 : cfArgs.content) === 'string' ? cfArgs.content : '',
                source: 'create_file',
            });
        }
        // For edit_lines: honour user edits from the diff editor, or record the
        // before/after mutation and let the MCP server apply the agent's args.
        if (input.toolName.includes('edit_lines') && (preview === null || preview === void 0 ? void 0 : preview.applyStrategy) === 'edit-tool') {
            if (preReadTargetPath !== undefined && preReadBeforeContent !== undefined) {
                const userFinalContent = typeof (modifiedArgs === null || modifiedArgs === void 0 ? void 0 : modifiedArgs.__userFinalContent) === 'string'
                    ? modifiedArgs.__userFinalContent : undefined;
                if (userFinalContent !== undefined) {
                    state.history.recordMutation({
                        path: preReadTargetPath,
                        beforeContent: preReadBeforeContent || null,
                        afterContent: userFinalContent,
                        source: 'edit_lines:user',
                    });
                    // Transform the agent's edit_lines call into one that takes
                    // the file from preReadBeforeContent to userFinalContent. We
                    // strip the common prefix/suffix to find the changed region,
                    // then encode it as one (or more, if >100 lines) edit_lines
                    // ranges. MCP applies the edit, runs LSP diagnostics, and
                    // reports the actual line changes back to the agent. Whether
                    // the agent sees the new content or a brief notice depends on
                    // the user's choice in the diff editor (__userEditNotify).
                    const notifyAgent = (modifiedArgs === null || modifiedArgs === void 0 ? void 0 : modifiedArgs.__userEditNotify) === true;
                    const beforeLines = preReadBeforeContent.split('\n');
                    const afterLines = userFinalContent.split('\n');
                    let cp = 0;
                    const maxCommon = Math.min(beforeLines.length, afterLines.length);
                    while (cp < maxCommon && beforeLines[cp] === afterLines[cp])
                        cp++;
                    let cs = 0;
                    while (cs < maxCommon - cp
                        && beforeLines[beforeLines.length - 1 - cs] === afterLines[afterLines.length - 1 - cs])
                        cs++;
                    const editStart = cp + 1;
                    const editEnd = Math.max(beforeLines.length - cs, cp);
                    const newSliceStart = cp;
                    const newSliceEnd = afterLines.length - cs;
                    const newAfterStart = cp + 1;
                    const newAfterEnd = afterLines.length - cs;
                    const newStarts = [];
                    const newEnds = [];
                    const newContents = [];
                    if (editEnd < editStart) {
                        const { safeLine, newContent } = (0, agentToolApproval_1.buildInsertionOnlyEdit)(beforeLines, afterLines, cp, newSliceStart, newSliceEnd);
                        newStarts.push(safeLine);
                        newEnds.push(safeLine);
                        newContents.push(newContent);
                    }
                    else {
                        const beforeSpan = editEnd - editStart + 1;
                        if (beforeSpan <= EDIT_LINES_HARD_CAP) {
                            newStarts.push(editStart);
                            newEnds.push(editEnd);
                            newContents.push(afterLines.slice(newSliceStart, newSliceEnd).join('\n'));
                        }
                        else {
                            // Split into ≤100-line ranges in the BEFORE file. MCP
                            // applies bottom-to-top, so each range's start/end
                            // refer to original line numbers. Distribute the
                            // after-side lines proportionally; the last chunk
                            // soaks up any leftover lines.
                            const chunkCount = Math.ceil(beforeSpan / EDIT_LINES_HARD_CAP);
                            const newRegionLines = afterLines.slice(newSliceStart, newSliceEnd);
                            const newPerChunk = Math.floor(newRegionLines.length / chunkCount);
                            let consumedBefore = 0;
                            let consumedAfter = 0;
                            for (let c = 0; c < chunkCount; c++) {
                                const isLast = c === chunkCount - 1;
                                const chunkBefore = isLast
                                    ? beforeSpan - consumedBefore
                                    : Math.min(EDIT_LINES_HARD_CAP, beforeSpan - consumedBefore);
                                const chunkAfter = isLast
                                    ? newRegionLines.length - consumedAfter
                                    : newPerChunk;
                                const s = editStart + consumedBefore;
                                const e = s + chunkBefore - 1;
                                const slice = newRegionLines.slice(consumedAfter, consumedAfter + chunkAfter).join('\n');
                                newStarts.push(s);
                                newEnds.push(e);
                                newContents.push(slice);
                                consumedBefore += chunkBefore;
                                consumedAfter += chunkAfter;
                            }
                        }
                    }
                    const args = (_d = (0, agentToolApproval_1.getToolArgsRecord)(input.toolArgs)) !== null && _d !== void 0 ? _d : {};
                    const useMulti = Array.isArray(args.startLines) || newStarts.length > 1;
                    const newArgs = Object.assign({}, args);
                    delete newArgs.__userFinalContent;
                    delete newArgs.__userEditNotify;
                    if (useMulti) {
                        newArgs.startLines = newStarts;
                        newArgs.endLines = newEnds;
                        newArgs.newContents = newContents;
                        delete newArgs.start_line;
                        delete newArgs.end_line;
                        delete newArgs.new_content;
                    }
                    else {
                        newArgs.start_line = newStarts[0];
                        newArgs.end_line = newEnds[0];
                        newArgs.new_content = newContents[0];
                        delete newArgs.startLines;
                        delete newArgs.endLines;
                        delete newArgs.newContents;
                    }
                    let context;
                    if (notifyAgent) {
                        const affectedAfterLines = afterLines.slice(newSliceStart, newSliceEnd);
                        let previewText;
                        let rangeLabel;
                        if (affectedAfterLines.length === 0) {
                            previewText = '(the affected region is now empty)';
                            rangeLabel = `near line ${newAfterStart}`;
                        }
                        else {
                            previewText = affectedAfterLines
                                .map((l, i) => `${newAfterStart + i}: ${l}`)
                                .join('\n');
                            rangeLabel = `lines ${newAfterStart}\u2013${newAfterEnd}`;
                        }
                        context =
                            `The user reviewed your proposed edit in the diff editor and adjusted it before applying. ` +
                                `${preReadTargetPath} now contains the user's final version. The post-edit content of the ` +
                                `affected region (${rangeLabel}) is:\n${previewText}`;
                    }
                    else {
                        context =
                            `The user reviewed your proposed edit in the diff editor and adjusted it before applying. ` +
                                `${preReadTargetPath} now contains the user's final version. They chose not to surface ` +
                                `the exact post-edit lines \u2014 assume the change is fine if no LSP diagnostics were ` +
                                `reported by the tool result. Only call read_lines if you specifically need to inspect ` +
                                `the new content.`;
                    }
                    return {
                        permissionDecision: 'allow',
                        modifiedArgs: newArgs,
                        additionalContext: context,
                    };
                }
                state.history.recordMutation({
                    path: preReadTargetPath,
                    beforeContent: preReadBeforeContent || null,
                    afterContent: preview.proposedContent,
                    source: 'edit_lines',
                });
            }
            return { permissionDecision: 'allow' };
        }
        if (decision.modifiedArgs) {
            return { permissionDecision: 'allow', modifiedArgs: decision.modifiedArgs };
        }
        return { permissionDecision: 'allow' };
    });
}
