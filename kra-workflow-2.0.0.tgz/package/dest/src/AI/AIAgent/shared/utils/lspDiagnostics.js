"use strict";
/**
 * Lightweight TypeScript diagnostics for the agent's edit/create tools.
 *
 * Uses the in-process TypeScript Compiler API (already a dep) instead of
 * spawning typescript-language-server — no JSON-RPC, no extra binary, and
 * we share the LanguageService across edits in the same session so warm
 * checks are sub-second.
 *
 * Public entry point: getDiagnosticsForFile(filePath) — returns a formatted
 * string of errors+warnings for that single file, or undefined if there are
 * none, the file is not a TS/JS source, or the project couldn't be loaded.
 *
 * The MCP server appends the result to edit_lines / create_file responses so
 * the agent sees type errors in the same turn it made the change.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.getDiagnosticsForFile = getDiagnosticsForFile;
const ts = __importStar(require("typescript"));
const path = __importStar(require("path"));
const fs = __importStar(require("fs"));
const TS_EXTS = new Set(['.ts', '.tsx', '.mts', '.cts', '.js', '.jsx', '.mjs', '.cjs']);
const MAX_DIAGNOSTICS = 20;
const projects = new Map();
function loadProject(filePath) {
    const configPath = ts.findConfigFile(path.dirname(filePath), ts.sys.fileExists, 'tsconfig.json');
    const rootDir = configPath ? path.dirname(configPath) : path.dirname(filePath);
    const key = configPath !== null && configPath !== void 0 ? configPath : rootDir;
    const existing = projects.get(key);
    if (existing)
        return existing;
    let compilerOptions = ts.getDefaultCompilerOptions();
    let rootFiles = new Set();
    if (configPath) {
        const configFile = ts.readConfigFile(configPath, ts.sys.readFile);
        if (configFile.error || !configFile.config)
            return undefined;
        const parsed = ts.parseJsonConfigFileContent(configFile.config, ts.sys, rootDir, undefined, configPath);
        compilerOptions = parsed.options;
        rootFiles = new Set(parsed.fileNames.map((f) => path.resolve(f)));
    }
    const project = {
        rootDir,
        compilerOptions,
        rootFiles,
        fileVersions: new Map(),
        fileSnapshots: new Map(),
        // Set after host construction below.
        service: null,
    };
    const host = {
        getScriptFileNames: () => Array.from(new Set([...project.rootFiles, ...project.fileSnapshots.keys()])),
        getScriptVersion: (f) => { var _a; return String((_a = project.fileVersions.get(path.resolve(f))) !== null && _a !== void 0 ? _a : 0); },
        getScriptSnapshot: (f) => {
            var _a;
            const abs = path.resolve(f);
            const snap = project.fileSnapshots.get(abs);
            if (snap !== undefined)
                return ts.ScriptSnapshot.fromString(snap);
            if (!ts.sys.fileExists(abs))
                return undefined;
            return ts.ScriptSnapshot.fromString((_a = ts.sys.readFile(abs)) !== null && _a !== void 0 ? _a : '');
        },
        getCurrentDirectory: () => rootDir,
        getCompilationSettings: () => compilerOptions,
        getDefaultLibFileName: ts.getDefaultLibFilePath,
        fileExists: ts.sys.fileExists,
        readFile: ts.sys.readFile,
        readDirectory: ts.sys.readDirectory,
        directoryExists: ts.sys.directoryExists,
        getDirectories: ts.sys.getDirectories,
    };
    project.service = ts.createLanguageService(host, ts.createDocumentRegistry());
    projects.set(key, project);
    return project;
}
function formatDiagnostic(d) {
    const msg = ts.flattenDiagnosticMessageText(d.messageText, '\n  ');
    const sev = d.category === ts.DiagnosticCategory.Error ? 'error' : 'warning';
    if (d.file && d.start !== undefined) {
        const { line, character } = d.file.getLineAndCharacterOfPosition(d.start);
        return `  L${line + 1}:${character + 1}  ${sev} TS${d.code}: ${msg}`;
    }
    return `  ${sev} TS${d.code}: ${msg}`;
}
function getDiagnosticsForFile(filePath) {
    var _a;
    const ext = path.extname(filePath).toLowerCase();
    if (!TS_EXTS.has(ext))
        return undefined;
    const absPath = path.resolve(filePath);
    let project;
    try {
        project = loadProject(absPath);
    }
    catch (_b) {
        return undefined;
    }
    if (!project)
        return undefined;
    let content;
    try {
        content = fs.readFileSync(absPath, 'utf8');
    }
    catch (_c) {
        return undefined;
    }
    const v = ((_a = project.fileVersions.get(absPath)) !== null && _a !== void 0 ? _a : 0) + 1;
    project.fileVersions.set(absPath, v);
    project.fileSnapshots.set(absPath, content);
    project.rootFiles.add(absPath);
    let diagnostics;
    try {
        diagnostics = [
            ...project.service.getSyntacticDiagnostics(absPath),
            ...project.service.getSemanticDiagnostics(absPath),
        ];
    }
    catch (_d) {
        return undefined;
    }
    // Filter out anything below warning so suggestions/messages don't pollute.
    const filtered = diagnostics.filter((d) => d.category === ts.DiagnosticCategory.Error || d.category === ts.DiagnosticCategory.Warning);
    if (filtered.length === 0)
        return undefined;
    const shown = filtered.slice(0, MAX_DIAGNOSTICS).map(formatDiagnostic);
    const more = filtered.length > MAX_DIAGNOSTICS
        ? `\n  ...and ${filtered.length - MAX_DIAGNOSTICS} more`
        : '';
    return `Diagnostics for ${path.relative(project.rootDir, absPath) || path.basename(absPath)} (${filtered.length}):\n${shown.join('\n')}${more}`;
}
