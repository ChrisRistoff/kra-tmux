"use strict";
/**
 * Generic Language Server Protocol client wrapper.
 *
 * Spawns an external LSP server (gopls, pyright, rust-analyzer, ...) as a
 * child process and speaks LSP JSON-RPC to it via vscode-languageserver-protocol.
 *
 * Lifecycle:
 *   const client = new LspClient(spec, workspaceRoot);
 *   await client.start();              // spawn + initialize + initialized
 *   await client.openFile(absPath);    // textDocument/didOpen (idempotent)
 *   const result = await client.sendRequest(HoverRequest.type, params);
 *   await client.shutdown();           // shutdown + exit + kill
 *
 * One client instance == one running language server == one (server, root)
 * pair. The registry decides when to spawn / reuse / shut down.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LspClient = void 0;
exports.languageIdForFile = languageIdForFile;
exports.fileUri = fileUri;
exports.uriToPath = uriToPath;
const child_process_1 = require("child_process");
const fs = __importStar(require("fs/promises"));
const path = __importStar(require("path"));
const url_1 = require("url");
const node_js_1 = require("vscode-languageserver-protocol/node.js");
const EXT_TO_LANGUAGE_ID = {
    '.go': 'go',
    '.py': 'python',
    '.pyi': 'python',
    '.ts': 'typescript',
    '.tsx': 'typescriptreact',
    '.mts': 'typescript',
    '.cts': 'typescript',
    '.js': 'javascript',
    '.jsx': 'javascriptreact',
    '.mjs': 'javascript',
    '.cjs': 'javascript',
    '.rs': 'rust',
    '.java': 'java',
    '.c': 'c',
    '.h': 'c',
    '.cc': 'cpp',
    '.cpp': 'cpp',
    '.cxx': 'cpp',
    '.hpp': 'cpp',
    '.cs': 'csharp',
    '.rb': 'ruby',
    '.php': 'php',
    '.lua': 'lua',
};
function languageIdForFile(filePath) {
    var _a;
    return (_a = EXT_TO_LANGUAGE_ID[path.extname(filePath).toLowerCase()]) !== null && _a !== void 0 ? _a : 'plaintext';
}
function fileUri(absPath) {
    return (0, url_1.pathToFileURL)(absPath).href;
}
function uriToPath(uri) {
    try {
        return (0, url_1.fileURLToPath)(uri);
    }
    catch (_a) {
        return uri;
    }
}
class LspClient {
    constructor(spec, workspaceRoot) {
        this.openDocs = new Map();
        this.diagnostics = new Map();
        this.stopped = false;
        this.spec = spec;
        this.workspaceRoot = workspaceRoot;
    }
    get root() {
        return this.workspaceRoot;
    }
    get serverId() {
        return this.spec.id;
    }
    get capabilities() {
        var _a;
        return (_a = this.initResult) === null || _a === void 0 ? void 0 : _a.capabilities;
    }
    isAlive() {
        return !this.stopped && this.proc !== undefined && this.proc.exitCode === null;
    }
    start() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.startPromise)
                return this.startPromise;
            this.startPromise = this.doStart();
            return this.startPromise;
        });
    }
    doStart() {
        return __awaiter(this, void 0, void 0, function* () {
            var _a;
            const proc = (0, child_process_1.spawn)(this.spec.cmd, this.spec.args, {
                cwd: this.workspaceRoot,
                env: this.spec.env ? Object.assign(Object.assign({}, process.env), this.spec.env) : process.env,
                stdio: ['pipe', 'pipe', 'pipe'],
            });
            this.proc = proc;
            // Without an 'error' listener, a spawn failure (ENOENT, EACCES) emits
            // an uncaught error event that crashes the parent (the MCP server).
            proc.on('error', () => { this.stopped = true; });
            proc.stderr.on('data', () => { });
            // Stream 'error' events on stdin/stdout/stderr (e.g. EPIPE when the
            // child dies mid-write) are also fatal without a listener.
            proc.stderr.on('error', () => { this.stopped = true; });
            proc.on('exit', () => {
                this.stopped = true;
            });
            if (!proc.stdout || !proc.stdin) {
                throw new Error(`LSP ${this.spec.id}: failed to acquire stdio pipes`);
            }
            proc.stdin.on('error', () => { this.stopped = true; });
            proc.stdout.on('error', () => { this.stopped = true; });
            const connection = (0, node_js_1.createProtocolConnection)(new node_js_1.StreamMessageReader(proc.stdout), new node_js_1.StreamMessageWriter(proc.stdin));
            this.connection = connection;
            connection.onNotification(node_js_1.PublishDiagnosticsNotification.type, (params) => {
                this.diagnostics.set(uriToPath(params.uri), params.diagnostics);
            });
            connection.onUnhandledNotification(() => { });
            connection.listen();
            const initParams = {
                processId: process.pid,
                clientInfo: { name: 'kra-agent-lsp', version: '0.1.0' },
                rootUri: fileUri(this.workspaceRoot),
                workspaceFolders: [{ uri: fileUri(this.workspaceRoot), name: path.basename(this.workspaceRoot) }],
                capabilities: {
                    textDocument: {
                        synchronization: { didSave: true, dynamicRegistration: false },
                        hover: { contentFormat: ['markdown', 'plaintext'] },
                        definition: { linkSupport: true },
                        typeDefinition: { linkSupport: true },
                        implementation: { linkSupport: true },
                        references: {},
                        documentSymbol: { hierarchicalDocumentSymbolSupport: true },
                        publishDiagnostics: { relatedInformation: true },
                        diagnostic: { dynamicRegistration: false, relatedDocumentSupport: true },
                        rename: { prepareSupport: true },
                    },
                    workspace: {
                        workspaceFolders: true,
                        configuration: false,
                    },
                },
                initializationOptions: (_a = this.spec.initOptions) !== null && _a !== void 0 ? _a : null,
            };
            this.initResult = yield this.withTimeout(connection.sendRequest(node_js_1.InitializeRequest.type, initParams), this.spec.spawnTimeoutMs, `${this.spec.id} initialize`);
            connection.sendNotification(node_js_1.InitializedNotification.type, {}).catch(() => { });
        });
    }
    withTimeout(promise, ms, label) {
        return __awaiter(this, void 0, void 0, function* () {
            let timer;
            const timeout = new Promise((_, reject) => {
                timer = setTimeout(() => reject(new Error(`LSP ${label} timed out after ${ms}ms`)), ms);
            });
            try {
                return yield Promise.race([promise, timeout]);
            }
            finally {
                if (timer)
                    clearTimeout(timer);
            }
        });
    }
    openFile(absPath) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.connection)
                throw new Error(`LSP ${this.spec.id} not started`);
            if (this.openDocs.has(absPath)) {
                yield this.refreshFile(absPath);
                return;
            }
            const text = yield fs.readFile(absPath, 'utf8');
            const languageId = languageIdForFile(absPath);
            this.openDocs.set(absPath, { version: 1, languageId, text });
            yield this.connection.sendNotification(node_js_1.DidOpenTextDocumentNotification.type, {
                textDocument: {
                    uri: fileUri(absPath),
                    languageId,
                    version: 1,
                    text,
                },
            });
        });
    }
    refreshFile(absPath) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.connection)
                return;
            const doc = this.openDocs.get(absPath);
            if (!doc) {
                yield this.openFile(absPath);
                return;
            }
            let text;
            try {
                text = yield fs.readFile(absPath, 'utf8');
            }
            catch (_a) {
                return;
            }
            if (text === doc.text)
                return;
            doc.version += 1;
            doc.text = text;
            yield this.connection.sendNotification(node_js_1.DidChangeTextDocumentNotification.type, {
                textDocument: { uri: fileUri(absPath), version: doc.version },
                contentChanges: [{ text }],
            });
            this.diagnostics.delete(absPath);
        });
    }
    isOpen(absPath) {
        return this.openDocs.has(absPath);
    }
    getOpenText(absPath) {
        var _a;
        return (_a = this.openDocs.get(absPath)) === null || _a === void 0 ? void 0 : _a.text;
    }
    sendRequest(type, params) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.connection)
                throw new Error(`LSP ${this.spec.id} not started`);
            return this.withTimeout(this.connection.sendRequest(type.method, params), this.spec.requestTimeoutMs, `${this.spec.id} ${type.method}`);
        });
    }
    getCachedDiagnostics(absPath) {
        return this.diagnostics.get(absPath);
    }
    syncKind() {
        var _a;
        const sync = (_a = this.initResult) === null || _a === void 0 ? void 0 : _a.capabilities.textDocumentSync;
        if (typeof sync === 'number')
            return sync;
        if (sync && typeof sync === 'object' && 'change' in sync && typeof sync.change === 'number') {
            return sync.change;
        }
        return node_js_1.TextDocumentSyncKind.Full;
    }
    shutdown() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.stopped)
                return;
            this.stopped = true;
            const conn = this.connection;
            const proc = this.proc;
            try {
                if (conn) {
                    yield Promise.race([
                        conn.sendRequest(node_js_1.ShutdownRequest.type),
                        new Promise((resolve) => setTimeout(resolve, 1000)),
                    ]);
                    conn.sendNotification(node_js_1.ExitNotification.type).catch(() => { });
                    conn.dispose();
                }
            }
            catch (_a) {
                // Server might already be dead; fall through to kill.
            }
            if (proc && proc.exitCode === null) {
                proc.kill();
            }
        });
    }
}
exports.LspClient = LspClient;
