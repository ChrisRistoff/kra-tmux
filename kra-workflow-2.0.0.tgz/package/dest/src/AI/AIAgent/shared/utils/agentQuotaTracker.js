"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.setupQuotaTracking = setupQuotaTracking;
const fs = __importStar(require("fs/promises"));
const path_1 = __importDefault(require("path"));
const filePaths_1 = require("@/filePaths");
const QUOTA_WARN_THRESHOLDS = [50, 25, 10];
const quotaCachePath = () => path_1.default.join((0, filePaths_1.kraHome)(), 'quota-cache.json');
/**
 * Listen for `assistant.usage` events on the session, persist quota snapshots
 * to disk for `kra ai quota` to read, and emit a console warning the first time
 * a quota crosses each threshold (50% / 25% / 10% remaining).
 */
function setupQuotaTracking(state) {
    const warnedThresholds = new Set();
    state.session.on('assistant.usage', (event) => {
        var _a;
        const snapshots = event.data.quotaSnapshots;
        if (!snapshots)
            return;
        // Persist for `kra ai quota` to read
        const cache = {};
        for (const [id, snap] of Object.entries(snapshots)) {
            cache[id] = {
                remainingPercentage: snap.remainingPercentage,
                resetDate: (_a = snap.resetDate) !== null && _a !== void 0 ? _a : null,
                isUnlimitedEntitlement: snap.isUnlimitedEntitlement,
            };
        }
        const cachePath = quotaCachePath();
        fs.mkdir(path_1.default.dirname(cachePath), { recursive: true })
            .then(() => __awaiter(this, void 0, void 0, function* () { return fs.writeFile(cachePath, JSON.stringify({ updatedAt: new Date().toISOString(), snapshots: cache }, null, 2)); }))
            .catch(() => { });
        for (const [quotaId, snap] of Object.entries(snapshots)) {
            if (snap.isUnlimitedEntitlement)
                continue;
            const pct = snap.remainingPercentage;
            const resetDate = snap.resetDate ? new Date(snap.resetDate).toLocaleString() : 'unknown';
            for (const threshold of QUOTA_WARN_THRESHOLDS) {
                const key = `${quotaId}:${threshold}`;
                if (pct <= threshold && !warnedThresholds.has(key)) {
                    warnedThresholds.add(key);
                    const label = quotaId === 'weekly' ? 'weekly usage limit' : `${quotaId} usage limit`;
                    const color = pct <= 10 ? '\x1b[31m' : '\x1b[33m';
                    console.warn(`\n${color}⚠ You've used over ${100 - threshold}% of your ${label}. Resets: ${resetDate}\x1b[0m\n`);
                }
            }
        }
    });
}
