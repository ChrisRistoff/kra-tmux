"use strict";
/**
 * Bridge between the post-edit `withDiagnostics()` hook in
 * fileContextMcpServer.ts and the generic LSP layer.
 *
 * For any file with a configured language server, asks that server for
 * diagnostics (errors + warnings) using pull mode (`textDocument/diagnostic`)
 * if the server advertises a diagnosticProvider, falling back to push mode
 * (cached `publishDiagnostics`) with a short timed wait otherwise.
 *
 * Output format mirrors the legacy in-process TS diagnostics formatter so
 * downstream rendering is identical.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getLspDiagnosticsForFile = getLspDiagnosticsForFile;
const path = __importStar(require("path"));
const lspRegistry_1 = require("./lspRegistry");
const lspClient_1 = require("./lspClient");
const node_js_1 = require("vscode-languageserver-protocol/node.js");
const DEFAULT_PUSH_WAIT_MS = 800;
const MAX_DIAGNOSTICS = 20;
function severityLabel(sev) {
    switch (sev) {
        case node_js_1.DiagnosticSeverity.Error: return 'error';
        case node_js_1.DiagnosticSeverity.Warning: return 'warning';
        case node_js_1.DiagnosticSeverity.Information: return 'info';
        case node_js_1.DiagnosticSeverity.Hint: return 'hint';
        default: return 'diagnostic';
    }
}
function formatOne(d) {
    const line = d.range.start.line + 1;
    const col = d.range.start.character + 1;
    const sev = severityLabel(d.severity);
    const code = d.code !== undefined ? ` ${String(d.code)}` : '';
    const msg = d.message.replace(/\n+/g, '\n  ');
    return `  L${line}:${col}  ${sev}${code}: ${msg}`;
}
function isErrorOrWarning(d) {
    if (d.severity === undefined)
        return true; // be conservative
    return d.severity === node_js_1.DiagnosticSeverity.Error || d.severity === node_js_1.DiagnosticSeverity.Warning;
}
/**
 * Returns a formatted diagnostics block for the file, or undefined when the
 * file has no configured server, the server can't be reached, or the file
 * has no error/warning diagnostics.
 */
function getLspDiagnosticsForFile(filePath_1) {
    return __awaiter(this, arguments, void 0, function* (filePath, waitMs = DEFAULT_PUSH_WAIT_MS) {
        var _a;
        const absPath = path.resolve(filePath);
        let registry;
        try {
            registry = yield (0, lspRegistry_1.getLspRegistry)();
        }
        catch (_b) {
            return undefined;
        }
        if (!registry.hasServerFor(absPath))
            return undefined;
        let client;
        try {
            client = yield registry.getClientFor(absPath);
        }
        catch (_c) {
            return undefined;
        }
        if (!client)
            return undefined;
        try {
            // Re-sync content first; the file may have just been edited.
            yield client.refreshFile(absPath);
            yield client.openFile(absPath);
        }
        catch (_d) {
            return undefined;
        }
        const uri = (0, lspClient_1.fileUri)(absPath);
        const supportsPull = ((_a = client.capabilities) === null || _a === void 0 ? void 0 : _a.diagnosticProvider) !== undefined;
        let diags;
        if (supportsPull) {
            try {
                const report = yield client.sendRequest(node_js_1.DocumentDiagnosticRequest.type, { textDocument: { uri } });
                diags = report === null || report === void 0 ? void 0 : report.items;
            }
            catch (_e) {
                // Fall through to push mode.
            }
        }
        if (!diags) {
            diags = client.getCachedDiagnostics(absPath);
            if (!diags && waitMs > 0) {
                const deadline = Date.now() + waitMs;
                const step = 50;
                while (Date.now() < deadline) {
                    yield new Promise((resolve) => setTimeout(resolve, step));
                    diags = client.getCachedDiagnostics(absPath);
                    if (diags)
                        break;
                }
            }
        }
        if (!diags)
            return undefined;
        const filtered = diags.filter(isErrorOrWarning);
        if (filtered.length === 0)
            return undefined;
        const shown = filtered.slice(0, MAX_DIAGNOSTICS).map(formatOne);
        const more = filtered.length > MAX_DIAGNOSTICS
            ? `\n  ...and ${filtered.length - MAX_DIAGNOSTICS} more`
            : '';
        const rel = path.relative(process.cwd(), absPath) || path.basename(absPath);
        return `Diagnostics for ${rel} (${filtered.length}):\n${shown.join('\n')}${more}`;
    });
}
