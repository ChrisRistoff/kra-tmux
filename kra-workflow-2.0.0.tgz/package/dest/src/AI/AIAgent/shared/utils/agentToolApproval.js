"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.coerceNumberArray = coerceNumberArray;
exports.coerceNumber = coerceNumber;
exports.getToolArgsRecord = getToolArgsRecord;
exports.getToolFamily = getToolFamily;
exports.shouldAutoApproveTool = shouldAutoApproveTool;
exports.extractWriteRequest = extractWriteRequest;
exports.extractEditRequest = extractEditRequest;
exports.extractEditLinesRequest = extractEditLinesRequest;
exports.buildInsertionOnlyEdit = buildInsertionOnlyEdit;
const path_1 = __importDefault(require("path"));
function isRecord(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
// Some agents (notably reasoning models) occasionally JSON-encode array or
// number fields, so we receive `"[1, 5]"` instead of `[1, 5]`. Try to recover
// the structured value before falling back to undefined.
function coerceArray(value) {
    if (Array.isArray(value))
        return value;
    if (typeof value === 'string') {
        try {
            const parsed = JSON.parse(value);
            return Array.isArray(parsed) ? parsed : undefined;
        }
        catch (_a) {
            return undefined;
        }
    }
    return undefined;
}
function coerceNumberArray(value) {
    const arr = coerceArray(value);
    if (!arr)
        return undefined;
    const out = [];
    for (const v of arr) {
        if (typeof v === 'number' && Number.isFinite(v)) {
            out.push(v);
        }
        else if (typeof v === 'string' && v.trim() !== '' && Number.isFinite(Number(v))) {
            out.push(Number(v));
        }
        else {
            return undefined;
        }
    }
    return out;
}
function coerceStringArray(value) {
    const arr = coerceArray(value);
    if (!arr)
        return undefined;
    const out = [];
    for (const v of arr) {
        if (typeof v === 'string') {
            out.push(v);
        }
        else {
            return undefined;
        }
    }
    return out;
}
function coerceNumber(value) {
    if (typeof value === 'number' && Number.isFinite(value))
        return value;
    if (typeof value === 'string' && value.trim() !== '' && Number.isFinite(Number(value))) {
        return Number(value);
    }
    return undefined;
}
function getToolArgsRecord(toolArgs) {
    if (isRecord(toolArgs)) {
        return toolArgs;
    }
    if (typeof toolArgs === 'string') {
        try {
            const parsed = JSON.parse(toolArgs);
            return isRecord(parsed) ? parsed : undefined;
        }
        catch (_a) {
            return undefined;
        }
    }
    return undefined;
}
function getToolFamily(toolName) {
    return toolName;
}
function shouldAutoApproveTool(toolName) {
    return toolName === 'report_intent';
}
function extractWriteRequest(toolArgs, workspacePath) {
    const args = getToolArgsRecord(toolArgs);
    if (!args) {
        return undefined;
    }
    const rawPath = typeof args.path === 'string'
        ? args.path
        : typeof args.file_path === 'string'
            ? args.file_path
            : typeof args.fileName === 'string'
                ? args.fileName
                : undefined;
    const contentField = typeof args.content === 'string'
        ? 'content'
        : typeof args.newContent === 'string'
            ? 'newContent'
            : undefined;
    if (!rawPath || !contentField) {
        return undefined;
    }
    return {
        contentField,
        displayPath: rawPath,
        nextContent: args[contentField],
        targetPath: path_1.default.isAbsolute(rawPath)
            ? rawPath
            : path_1.default.join(workspacePath, rawPath),
    };
}
function extractEditRequest(toolArgs, workspacePath) {
    const args = getToolArgsRecord(toolArgs);
    if (!args || typeof args.path !== 'string' || typeof args.new_str !== 'string') {
        return undefined;
    }
    return typeof args.old_str === 'string'
        ? {
            displayPath: args.path,
            newString: args.new_str,
            oldString: args.old_str,
            targetPath: path_1.default.isAbsolute(args.path)
                ? args.path
                : path_1.default.join(workspacePath, args.path),
        }
        : {
            displayPath: args.path,
            newString: args.new_str,
            targetPath: path_1.default.isAbsolute(args.path)
                ? args.path
                : path_1.default.join(workspacePath, args.path),
        };
}
function extractEditLinesRequest(toolArgs, workspacePath) {
    const args = getToolArgsRecord(toolArgs);
    if (!args)
        return undefined;
    const rawPath = typeof args.file_path === 'string' ? args.file_path : undefined;
    if (!rawPath)
        return undefined;
    const targetPath = path_1.default.isAbsolute(rawPath) ? rawPath : path_1.default.join(workspacePath, rawPath);
    // Multi-edit (array) form — accept real arrays OR JSON-encoded strings.
    const startLines = coerceNumberArray(args.startLines);
    const endLines = coerceNumberArray(args.endLines);
    const newContents = coerceStringArray(args.newContents);
    if (startLines && endLines && newContents) {
        return { displayPath: rawPath, targetPath, startLines, endLines, newContents };
    }
    // Single-edit form
    const startLine = coerceNumber(args.start_line);
    const endLine = coerceNumber(args.end_line);
    const newContent = typeof args.new_content === 'string' ? args.new_content : undefined;
    if (startLine === undefined || endLine === undefined || newContent === undefined) {
        return undefined;
    }
    return { displayPath: rawPath, endLine, newContent, startLine, targetPath };
}
function buildInsertionOnlyEdit(beforeLines, afterLines, commonPrefixLines, newSliceStart, newSliceEnd) {
    var _a;
    const safeLine = Math.min(Math.max(commonPrefixLines + 1, 1), Math.max(beforeLines.length, 1));
    const original = (_a = beforeLines[safeLine - 1]) !== null && _a !== void 0 ? _a : '';
    const insertedLines = afterLines.slice(newSliceStart, newSliceEnd);
    // Insertions inside the BEFORE file belong before the anchor line; true EOF
    // appends without a trailing newline must keep the last real line first.
    const insertBeforeAnchor = commonPrefixLines < beforeLines.length;
    const replacementLines = insertBeforeAnchor
        ? [...insertedLines, original]
        : [original, ...insertedLines];
    return { safeLine, newContent: replacementLines.join('\n') };
}
