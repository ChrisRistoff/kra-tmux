"use strict";
/**
 * LSP server registry.
 *
 * Reads `[lsp.<id>]` blocks from settings, maps file extensions to server
 * specs, resolves a per-file workspace root via root-marker walk, and caches
 * one running `LspClient` per (serverId, workspaceRoot) pair.
 *
 * Clients are spawned lazily on the first `getClientFor()` call for a given
 * pair, kept alive for the lifetime of the host process, and shut down via
 * the registered exit hooks.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LspRegistry = void 0;
exports.getLspRegistry = getLspRegistry;
const fs = __importStar(require("fs/promises"));
const path = __importStar(require("path"));
const common_1 = require("@/utils/common");
const lspClient_1 = require("./lspClient");
const DEFAULT_ROOT_MARKERS = ['.git'];
const DEFAULT_SPAWN_TIMEOUT_MS = 30000;
const DEFAULT_REQUEST_TIMEOUT_MS = 10000;
let registryPromise;
function getLspRegistry() {
    return __awaiter(this, void 0, void 0, function* () {
        if (!registryPromise) {
            registryPromise = LspRegistry.load();
        }
        return registryPromise;
    });
}
class LspRegistry {
    constructor() {
        this.extToEntry = new Map();
        this.clients = new Map();
        this.shuttingDown = false;
    }
    static load() {
        return __awaiter(this, void 0, void 0, function* () {
            var _a;
            const settings = yield (0, common_1.loadSettings)();
            const reg = new LspRegistry();
            const lsp = (_a = settings.lsp) !== null && _a !== void 0 ? _a : {};
            for (const [id, spec] of Object.entries(lsp)) {
                if (spec.active === false)
                    continue;
                for (const ext of spec.extensions) {
                    const norm = ext.startsWith('.') ? ext.toLowerCase() : `.${ext.toLowerCase()}`;
                    reg.extToEntry.set(norm, { id, settings: spec });
                }
            }
            reg.installShutdownHooks();
            return reg;
        });
    }
    installShutdownHooks() {
        const handler = () => { this.shutdownAll().catch(() => { }); };
        process.once('exit', handler);
        process.once('SIGINT', () => { void this.shutdownAll().catch(() => undefined).then(() => process.exit(130)); });
        process.once('SIGTERM', () => { void this.shutdownAll().catch(() => undefined).then(() => process.exit(143)); });
    }
    hasServerFor(filePath) {
        return this.extToEntry.has(path.extname(filePath).toLowerCase());
    }
    /**
     * Returns a started client for the given file, or undefined when no LSP
     * is configured for the file's extension. Spawns lazily; subsequent calls
     * for the same (server, root) reuse the same client.
     */
    getClientFor(filePath) {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.shuttingDown)
                return undefined;
            const abs = path.resolve(filePath);
            const ext = path.extname(abs).toLowerCase();
            const entry = this.extToEntry.get(ext);
            if (!entry)
                return undefined;
            const markers = entry.settings.rootMarkers && entry.settings.rootMarkers.length > 0
                ? entry.settings.rootMarkers
                : DEFAULT_ROOT_MARKERS;
            const root = yield resolveWorkspaceRoot(abs, markers);
            const key = `${entry.id}\u0000${root}`;
            let client = this.clients.get(key);
            if (client && !client.isAlive()) {
                this.clients.delete(key);
                client = undefined;
            }
            if (!client) {
                const spec = toSpec(entry);
                client = new lspClient_1.LspClient(spec, root);
                this.clients.set(key, client);
                try {
                    yield client.start();
                }
                catch (err) {
                    this.clients.delete(key);
                    throw err;
                }
            }
            else {
                yield client.start();
            }
            return client;
        });
    }
    listConfiguredExtensions() {
        return Array.from(this.extToEntry.keys()).sort();
    }
    listLiveClients() {
        return Array.from(this.clients.values()).filter(c => c.isAlive());
    }
    shutdownAll() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.shuttingDown)
                return;
            this.shuttingDown = true;
            const clients = Array.from(this.clients.values());
            this.clients.clear();
            yield Promise.allSettled(clients.map((c) => __awaiter(this, void 0, void 0, function* () { return c.shutdown(); })));
        });
    }
}
exports.LspRegistry = LspRegistry;
function toSpec(entry) {
    var _a, _b, _c;
    return {
        id: entry.id,
        cmd: entry.settings.cmd,
        args: (_a = entry.settings.args) !== null && _a !== void 0 ? _a : [],
        env: entry.settings.env,
        initOptions: entry.settings.initOptions,
        spawnTimeoutMs: (_b = entry.settings.spawnTimeoutMs) !== null && _b !== void 0 ? _b : DEFAULT_SPAWN_TIMEOUT_MS,
        requestTimeoutMs: (_c = entry.settings.requestTimeoutMs) !== null && _c !== void 0 ? _c : DEFAULT_REQUEST_TIMEOUT_MS,
    };
}
function resolveWorkspaceRoot(absFilePath, markers) {
    return __awaiter(this, void 0, void 0, function* () {
        let dir = path.dirname(absFilePath);
        const root = path.parse(dir).root;
        while (true) {
            for (const marker of markers) {
                try {
                    yield fs.access(path.join(dir, marker));
                    return dir;
                }
                catch (_a) {
                    // not found here; keep walking
                }
            }
            if (dir === root)
                break;
            const parent = path.dirname(dir);
            if (parent === dir)
                break;
            dir = parent;
        }
        return path.dirname(absFilePath);
    });
}
