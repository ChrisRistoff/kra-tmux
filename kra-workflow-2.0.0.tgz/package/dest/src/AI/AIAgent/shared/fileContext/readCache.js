"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.LARGE_READ_THRESHOLD = exports.LARGE_RANGE_THRESHOLD = void 0;
exports.canonicalPath = canonicalPath;
exports.markRead = markRead;
exports.findUnreadGap = findUnreadGap;
exports.clearReadCache = clearReadCache;
const path = __importStar(require("path"));
/**
 * Per-session read-before-edit tracker.
 *
 * edit_lines refuses to touch lines the agent has not read via read_lines /
 * read_function / create_file in the same session. The cache is cleared per
 * file after each successful edit_lines or create_file, since prior line
 * numbers may shift.
 */
// Hard cap on a single edit_lines range. There is intentionally NO override
// flag of any kind \u2014 neither agents nor MCP clients can bypass this. Larger
// changes must be split into multiple ranges (multi-edit array form counts
// each range separately).
exports.LARGE_RANGE_THRESHOLD = 100;
// Soft gate: if a single read_lines call requests more than this many lines
// (summed across ranges), return the file's outline instead of raw content
// so the AI can pick a tighter range. Pure range-based \u2014 no per-file state.
exports.LARGE_READ_THRESHOLD = 200;
const seenLines = new Map();
function canonicalPath(p) {
    return path.resolve(p);
}
function markRead(filePath, start, end) {
    const key = canonicalPath(filePath);
    let s = seenLines.get(key);
    if (!s) {
        s = new Set();
        seenLines.set(key, s);
    }
    for (let i = start; i <= end; i++)
        s.add(i);
}
// Note currently in use, left here to potentially force errors on edit_lines calls
// that would mutate large ranges without first reading them.
function findUnreadGap(filePath, start, end) {
    const s = seenLines.get(canonicalPath(filePath));
    if (!s)
        return [start, end];
    let gapStart;
    let gapEnd = start;
    for (let i = start; i <= end; i++) {
        if (!s.has(i)) {
            if (gapStart === undefined)
                gapStart = i;
            gapEnd = i;
        }
    }
    return gapStart !== undefined ? [gapStart, gapEnd] : undefined;
}
function clearReadCache(filePath) {
    seenLines.delete(canonicalPath(filePath));
}
