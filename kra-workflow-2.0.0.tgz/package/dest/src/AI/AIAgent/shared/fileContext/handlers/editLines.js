"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleEditLines = handleEditLines;
const fs = __importStar(require("fs/promises"));
const args_1 = require("../args");
const fileSafety_1 = require("../../utils/fileSafety");
const readCache_1 = require("../readCache");
const format_1 = require("../format");
const toolResult_1 = require("../toolResult");
function handleEditLines(filePath, args) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        let startLines = (0, args_1.coerceNumberArray)(args.startLines);
        let endLines = (0, args_1.coerceNumberArray)(args.endLines);
        let newContents = (0, args_1.coerceStringArray)(args.newContents);
        const isMulti = !!((_a = startLines !== null && startLines !== void 0 ? startLines : endLines) !== null && _a !== void 0 ? _a : newContents);
        if (isMulti) {
            if (!startLines || !endLines || !newContents ||
                startLines.length !== endLines.length || startLines.length !== newContents.length) {
                return (0, toolResult_1.errorContent)('startLines, endLines, and newContents must all be arrays of the same length.');
            }
        }
        else {
            const start = (0, args_1.coerceNumber)(args.start_line);
            const end = (0, args_1.coerceNumber)(args.end_line);
            const newContent = typeof args.new_content === 'string' ? args.new_content : undefined;
            if (!start || !end || newContent === undefined) {
                return (0, toolResult_1.errorContent)('Provide start_line + end_line + new_content for a single edit, or startLines + endLines + newContents arrays for multiple edits.');
            }
            startLines = [start];
            endLines = [end];
            newContents = [newContent];
        }
        // O(n log n) overlap check, sort by start, scan adjacent pairs.
        // Loop body is a no-op for single-range edits, so this is safe to run unconditionally.
        const order = Array.from({ length: startLines.length }, (_, i) => i)
            .sort((a, b) => startLines[a] - startLines[b]);
        for (let i = 1; i < order.length; i++) {
            const prev = order[i - 1];
            const curr = order[i];
            if (endLines[prev] >= startLines[curr]) {
                return (0, toolResult_1.errorContent)(`Ranges at index ${prev} (${startLines[prev]}\u2013${endLines[prev]}) and ${curr} (${startLines[curr]}\u2013${endLines[curr]}) overlap. ` +
                    'Make separate edit_lines calls for overlapping regions.');
            }
        }
        try {
            const raw = yield fs.readFile(filePath, 'utf8');
            let lines = raw.split('\n');
            // Validate range sizes against the ORIGINAL file before applying any edit.
            // Hard cap: no override of any kind. Larger changes must be split into
            // multiple ranges (multi-edit form counts each range separately).
            for (let i = 0; i < startLines.length; i++) {
                const start = startLines[i];
                const end = endLines[i];
                const where = isMulti ? ` at index ${i}` : '';
                if (start < 1 || end < start) {
                    return (0, toolResult_1.errorContent)(`Invalid range${where}: start_line (${start}) must be >= 1 and <= end_line (${end}).`);
                }
                if (start > lines.length) {
                    return (0, toolResult_1.errorContent)(`start_line (${start})${where} is beyond the file length (${lines.length} lines).`);
                }
                const clampedEnd = Math.min(end, lines.length);
                const span = clampedEnd - start + 1;
                if (span > readCache_1.LARGE_RANGE_THRESHOLD) {
                    return (0, toolResult_1.errorContent)(`Range${where} (${start}\u2013${end}) covers ${span} lines, exceeding the hard cap of ${readCache_1.LARGE_RANGE_THRESHOLD}. ` +
                        'Split the change into multiple smaller edit_lines calls (a multi-edit array call counts each range separately).');
                }
            }
            // Apply edits bottom-to-top (by startLine desc) so earlier line numbers remain valid as we apply each edit.
            const indices = Array.from({ length: startLines.length }, (_, i) => i)
                .sort((a, b) => startLines[b] - startLines[a]);
            const summaries = [];
            for (const i of indices) {
                const start = startLines[i];
                const end = endLines[i];
                const newContent = newContents[i];
                const clampedEnd = Math.min(end, lines.length);
                const insertLines = newContent === '' ? [] : newContent.split('\n');
                lines = [...lines.slice(0, start - 1), ...insertLines, ...lines.slice(clampedEnd)];
                const newEnd = start - 1 + insertLines.length;
                summaries.push(newContent === ''
                    ? `Deleted lines ${start}\u2013${clampedEnd}.`
                    : `Replaced lines ${start}\u2013${clampedEnd} with ${insertLines.length} line${insertLines.length === 1 ? '' : 's'} (new lines ${start}\u2013${newEnd}).`);
            }
            yield (0, fileSafety_1.atomicWriteFile)(filePath, lines.join('\n'));
            (0, readCache_1.clearReadCache)(filePath);
            return (0, toolResult_1.textContent)(yield (0, format_1.withDiagnostics)(filePath, summaries.join('\n')));
        }
        catch (err) {
            return (0, toolResult_1.errorContent)(`Could not edit file: ${err instanceof Error ? err.message : String(err)}`);
        }
    });
}
