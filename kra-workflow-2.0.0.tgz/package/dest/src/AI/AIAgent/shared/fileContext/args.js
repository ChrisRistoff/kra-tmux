"use strict";
/**
 * Argument coercion helpers used by the fileContext MCP tool handlers.
 *
 * Some agents JSON-encode array or number arguments as strings (e.g. "[1, 5]"
 * or "42"). These helpers normalise them back to structured values so each
 * handler can validate uniformly regardless of how the model formatted them.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getArgs = getArgs;
exports.coerceArray = coerceArray;
exports.coerceNumberArray = coerceNumberArray;
exports.coerceStringArray = coerceStringArray;
exports.coerceNumber = coerceNumber;
function getArgs(params) {
    if (typeof params === 'object' && params !== null) {
        const p = params;
        if (typeof p.arguments === 'object' && p.arguments !== null) {
            return p.arguments;
        }
    }
    return {};
}
function coerceArray(value) {
    if (Array.isArray(value))
        return value;
    if (typeof value === 'string') {
        try {
            const parsed = JSON.parse(value);
            return Array.isArray(parsed) ? parsed : undefined;
        }
        catch (_a) {
            return undefined;
        }
    }
    return undefined;
}
function coerceNumberArray(value) {
    const arr = coerceArray(value);
    if (!arr)
        return undefined;
    const out = [];
    for (const v of arr) {
        if (typeof v === 'number' && Number.isFinite(v)) {
            out.push(v);
        }
        else if (typeof v === 'string' && v.trim() !== '' && Number.isFinite(Number(v))) {
            out.push(Number(v));
        }
        else {
            return undefined;
        }
    }
    return out;
}
function coerceStringArray(value) {
    const arr = coerceArray(value);
    if (!arr)
        return undefined;
    const out = [];
    for (const v of arr) {
        if (typeof v === 'string') {
            out.push(v);
        }
        else {
            return undefined;
        }
    }
    return out;
}
function coerceNumber(value) {
    if (typeof value === 'number' && Number.isFinite(value))
        return value;
    if (typeof value === 'string' && value.trim() !== '' && Number.isFinite(Number(value))) {
        return Number(value);
    }
    return undefined;
}
