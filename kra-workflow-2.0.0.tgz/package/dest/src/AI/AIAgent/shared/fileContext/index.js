"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.textContent = exports.errorContent = exports.getArgs = void 0;
/**
 * Barrel for the small public surface used by the MCP server entrypoint.
 */
var args_1 = require("./args");
Object.defineProperty(exports, "getArgs", { enumerable: true, get: function () { return args_1.getArgs; } });
var toolResult_1 = require("./toolResult");
Object.defineProperty(exports, "errorContent", { enumerable: true, get: function () { return toolResult_1.errorContent; } });
Object.defineProperty(exports, "textContent", { enumerable: true, get: function () { return toolResult_1.textContent; } });
