"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleReadLines = handleReadLines;
const fs = __importStar(require("fs/promises"));
const args_1 = require("../args");
const fileOutline_1 = require("../../utils/fileOutline");
const fileSafety_1 = require("../../utils/fileSafety");
const readCache_1 = require("../readCache");
const format_1 = require("../format");
const toolResult_1 = require("../toolResult");
function handleReadLines(filePath, args) {
    return __awaiter(this, void 0, void 0, function* () {
        let startLines = (0, args_1.coerceNumberArray)(args.startLines);
        let endLines = (0, args_1.coerceNumberArray)(args.endLines);
        const isMulti = !!(startLines !== null && startLines !== void 0 ? startLines : endLines);
        if (isMulti) {
            if (!startLines || !endLines || startLines.length !== endLines.length) {
                return (0, toolResult_1.errorContent)('startLines and endLines must both be arrays of the same length.');
            }
        }
        else {
            const start = (0, args_1.coerceNumber)(args.start_line);
            const end = (0, args_1.coerceNumber)(args.end_line);
            if (!start || !end) {
                return (0, toolResult_1.errorContent)('Provide start_line + end_line for a single range, or startLines + endLines arrays for multiple ranges.');
            }
            startLines = [start];
            endLines = [end];
        }
        const totalLines = (0, format_1.totalRequestedLines)(startLines, endLines);
        if (totalLines > fileSafety_1.MAX_LINES_PER_CALL) {
            return (0, toolResult_1.errorContent)(`Requested ${totalLines} lines across ${startLines.length} range${startLines.length === 1 ? '' : 's'}, exceeds the per-call cap of ${fileSafety_1.MAX_LINES_PER_CALL}. ` +
                'Split into multiple read_lines calls or narrow the ranges.');
        }
        try {
            // Soft gate: large reads get bounced to the outline so the AI can
            // pick a tighter range. Skipped for files with no recognisable
            // structure (plain text, JSON, logs) where an outline would be
            // empty and unhelpful.
            if (totalLines > readCache_1.LARGE_READ_THRESHOLD) {
                const outline = yield (0, fileOutline_1.getFileOutline)(filePath);
                const hasStructure = outline.entries.length > 0 || !!outline.imports;
                if (hasStructure) {
                    return (0, toolResult_1.errorContent)(`Requested ${totalLines} lines in one call, exceeds the soft cap of ${readCache_1.LARGE_READ_THRESHOLD}. ` +
                        `Use the outline below to pick a tighter range, then retry read_lines.\n\n` +
                        (0, fileOutline_1.formatOutline)(filePath, outline));
                }
            }
            if (yield (0, fileSafety_1.isBinaryFile)(filePath)) {
                return (0, toolResult_1.errorContent)(`File appears to be binary: ${filePath}. Refusing to return its contents.`);
            }
            const content = yield fs.readFile(filePath, 'utf8');
            const lines = content.split('\n');
            const sections = [];
            for (let i = 0; i < startLines.length; i++) {
                const s = startLines[i];
                const e = endLines[i];
                const count = e - s + 1;
                const numbered = (0, format_1.numberLines)(lines, s, e);
                sections.push(`Lines ${s}\u2013${e} (${count} line${count === 1 ? '' : 's'}):\n${numbered}`);
            }
            for (let i = 0; i < startLines.length; i++)
                (0, readCache_1.markRead)(filePath, startLines[i], endLines[i]);
            return (0, toolResult_1.textContent)(sections.join('\n\n'));
        }
        catch (err) {
            return (0, toolResult_1.errorContent)(`Could not read file: ${err instanceof Error ? err.message : String(err)}`);
        }
    });
}
