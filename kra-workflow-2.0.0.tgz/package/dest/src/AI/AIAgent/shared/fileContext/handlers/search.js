"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleSearch = handleSearch;
const args_1 = require("../args");
const rgSearch_1 = require("../rgSearch");
const toolResult_1 = require("../toolResult");
function handleSearch(args) {
    return __awaiter(this, void 0, void 0, function* () {
        const namePattern = typeof args.name_pattern === 'string' && args.name_pattern.length > 0
            ? args.name_pattern
            : undefined;
        const contentPattern = typeof args.content_pattern === 'string' && args.content_pattern.length > 0
            ? args.content_pattern
            : undefined;
        if (!namePattern && !contentPattern) {
            return (0, toolResult_1.errorContent)('Provide name_pattern, content_pattern, or both. At least one is required.');
        }
        const rootPath = typeof args.path === 'string' && args.path.length > 0 ? args.path : process.cwd();
        const type = typeof args.type === 'string' && args.type.length > 0 ? args.type : undefined;
        const caseInsensitive = args.case_insensitive === true;
        const contextRaw = (0, args_1.coerceNumber)(args.context);
        const context = contextRaw && contextRaw > 0 ? Math.floor(contextRaw) : 0;
        const multiline = args.multiline === true;
        const maxRaw = (0, args_1.coerceNumber)(args.max_results);
        const maxResults = Math.min(rgSearch_1.SEARCH_HARD_CAP_MAX_RESULTS, maxRaw && maxRaw > 0 ? Math.floor(maxRaw) : rgSearch_1.SEARCH_DEFAULT_MAX_RESULTS);
        const opts = {
            namePattern,
            contentPattern,
            rootPath,
            type,
            caseInsensitive,
            context,
            multiline,
            maxResults,
        };
        try {
            const out = contentPattern
                ? yield (0, rgSearch_1.searchContent)(opts)
                : yield (0, rgSearch_1.searchNameOnly)(opts);
            return (0, toolResult_1.textContent)(out);
        }
        catch (err) {
            const msg = err instanceof Error ? err.message : String(err);
            if (msg.includes('ENOENT')) {
                return (0, toolResult_1.errorContent)('ripgrep (rg) not found on PATH. Install ripgrep to use the search tool.');
            }
            return (0, toolResult_1.errorContent)(`search failed: ${msg}`);
        }
    });
}
