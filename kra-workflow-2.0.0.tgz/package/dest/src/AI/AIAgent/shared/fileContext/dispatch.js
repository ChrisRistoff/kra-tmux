"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.dispatchFileContextTool = dispatchFileContextTool;
const toolResult_1 = require("./toolResult");
const createFile_1 = require("./handlers/createFile");
const editLines_1 = require("./handlers/editLines");
const getOutline_1 = require("./handlers/getOutline");
const lspQuery_1 = require("./handlers/lspQuery");
const readFunction_1 = require("./handlers/readFunction");
const readLines_1 = require("./handlers/readLines");
const search_1 = require("./handlers/search");
/**
 * Dispatches a tool call to the appropriate handler. Tools that take a
 * `file_path` are validated centrally so each handler can assume non-empty.
 */
function dispatchFileContextTool(name, args) {
    return __awaiter(this, void 0, void 0, function* () {
        if (name === 'lsp_query') {
            return (0, lspQuery_1.handleLspQuery)(args);
        }
        if (name === 'search') {
            return (0, search_1.handleSearch)(args);
        }
        const filePath = typeof args.file_path === 'string' ? args.file_path : undefined;
        if (!filePath)
            return (0, toolResult_1.errorContent)('file_path argument is required.');
        switch (name) {
            case 'get_outline':
                return (0, getOutline_1.handleGetOutline)(filePath);
            case 'read_lines':
                return (0, readLines_1.handleReadLines)(filePath, args);
            case 'read_function':
                return (0, readFunction_1.handleReadFunction)(filePath, args);
            case 'edit_lines':
                return (0, editLines_1.handleEditLines)(filePath, args);
            case 'create_file':
                return (0, createFile_1.handleCreateFile)(filePath, args);
            default:
                return (0, toolResult_1.errorContent)(`Unknown tool: ${name}`);
        }
    });
}
