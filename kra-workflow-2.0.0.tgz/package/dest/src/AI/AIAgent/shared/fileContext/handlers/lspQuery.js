"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleLspQuery = handleLspQuery;
const lspQueryHandler_1 = require("../../utils/lspQueryHandler");
const toolResult_1 = require("../toolResult");
function handleLspQuery(args) {
    return __awaiter(this, void 0, void 0, function* () {
        const filePath = typeof args.file_path === 'string' ? args.file_path : '';
        const op = args.op;
        const queryArgs = { file_path: filePath, op };
        if (typeof args.line === 'number')
            queryArgs.line = args.line;
        if (typeof args.col === 'number')
            queryArgs.col = args.col;
        if (typeof args.symbol === 'string')
            queryArgs.symbol = args.symbol;
        if (typeof args.occurrence === 'number')
            queryArgs.occurrence = args.occurrence;
        if (typeof args.include_declaration === 'boolean')
            queryArgs.include_declaration = args.include_declaration;
        try {
            const text = yield (0, lspQueryHandler_1.runLspQuery)(queryArgs);
            return (0, toolResult_1.textContent)(text);
        }
        catch (err) {
            return (0, toolResult_1.errorContent)(`lsp_query failed: ${err instanceof Error ? err.message : String(err)}`);
        }
    });
}
