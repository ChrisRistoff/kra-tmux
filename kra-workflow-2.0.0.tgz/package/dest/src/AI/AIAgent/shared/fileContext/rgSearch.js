"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SEARCH_HARD_CAP_MAX_RESULTS = exports.SEARCH_DEFAULT_MAX_RESULTS = void 0;
exports.searchNameOnly = searchNameOnly;
exports.searchContent = searchContent;
const fs = __importStar(require("fs/promises"));
const child_process_1 = require("child_process");
const fileSafety_1 = require("../utils/fileSafety");
exports.SEARCH_DEFAULT_MAX_RESULTS = 50;
exports.SEARCH_HARD_CAP_MAX_RESULTS = 200;
const SEARCH_LINE_TRUNCATE = 500;
const SEARCH_LINE_COUNT_CONCURRENCY = 16;
function runRg(rgArgs, cwd) {
    return __awaiter(this, void 0, void 0, function* () {
        return new Promise((resolve, reject) => {
            const child = (0, child_process_1.spawn)('rg', rgArgs, { cwd });
            let stdout = '';
            let stderr = '';
            child.stdout.on('data', (d) => { stdout += d.toString('utf8'); });
            child.stderr.on('data', (d) => { stderr += d.toString('utf8'); });
            child.on('error', reject);
            child.on('close', (code) => resolve({ stdout, stderr, code: code !== null && code !== void 0 ? code : 0 }));
        });
    });
}
// Returns the line count using the same `split('\n').length` semantics that
// read_lines uses internally, so a `read_lines 1-N` call lines up exactly.
function countFileLines(filePath) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            if (yield (0, fileSafety_1.isBinaryFile)(filePath))
                return 'binary';
            const content = yield fs.readFile(filePath, 'utf8');
            return content.split('\n').length;
        }
        catch (_a) {
            return 0;
        }
    });
}
// Concurrency-capped Promise.all so a 50-file result set doesn't open 50 file
// handles at once.
function countLinesForAll(filePaths) {
    return __awaiter(this, void 0, void 0, function* () {
        const result = new Map();
        let next = 0;
        function worker() {
            return __awaiter(this, void 0, void 0, function* () {
                for (;;) {
                    const i = next++;
                    if (i >= filePaths.length)
                        return;
                    const fp = filePaths[i];
                    result.set(fp, yield countFileLines(fp));
                }
            });
        }
        const workers = Array.from({ length: Math.min(SEARCH_LINE_COUNT_CONCURRENCY, filePaths.length) }, () => __awaiter(this, void 0, void 0, function* () { return worker(); }));
        yield Promise.all(workers);
        return result;
    });
}
function formatPathLine(filePath, count) {
    if (count === 'binary')
        return `${filePath} (binary)`;
    return `${filePath} (${count} line${count === 1 ? '' : 's'})`;
}
function truncateMatchLine(line) {
    if (line.length <= SEARCH_LINE_TRUNCATE)
        return line;
    return `${line.slice(0, SEARCH_LINE_TRUNCATE)}... [truncated]`;
}
function asString(value) {
    if (typeof value === 'string')
        return value;
    if (value && typeof value === 'object' && 'text' in value) {
        const t = value.text;
        return typeof t === 'string' ? t : undefined;
    }
    return undefined;
}
// Parse rg --json stream into per-file match groups, preserving order.
function parseRgJson(stdout) {
    var _a;
    const files = [];
    let current;
    for (const line of stdout.split('\n')) {
        if (!line)
            continue;
        let evt;
        try {
            evt = JSON.parse(line);
        }
        catch (_b) {
            continue;
        }
        const data = evt.data;
        if (!data)
            continue;
        if (evt.type === 'begin') {
            const p = asString(data.path);
            if (p) {
                current = { path: p, entries: [], matchCount: 0 };
                files.push(current);
            }
            continue;
        }
        if ((evt.type === 'match' || evt.type === 'context') && current) {
            const lineNumber = typeof data.line_number === 'number' ? data.line_number : 0;
            const text = (_a = asString(data.lines)) !== null && _a !== void 0 ? _a : '';
            // rg includes the trailing newline on each line; strip it so our
            // formatter doesn't introduce blank lines.
            const cleanText = text.endsWith('\n') ? text.slice(0, -1) : text;
            const isMatch = evt.type === 'match';
            current.entries.push({ lineNumber, text: cleanText, isMatch });
            if (isMatch)
                current.matchCount++;
            continue;
        }
        if (evt.type === 'end') {
            current = undefined;
        }
    }
    return files;
}
function renderRgFile(file, lineCount) {
    const header = formatPathLine(file.path, lineCount);
    const lines = [header];
    let prevLine = -2;
    for (const entry of file.entries) {
        if (prevLine !== -2 && entry.lineNumber > prevLine + 1) {
            lines.push('   --');
        }
        lines.push(`${String(entry.lineNumber).padStart(5)}: ${truncateMatchLine(entry.text)}`);
        prevLine = entry.lineNumber;
    }
    return lines.join('\n');
}
function searchNameOnly(opts) {
    return __awaiter(this, void 0, void 0, function* () {
        const args = ['--files', '--color', 'never'];
        if (opts.namePattern) {
            args.push('--glob', opts.namePattern);
        }
        if (opts.type) {
            args.push('--type', opts.type);
        }
        args.push('--', opts.rootPath);
        const { stdout, stderr, code } = yield runRg(args, process.cwd());
        // rg returns 1 when no matches, 0 on matches; >1 is a real error.
        if (code > 1) {
            throw new Error(stderr.trim() || `ripgrep exited with code ${code}`);
        }
        const allPaths = stdout.split('\n').filter((p) => p.length > 0).sort();
        if (allPaths.length === 0)
            return 'No matching files.';
        const truncated = allPaths.length > opts.maxResults;
        const shown = truncated ? allPaths.slice(0, opts.maxResults) : allPaths;
        const counts = yield countLinesForAll(shown);
        const lines = shown.map((p) => { var _a; return formatPathLine(p, (_a = counts.get(p)) !== null && _a !== void 0 ? _a : 0); });
        if (truncated) {
            lines.push(`... and ${allPaths.length - opts.maxResults} more results truncated. Narrow with name_pattern/path/type.`);
        }
        return lines.join('\n');
    });
}
function searchContent(opts) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        const args = ['--json', '--color', 'never'];
        if (opts.namePattern) {
            args.push('--glob', opts.namePattern);
        }
        if (opts.type) {
            args.push('--type', opts.type);
        }
        if (opts.caseInsensitive) {
            args.push('-i');
        }
        if (opts.context > 0) {
            args.push('-C', String(opts.context));
        }
        if (opts.multiline) {
            args.push('-U', '--multiline-dotall');
        }
        args.push('--', (_a = opts.contentPattern) !== null && _a !== void 0 ? _a : '', opts.rootPath);
        const { stdout, stderr, code } = yield runRg(args, process.cwd());
        if (code > 1) {
            throw new Error(stderr.trim() || `ripgrep exited with code ${code}`);
        }
        const files = parseRgJson(stdout);
        if (files.length === 0)
            return 'No content matches.';
        files.sort((a, b) => a.path.localeCompare(b.path));
        // Cap by total match-line count (not context lines, not files).
        const cappedFiles = [];
        let matchTotal = 0;
        let truncated = false;
        for (const file of files) {
            if (matchTotal >= opts.maxResults) {
                truncated = true;
                break;
            }
            const remaining = opts.maxResults - matchTotal;
            if (file.matchCount <= remaining) {
                cappedFiles.push(file);
                matchTotal += file.matchCount;
                continue;
            }
            // Trim entries: keep matches up to `remaining`, plus their adjacent context.
            const trimmedEntries = [];
            let kept = 0;
            for (const entry of file.entries) {
                if (entry.isMatch) {
                    if (kept >= remaining)
                        break;
                    kept++;
                }
                trimmedEntries.push(entry);
            }
            cappedFiles.push(Object.assign(Object.assign({}, file), { entries: trimmedEntries, matchCount: kept }));
            matchTotal += kept;
            truncated = true;
            break;
        }
        const counts = yield countLinesForAll(cappedFiles.map((f) => f.path));
        const sections = cappedFiles.map((f) => { var _a; return renderRgFile(f, (_a = counts.get(f.path)) !== null && _a !== void 0 ? _a : 0); });
        if (truncated) {
            const totalMatches = files.reduce((s, f) => s + f.matchCount, 0);
            sections.push(`... and ${totalMatches - matchTotal} more match line${totalMatches - matchTotal === 1 ? '' : 's'} truncated. Narrow with name_pattern/path/type.`);
        }
        return sections.join('\n\n');
    });
}
