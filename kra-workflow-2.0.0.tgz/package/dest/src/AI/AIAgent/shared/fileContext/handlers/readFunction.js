"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleReadFunction = handleReadFunction;
const fs = __importStar(require("fs/promises"));
const fileOutline_1 = require("../../utils/fileOutline");
const fileSafety_1 = require("../../utils/fileSafety");
const format_1 = require("../format");
const readCache_1 = require("../readCache");
const toolResult_1 = require("../toolResult");
function handleReadFunction(filePath, args) {
    return __awaiter(this, void 0, void 0, function* () {
        const fnName = typeof args.function_name === 'string' ? args.function_name : undefined;
        if (!fnName)
            return (0, toolResult_1.errorContent)('function_name argument is required.');
        try {
            const outline = yield (0, fileOutline_1.getFileOutline)(filePath);
            const range = (0, fileOutline_1.findFunctionRange)(outline, fnName);
            if (!range) {
                return (0, toolResult_1.errorContent)(`Symbol "${fnName}" not found in ${filePath}.\n\n${(0, format_1.formatOutlineForMiss)(filePath, outline)}`);
            }
            const span = range.end - range.start + 1;
            if (span > fileSafety_1.MAX_LINES_PER_CALL) {
                return (0, toolResult_1.errorContent)(`Symbol "${fnName}" spans ${span} lines (${range.start}\u2013${range.end}), exceeds the per-call cap of ${fileSafety_1.MAX_LINES_PER_CALL}. ` +
                    'Use read_lines with a narrower range.');
            }
            if (yield (0, fileSafety_1.isBinaryFile)(filePath)) {
                return (0, toolResult_1.errorContent)(`File appears to be binary: ${filePath}. Refusing to return its contents.`);
            }
            const content = yield fs.readFile(filePath, 'utf8');
            const lines = content.split('\n');
            const numbered = (0, format_1.numberLines)(lines, range.start, range.end);
            (0, readCache_1.markRead)(filePath, range.start, range.end);
            return (0, toolResult_1.textContent)(`Lines ${range.start}\u2013${range.end}:\n\n${numbered}`);
        }
        catch (err) {
            return (0, toolResult_1.errorContent)(`Could not read file: ${err instanceof Error ? err.message : String(err)}`);
        }
    });
}
