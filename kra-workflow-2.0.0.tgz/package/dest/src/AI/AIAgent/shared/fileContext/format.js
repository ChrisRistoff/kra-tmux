"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.formatOutlineForMiss = formatOutlineForMiss;
exports.totalRequestedLines = totalRequestedLines;
exports.withDiagnostics = withDiagnostics;
exports.numberLines = numberLines;
const fileOutline_1 = require("../utils/fileOutline");
const lspDiagnostics_1 = require("../utils/lspDiagnostics");
const lspDiagnosticsBridge_1 = require("../utils/lspDiagnosticsBridge");
/**
 * Build a compact outline string for read_function not-found errors so we don't
 * dump hundreds of entries back into the agent's context just to say "missing".
 */
function formatOutlineForMiss(filePath, outline, max = 40) {
    if (outline.entries.length <= max) {
        return (0, fileOutline_1.formatOutline)(filePath, outline);
    }
    const truncated = Object.assign(Object.assign({}, outline), { entries: outline.entries.slice(0, max) });
    return `${(0, fileOutline_1.formatOutline)(filePath, truncated)}\n\n  ...and ${outline.entries.length - max} more (showing first ${max}). Use get_outline for the full list.`;
}
// Sum of (end - start + 1) across all requested ranges.
function totalRequestedLines(starts, ends) {
    let total = 0;
    for (let i = 0; i < starts.length; i++)
        total += Math.max(0, ends[i] - starts[i] + 1);
    return total;
}
/**
 * Append diagnostics (errors + warnings, single-file scope) to an edit
 * summary so the agent sees them in the same turn it made the change.
 *
 * Source order:
 *   1. If the file's extension has a configured LSP server in settings.toml,
 *      ask that server (pull-mode `textDocument/diagnostic`, falling back to
 *      cached push-mode `publishDiagnostics`). This is the same code path
 *      used by editors like VS Code and Neovim.
 *   2. Otherwise (or if the LSP path returned nothing usable), fall back to
 *      the in-process TypeScript Compiler API check for .ts/.js files.
 *
 * Silent no-op when neither path produces diagnostics.
 */
function withDiagnostics(filePath, summary) {
    return __awaiter(this, void 0, void 0, function* () {
        let diags;
        try {
            diags = yield (0, lspDiagnosticsBridge_1.getLspDiagnosticsForFile)(filePath);
        }
        catch (_a) {
            // ignore; try the in-process fallback
        }
        if (!diags) {
            try {
                diags = (0, lspDiagnostics_1.getDiagnosticsForFile)(filePath);
            }
            catch (_b) {
                return summary;
            }
        }
        return diags ? `${summary}\n\n${diags}` : summary;
    });
}
/**
 * Render a 1-indexed slice of `lines` with right-padded line numbers.
 * Shared between read_lines (single + multi-range) and read_function so the
 * numbering format stays in lock-step across tools.
 */
function numberLines(lines, start, end) {
    return lines.slice(start - 1, end)
        .map((l, i) => `${String(start + i).padStart(5)}: ${l}`)
        .join('\n');
}
