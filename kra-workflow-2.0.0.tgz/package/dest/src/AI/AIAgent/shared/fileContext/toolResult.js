"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.textContent = textContent;
exports.errorContent = errorContent;
function textContent(text) {
    return { content: [{ type: 'text', text }], isError: false };
}
function errorContent(text) {
    return { content: [{ type: 'text', text }], isError: true };
}
