"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleCreateFile = handleCreateFile;
const fs = __importStar(require("fs/promises"));
const fileSafety_1 = require("../../utils/fileSafety");
const readCache_1 = require("../readCache");
const format_1 = require("../format");
const toolResult_1 = require("../toolResult");
function handleCreateFile(filePath, args) {
    return __awaiter(this, void 0, void 0, function* () {
        const content = typeof args.content === 'string' ? args.content : undefined;
        if (content === undefined)
            return (0, toolResult_1.errorContent)('content argument is required.');
        // create_file is for NEW files only. Modifications to existing files must
        // go through edit_lines (multi-range form for changes spanning multiple
        // regions). This prevents bypassing the edit_lines cap by overwriting.
        let exists = false;
        try {
            yield fs.access(filePath);
            exists = true;
        }
        catch ( /* does not exist */_a) { /* does not exist */ }
        if (exists) {
            return (0, toolResult_1.errorContent)(`Refusing to create_file: ${filePath} already exists. Use edit_lines to modify existing files ` +
                '(use the multi-range form \u2014 startLines/endLines/newContents arrays \u2014 for changes spanning multiple regions).');
        }
        try {
            yield (0, fileSafety_1.atomicWriteFile)(filePath, content);
            const lineCount = content.split('\n').length;
            (0, readCache_1.clearReadCache)(filePath);
            (0, readCache_1.markRead)(filePath, 1, lineCount);
            return (0, toolResult_1.textContent)(yield (0, format_1.withDiagnostics)(filePath, `Created ${filePath} (${lineCount} line${lineCount === 1 ? '' : 's'}).`));
        }
        catch (err) {
            return (0, toolResult_1.errorContent)(`Could not create file: ${err instanceof Error ? err.message : String(err)}`);
        }
    });
}
