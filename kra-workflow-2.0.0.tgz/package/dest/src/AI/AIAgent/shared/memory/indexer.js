"use strict";
/**
 * File-system indexer for the kra-memory code-chunks table.
 *
 * Pipeline:
 *   1. List indexable files (git ls-files when in a repo, fs walk otherwise)
 *   2. For each file: read → chunk → compute content hashes
 *   3. Diff against existing chunk IDs to skip unchanged chunks
 *   4. Embed only new/changed chunks (batched, 32 per call)
 *   5. Upsert: delete old IDs for the file, then add new rows
 *
 * Storage lives at `<repo>/.kra-memory/lance/code_chunks.lance/`. Per-file
 * reindex is fast (30–150 ms typical) so the on-save watcher can call
 * `indexFile` without UI hitches.
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.reindexAll = reindexAll;
exports.indexFile = indexFile;
exports.removeFile = removeFile;
exports.workspaceRoot = workspaceRoot;
exports.memoryDirectory = memoryDirectory;
exports.listIndexableFiles = listIndexableFiles;
exports.isIndexable = isIndexable;
exports.matchGlob = matchGlob;
const child_process_1 = require("child_process");
const promises_1 = __importDefault(require("fs/promises"));
const path_1 = __importDefault(require("path"));
const embedder_1 = require("./embedder");
const db_1 = require("./db");
const chunker_1 = require("./chunker");
const settings_1 = require("./settings");
/**
 * Reindex every indexable file in the workspace. Safe to re-run; chunks whose
 * contentHash hasn't changed are skipped.
 */
function reindexAll() {
    return __awaiter(this, arguments, void 0, function* (opts = {}) {
        var _a, _b, _c;
        const started = Date.now();
        const settings = yield (0, settings_1.loadMemorySettings)();
        const root = workspaceRoot();
        const files = yield listIndexableFiles(root, settings);
        (_a = opts.onProgress) === null || _a === void 0 ? void 0 : _a.call(opts, {
            phase: 'scanning',
            filesTotal: files.length,
            filesDone: 0,
            chunksTotal: 0,
            chunksWritten: 0,
        });
        let chunksWritten = 0;
        let chunksSkipped = 0;
        let chunksDeleted = 0;
        for (let i = 0; i < files.length; i++) {
            const rel = files[i];
            (_b = opts.onProgress) === null || _b === void 0 ? void 0 : _b.call(opts, {
                phase: 'embedding',
                filesTotal: files.length,
                filesDone: i,
                chunksTotal: 0,
                chunksWritten,
                currentPath: rel,
            });
            try {
                const result = yield indexFile(rel, { settings, root });
                chunksWritten += result.chunksWritten;
                chunksSkipped += result.chunksSkipped;
                chunksDeleted += result.chunksDeleted;
            }
            catch (err) {
                process.stderr.write(`[kra-memory] index failed for ${rel}: ${err instanceof Error ? err.message : String(err)}\n`);
            }
        }
        (_c = opts.onProgress) === null || _c === void 0 ? void 0 : _c.call(opts, {
            phase: 'done',
            filesTotal: files.length,
            filesDone: files.length,
            chunksTotal: chunksWritten + chunksSkipped,
            chunksWritten,
        });
        return {
            filesScanned: files.length,
            chunksWritten,
            chunksSkipped,
            chunksDeleted,
            elapsedMs: Date.now() - started,
        };
    });
}
/**
 * Reindex a single file. `relPath` is relative to the workspace root.
 * If the file no longer exists or is filtered out, all of its existing
 * chunks are removed.
 */
function indexFile(relPath_1) {
    return __awaiter(this, arguments, void 0, function* (relPath, opts = {}) {
        var _a, _b, _c;
        const settings = (_a = opts.settings) !== null && _a !== void 0 ? _a : yield (0, settings_1.loadMemorySettings)();
        const root = (_b = opts.root) !== null && _b !== void 0 ? _b : workspaceRoot();
        const abs = path_1.default.isAbsolute(relPath) ? relPath : path_1.default.join(root, relPath);
        const rel = path_1.default.isAbsolute(relPath) ? path_1.default.relative(root, relPath) : relPath;
        let content = null;
        try {
            const stat = yield promises_1.default.stat(abs);
            if (!stat.isFile())
                return { chunksWritten: 0, chunksSkipped: 0, chunksDeleted: yield removeFile(rel) };
            if (!isIndexable(rel, settings)) {
                return { chunksWritten: 0, chunksSkipped: 0, chunksDeleted: yield removeFile(rel) };
            }
            content = yield promises_1.default.readFile(abs, 'utf8');
        }
        catch (_d) {
            return { chunksWritten: 0, chunksSkipped: 0, chunksDeleted: yield removeFile(rel) };
        }
        const built = (0, chunker_1.buildChunks)({
            relPath: rel,
            content,
            chunkLines: settings.chunkLines,
            chunkOverlap: settings.chunkOverlap,
            indexedAt: Date.now(),
        });
        if (built.length === 0) {
            return { chunksWritten: 0, chunksSkipped: 0, chunksDeleted: yield removeFile(rel) };
        }
        const existingIds = yield existingChunkIdsForPath(rel);
        const newIds = new Set(built.map((b) => b.row.id));
        const toDelete = [...existingIds].filter((id) => !newIds.has(id));
        const toInsert = built.filter((b) => !existingIds.has(b.row.id));
        const skipped = built.length - toInsert.length;
        if (toInsert.length === 0 && toDelete.length === 0) {
            return { chunksWritten: 0, chunksSkipped: skipped, chunksDeleted: 0 };
        }
        const vectors = toInsert.length > 0
            ? yield (0, embedder_1.embedMany)(toInsert.map((b) => b.row.content))
            : [];
        const rows = toInsert.map((b, i) => (Object.assign(Object.assign({}, b.row), { vector: vectors[i] })));
        const seedRow = (_c = rows[0]) !== null && _c !== void 0 ? _c : null;
        const { table, justCreated } = yield (0, db_1.getCodeChunksTable)(seedRow);
        if (!table)
            return { chunksWritten: 0, chunksSkipped: skipped, chunksDeleted: 0 };
        if (toDelete.length > 0) {
            const quoted = toDelete.map((id) => `'${id.replace(/'/g, "''")}'`).join(', ');
            yield table.delete(`id IN (${quoted})`);
        }
        let written = 0;
        if (rows.length > 0) {
            if (justCreated) {
                // Seed row was inserted by createTable; add the rest.
                if (rows.length > 1) {
                    yield table.add(rows.slice(1));
                }
            }
            else {
                yield table.add(rows);
            }
            written = rows.length;
        }
        return { chunksWritten: written, chunksSkipped: skipped, chunksDeleted: toDelete.length };
    });
}
/**
 * Remove every chunk row associated with `relPath`. Returns the number of
 * chunks removed (0 if the table doesn't exist yet).
 */
function removeFile(relPath) {
    return __awaiter(this, void 0, void 0, function* () {
        const { table } = yield (0, db_1.getCodeChunksTable)(null);
        if (!table)
            return 0;
        const existing = yield existingChunkIdsForPath(relPath);
        if (existing.size === 0)
            return 0;
        yield table.delete(`path = '${relPath.replace(/'/g, "''")}'`);
        return existing.size;
    });
}
function existingChunkIdsForPath(relPath) {
    return __awaiter(this, void 0, void 0, function* () {
        const { table } = yield (0, db_1.getCodeChunksTable)(null);
        if (!table)
            return new Set();
        try {
            const rows = yield table
                .query()
                .where(`path = '${relPath.replace(/'/g, "''")}'`)
                .select(['id'])
                .toArray();
            return new Set(rows.map((r) => String(r.id)));
        }
        catch (_a) {
            return new Set();
        }
    });
}
function workspaceRoot() {
    var _a;
    return (_a = process.env['WORKING_DIR']) !== null && _a !== void 0 ? _a : process.cwd();
}
function memoryDirectory() {
    return (0, db_1.memoryDirectoryRoot)();
}
/**
 * List candidate files for indexing. Uses `git ls-files` when available so
 * .gitignore is honoured for free. Falls back to an fs walk otherwise.
 */
function listIndexableFiles(root, settings) {
    return __awaiter(this, void 0, void 0, function* () {
        let files = [];
        try {
            files = yield gitLsFiles(root);
        }
        catch (_a) {
            files = yield walk(root, root);
        }
        return files.filter((rel) => isIndexable(rel, settings));
    });
}
function gitLsFiles(root) {
    return __awaiter(this, void 0, void 0, function* () {
        return new Promise((resolve, reject) => {
            const child = (0, child_process_1.spawn)('git', ['-C', root, 'ls-files', '-co', '--exclude-standard'], {
                stdio: ['ignore', 'pipe', 'pipe'],
            });
            const chunks = [];
            const errChunks = [];
            child.stdout.on('data', (b) => chunks.push(b));
            child.stderr.on('data', (b) => errChunks.push(b));
            child.on('error', (err) => reject(err));
            child.on('close', (code) => {
                if (code !== 0) {
                    reject(new Error(`git ls-files exited ${code !== null && code !== void 0 ? code : '?'}: ${Buffer.concat(errChunks).toString()}`));
                    return;
                }
                const out = Buffer.concat(chunks).toString('utf8');
                resolve(out.split('\n').filter((line) => line.length > 0));
            });
        });
    });
}
function walk(root, current) {
    return __awaiter(this, void 0, void 0, function* () {
        const out = [];
        const entries = yield promises_1.default.readdir(current, { withFileTypes: true });
        for (const entry of entries) {
            const abs = path_1.default.join(current, entry.name);
            const rel = path_1.default.relative(root, abs);
            if (entry.isDirectory()) {
                if (entry.name === '.git' || entry.name === 'node_modules' || entry.name === '.kra-memory')
                    continue;
                out.push(...yield walk(root, abs));
            }
            else if (entry.isFile()) {
                out.push(rel);
            }
        }
        return out;
    });
}
function isIndexable(relPath, settings) {
    const posix = relPath.split(path_1.default.sep).join('/');
    if (!settings.includeExtensions.includes(path_1.default.extname(relPath).toLowerCase())) {
        return false;
    }
    for (const glob of settings.excludeGlobs) {
        if (matchGlob(posix, glob))
            return false;
    }
    return true;
}
/**
 * Tiny glob matcher: supports `*`, `**`, and exact characters. Good enough
 * for the gitignore-style patterns we ship in defaults; users wanting more
 * power can lean on git ls-files honouring their actual .gitignore.
 */
function matchGlob(text, glob) {
    const re = globToRegex(glob);
    return re.test(text);
}
function globToRegex(glob) {
    let pattern = '^';
    for (let i = 0; i < glob.length; i++) {
        const ch = glob[i];
        if (ch === '*') {
            if (glob[i + 1] === '*') {
                pattern += '.*';
                i++;
                if (glob[i + 1] === '/')
                    i++;
            }
            else {
                pattern += '[^/]*';
            }
        }
        else if (ch === '?') {
            pattern += '[^/]';
        }
        else if (ch === '.') {
            pattern += '\\.';
        }
        else if (/[\\^$+(){}|[\]]/.test(ch)) {
            pattern += '\\' + ch;
        }
        else {
            pattern += ch;
        }
    }
    pattern += '$';
    return new RegExp(pattern);
}
