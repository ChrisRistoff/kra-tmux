"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.semanticSearch = semanticSearch;
/**
 * Vector search across the kra-memory code_chunks (and optionally memory)
 * tables. Code hits are aggregated per file: one entry per matched path with
 * merged matched line ranges (parallel `startLines` / `endLines` arrays
 * matching the read_lines tool shape) so the agent knows where to look
 * without us shipping any source code in the response.
 */
const embedder_1 = require("./embedder");
const db_1 = require("./db");
const indexer_1 = require("./indexer");
const types_1 = require("./types");
// Drop low-confidence semantic hits before returning to the caller. Anything
// below this score is noise in practice and just bloats the agent's context.
const MIN_SCORE = 0.55;
function semanticSearch(input) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b;
        if (typeof input.query !== 'string' || input.query.trim() === '') {
            throw new Error('semanticSearch: query is required and must be non-empty');
        }
        const k = clamp((_a = input.k) !== null && _a !== void 0 ? _a : 10, 1, 100);
        const scope = (_b = input.scope) !== null && _b !== void 0 ? _b : 'code';
        const queryVector = yield (0, embedder_1.embedOne)(input.query);
        const hits = [];
        if (scope === 'code' || scope === 'both') {
            hits.push(...yield searchCode(queryVector, k, input.pathGlob));
        }
        if (scope === 'memory' || scope === 'both') {
            if (!input.memoryKind || !(0, types_1.isMemoryLookupKind)(input.memoryKind)) {
                throw new Error(`semanticSearch: 'memoryKind' is required when scope includes 'memory' and must be one of: ${types_1.MEMORY_LOOKUP_KINDS.join(', ')}`);
            }
            hits.push(...yield searchMemory(queryVector, k, input.memoryKind, input.selectedIds));
        }
        const filtered = hits.filter((h) => h.score >= MIN_SCORE);
        filtered.sort((a, b) => b.score - a.score);
        return filtered.slice(0, k);
    });
}
function searchCode(vector, k, pathGlob) {
    return __awaiter(this, void 0, void 0, function* () {
        const { table } = yield (0, db_1.getCodeChunksTable)(null);
        if (!table)
            return [];
        // Pull a wide net so deduping by path still leaves us with k distinct files.
        // Files commonly own multiple matching chunks; an unfiltered fetch of `k`
        // would routinely yield <k unique paths after grouping.
        const fetchK = Math.min(Math.max(k * 8, 40), 400);
        const rows = yield table.search(vector).limit(fetchK).toArray();
        const rawHits = rows
            .map(toRawCodeHit)
            .filter((hit) => !pathGlob || (0, indexer_1.matchGlob)(hit.path, pathGlob));
        const grouped = groupByPath(rawHits);
        const topPaths = [...grouped.values()]
            .sort((a, b) => b.score - a.score)
            .slice(0, k);
        return Promise.all(topPaths.map((group) => __awaiter(this, void 0, void 0, function* () {
            const merged = mergeRanges(group.ranges);
            const code = {
                path: group.path,
                language: group.language,
                lineCount: 0,
                startLines: merged.map((r) => r.start),
                endLines: merged.map((r) => r.end),
            };
            return { type: 'code', score: group.score, code };
        })));
    });
}
function searchMemory(vector, k, kind, selectedIds) {
    return __awaiter(this, void 0, void 0, function* () {
        const getter = kind === 'findings' || (0, types_1.isFindingKind)(kind) ? db_1.getFindingsTable : db_1.getRevisitsTable;
        const { table } = yield getter(null);
        if (!table)
            return [];
        const selectedIdSet = selectedIds !== undefined ? new Set(selectedIds.filter((id) => typeof id === 'string' && id.length > 0)) : undefined;
        const fetchK = Math.min(k * 4, 200);
        const rows = yield table.search(vector).limit(fetchK).toArray();
        return rows
            .map(toMemoryHit)
            .filter((hit) => {
            if (!hit.memory) {
                return false;
            }
            if (kind !== 'findings' && hit.memory.kind !== kind) {
                return false;
            }
            if (selectedIdSet !== undefined && !selectedIdSet.has(hit.memory.id)) {
                return false;
            }
            return true;
        })
            .slice(0, k);
    });
}
function toRawCodeHit(raw) {
    const row = raw;
    return {
        path: row.path,
        language: row.language,
        startLine: row.startLine,
        endLine: row.endLine,
        score: distanceToScore(row._distance),
    };
}
function groupByPath(hits) {
    const groups = new Map();
    for (const hit of hits) {
        const existing = groups.get(hit.path);
        if (existing) {
            existing.ranges.push({ start: hit.startLine, end: hit.endLine });
            if (hit.score > existing.score)
                existing.score = hit.score;
        }
        else {
            groups.set(hit.path, {
                path: hit.path,
                language: hit.language,
                score: hit.score,
                ranges: [{ start: hit.startLine, end: hit.endLine }],
            });
        }
    }
    return groups;
}
function mergeRanges(ranges) {
    if (ranges.length === 0)
        return [];
    const sorted = [...ranges].sort((a, b) => a.start - b.start);
    const out = [Object.assign({}, sorted[0])];
    for (let i = 1; i < sorted.length; i++) {
        const cur = sorted[i];
        const tail = out[out.length - 1];
        if (cur.start <= tail.end + 1) {
            if (cur.end > tail.end)
                tail.end = cur.end;
        }
        else {
            out.push(Object.assign({}, cur));
        }
    }
    return out;
}
function toMemoryHit(raw) {
    const row = raw;
    const score = distanceToScore(row._distance);
    return {
        type: 'memory',
        score,
        memory: (0, types_1.decodeRow)(row),
    };
}
function distanceToScore(distance) {
    if (typeof distance !== 'number' || !Number.isFinite(distance))
        return 0;
    // LanceDB returns L2 distance by default for BGE vectors. Convert to a
    // similarity in [0, 1] by mapping with 1 / (1 + d). It's monotonic so the
    // sort order is preserved and consumers get a friendlier score.
    return 1 / (1 + distance);
}
function clamp(n, min, max) {
    if (n < min)
        return min;
    if (n > max)
        return max;
    return n;
}
