"use strict";
/**
 * LanceDB connection for the kra-memory layer.
 *
 * Storage layout:
 *   <repo>/.kra-memory/lance/        ← LanceDB datasets (one dir per table)
 *
 * `<repo>` is resolved from `WORKING_DIR` (set by the spawning provider when
 * the MCP server is launched as a child process) or `process.cwd()` for direct
 * tests.
 *
 * The `memory` table is created lazily on the first write. We do this rather
 * than declaring an Arrow schema up front so we can rely on LanceDB's
 * row-based schema inference and keep the table-management code small.
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getFindingsTable = getFindingsTable;
exports.getRevisitsTable = getRevisitsTable;
exports._resetCachesForTest = _resetCachesForTest;
exports.memoryDirectoryRoot = memoryDirectoryRoot;
exports.getCodeChunksTable = getCodeChunksTable;
exports.countCodeChunks = countCodeChunks;
const path_1 = __importDefault(require("path"));
const lancedb_1 = require("@lancedb/lancedb");
const MEMORY_FINDINGS_TABLE = 'memory_findings';
const MEMORY_REVISITS_TABLE = 'memory_revisits';
let dbCache = null;
let memoryFindingsTableCache = null;
let memoryRevisitsTableCache = null;
let codeChunksTableCache = null;
const CODE_CHUNKS_TABLE = 'code_chunks';
const LEGACY_MEMORY_TABLE = 'memory';
let legacyDropAttempted = false;
function memoryRoot() {
    var _a;
    const cwd = (_a = process.env['WORKING_DIR']) !== null && _a !== void 0 ? _a : process.cwd();
    return path_1.default.join(cwd, '.kra-memory');
}
function lanceRoot() {
    return path_1.default.join(memoryRoot(), 'lance');
}
function getDb() {
    return __awaiter(this, void 0, void 0, function* () {
        if (dbCache) {
            return dbCache;
        }
        dbCache = yield (0, lancedb_1.connect)(lanceRoot());
        if (!legacyDropAttempted) {
            legacyDropAttempted = true;
            try {
                const names = yield dbCache.tableNames();
                if (names.includes(LEGACY_MEMORY_TABLE)) {
                    yield dbCache.dropTable(LEGACY_MEMORY_TABLE);
                }
            }
            catch (_a) {
                // best-effort cleanup; ignore failures
            }
        }
        return dbCache;
    });
}
let mutex = Promise.resolve();
function getOrCreateMemoryTable(tableName, cacheGet, cacheSet, seedRow) {
    return __awaiter(this, void 0, void 0, function* () {
        const cached = cacheGet();
        if (cached) {
            return { table: cached, justCreated: false };
        }
        const next = mutex.then(() => __awaiter(this, void 0, void 0, function* () {
            const c = cacheGet();
            if (c) {
                return { table: c, justCreated: false };
            }
            const db = yield getDb();
            const tableNames = yield db.tableNames();
            if (tableNames.includes(tableName)) {
                const t = yield db.openTable(tableName);
                cacheSet(t);
                return { table: t, justCreated: false };
            }
            if (!seedRow) {
                return { table: null, justCreated: false };
            }
            const t = yield db.createTable(tableName, [seedRow]);
            cacheSet(t);
            return { table: t, justCreated: true };
        }));
        mutex = next.catch(() => undefined);
        return next;
    });
}
function getFindingsTable(seedRow) {
    return __awaiter(this, void 0, void 0, function* () {
        return getOrCreateMemoryTable(MEMORY_FINDINGS_TABLE, () => memoryFindingsTableCache, (t) => { memoryFindingsTableCache = t; }, seedRow);
    });
}
function getRevisitsTable(seedRow) {
    return __awaiter(this, void 0, void 0, function* () {
        return getOrCreateMemoryTable(MEMORY_REVISITS_TABLE, () => memoryRevisitsTableCache, (t) => { memoryRevisitsTableCache = t; }, seedRow);
    });
}
/**
 * Test-only reset of the in-process cache. Not exported via index.
 */
function _resetCachesForTest() {
    dbCache = null;
    memoryFindingsTableCache = null;
    memoryRevisitsTableCache = null;
    codeChunksTableCache = null;
    legacyDropAttempted = false;
}
/**
 * Returns the LanceDB root directory used by the memory layer.
 * Resolved relative to `WORKING_DIR` (set by the parent process when the MCP
 * server is spawned) or `process.cwd()` for direct calls.
 */
function memoryDirectoryRoot() {
    return memoryRoot();
}
/**
 * Returns the code_chunks table. Pass a seed row when about to write so the
 * table can be created on first use; pass `null` for read-only callers and
 * handle `table === null`.
 */
function getCodeChunksTable(seedRow) {
    return __awaiter(this, void 0, void 0, function* () {
        if (codeChunksTableCache) {
            return { table: codeChunksTableCache, justCreated: false };
        }
        const next = mutex.then(() => __awaiter(this, void 0, void 0, function* () {
            if (codeChunksTableCache) {
                return { table: codeChunksTableCache, justCreated: false };
            }
            const db = yield getDb();
            const tableNames = yield db.tableNames();
            if (tableNames.includes(CODE_CHUNKS_TABLE)) {
                codeChunksTableCache = yield db.openTable(CODE_CHUNKS_TABLE);
                return { table: codeChunksTableCache, justCreated: false };
            }
            if (!seedRow) {
                return { table: null, justCreated: false };
            }
            codeChunksTableCache = yield db.createTable(CODE_CHUNKS_TABLE, [seedRow]);
            return { table: codeChunksTableCache, justCreated: true };
        }));
        mutex = next.catch(() => undefined);
        return next;
    });
}
/**
 * Total number of code chunks currently stored. Returns 0 if the table has
 * never been created.
 */
function countCodeChunks() {
    return __awaiter(this, void 0, void 0, function* () {
        const { table } = yield getCodeChunksTable(null);
        if (!table)
            return 0;
        try {
            return yield table.countRows();
        }
        catch (_a) {
            return 0;
        }
    });
}
