"use strict";
/**
 * Compute which files have changed since the last code-index pass so the
 * agent can catch up without doing a full reindex on every launch.
 *
 * Strategy by repo type:
 *   - **Git repo with a known `lastIndexedCommit`**: union of
 *       `git diff --name-only $lastIndexedCommit HEAD` (committed changes
 *           since the index)
 *       `git status --porcelain` (modified, staged, and untracked uncommitted
 *           changes — including files the user edited externally before
 *           launching the agent).
 *     Deletions are reported with `kind: 'delete'`; everything else is
 *     `kind: 'index'`.
 *   - **Git repo without a `lastIndexedCommit`**: treat as first-time
 *       index — caller should run `reindexAll` instead.
 *   - **Non-git workspace**: walk the indexable file list (using the same
 *       filter as the indexer) and compare each file's mtime to
 *       `lastIndexedAt`.
 *
 * If the resulting change set exceeds `CATCHUP_FULL_REINDEX_THRESHOLD`, the
 * caller should prompt the user and prefer `reindexAll` for speed.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CATCHUP_FULL_REINDEX_THRESHOLD = void 0;
exports.computeChangedFiles = computeChangedFiles;
const fs = __importStar(require("fs/promises"));
const path_1 = __importDefault(require("path"));
const bashHelper_1 = require("@/utils/bashHelper");
const indexer_1 = require("./indexer");
const settings_1 = require("./settings");
exports.CATCHUP_FULL_REINDEX_THRESHOLD = 500;
function quote(value) {
    return `'${value.replace(/'/g, `'\\''`)}'`;
}
function tryExec(cmd) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const result = yield (0, bashHelper_1.execCommand)(cmd);
            return result.stdout;
        }
        catch (_a) {
            return null;
        }
    });
}
function getHeadCommit(repoRoot) {
    return __awaiter(this, void 0, void 0, function* () {
        const head = yield tryExec(`git -C ${quote(repoRoot)} rev-parse HEAD`);
        return head ? head.trim() || null : null;
    });
}
function isGitRepo(repoRoot) {
    return __awaiter(this, void 0, void 0, function* () {
        const inside = yield tryExec(`git -C ${quote(repoRoot)} rev-parse --is-inside-work-tree`);
        return inside !== null && inside.trim() === 'true';
    });
}
/**
 * Parse `git diff --name-status` output into our change shape. The format is
 * `<status>\t<path>` (or `<status>\t<old>\t<new>` for renames).
 */
function parseNameStatus(stdout) {
    var _a, _b;
    const changes = [];
    for (const rawLine of stdout.split('\n')) {
        const line = rawLine.trimEnd();
        if (!line)
            continue;
        const parts = line.split('\t');
        const status = (_b = (_a = parts[0]) === null || _a === void 0 ? void 0 : _a.charAt(0)) !== null && _b !== void 0 ? _b : '';
        if (status === 'D') {
            const p = parts[1];
            if (p)
                changes.push({ relPath: p, kind: 'delete' });
            continue;
        }
        if (status === 'R' || status === 'C') {
            const oldPath = parts[1];
            const newPath = parts[2];
            if (oldPath)
                changes.push({ relPath: oldPath, kind: 'delete' });
            if (newPath)
                changes.push({ relPath: newPath, kind: 'index' });
            continue;
        }
        const p = parts[1];
        if (p)
            changes.push({ relPath: p, kind: 'index' });
    }
    return changes;
}
/** Parse `git status --porcelain` (short form) into our change shape. */
function parsePorcelain(stdout) {
    const changes = [];
    for (const rawLine of stdout.split('\n')) {
        if (!rawLine)
            continue;
        // Lines look like ` M path`, `?? path`, `D  path`, `R  old -> new`, etc.
        const xy = rawLine.slice(0, 2);
        const rest = rawLine.slice(3);
        const isDelete = xy.includes('D');
        if (xy.startsWith('R') || xy.startsWith('C')) {
            const arrow = rest.indexOf(' -> ');
            if (arrow >= 0) {
                const oldPath = rest.slice(0, arrow).trim();
                const newPath = rest.slice(arrow + 4).trim();
                if (oldPath)
                    changes.push({ relPath: oldPath, kind: 'delete' });
                if (newPath)
                    changes.push({ relPath: newPath, kind: 'index' });
                continue;
            }
        }
        const p = rest.trim();
        if (!p)
            continue;
        changes.push({ relPath: p, kind: isDelete ? 'delete' : 'index' });
    }
    return changes;
}
function mergeChanges(...lists) {
    const seen = new Map();
    for (const list of lists) {
        for (const change of list) {
            // Later lists override earlier (uncommitted overrides committed).
            seen.set(change.relPath, change);
        }
    }
    return [...seen.values()];
}
/**
 * Build the list of files that need to be (re)indexed for the current
 * workspace, given the previously persisted `lastIndexedCommit` /
 * `lastIndexedAt` from the registry.
 */
function computeChangedFiles(opts) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        const repoRoot = (_a = opts.repoRoot) !== null && _a !== void 0 ? _a : (0, indexer_1.workspaceRoot)();
        if (yield isGitRepo(repoRoot)) {
            const headCommit = yield getHeadCommit(repoRoot);
            if (!opts.lastIndexedCommit) {
                return {
                    changes: [],
                    exceedsThreshold: false,
                    source: 'first-time',
                    headCommit,
                };
            }
            const settings = yield (0, settings_1.loadMemorySettings)();
            const committedRaw = yield tryExec(`git -C ${quote(repoRoot)} diff --name-status ${quote(opts.lastIndexedCommit)} HEAD`);
            const dirtyRaw = yield tryExec(`git -C ${quote(repoRoot)} status --porcelain`);
            const committed = committedRaw ? parseNameStatus(committedRaw) : [];
            const dirty = dirtyRaw ? parsePorcelain(dirtyRaw) : [];
            const merged = mergeChanges(committed, dirty)
                .filter((c) => c.kind === 'delete' || (0, indexer_1.isIndexable)(c.relPath, settings));
            return {
                changes: merged,
                exceedsThreshold: merged.length > exports.CATCHUP_FULL_REINDEX_THRESHOLD,
                source: 'git',
                headCommit,
            };
        }
        // Non-git fallback: mtime > lastIndexedAt across the indexable set.
        if (!opts.lastIndexedAt) {
            return { changes: [], exceedsThreshold: false, source: 'first-time', headCommit: null };
        }
        const settings = yield (0, settings_1.loadMemorySettings)();
        const files = yield (0, indexer_1.listIndexableFiles)(repoRoot, settings);
        const changes = [];
        for (const rel of files) {
            const abs = path_1.default.join(repoRoot, rel);
            try {
                const stat = yield fs.stat(abs);
                if (stat.mtimeMs > opts.lastIndexedAt) {
                    changes.push({ relPath: rel, kind: 'index' });
                }
            }
            catch (_b) {
                changes.push({ relPath: rel, kind: 'delete' });
            }
        }
        return {
            changes,
            exceedsThreshold: changes.length > exports.CATCHUP_FULL_REINDEX_THRESHOLD,
            source: 'mtime',
            headCommit: null,
        };
    });
}
