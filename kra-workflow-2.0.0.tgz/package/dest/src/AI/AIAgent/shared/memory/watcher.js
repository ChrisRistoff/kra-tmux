"use strict";
/**
 * Chokidar-backed file watcher for incremental code-chunk reindexing.
 *
 * Events are debounced per-path so a flurry of writes (e.g. formatter on
 * save) collapses into one reindex. Only paths matching the include filter
 * are reindexed; deletes remove the file's chunks entirely.
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.startWatcher = startWatcher;
const path_1 = __importDefault(require("path"));
const chokidar_1 = __importDefault(require("chokidar"));
const indexer_1 = require("./indexer");
const settings_1 = require("./settings");
const registry_1 = require("./registry");
const DEBOUNCE_MS = 500;
function startWatcher() {
    return __awaiter(this, void 0, void 0, function* () {
        const settings = yield (0, settings_1.loadMemorySettings)();
        if (!settings.enabled || !settings.indexCodeOnSave)
            return null;
        const root = (0, indexer_1.workspaceRoot)();
        const ignored = (filePath) => {
            const rel = path_1.default.relative(root, filePath);
            if (rel === '' || rel.startsWith('..'))
                return false;
            // Ignore directories that shouldn't be traversed even partially.
            if (rel.split(path_1.default.sep).some((p) => p === 'node_modules' || p === '.git' || p === '.kra-memory' || p === 'dest' || p === 'dist')) {
                return true;
            }
            return false;
        };
        const watcher = chokidar_1.default.watch(root, {
            ignored,
            ignoreInitial: true,
            persistent: true,
            awaitWriteFinish: { stabilityThreshold: 200, pollInterval: 50 },
        });
        const pending = new Map();
        const schedule = (kind, rel, currentSettings) => {
            const existing = pending.get(rel);
            if (existing)
                clearTimeout(existing);
            pending.set(rel, setTimeout(() => {
                pending.delete(rel);
                void run(kind, rel, currentSettings);
            }, DEBOUNCE_MS));
        };
        const handle = (event, filePath) => {
            const rel = path_1.default.relative(root, filePath);
            if (rel === '' || rel.startsWith('..'))
                return;
            if (event === 'unlink') {
                schedule('remove', rel, settings);
                return;
            }
            if (!(0, indexer_1.isIndexable)(rel, settings))
                return;
            schedule('index', rel, settings);
        };
        watcher.on('add', (p) => handle('add', p));
        watcher.on('change', (p) => handle('change', p));
        watcher.on('unlink', (p) => handle('unlink', p));
        return {
            close: () => __awaiter(this, void 0, void 0, function* () {
                for (const t of pending.values())
                    clearTimeout(t);
                pending.clear();
                yield watcher.close();
            }),
        };
    });
}
function run(kind, rel, settings) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            // Only the repos the user has explicitly opted into (i.e. a registry
            // entry exists) participate in incremental indexing. Without this
            // guard, any file save in an opted-out repo would silently recreate
            // the code_chunks table.
            const root = (0, indexer_1.workspaceRoot)();
            const identity = yield (0, registry_1.getRepoIdentity)(root);
            const existing = yield (0, registry_1.getRegistryEntry)(identity.id);
            if (!existing)
                return;
            if (kind === 'remove') {
                yield (0, indexer_1.removeFile)(rel);
            }
            else {
                yield (0, indexer_1.indexFile)(rel, { settings });
            }
            yield touchRegistryLastIndexed();
        }
        catch (err) {
            process.stderr.write(`[kra-memory] watcher ${kind} failed for ${rel}: ${err instanceof Error ? err.message : String(err)}\n`);
        }
    });
}
function touchRegistryLastIndexed() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const root = (0, indexer_1.workspaceRoot)();
            const identity = yield (0, registry_1.getRepoIdentity)(root);
            const existing = yield (0, registry_1.getRegistryEntry)(identity.id);
            if (!existing)
                return; // Only bump for repos the user explicitly opted into.
            yield (0, registry_1.upsertRegistryEntry)(identity.id, { lastIndexedAt: Date.now() });
        }
        catch (_a) {
            // Registry update is best-effort; never block the watcher on it.
        }
    });
}
