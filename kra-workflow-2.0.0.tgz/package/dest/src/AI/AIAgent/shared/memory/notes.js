"use strict";
/**
 * Memory operations exposed via the kra-memory MCP server.
 *
 * The public surface is intentionally tiny:
 *   - remember         add a memory entry (any kind, including 'revisit')
 *   - recall           vector search OR list mode (when query is omitted)
 *   - updateMemory     mark an entry resolved / dismissed (optionally with a resolution note)
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.remember = remember;
exports.recall = recall;
exports.listMemories = listMemories;
exports.updateMemory = updateMemory;
exports.deleteMemory = deleteMemory;
exports.editMemory = editMemory;
const crypto_1 = __importDefault(require("crypto"));
const embedder_1 = require("./embedder");
const db_1 = require("./db");
const types_1 = require("./types");
const DEFAULT_RECALL_K = 5;
const DEFAULT_LIST_LIMIT = 50;
const MAX_BODY_FETCH = 1000;
function newId() {
    return crypto_1.default.randomBytes(8).toString('hex');
}
function sanitizeStringList(input) {
    if (!Array.isArray(input)) {
        return [];
    }
    const seen = new Set();
    for (const item of input) {
        if (typeof item === 'string' && item.length > 0) {
            seen.add(item);
        }
    }
    return [...seen];
}
function embedTextFor(title, body) {
    return `${title}\n\n${body}`.trim();
}
function buildRow(base) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        const vector = yield (0, embedder_1.embedOne)(embedTextFor(base.title, base.body));
        return Object.assign(Object.assign({}, base), { updatedAt: (_a = base.updatedAt) !== null && _a !== void 0 ? _a : base.createdAt, vector });
    });
}
function pickTableGetter(kind) {
    return (0, types_1.isRevisitKind)(kind) ? db_1.getRevisitsTable : db_1.getFindingsTable;
}
function pickReadTableGetter(kind) {
    return kind === 'findings' || (0, types_1.isFindingKind)(kind) ? db_1.getFindingsTable : db_1.getRevisitsTable;
}
function remember(input) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b;
        if (!input.title || !input.body) {
            throw new Error('remember: title and body are required');
        }
        if (!(0, types_1.isFindingKind)(input.kind) && !(0, types_1.isRevisitKind)(input.kind)) {
            throw new Error(`remember: unknown kind '${input.kind}'`);
        }
        const now = Date.now();
        const row = yield buildRow({
            id: newId(),
            kind: input.kind,
            title: input.title.trim(),
            body: input.body.trim(),
            tags: JSON.stringify(sanitizeStringList(input.tags)),
            paths: JSON.stringify(sanitizeStringList(input.paths)),
            branch: (_a = input.branch) !== null && _a !== void 0 ? _a : '',
            status: (0, types_1.isRevisitKind)(input.kind) ? 'open' : 'resolved',
            resolution: '',
            createdAt: now,
            source: (_b = input.source) !== null && _b !== void 0 ? _b : 'agent-auto',
        });
        const getter = pickTableGetter(input.kind);
        const { table, justCreated } = yield getter(row);
        if (!table) {
            throw new Error('remember: failed to obtain memory table');
        }
        if (!justCreated) {
            yield table.add([row]);
        }
        return { id: row.id };
    });
}
function readFromTable(table, input) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c, _d;
        const k = Math.max(1, Math.min((_a = input.k) !== null && _a !== void 0 ? _a : DEFAULT_RECALL_K, 200));
        const tagFilter = sanitizeStringList(input.tagsAny);
        const selectedIdSet = input.selectedIds !== undefined ? new Set(sanitizeStringList(input.selectedIds)) : undefined;
        const query = (_c = (_b = input.query) === null || _b === void 0 ? void 0 : _b.trim()) !== null && _c !== void 0 ? _c : '';
        const matchesFilters = (row) => {
            if (input.kind && input.kind !== 'findings' && row.kind !== input.kind) {
                return false;
            }
            if (selectedIdSet !== undefined && !selectedIdSet.has(row.id)) {
                return false;
            }
            if (input.status && row.status !== input.status) {
                return false;
            }
            if (tagFilter.length > 0) {
                const decoded = (0, types_1.decodeRow)(row);
                if (!tagFilter.some((t) => decoded.tags.includes(t))) {
                    return false;
                }
            }
            return true;
        };
        if (query.length === 0) {
            const total = yield table.countRows();
            if (total === 0) {
                return [];
            }
            const fetchLimit = Math.min(total, MAX_BODY_FETCH);
            const raw = yield table.query().limit(fetchLimit).toArray();
            const out = [];
            for (const r of raw) {
                const row = r;
                if (!matchesFilters(row)) {
                    continue;
                }
                out.push(Object.assign(Object.assign({}, (0, types_1.decodeRow)(row)), { score: 0 }));
            }
            out.sort((a, b) => b.createdAt - a.createdAt);
            const limit = Math.min((_d = input.k) !== null && _d !== void 0 ? _d : DEFAULT_LIST_LIMIT, k);
            return out.slice(0, limit);
        }
        const queryVector = yield (0, embedder_1.embedOne)(query);
        const fetchK = Math.min(k * 4, MAX_BODY_FETCH);
        const raw = yield table.search(queryVector).limit(fetchK).toArray();
        const out = [];
        for (const r of raw) {
            const row = r;
            if (!matchesFilters(row)) {
                continue;
            }
            out.push(Object.assign(Object.assign({}, (0, types_1.decodeRow)(row)), { score: 1 - row._distance }));
            if (out.length >= k) {
                break;
            }
        }
        return out;
    });
}
function recall(input) {
    return __awaiter(this, void 0, void 0, function* () {
        if (!(0, types_1.isMemoryLookupKind)(input.kind)) {
            throw new Error(`recall: 'kind' is required and must be one of: ${types_1.MEMORY_LOOKUP_KINDS.join(', ')}`);
        }
        const getter = pickReadTableGetter(input.kind);
        const { table } = yield getter(null);
        if (!table) {
            return [];
        }
        const subInput = {
            kind: input.kind,
        };
        if (input.query !== undefined) {
            subInput.query = input.query;
        }
        if (input.k !== undefined) {
            subInput.k = input.k;
        }
        if (input.selectedIds !== undefined) {
            subInput.selectedIds = input.selectedIds;
        }
        if (input.tagsAny !== undefined) {
            subInput.tagsAny = input.tagsAny;
        }
        if (input.status !== undefined) {
            subInput.status = input.status;
        }
        return readFromTable(table, subInput);
    });
}
/**
 * UI-oriented listing that returns entries from one or both memory tables
 * without requiring a single specific MemoryKind. Always list mode (no vector
 * search). Sorted newest-first across the merged result set.
 */
function listMemories(input) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        const limit = Math.max(1, Math.min((_a = input.limit) !== null && _a !== void 0 ? _a : 200, MAX_BODY_FETCH));
        const out = [];
        const fetchOne = (getter) => __awaiter(this, void 0, void 0, function* () {
            const { table } = yield getter(null);
            if (!table) {
                return;
            }
            const subInput = { k: limit };
            if (input.tagsAny !== undefined) {
                subInput.tagsAny = input.tagsAny;
            }
            const part = yield readFromTable(table, subInput);
            out.push(...part);
        });
        if (input.scope === 'findings' || input.scope === 'all') {
            yield fetchOne(db_1.getFindingsTable);
        }
        if (input.scope === 'revisits' || input.scope === 'all') {
            yield fetchOne(db_1.getRevisitsTable);
        }
        out.sort((a, b) => b.createdAt - a.createdAt);
        return out.slice(0, limit);
    });
}
function updateMemory(input) {
    return __awaiter(this, void 0, void 0, function* () {
        if (!input.id) {
            throw new Error('update_memory: id is required');
        }
        const status = input.status;
        if (status !== 'open' && status !== 'resolved' && status !== 'dismissed') {
            throw new Error(`update_memory: status must be 'open', 'resolved' or 'dismissed', got '${status}'`);
        }
        const { table } = yield (0, db_1.getRevisitsTable)(null);
        if (!table) {
            throw new Error('update_memory: revisits table does not exist yet');
        }
        const safeId = input.id.replace(/'/g, "''");
        const updateValues = {
            status: input.status,
            updatedAt: Date.now(),
        };
        if (status === 'open') {
            // Reopening clears any prior resolution note so the entry is back to a
            // pristine "awaiting human input" state.
            updateValues['resolution'] = '';
        }
        else if (input.resolution !== undefined) {
            updateValues['resolution'] = input.resolution;
        }
        yield table.update({
            values: updateValues,
            where: `id = '${safeId}'`,
        });
        return { ok: true };
    });
}
function findRowAcrossTables(id) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        const safeId = id.replace(/'/g, "''");
        const tryGetter = (getter) => __awaiter(this, void 0, void 0, function* () {
            const { table } = yield getter(null);
            if (!table) {
                return null;
            }
            const found = yield table.query().where(`id = '${safeId}'`).limit(1).toArray();
            if (found.length === 0) {
                return null;
            }
            return { table, row: found[0] };
        });
        return (_a = (yield tryGetter(db_1.getRevisitsTable))) !== null && _a !== void 0 ? _a : (yield tryGetter(db_1.getFindingsTable));
    });
}
function deleteMemory(id) {
    return __awaiter(this, void 0, void 0, function* () {
        if (!id) {
            throw new Error('delete_memory: id is required');
        }
        const safeId = id.replace(/'/g, "''");
        const where = `id = '${safeId}'`;
        const { table: revisitsTable } = yield (0, db_1.getRevisitsTable)(null);
        if (revisitsTable) {
            yield revisitsTable.delete(where);
        }
        const { table: findingsTable } = yield (0, db_1.getFindingsTable)(null);
        if (findingsTable) {
            yield findingsTable.delete(where);
        }
        return { ok: true };
    });
}
function editMemory(input) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a;
        if (!input.id) {
            throw new Error('edit_memory: id is required');
        }
        const located = yield findRowAcrossTables(input.id);
        if (!located) {
            throw new Error(`edit_memory: no entry found for id '${input.id}'`);
        }
        const { table, row } = located;
        const safeId = input.id.replace(/'/g, "''");
        const newTitle = input.title !== undefined ? input.title.trim() : row.title;
        const newBody = input.body !== undefined ? input.body.trim() : row.body;
        const newTags = input.tags !== undefined ? JSON.stringify(sanitizeStringList(input.tags)) : row.tags;
        const newPaths = input.paths !== undefined ? JSON.stringify(sanitizeStringList(input.paths)) : row.paths;
        const newBranch = input.branch !== undefined ? ((_a = input.branch) !== null && _a !== void 0 ? _a : '') : row.branch;
        const updateValues = {
            title: newTitle,
            body: newBody,
            tags: newTags,
            paths: newPaths,
            branch: newBranch,
            updatedAt: Date.now(),
        };
        if (input.title !== undefined || input.body !== undefined) {
            updateValues['vector'] = yield (0, embedder_1.embedOne)(embedTextFor(newTitle, newBody));
        }
        yield table.update({
            values: updateValues,
            where: `id = '${safeId}'`,
        });
        return { ok: true };
    });
}
