"use strict";
/**
 * Central registry of code-indexed repositories.
 *
 * Lives at `~/.kra-memory/registry.json`. Each entry is keyed by a stable
 * repo identity (git origin URL when available, falling back to the absolute
 * top-level path) and records the metadata the agent needs to decide whether
 * to re-index, what to catch up, and how to label the repo in the UI.
 *
 * The actual code-chunks LanceDB still lives at `${repoRoot}/.kra-memory/`
 * and is opened per-cwd by `db.ts` — this registry is pure metadata, not the
 * data store.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getRepoIdentity = getRepoIdentity;
exports.loadRegistry = loadRegistry;
exports.saveRegistry = saveRegistry;
exports.getRegistryEntry = getRegistryEntry;
exports.upsertRegistryEntry = upsertRegistryEntry;
exports.removeRegistryEntry = removeRegistryEntry;
const os_1 = __importDefault(require("os"));
const path_1 = __importDefault(require("path"));
const fs = __importStar(require("fs/promises"));
const fileSafety_1 = require("@/AI/AIAgent/shared/utils/fileSafety");
const bashHelper_1 = require("@/utils/bashHelper");
const EMPTY_REGISTRY = { version: 1, repos: {} };
function registryRoot() {
    return path_1.default.join(os_1.default.homedir(), '.kra-memory');
}
function registryPath() {
    return path_1.default.join(registryRoot(), 'registry.json');
}
/**
 * Resolve a stable identifier for the repo rooted at `cwd`. Prefers the git
 * remote origin URL because it survives renames and re-clones; falls back to
 * the absolute top-level path for non-git workspaces.
 */
function getRepoIdentity(cwd) {
    return __awaiter(this, void 0, void 0, function* () {
        const top = yield tryExec(`git -C '${cwd.replace(/'/g, `'\\''`)}' rev-parse --show-toplevel`);
        const rootPath = top !== null && top !== void 0 ? top : path_1.default.resolve(cwd);
        const origin = yield tryExec(`git -C '${rootPath.replace(/'/g, `'\\''`)}' config --get remote.origin.url`);
        const id = origin && origin.length > 0 ? origin : rootPath;
        const alias = path_1.default.basename(rootPath);
        return { id, rootPath, alias };
    });
}
function tryExec(cmd) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const result = yield (0, bashHelper_1.execCommand)(cmd);
            const out = result.stdout.trim();
            return out.length > 0 ? out : null;
        }
        catch (_a) {
            return null;
        }
    });
}
function loadRegistry() {
    return __awaiter(this, void 0, void 0, function* () {
        const file = registryPath();
        try {
            const raw = yield fs.readFile(file, 'utf8');
            const parsed = JSON.parse(raw);
            if (!parsed || typeof parsed !== 'object' || parsed.version !== 1 || !parsed.repos) {
                return Object.assign({}, EMPTY_REGISTRY);
            }
            return { version: 1, repos: parsed.repos };
        }
        catch (_a) {
            return Object.assign({}, EMPTY_REGISTRY);
        }
    });
}
function saveRegistry(reg) {
    return __awaiter(this, void 0, void 0, function* () {
        yield fs.mkdir(registryRoot(), { recursive: true });
        yield (0, fileSafety_1.atomicWriteFile)(registryPath(), `${JSON.stringify(reg, null, 2)}\n`);
    });
}
function getRegistryEntry(id) {
    return __awaiter(this, void 0, void 0, function* () {
        const reg = yield loadRegistry();
        return reg.repos[id];
    });
}
/**
 * Merge `patch` into the entry for `id`, creating the entry if it does not
 * yet exist. `alias` and `rootPath` must be supplied on first creation.
 */
function upsertRegistryEntry(id, patch) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k;
        const reg = yield loadRegistry();
        const existing = reg.repos[id];
        const next = {
            alias: (_b = (_a = patch.alias) !== null && _a !== void 0 ? _a : existing.alias) !== null && _b !== void 0 ? _b : id,
            rootPath: (_d = (_c = patch.rootPath) !== null && _c !== void 0 ? _c : existing.rootPath) !== null && _d !== void 0 ? _d : '',
            lastIndexedCommit: (_f = (_e = patch.lastIndexedCommit) !== null && _e !== void 0 ? _e : existing.lastIndexedCommit) !== null && _f !== void 0 ? _f : '',
            lastIndexedAt: (_h = (_g = patch.lastIndexedAt) !== null && _g !== void 0 ? _g : existing.lastIndexedAt) !== null && _h !== void 0 ? _h : 0,
            chunksCount: (_k = (_j = patch.chunksCount) !== null && _j !== void 0 ? _j : existing.chunksCount) !== null && _k !== void 0 ? _k : 0,
        };
        reg.repos[id] = next;
        yield saveRegistry(reg);
        return next;
    });
}
function removeRegistryEntry(id) {
    return __awaiter(this, void 0, void 0, function* () {
        const reg = yield loadRegistry();
        if (!(id in reg.repos))
            return false;
        delete reg.repos[id];
        yield saveRegistry(reg);
        return true;
    });
}
