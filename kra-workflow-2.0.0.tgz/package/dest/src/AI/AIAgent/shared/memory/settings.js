"use strict";
/**
 * Settings loader for the kra-memory layer.
 *
 * Reads the `[ai.agent.memory]` block from `settings.toml` (via the shared
 * settings loader) and fills in defaults. Returned shape is normalised so the
 * rest of the memory layer never has to deal with `undefined`.
 *
 * NOTE: this module is loaded by both the long-lived agent process and the
 * MCP server child. Both share the same defaults.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.loadMemorySettings = loadMemorySettings;
const promises_1 = __importDefault(require("fs/promises"));
const toml = __importStar(require("smol-toml"));
const filePaths_1 = require("@/filePaths");
const DEFAULT_INCLUDE_EXTENSIONS = [
    '.ts', '.tsx', '.mts', '.cts',
    '.js', '.jsx', '.mjs', '.cjs',
    '.py', '.go', '.rs', '.java', '.kt',
    '.c', '.h', '.cc', '.cpp', '.cxx', '.hpp',
    '.rb', '.php', '.lua',
    '.md', '.toml', '.yaml', '.yml', '.json', '.jsonc',
];
// Globs applied to the relative path (POSIX separators).
const DEFAULT_EXCLUDE_GLOBS = [
    'node_modules/**',
    'dest/**',
    'dist/**',
    'build/**',
    'coverage/**',
    '.git/**',
    '.kra-memory/**',
    '.next/**',
    '.cache/**',
    '**/*.min.js',
    '**/*.min.css',
    '**/*.map',
    '**/*.lock',
    '**/package-lock.json',
];
const DEFAULTS = {
    enabled: true,
    indexCodeOnStart: false,
    indexCodeOnSave: false,
    autoSurfaceOnStart: false,
    gitignoreMemory: true,
    includeExtensions: DEFAULT_INCLUDE_EXTENSIONS,
    excludeGlobs: DEFAULT_EXCLUDE_GLOBS,
    chunkLines: 80,
    chunkOverlap: 5,
};
function loadMemorySettings() {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, _b, _c, _d, _e, _f, _g;
        let raw = {};
        try {
            const content = yield promises_1.default.readFile(filePaths_1.settingsFilePath, 'utf8');
            const parsed = toml.parse(content);
            const memory = (_b = (_a = parsed.ai) === null || _a === void 0 ? void 0 : _a.agent) === null || _b === void 0 ? void 0 : _b.memory;
            if (memory && typeof memory === 'object')
                raw = memory;
        }
        catch (_h) {
            // settings.toml not present yet — fall back to defaults.
        }
        return {
            enabled: (_c = raw.enabled) !== null && _c !== void 0 ? _c : DEFAULTS.enabled,
            indexCodeOnStart: (_d = raw.indexCodeOnStart) !== null && _d !== void 0 ? _d : DEFAULTS.indexCodeOnStart,
            indexCodeOnSave: (_e = raw.indexCodeOnSave) !== null && _e !== void 0 ? _e : DEFAULTS.indexCodeOnSave,
            autoSurfaceOnStart: (_f = raw.autoSurfaceOnStart) !== null && _f !== void 0 ? _f : DEFAULTS.autoSurfaceOnStart,
            gitignoreMemory: (_g = raw.gitignoreMemory) !== null && _g !== void 0 ? _g : DEFAULTS.gitignoreMemory,
            includeExtensions: Array.isArray(raw.includeExtensions) && raw.includeExtensions.length > 0
                ? raw.includeExtensions.map(normaliseExt)
                : DEFAULTS.includeExtensions,
            excludeGlobs: Array.isArray(raw.excludeGlobs) && raw.excludeGlobs.length > 0
                ? raw.excludeGlobs
                : DEFAULTS.excludeGlobs,
            chunkLines: clampInt(raw.chunkLines, 20, 400, DEFAULTS.chunkLines),
            chunkOverlap: clampInt(raw.chunkOverlap, 0, 50, DEFAULTS.chunkOverlap),
        };
    });
}
function normaliseExt(ext) {
    return ext.startsWith('.') ? ext : `.${ext}`;
}
function clampInt(value, min, max, fallback) {
    if (typeof value !== 'number' || !Number.isFinite(value))
        return fallback;
    const i = Math.round(value);
    if (i < min)
        return min;
    if (i > max)
        return max;
    return i;
}
