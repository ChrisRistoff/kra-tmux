"use strict";
/**
 * Shared types for the kra-memory layer.
 *
 * The memory layer is provider-neutral and lives entirely under
 * `src/AI/AIAgent/shared/memory/`. It is exposed to agents through the
 * `kra-memory` MCP server (`src/AI/AIAgent/shared/utils/memoryMcpServer.ts`).
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.MEMORY_SOURCES = exports.MEMORY_STATUSES = exports.MEMORY_LOOKUP_KINDS = exports.MEMORY_KINDS = exports.REVISIT_KIND = exports.FINDING_KINDS = void 0;
exports.isRevisitKind = isRevisitKind;
exports.isFindingKind = isFindingKind;
exports.isMemoryLookupKind = isMemoryLookupKind;
exports.decodeRow = decodeRow;
exports.FINDING_KINDS = [
    'note',
    'bug-fix',
    'gotcha',
    'decision',
    'investigation',
];
exports.REVISIT_KIND = 'revisit';
exports.MEMORY_KINDS = [
    ...exports.FINDING_KINDS,
    exports.REVISIT_KIND,
];
exports.MEMORY_LOOKUP_KINDS = ['findings', ...exports.MEMORY_KINDS];
function isRevisitKind(kind) {
    return kind === exports.REVISIT_KIND;
}
function isFindingKind(kind) {
    return exports.FINDING_KINDS.includes(kind);
}
function isMemoryLookupKind(kind) {
    return kind === 'findings' || exports.MEMORY_KINDS.includes(kind);
}
exports.MEMORY_STATUSES = ['open', 'resolved', 'dismissed'];
exports.MEMORY_SOURCES = ['user', 'agent-auto'];
function decodeRow(row) {
    return {
        id: row.id,
        kind: row.kind,
        title: row.title,
        body: row.body,
        tags: parseList(row.tags),
        paths: parseList(row.paths),
        branch: row.branch === '' ? null : row.branch,
        status: row.status,
        resolution: row.resolution === '' ? null : row.resolution,
        createdAt: row.createdAt,
        updatedAt: row.updatedAt,
        source: row.source,
    };
}
function parseList(serialized) {
    if (!serialized) {
        return [];
    }
    try {
        const parsed = JSON.parse(serialized);
        return Array.isArray(parsed) ? parsed.filter((x) => typeof x === 'string') : [];
    }
    catch (_a) {
        return [];
    }
}
