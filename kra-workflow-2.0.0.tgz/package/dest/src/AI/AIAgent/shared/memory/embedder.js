"use strict";
/**
 * fastembed wrapper for the kra-memory layer.
 *
 * Uses BGESmallENV15 (384-dim, ~33MB quantized) for a balance of quality and
 * footprint. Model is loaded lazily on first call. The model cache lives in a
 * stable user-global directory so we don't pollute every working tree with a
 * local_cache/ folder.
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __asyncValues = (this && this.__asyncValues) || function (o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
    function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
    function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.VECTOR_DIM = void 0;
exports.embedOne = embedOne;
exports.embedMany = embedMany;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const fastembed_1 = require("fastembed");
const filePaths_1 = require("@/filePaths");
const MODEL = fastembed_1.EmbeddingModel.BGESmallENV15;
exports.VECTOR_DIM = 384;
let cachedModel = null;
let pendingLoad = null;
function defaultCacheDir() {
    const override = process.env['KRA_MEMORY_MODEL_CACHE'];
    if (override && override.length > 0) {
        return override;
    }
    return path_1.default.join((0, filePaths_1.kraHome)(), 'cache', 'fastembed');
}
function loadModel() {
    return __awaiter(this, void 0, void 0, function* () {
        if (cachedModel) {
            return cachedModel;
        }
        if (pendingLoad) {
            return pendingLoad;
        }
        const cacheDir = defaultCacheDir();
        fs_1.default.mkdirSync(cacheDir, { recursive: true });
        pendingLoad = fastembed_1.FlagEmbedding.init({
            model: MODEL,
            cacheDir,
        }).then((model) => {
            cachedModel = model;
            pendingLoad = null;
            return model;
        }).catch((error) => {
            pendingLoad = null;
            throw error;
        });
        return pendingLoad;
    });
}
/**
 * Embed a single string. Returns a plain `number[]` so it can be passed
 * directly to LanceDB without Arrow conversion gymnastics.
 */
function embedOne(text) {
    return __awaiter(this, void 0, void 0, function* () {
        const results = yield embedMany([text]);
        if (results.length === 0) {
            throw new Error('embedOne: fastembed returned no vectors');
        }
        return results[0];
    });
}
/**
 * Embed a batch of strings. Order of returned vectors matches input order.
 */
function embedMany(texts) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, e_1, _b, _c;
        if (texts.length === 0) {
            return [];
        }
        const model = yield loadModel();
        const out = [];
        try {
            for (var _d = true, _e = __asyncValues(model.embed(texts, Math.min(32, texts.length))), _f; _f = yield _e.next(), _a = _f.done, !_a; _d = true) {
                _c = _f.value;
                _d = false;
                const batch = _c;
                for (const vec of batch) {
                    out.push(Array.from(vec));
                }
            }
        }
        catch (e_1_1) { e_1 = { error: e_1_1 }; }
        finally {
            try {
                if (!_d && !_a && (_b = _e.return)) yield _b.call(_e);
            }
            finally { if (e_1) throw e_1.error; }
        }
        if (out.length !== texts.length) {
            throw new Error(`embedMany: expected ${texts.length} vectors, got ${out.length}`);
        }
        return out;
    });
}
