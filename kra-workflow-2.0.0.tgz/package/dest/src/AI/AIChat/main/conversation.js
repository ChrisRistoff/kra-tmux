"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __asyncValues = (this && this.__asyncValues) || function (o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
    function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
    function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.converse = converse;
exports.initializeChatFile = initializeChatFile;
const fs = __importStar(require("fs/promises"));
const neovim = __importStar(require("neovim"));
const roles_1 = require("@/AI/shared/data/roles");
const promptModel_1 = require("@/AI/AIChat/utils/promptModel");
const saveChat_1 = require("@/AI/AIChat/utils/saveChat");
const aiTypes_1 = require("@/AI/shared/types/aiTypes");
const bash = __importStar(require("@/utils/bashHelper"));
const neovimHelper_1 = require("@/utils/neovimHelper");
const filePaths_1 = require("@/filePaths");
const conversation = __importStar(require("@/AI/shared/conversation"));
const chatHeaders_1 = require("@/AI/shared/utils/conversationUtils/chatHeaders");
const aiNeovimHelper = conversation;
const fileContext = conversation;
// stream controller for the current request
let currentStreamController = null;
function converse(chatFile_1, temperature_1, role_1, provider_1, model_1) {
    return __awaiter(this, arguments, void 0, function* (chatFile, temperature, role, provider, model, isChatLoaded = false) {
        try {
            if (!isChatLoaded) {
                fileContext.clearFileContexts();
                yield initializeChatFile(chatFile, true);
            }
            else {
                yield fileContext.rebuildFileContextsFromChat(chatFile);
            }
            const socketPath = yield aiNeovimHelper.generateSocketPath();
            // open neovim and listen to socket
            if (process.env.TMUX) {
                const tmuxCommand = `tmux split-window -v -p 90 -c "#{pane_current_path}" \; \
                tmux send-keys -t :. 'sh -c "trap \\"exit 0\\" TERM; nvim -u ${filePaths_1.neovimConfig} --listen \\"${socketPath}\\" \\"${chatFile}\\"d;
                tmux send-keys exit C-m"' C-m`;
                bash.execCommand(tmuxCommand);
            }
            else {
                (0, neovimHelper_1.openVim)(chatFile, '-u', filePaths_1.neovimConfig, '--listen', socketPath);
            }
            yield aiNeovimHelper.waitForSocket(socketPath);
            const nvim = neovim.attach({ socket: socketPath });
            const channelId = yield nvim.channelId;
            try {
                yield aiNeovimHelper.addNeovimFunctions(nvim, channelId);
                yield aiNeovimHelper.addCommands(nvim);
                yield aiNeovimHelper.setupKeyBindings(nvim);
            }
            catch (error) {
                console.error('Error setting up commands:', error);
            }
            // open the file in Neovim
            yield nvim.command(`edit ${chatFile}`);
            yield aiNeovimHelper.setupChatSplitLayout(nvim, channelId);
            yield aiNeovimHelper.refreshChatLayout(nvim);
            yield aiNeovimHelper.focusChatPrompt(nvim);
            yield setupEventHandlers(nvim, chatFile, provider, model, temperature, role);
            nvim.on('disconnect', () => __awaiter(this, void 0, void 0, function* () {
                console.log('Chat Ended.');
                const conversationHistory = yield fs.readFile(chatFile, 'utf8');
                const fullPrompt = conversationHistory + '\n';
                yield (0, saveChat_1.saveChat)(chatFile, provider, model, role, temperature, parseChatHistory(fullPrompt));
                yield fs.rm(chatFile);
            }));
        }
        catch (error) {
            console.error('Error in AI prompt workflow:', error.message);
            throw error;
        }
    });
}
function setupEventHandlers(nvim, chatFile, provider, model, temperature, role) {
    return __awaiter(this, void 0, void 0, function* () {
        nvim.on('notification', (method, args) => __awaiter(this, void 0, void 0, function* () {
            if (method !== 'prompt_action')
                return;
            const action = args[0];
            switch (action) {
                case 'submit_pressed':
                    yield handleSubmit(nvim, chatFile, provider, model, temperature, role);
                    break;
                case 'add_file_context':
                    yield fileContext.handleAddFileContext(nvim, chatFile);
                    break;
                case 'stop_stream':
                    yield aiNeovimHelper.handleStopStream(currentStreamController, nvim);
                    break;
                case 'show_contexts_popup':
                    yield fileContext.showFileContextsPopup(nvim);
                    break;
                case 'remove_file_context':
                    yield fileContext.handleRemoveFileContext(nvim, chatFile);
                    break;
                case 'clear_contexts':
                    yield fileContext.clearAllFileContexts(nvim, chatFile);
                    break;
                default:
                    console.log('Unknown action:', action);
            }
        }));
    });
}
function handleSubmit(nvim, chatFile, provider, model, temperature, role) {
    return __awaiter(this, void 0, void 0, function* () {
        const prompt = yield aiNeovimHelper.getChatPromptText(nvim);
        if (!prompt.trim()) {
            yield nvim.command('echohl WarningMsg | echo "Type a prompt before submitting" | echohl None');
            yield aiNeovimHelper.focusChatPrompt(nvim);
            return;
        }
        const conversationHistory = yield fs.readFile(chatFile, 'utf8');
        const trimmedPrompt = prompt.trim();
        const turnTimestamp = new Date().toISOString();
        const promptCompletion = `${trimmedPrompt}\n`;
        // Replace the trailing `(draft)` USER header with a real timestamped one
        // so the prompt body (and any @-added file context) sits under it cleanly.
        yield (0, chatHeaders_1.materializeUserDraft)(chatFile, turnTimestamp);
        yield appendToChat(chatFile, promptCompletion);
        yield aiNeovimHelper.clearChatPrompt(nvim);
        // Load fresh file contexts right before sending to LLM.
        const fileContextPrompt = yield fileContext.getFileContextsForPrompt();
        const fullPrompt = conversationHistory + promptCompletion + fileContextPrompt + '\n';
        yield appendToChat(chatFile, (0, chatHeaders_1.formatAssistantHeader)(model, turnTimestamp));
        yield aiNeovimHelper.refreshChatLayout(nvim);
        yield aiNeovimHelper.focusChatPrompt(nvim);
        // create stream controller for this request
        currentStreamController = createStreamController();
        try {
            const response = yield (0, promptModel_1.promptModel)(provider, model, fullPrompt, temperature, roles_1.aiRoles[role], currentStreamController);
            yield handleStreamingResponse(response, chatFile, nvim, currentStreamController);
        }
        catch (error) {
            if (currentStreamController.isAborted) {
                yield appendToChat(chatFile, '\n[Generation stopped by user]\n');
            }
            else {
                console.error('Error in AI response:', error);
                yield appendToChat(chatFile, '\n[Error generating response]\n');
            }
        }
        finally {
            currentStreamController = null;
            yield appendToChat(chatFile, (0, chatHeaders_1.formatUserDraftHeader)());
            yield aiNeovimHelper.refreshChatLayout(nvim);
            yield aiNeovimHelper.focusChatPrompt(nvim);
        }
    });
}
function handleStreamingResponse(response, chatFile, nvim, controller) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, response_1, response_1_1;
        var _b, e_1, _c, _d;
        let pendingBuffer = '';
        let lastUpdate = Date.now();
        const updateInterval = 100;
        try {
            try {
                for (_a = true, response_1 = __asyncValues(response); response_1_1 = yield response_1.next(), _b = response_1_1.done, !_b; _a = true) {
                    _d = response_1_1.value;
                    _a = false;
                    const chunk = _d;
                    if (controller.isAborted) {
                        break;
                    }
                    pendingBuffer += chunk;
                    if (Date.now() - lastUpdate >= updateInterval) {
                        yield appendToChat(chatFile, pendingBuffer);
                        yield aiNeovimHelper.refreshChatLayout(nvim);
                        pendingBuffer = '';
                        lastUpdate = Date.now();
                    }
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (!_a && !_b && (_c = response_1.return)) yield _c.call(response_1);
                }
                finally { if (e_1) throw e_1.error; }
            }
            if (pendingBuffer && !controller.isAborted) {
                yield appendToChat(chatFile, pendingBuffer);
                yield aiNeovimHelper.refreshChatLayout(nvim);
            }
            yield aiNeovimHelper.refreshChatLayout(nvim);
        }
        catch (error) {
            if (!controller.isAborted) {
                throw error;
            }
        }
    });
}
function createStreamController() {
    let isAborted = false;
    return {
        abort: () => {
            isAborted = true;
        },
        get isAborted() {
            return isAborted;
        }
    };
}
function initializeChatFile(filePath_1) {
    return __awaiter(this, arguments, void 0, function* (filePath, userPrompt = false) {
        const initialContent = `
# AI Chat History

This file contains the conversation history between the user and AI.

        # Controls / Shortcuts:
        #   Enter          -> Submit prompt
        #   Tab / S-Tab    -> Switch between transcript and prompt
        #   @              -> Add File Context(s) (<Tab> multi-select, + marks selections, <CR> confirm, <Esc> cancel)
        #   r              -> Remove File From Context
        #   f              -> Show Current File Contexts
        #   <C-x>          -> Clear Contexts
        #   <C-c>          -> Stop Stream
        #
        # Tip: Type your next message in the bottom prompt split.
`;
        const finalContent = userPrompt
            ? `${initialContent}${(0, chatHeaders_1.formatUserDraftHeader)()}`
            : initialContent;
        yield fs.writeFile(filePath, finalContent, 'utf-8');
    });
}
function appendToChat(file, content) {
    return __awaiter(this, void 0, void 0, function* () {
        yield fs.appendFile(file, content, 'utf-8');
    });
}
function parseChatHistory(historyString) {
    var _a;
    const chatMessages = [];
    const lines = historyString.split(/\n/);
    let currentRole = null;
    let currentTextLines = [];
    let currentTimestamp = '';
    const flushMessage = () => {
        if (currentRole !== null && currentTextLines.length > 0) {
            const messageText = currentTextLines.join("\n").trim();
            if (messageText) {
                chatMessages.push({
                    role: currentRole,
                    message: messageText,
                    timestamp: currentTimestamp,
                });
            }
        }
    };
    for (const line of lines) {
        const isUserMarker = (0, chatHeaders_1.isUserHeader)(line) || line.startsWith('### USER (');
        const isAiMarker = (0, chatHeaders_1.isAssistantHeader)(line) || line.startsWith('### AI -');
        if (isUserMarker || isAiMarker) {
            flushMessage();
            currentTimestamp = ((0, chatHeaders_1.isUserHeader)(line) || (0, chatHeaders_1.isAssistantHeader)(line))
                ? (0, chatHeaders_1.extractTimestampFromHeader)(line)
                : ((_a = extractTimestamp(line)) !== null && _a !== void 0 ? _a : '');
            currentRole = isUserMarker ? aiTypes_1.Role.User : aiTypes_1.Role.AI;
            currentTextLines = [];
        }
        else if (currentRole !== null) {
            currentTextLines.push(line);
        }
    }
    flushMessage();
    return chatMessages;
}
function extractTimestamp(line) {
    const match = line.match(/\(([^)]+)\)/);
    return match ? match[1] : null;
}
