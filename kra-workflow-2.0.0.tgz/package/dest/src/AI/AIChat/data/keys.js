"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getClaudeKey = getClaudeKey;
exports.getDeepInfraKey = getDeepInfraKey;
exports.getGeminiKey = getGeminiKey;
exports.getDeepSeekKey = getDeepSeekKey;
exports.getOpenRouterKey = getOpenRouterKey;
exports.getMistralKey = getMistralKey;
const dotenv_1 = __importDefault(require("dotenv"));
dotenv_1.default.config();
function getClaudeKey() {
    const apiKey = process.env.ANTHROPIC_API_KEY;
    if (!apiKey) {
        throw new Error('ANTHROPIC_API_KEY environment variable is not set');
    }
    return apiKey;
}
function getDeepInfraKey() {
    const apiKey = process.env.DEEP_INFRA;
    if (!apiKey) {
        throw new Error('DEEP_INFRA environment variable is not set');
    }
    return apiKey;
}
function getGeminiKey() {
    const apiKey = process.env.GEMINI;
    if (!apiKey) {
        throw new Error('GEMINI environment variable is not set');
    }
    return apiKey;
}
function getDeepSeekKey() {
    const apiKey = process.env.DEEP_SEEK;
    if (!apiKey) {
        throw new Error('DEEP_SEEK environment variable is not set');
    }
    return apiKey;
}
function getOpenRouterKey() {
    const apiKey = process.env.OPEN_ROUTER;
    if (!apiKey) {
        throw new Error('OPEN_ROUTER environment variable is not set');
    }
    return apiKey;
}
function getMistralKey() {
    const apiKey = process.env.MISTRAL;
    if (!apiKey) {
        throw new Error('MISTRAL environment variable is not set');
    }
    return apiKey;
}
