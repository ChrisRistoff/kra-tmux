"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.loadChat = loadChat;
const fs = __importStar(require("fs/promises"));
const path = __importStar(require("path"));
const conversation = __importStar(require("@/AI/AIChat/main/conversation"));
const aiTypes_1 = require("@/AI/shared/types/aiTypes");
const modelCatalog_1 = require("@/AI/shared/data/modelCatalog");
const providers_1 = require("@/AI/shared/data/providers");
const aiUtils_1 = require("@/AI/AIChat/utils/aiUtils");
const chatHeaders_1 = require("@/AI/shared/utils/conversationUtils/chatHeaders");
const ui = __importStar(require("@/UI/generalUI"));
const nvim = __importStar(require("@/utils/neovimHelper"));
const bash = __importStar(require("@/utils/bashHelper"));
const common_1 = require("@/utils/common");
const filePaths_1 = require("@/filePaths");
const conversation_1 = require("@/AI/shared/conversation");
function loadChat() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const savedChats = yield fs.readdir(filePaths_1.aiHistoryPath);
            if (savedChats.length === 0) {
                console.log('No saved chats found.');
                return;
            }
            const selectedChat = yield ui.searchSelectAndReturnFromArray({
                itemsArray: (0, common_1.filterGitKeep)(savedChats),
                prompt: 'Select a chat to load: '
            });
            const timestamp = Date.now();
            const chatFile = `/tmp/ai-chat-${timestamp}.md`;
            const chatDataPath = path.join(filePaths_1.aiHistoryPath, selectedChat, `${selectedChat}.json`);
            const chatData = JSON.parse(yield fs.readFile(chatDataPath, 'utf-8'));
            const chatSummaryPath = path.join(filePaths_1.aiHistoryPath, selectedChat, 'summary.md');
            yield fs.writeFile(chatSummaryPath, (0, aiUtils_1.formatChatEntry)('Chat Summary', chatData.summary + '\n', true));
            const shouldLoadTheChat = yield openSummaryAndPromptUserYesOrNo(chatSummaryPath);
            if (!shouldLoadTheChat) {
                return yield loadChat();
            }
            let chatTranscript;
            if (chatData.chatHistory && chatData.chatHistory.length) {
                chatTranscript = formatFullChat(chatData);
            }
            if (chatTranscript) {
                yield conversation.initializeChatFile(chatFile);
                yield fs.appendFile(chatFile, chatTranscript);
            }
            else {
                const chatHistoryPath = path.join(filePaths_1.aiHistoryPath, selectedChat, `${selectedChat}.md`);
                yield fs.copyFile(chatHistoryPath, chatFile);
            }
            yield fs.appendFile(chatFile, (0, chatHeaders_1.formatUserDraftHeader)());
            if (!chatData.provider || !(yield checkProviderAndModelValid(chatData.provider, chatData.model))) {
                console.log('Pick a new provider');
                console.log('Old model on save: ', chatData.model);
                const { provider, model } = yield (0, aiUtils_1.pickProviderAndModel)();
                chatData.provider = provider;
                chatData.model = model;
            }
            if (chatData.fileContexts && chatData.fileContexts.length > 0) {
                yield restoreFileContexts(chatFile, chatData.fileContexts);
            }
            const chatFileLoaded = true;
            yield conversation.converse(chatFile, chatData.temperature, chatData.role, chatData.provider, chatData.model, chatFileLoaded);
        }
        catch (error) {
            console.error('Error loading chat:', error.message);
            throw error;
        }
    });
}
function formatFullChat(chatData) {
    return chatData.chatHistory.map((entry) => {
        if (entry.role === aiTypes_1.Role.AI) {
            return `${(0, chatHeaders_1.formatAssistantHeader)(chatData.model, entry.timestamp)}${entry.message}`;
        }
        return `${(0, chatHeaders_1.formatUserHeader)(entry.timestamp)}${entry.message}`;
    }).join('');
}
function checkProviderAndModelValid(provider, model) {
    return __awaiter(this, void 0, void 0, function* () {
        if (!providers_1.SUPPORTED_PROVIDERS.includes(provider)) {
            return false;
        }
        const models = yield (0, modelCatalog_1.getModelCatalog)(provider);
        return models.some((m) => m.id === model);
    });
}
function openSummaryAndPromptUserYesOrNo(chatSummaryPath) {
    return __awaiter(this, void 0, void 0, function* () {
        if (process.env.TMUX) {
            const tmuxCommand = `tmux split-window -v -p 90 -c "#{pane_current_path}" \; \
            tmux send-keys -t :. 'sh -c "trap \\"exit 0\\" TERM; nvim  \\"${chatSummaryPath}\\";
            tmux send-keys exit C-m"' C-m`;
            bash.execCommand(tmuxCommand);
        }
        else {
            nvim.openVim(chatSummaryPath);
        }
        return yield ui.promptUserYesOrNo('Do you want to open this chat?');
    });
}
function restoreFileContexts(chatFile, savedContexts) {
    return __awaiter(this, void 0, void 0, function* () {
        for (const context of savedContexts) {
            try {
                const content = yield fs.readFile(context.filePath, 'utf-8');
                const fileName = context.filePath.split('/').pop() || context.filePath;
                const ext = (0, conversation_1.getFileExtension)(fileName);
                let contextSummary = '';
                if (context.isPartial && context.startLine !== undefined && context.endLine !== undefined) {
                    // Handle partial file context
                    const lines = content.split('\n');
                    const selectedLines = lines.slice(context.startLine - 1, context.endLine);
                    const selectedText = selectedLines.join('\n');
                    const lineRange = context.startLine === context.endLine
                        ? `line ${context.startLine}`
                        : `lines ${context.startLine}-${context.endLine}`;
                    contextSummary = `📁 ${fileName} (${lineRange})\n\n\`\`\`${ext}\n// Selected from: ${context.filePath} (${lineRange})\n${selectedText}\n\`\`\`\n\n`;
                }
                else {
                    // Handle full file context
                    const lineCount = content.split('\n').length;
                    contextSummary = `📁 ${fileName} (${lineCount} lines, ${Math.round(content.length / 1024)}KB)\n\n\`\`\`${ext}\n// Full file content loaded: ${context.filePath}\n// Use this file context in your responses\n// File contains ${lineCount} lines of ${ext} code\n\`\`\`\n\n`;
                }
                yield fs.appendFile(chatFile, contextSummary);
            }
            catch (error) {
                console.error(`Error restoring context for ${context.filePath}:`, error);
            }
        }
    });
}
