"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __asyncValues = (this && this.__asyncValues) || function (o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
    function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
    function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.saveChat = saveChat;
const fs = __importStar(require("fs/promises"));
const prompts_1 = require("@/AI/AIChat/data/prompts");
const aiUtils_1 = require("@/AI/AIChat/utils/aiUtils");
const roles_1 = require("@/AI/shared/data/roles");
const promptModel_1 = require("@/AI/AIChat/utils/promptModel");
const bash = __importStar(require("@/utils/bashHelper"));
const nvim = __importStar(require("@/utils/neovimHelper"));
const ui = __importStar(require("@/UI/generalUI"));
const filePaths_1 = require("@/filePaths");
const common_1 = require("@/utils/common");
const menuChain_1 = require("@/UI/menuChain");
function saveChat(chatFile, provider, model, role, temperature, chatHistory) {
    return __awaiter(this, void 0, void 0, function* () {
        var _a, e_1, _b, _c;
        const saves = (0, common_1.filterGitKeep)(yield fs.readdir(filePaths_1.aiHistoryPath));
        const { saveFile, saveName } = yield (0, menuChain_1.menuChain)()
            .step('saveFile', () => __awaiter(this, void 0, void 0, function* () { return ui.promptUserYesOrNo('Do you want to save the chat history?'); }))
            .step('saveName', (d) => __awaiter(this, void 0, void 0, function* () {
            return (d.saveFile)
                ? ui.searchAndSelect({ itemsArray: saves, prompt: 'Type file name: ' })
                : Promise.resolve('');
        }))
            .run();
        if (!saveFile) {
            process.exit(0);
        }
        if (saves.includes(saveName)) {
            yield bash.execCommand(`rm -rf ${filePaths_1.aiHistoryPath}/${saveName}`);
        }
        const historyFile = `${filePaths_1.aiHistoryPath}/${saveName}/${saveName}`;
        yield fs.mkdir(`${filePaths_1.aiHistoryPath}/${saveName}`);
        const chatContent = yield fs.readFile(chatFile, 'utf-8');
        const finalSummaryPrompt = `${prompts_1.summaryPrompt}:\n\n${chatContent}`;
        console.log('Preparing summary...');
        const summary = yield (0, promptModel_1.promptModel)('gemini', 'gemini-2.5-flash', finalSummaryPrompt, temperature, roles_1.aiRoles[role]);
        let fullResponse = '';
        try {
            for (var _d = true, summary_1 = __asyncValues(summary), summary_1_1; summary_1_1 = yield summary_1.next(), _a = summary_1_1.done, !_a; _d = true) {
                _c = summary_1_1.value;
                _d = false;
                const chunk = _c;
                fullResponse += chunk;
            }
        }
        catch (e_1_1) { e_1 = { error: e_1_1 }; }
        finally {
            try {
                if (!_d && !_a && (_b = summary_1.return)) yield _b.call(summary_1);
            }
            finally { if (e_1) throw e_1.error; }
        }
        const chatData = createChatData(saveName, fullResponse, provider, model, role, temperature, chatHistory);
        yield fs.writeFile(`${historyFile}.json`, chatData);
        const formattedSummary = (0, aiUtils_1.formatChatEntry)('Chat Summary', fullResponse + '\n', true);
        const summaryFile = `${filePaths_1.aiHistoryPath}/${saveName}/summary.md`;
        yield fs.writeFile(summaryFile, formattedSummary);
        if (process.env.TMUX) {
            const tmuxCommand = `tmux split-window -v -p 90 -c "#{pane_current_path}" \; \
            tmux send-keys -t :. 'sh -c "trap \\"exit 0\\" TERM; nvim  \\"${summaryFile}\\";
            tmux send-keys exit C-m"' C-m`;
            yield bash.execCommand(tmuxCommand);
        }
        else {
            yield nvim.openVim(summaryFile);
        }
        console.log('Chat saved as ', saveName);
        return;
    });
}
function createChatData(title, summary, provider, model, role, temperature, chatHistory, fileContexts) {
    const chatData = {
        title,
        summary,
        provider,
        model,
        role,
        temperature,
        chatHistory,
        fileContexts,
    };
    return JSON.stringify(chatData, null, 2);
}
