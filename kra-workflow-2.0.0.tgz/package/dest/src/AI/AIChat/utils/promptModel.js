"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __asyncValues = (this && this.__asyncValues) || function (o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
    function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
    function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
};
var __await = (this && this.__await) || function (v) { return this instanceof __await ? (this.v = v, this) : new __await(v); }
var __asyncGenerator = (this && this.__asyncGenerator) || function (thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = Object.create((typeof AsyncIterator === "function" ? AsyncIterator : Object).prototype), verb("next"), verb("throw"), verb("return", awaitReturn), i[Symbol.asyncIterator] = function () { return this; }, i;
    function awaitReturn(f) { return function (v) { return Promise.resolve(v).then(f, reject); }; }
    function verb(n, f) { if (g[n]) { i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; if (f) i[n] = f(i[n]); } }
    function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
    function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
    function fulfill(value) { resume("next", value); }
    function reject(value) { resume("throw", value); }
    function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.promptModel = promptModel;
const providers_1 = require("@/AI/shared/data/providers");
const openai_1 = __importDefault(require("openai"));
function promptModel(provider, model, prompt, temperature, system, controller) {
    return __awaiter(this, void 0, void 0, function* () {
        const apiKey = (0, providers_1.getProviderApiKey)(provider);
        const baseURL = (0, providers_1.getProviderBaseURL)(provider);
        const openai = new openai_1.default({ apiKey, baseURL });
        return createOpenAIStream(openai, model, system, prompt, temperature, controller);
    });
}
function createOpenAIStream(openai, llmModel, system, prompt, temperature, controller) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const completion = yield openai.chat.completions.create({
                messages: [
                    { role: 'system', content: system },
                    { role: 'user', content: prompt },
                ],
                model: llmModel,
                temperature: temperature,
                stream: true,
            });
            function streamResponse() {
                return __asyncGenerator(this, arguments, function* streamResponse_1() {
                    var _a, e_1, _b, _c;
                    var _d, _e, _f;
                    try {
                        try {
                            for (var _g = true, completion_1 = __asyncValues(completion), completion_1_1; completion_1_1 = yield __await(completion_1.next()), _a = completion_1_1.done, !_a; _g = true) {
                                _c = completion_1_1.value;
                                _g = false;
                                const chunk = _c;
                                if (controller === null || controller === void 0 ? void 0 : controller.isAborted) {
                                    break;
                                }
                                const text = (_f = (_e = (_d = chunk.choices[0]) === null || _d === void 0 ? void 0 : _d.delta) === null || _e === void 0 ? void 0 : _e.content) !== null && _f !== void 0 ? _f : '';
                                yield yield __await(text);
                            }
                        }
                        catch (e_1_1) { e_1 = { error: e_1_1 }; }
                        finally {
                            try {
                                if (!_g && !_a && (_b = completion_1.return)) yield __await(_b.call(completion_1));
                            }
                            finally { if (e_1) throw e_1.error; }
                        }
                    }
                    catch (error) {
                        if (controller === null || controller === void 0 ? void 0 : controller.isAborted) {
                            return yield __await(void 0);
                        }
                        throw error;
                    }
                });
            }
            return streamResponse();
        }
        catch (error) {
            if (controller === null || controller === void 0 ? void 0 : controller.isAborted) {
                throw new Error('Request aborted by user');
            }
            throw error;
        }
    });
}
