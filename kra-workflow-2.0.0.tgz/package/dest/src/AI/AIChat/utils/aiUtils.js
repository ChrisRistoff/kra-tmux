"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.promptUserForTemperature = promptUserForTemperature;
exports.formatChatEntry = formatChatEntry;
exports.pickProviderAndModel = pickProviderAndModel;
const ui = __importStar(require("@/UI/generalUI"));
const providers_1 = require("@/AI/shared/data/providers");
const modelCatalog_1 = require("@/AI/shared/data/modelCatalog");
const menuChain_1 = require("@/UI/menuChain");
function promptUserForTemperature(model) {
    return __awaiter(this, void 0, void 0, function* () {
        const maxTemp = model.startsWith('gemini') ? 20 : 10;
        const optionsArray = [];
        for (let i = 0; i <= maxTemp; i++) {
            optionsArray.push(i.toString());
        }
        const temperature = yield ui.searchAndSelect({
            prompt: 'Select temperature',
            itemsArray: optionsArray,
        });
        return +temperature / 10;
    });
}
function formatChatEntry(role, content, topLevel = false) {
    const timestamp = new Date().toISOString();
    let header = `\n---\n### ${role} (${timestamp})\n\n`;
    if (topLevel) {
        header = `### ${role} (${timestamp})\n\n`;
    }
    return content ? `${header}${content}\n---\n` : header;
}
function pickProviderAndModel() {
    return __awaiter(this, void 0, void 0, function* () {
        const result = yield (0, menuChain_1.menuChain)()
            .step('provider', () => __awaiter(this, void 0, void 0, function* () {
            return ui.searchSelectAndReturnFromArray({
                itemsArray: [...providers_1.SUPPORTED_PROVIDERS],
                prompt: 'Select a provider',
            });
        }))
            .step('model', (d) => __awaiter(this, void 0, void 0, function* () {
            const provider = d.provider;
            const models = yield (0, modelCatalog_1.getModelCatalog)(provider);
            if (models.length === 0) {
                throw new Error(`No models returned for provider '${provider}'.`);
            }
            const sorted = [...models].sort((a, b) => a.label.localeCompare(b.label));
            const labelToModel = new Map();
            for (const m of sorted) {
                labelToModel.set((0, modelCatalog_1.formatModelInfoForPicker)(m), m);
            }
            const selectedLabel = yield ui.searchSelectAndReturnFromArray({
                itemsArray: [...labelToModel.keys()],
                prompt: `Select a ${provider} model`,
            });
            const picked = labelToModel.get(selectedLabel);
            if (!picked) {
                throw new Error(`Model selection '${selectedLabel}' could not be resolved.`);
            }
            return picked;
        }))
            .run();
        return {
            provider: result.provider,
            model: (result.model).id,
        };
    });
}
