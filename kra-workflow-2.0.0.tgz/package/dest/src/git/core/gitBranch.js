"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getCurrentBranch = getCurrentBranch;
exports.getTopLevelPath = getTopLevelPath;
exports.hardReset = hardReset;
exports.getGitLog = getGitLog;
const bash = __importStar(require("@/utils/bashHelper"));
const gitConstants_1 = require("@/git/config/gitConstants");
const neovimHelper_1 = require("@/utils/neovimHelper");
function getCurrentBranch() {
    return __awaiter(this, void 0, void 0, function* () {
        const response = yield bash.execCommand(gitConstants_1.GIT_COMMANDS.GET_BRANCH);
        return response.stdout.split('\n')[0];
    });
}
function getTopLevelPath() {
    return __awaiter(this, void 0, void 0, function* () {
        const response = yield bash.execCommand(gitConstants_1.GIT_COMMANDS.GET_TOP_LEVEL);
        return response.stdout.split('\n')[0];
    });
}
function hardReset() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const currentBranch = yield getCurrentBranch();
            const beforeFetch = yield bash.execCommand(gitConstants_1.GIT_COMMANDS.GET_REMOTE_BRANCHES);
            yield bash.execCommand('git fetch --prune');
            const afterFetch = yield bash.execCommand(gitConstants_1.GIT_COMMANDS.GET_REMOTE_BRANCHES);
            const beforeBranches = beforeFetch.stdout.split('\n').filter(Boolean);
            const afterBranches = afterFetch.stdout.split('\n').filter(Boolean);
            const fetchedBranches = afterBranches.filter(branch => !beforeBranches.includes(branch));
            const prunedBranches = beforeBranches.filter(branch => !afterBranches.includes(branch));
            const reset = yield bash.execCommand(`git reset --hard origin/${currentBranch}`);
            console.table({
                HEAD: reset.stdout,
                '': '=======================',
                'Fetched Branches': fetchedBranches,
                'Pruned Branches': prunedBranches
            });
        }
        catch (error) {
            console.error("Failed to reset branch:", error);
        }
    });
}
function getGitLog() {
    return __awaiter(this, void 0, void 0, function* () {
        const tmpfile = '/tmp/git-log-XXXXXX.txt';
        const command = `
        git log --graph --abbrev-commit --oneline --decorate --color=always \
        --pretty=format:'%C(yellow)%h%C(reset) %C(green)(%d)%C(reset) %C(blue)%s%C(reset) %C(red)%an%C(reset) %C(magenta)%ar%C(reset) %C(cyan)%d%C(reset) %C(white)%B%C(reset)' \
        | sed -E 's/\x1B\[[0-9;]*m//g' | sed 's/\|/   /g;s/[[:space:]]+$//;s/^    $//' > ${tmpfile}
    `;
        try {
            yield bash.execCommand(command);
            if (process.env.TMUX) {
                yield bash.sendKeysToTmuxTargetSession({
                    command: `nvim -c 'set filetype=git' ${tmpfile}`,
                });
            }
            else {
                (0, neovimHelper_1.openVim)(tmpfile, '-c', 'set filetype=git');
            }
        }
        catch (error) {
            console.error('Failed to run git log or open nvim:', error);
        }
    });
}
