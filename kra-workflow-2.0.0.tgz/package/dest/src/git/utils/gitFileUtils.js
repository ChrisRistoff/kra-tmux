"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.allFiles = void 0;
exports.getFileList = getFileList;
exports.getModifiedFiles = getModifiedFiles;
exports.getUntrackedFiles = getUntrackedFiles;
exports.getConflictedFiles = getConflictedFiles;
exports.getStashes = getStashes;
const bash = __importStar(require("@/utils/bashHelper"));
const gitConstants_1 = require("@/git/config/gitConstants");
exports.allFiles = 'All';
function getFileList(command) {
    return __awaiter(this, void 0, void 0, function* () {
        const response = yield bash.execCommand(command);
        if (!response || typeof response.stdout !== 'string') {
            return [];
        }
        const files = response.stdout.split('\n');
        return files.filter(Boolean); // Removes empty strings
    });
}
function getModifiedFiles() {
    return __awaiter(this, void 0, void 0, function* () {
        return getFileList(gitConstants_1.GIT_COMMANDS.GET_MODIFIED);
    });
}
function getUntrackedFiles() {
    return __awaiter(this, void 0, void 0, function* () {
        return getFileList(gitConstants_1.GIT_COMMANDS.GET_UNTRACKED);
    });
}
function getConflictedFiles() {
    return __awaiter(this, void 0, void 0, function* () {
        return getFileList(gitConstants_1.GIT_COMMANDS.GET_CONFLICTS);
    });
}
function getStashes() {
    return __awaiter(this, void 0, void 0, function* () {
        return getFileList(gitConstants_1.GIT_COMMANDS.GET_STASHES);
    });
}
