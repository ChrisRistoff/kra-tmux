"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.saveUntracked = saveUntracked;
exports.loadUntracked = loadUntracked;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const bash = __importStar(require("@/utils/bashHelper"));
const ui = __importStar(require("@/UI/generalUI"));
const filePaths_1 = require("@/filePaths");
const gitBranch_1 = require("@/git/core/gitBranch");
const gitFileUtils_1 = require("@/git/utils/gitFileUtils");
const gitConstants_1 = require("@/git/config/gitConstants");
function saveUntracked() {
    return __awaiter(this, void 0, void 0, function* () {
        const fileToSavePath = yield getFileToMoveFromUser();
        const gitBranchName = yield (0, gitBranch_1.getCurrentBranch)();
        if (Array.isArray(fileToSavePath)) {
            yield Promise.all(fileToSavePath.map((file) => __awaiter(this, void 0, void 0, function* () { return saveUntrackedFile(file, gitBranchName); })));
        }
        else {
            yield saveUntrackedFile(fileToSavePath, gitBranchName);
        }
    });
}
function loadUntracked() {
    return __awaiter(this, void 0, void 0, function* () {
        const gitBranchName = yield (0, gitBranch_1.getCurrentBranch)();
        const branchPath = path_1.default.join(filePaths_1.gitFilesFolder, gitConstants_1.UNTRACKED_CONFIG.untrackedFilesFolderName, gitBranchName);
        const dirEntries = fs_1.default.readdirSync(branchPath, { withFileTypes: true });
        const savedUntrackedFiles = dirEntries
            .filter(entry => entry.isFile() && entry.name !== gitConstants_1.UNTRACKED_CONFIG.pathInfoFileName)
            .map(entry => entry.name);
        savedUntrackedFiles.unshift(gitFileUtils_1.allFiles);
        const fileToLoadName = yield ui.searchSelectAndReturnFromArray({
            prompt: "Pick a file to retrieve from stored untracked files: ",
            itemsArray: savedUntrackedFiles,
        });
        if (fileToLoadName === gitFileUtils_1.allFiles) {
            savedUntrackedFiles.shift();
            yield Promise.all(savedUntrackedFiles.map((fileName) => __awaiter(this, void 0, void 0, function* () { return loadUntrackedFile(fileName, gitBranchName); })));
            return;
        }
        yield loadUntrackedFile(fileToLoadName, gitBranchName);
    });
}
function getFileToMoveFromUser() {
    return __awaiter(this, void 0, void 0, function* () {
        const itemsArray = [gitFileUtils_1.allFiles, ...yield (0, gitFileUtils_1.getUntrackedFiles)()];
        const fileToSave = yield ui.searchSelectAndReturnFromArray({
            prompt: "Pick a file to save and remove from project: ",
            itemsArray,
        });
        if (fileToSave === gitFileUtils_1.allFiles) {
            itemsArray.shift();
            return itemsArray;
        }
        return fileToSave;
    });
}
function saveUntrackedFile(fileToSavePath, gitBranchName) {
    return __awaiter(this, void 0, void 0, function* () {
        const branchFolderToSaveFileIn = path_1.default.join(filePaths_1.gitFilesFolder, gitConstants_1.UNTRACKED_CONFIG.untrackedFilesFolderName, gitBranchName);
        if (!fs_1.default.existsSync(branchFolderToSaveFileIn)) {
            fs_1.default.mkdirSync(branchFolderToSaveFileIn, { recursive: true });
        }
        const topLevelPath = yield (0, gitBranch_1.getTopLevelPath)();
        const pathInProjectToUntrackedFile = path_1.default.join(topLevelPath, fileToSavePath);
        yield bash.execCommand(`mv ${pathInProjectToUntrackedFile} ${branchFolderToSaveFileIn}`);
        const infoFilePath = path_1.default.join(branchFolderToSaveFileIn, gitConstants_1.UNTRACKED_CONFIG.pathInfoFileName);
        let pathInfoObject = {};
        if (fs_1.default.existsSync(infoFilePath)) {
            pathInfoObject = JSON.parse(fs_1.default.readFileSync(infoFilePath).toString());
        }
        const fileName = path_1.default.basename(fileToSavePath);
        pathInfoObject[fileName] = pathInProjectToUntrackedFile;
        fs_1.default.writeFileSync(infoFilePath, JSON.stringify(pathInfoObject, null, 2), 'utf-8');
        console.log(`File ${fileName} has been saved under branch name "${gitBranchName}"`);
    });
}
function loadUntrackedFile(fileToLoadName, gitBranchName) {
    return __awaiter(this, void 0, void 0, function* () {
        const pathInfoObject = JSON.parse(fs_1.default.readFileSync(path_1.default.join(filePaths_1.gitFilesFolder, gitConstants_1.UNTRACKED_CONFIG.untrackedFilesFolderName, gitBranchName, gitConstants_1.UNTRACKED_CONFIG.pathInfoFileName)).toString());
        const originalPath = pathInfoObject[fileToLoadName];
        if (!originalPath) {
            throw new Error(`No path information found for file: ${fileToLoadName}`);
        }
        const fileToRetrievePathArray = originalPath.split('/');
        fileToRetrievePathArray.pop();
        const fileToRetrievePath = fileToRetrievePathArray.join('/');
        const untrackedFolder = path_1.default.join(filePaths_1.gitFilesFolder, gitConstants_1.UNTRACKED_CONFIG.untrackedFilesFolderName, gitBranchName, fileToLoadName);
        yield bash.execCommand(`mv ${untrackedFolder} ${fileToRetrievePath}`);
        console.log(`File ${fileToLoadName} moved back to ${fileToRetrievePath}`);
    });
}
