"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.openRemoteUrl = openRemoteUrl;
const url_1 = require("url");
const os_1 = require("os");
const gitBranch_1 = require("@/git/core/gitBranch");
const bash = __importStar(require("@/utils/bashHelper"));
function openRemoteUrl() {
    return __awaiter(this, void 0, void 0, function* () {
        const branchName = yield (0, gitBranch_1.getCurrentBranch)();
        const { stdout: rawRepoUrl } = yield bash.execCommand('git remote get-url origin');
        const repoUrl = rawRepoUrl.trim();
        let prUrl;
        let parsedUrl;
        try {
            parsedUrl = new url_1.URL(repoUrl);
        }
        catch (_a) {
            // handle ssh
            const [hostPath, repoPath] = repoUrl.split(':');
            const [_, host, ...userParts] = hostPath.split('@');
            const user = userParts.join('@');
            const [repoOwner, repoName] = repoPath.split('/').map(p => p.replace('.git', ''));
            parsedUrl = new url_1.URL(`https://${host}/${user}/${repoOwner}/${repoName}`);
        }
        if (parsedUrl.hostname === 'github.com') {
            const pathParts = parsedUrl.pathname.split('/').filter(Boolean);
            prUrl = `https://github.com/${pathParts[0]}/${pathParts[1]}/pull/new/${branchName}`;
        }
        else if (parsedUrl.hostname === 'bitbucket.org') {
            const [workspace, repo] = parsedUrl.pathname.split('/').filter(Boolean);
            prUrl = `https://bitbucket.org/${workspace}/${repo}/pull-requests/new?source=${branchName}`;
        }
        else {
            throw new Error('Unsupported Git host.');
        }
        const command = (0, os_1.platform)() === 'darwin' ? 'open' : 'xdg-open';
        yield bash.execCommand(`${command} ${prUrl}`);
    });
}
