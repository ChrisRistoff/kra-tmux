"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.checkoutBranch = checkoutBranch;
const bash = __importStar(require("@/utils/bashHelper"));
const ui = __importStar(require("@/UI/generalUI"));
const os_1 = require("os");
const gitFileUtils_1 = require("@/git/utils/gitFileUtils");
const menuChain_1 = require("@/UI/menuChain");
function checkoutBranch() {
    return __awaiter(this, void 0, void 0, function* () {
        const { selectedBranch } = yield (0, menuChain_1.menuChain)()
            .step('days', () => __awaiter(this, void 0, void 0, function* () { return ui.askUserForInput('How many days ago'); }))
            .step('selectedBranch', (d) => __awaiter(this, void 0, void 0, function* () {
            const daysNum = Number(d.days);
            const date = (0, os_1.platform)() === 'darwin'
                ? `date -v-${daysNum}d +%s`
                : `date -d '${daysNum} days ago' +%s`;
            const command = `git for-each-ref --format='%(refname:short) %(committerdate:unix) %(contents:subject)' refs/heads/ |
        awk -v cutoff=$(${date}) '$2 >= cutoff'`;
            const branchList = yield bash.execCommand(command).then((res) => res.stdout.trim().split('\n').map((item) => {
                const splitItem = item.split(' ');
                splitItem[0] += ':';
                return splitItem.join(' ');
            }));
            return ui.searchSelectAndReturnFromArray({
                itemsArray: branchList,
                prompt: 'Select a branch to checkout to:',
            });
        }))
            .run();
        const branchToCheckoutTo = (selectedBranch).split(':')[0];
        const modifiedFiles = [...yield (0, gitFileUtils_1.getModifiedFiles)(), ...yield (0, gitFileUtils_1.getUntrackedFiles)()];
        if (modifiedFiles.length > 0) {
            yield handleModifiedFiles(branchToCheckoutTo);
        }
        yield bash.execCommand(`git checkout ${branchToCheckoutTo}`);
    });
}
function handleModifiedFiles(branchName) {
    return __awaiter(this, void 0, void 0, function* () {
        const { stashChanges, stashMessage } = yield (0, menuChain_1.menuChain)()
            .step('stashChanges', () => __awaiter(this, void 0, void 0, function* () { return ui.promptUserYesOrNo(`Do you want to stash changes before you checkout to ${branchName}`); }))
            .step('stashMessage', (d) => __awaiter(this, void 0, void 0, function* () {
            return (d.stashChanges)
                ? ui.askUserForInput('Write stash message: ')
                : Promise.resolve('');
        }))
            .run();
        if (stashChanges) {
            yield bash.execCommand(`git stash --include-untracked -m "${stashMessage}"`);
        }
    });
}
