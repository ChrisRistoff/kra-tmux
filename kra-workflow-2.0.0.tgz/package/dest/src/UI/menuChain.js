"use strict";
/**
 * Fluent menu chaining for blessed-style prompts with Esc-as-back navigation.
 *
 * Each step sees everything collected so far and returns one more value.
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserCancelled = void 0;
exports.menuChain = menuChain;
class UserCancelled extends Error {
    constructor(message = 'User cancelled') {
        super(message);
        this.name = 'UserCancelled';
    }
}
exports.UserCancelled = UserCancelled;
function buildChain(initial, steps) {
    return {
        step(key, fn) {
            return buildChain(initial, [
                ...steps,
                (data) => __awaiter(this, void 0, void 0, function* () {
                    return (Object.assign(Object.assign({}, data), { [key]: yield fn(data) }));
                }),
            ]);
        },
        run() {
            return __awaiter(this, arguments, void 0, function* (seed = initial) {
                var _a;
                const snapshots = [seed];
                let index = 0;
                while (index < steps.length) {
                    try {
                        snapshots[index + 1] = yield steps[index](snapshots[index]);
                        index++;
                    }
                    catch (error) {
                        if (!(error instanceof UserCancelled) || index === 0)
                            throw error;
                        snapshots.length = index;
                        index--;
                    }
                }
                return ((_a = snapshots[steps.length]) !== null && _a !== void 0 ? _a : seed);
            });
        },
    };
}
function menuChain(initial) {
    return buildChain((initial !== null && initial !== void 0 ? initial : {}), []);
}
