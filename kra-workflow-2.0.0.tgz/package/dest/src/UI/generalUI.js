"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.showInfoScreen = showInfoScreen;
exports.promptUserYesOrNo = promptUserYesOrNo;
exports.askUserForInput = askUserForInput;
exports.searchAndSelect = searchAndSelect;
exports.searchSelectAndReturnFromArray = searchSelectAndReturnFromArray;
const blessed_1 = __importDefault(require("blessed"));
const figlet_1 = __importDefault(require("figlet"));
const menuChain_1 = require("@/UI/menuChain");
/**
 * Shared helpers
 */
function createScreen(title) {
    return blessed_1.default.screen({ smartCSR: true, title });
}
function getListSelectedValue(list) {
    var _a, _b;
    const idx = (_a = list.selected) !== null && _a !== void 0 ? _a : 0;
    const item = list.getItem(idx);
    return (item.getText()) || ((_b = item.content) !== null && _b !== void 0 ? _b : '');
}
function uniqueStrings(items) {
    const seen = new Set();
    const out = [];
    for (const s of items) {
        if (!seen.has(s)) {
            seen.add(s);
            out.push(s);
        }
    }
    return out;
}
function cleanResolve(screen, resolve) {
    let done = false;
    return (value) => {
        if (done)
            return;
        done = true;
        // avoid throwing if already destroyed
        try {
            screen.destroy();
        }
        catch ( /* noop */_a) { /* noop */ }
        resolve(value);
    };
}
function cleanSettle(screen, resolve, reject) {
    let done = false;
    const settle = (fn) => {
        if (done)
            return;
        done = true;
        try {
            screen.destroy();
        }
        catch ( /* noop */_a) { /* noop */ }
        fn();
    };
    return {
        finish: (value) => settle(() => resolve(value)),
        cancel: () => settle(() => reject(new menuChain_1.UserCancelled())),
    };
}
/**
 * Read-only info screen. Displays `content` in a scrollable, vim-keyed box.
 * Resolves when the user presses Esc/q/Ctrl+C. Used for "nothing here" empty
 * states and detail/body viewers where blessed (with vim navigation) is
 * preferable to spawning nvim.
 */
function showInfoScreen(title, content) {
    return __awaiter(this, void 0, void 0, function* () {
        return new Promise((resolve) => {
            const screen = createScreen(title);
            const finish = cleanResolve(screen, resolve);
            const headerText = figlet_1.default.textSync(title.slice(0, 20), {
                font: 'Banner',
                horizontalLayout: 'default',
                verticalLayout: 'default',
            });
            const header = blessed_1.default.box({
                top: 0,
                left: 'center',
                width: '100%',
                height: 7,
                content: '{bold}' + headerText + '{/bold}',
                tags: true,
                align: 'center',
                valign: 'middle',
                style: { fg: 'red', bg: 'black' },
            });
            const headerLines = headerText.split('\n').length;
            const body = blessed_1.default.box({
                parent: screen,
                top: headerLines + 2,
                left: 'center',
                width: '90%',
                bottom: 3,
                content,
                tags: false,
                border: { type: 'line' },
                style: { fg: 'white', bg: 'black', border: { fg: 'red' } },
                scrollable: true,
                alwaysScroll: true,
                keys: true,
                vi: true,
                mouse: true,
                scrollbar: { ch: ' ', style: { bg: 'red' } },
            });
            const status = blessed_1.default.box({
                parent: screen,
                bottom: 0,
                left: 'center',
                width: '100%',
                height: 3,
                content: 'j/k or ↑/↓: Scroll | g/G: Top/Bottom | Esc/q/Ctrl+C: Back',
                style: { fg: 'white', bg: 'black' },
            });
            screen.append(header);
            screen.append(body);
            screen.append(status);
            screen.key(['escape', 'q'], () => finish());
            screen.key(['C-c'], () => process.exit(0));
            body.focus();
            screen.render();
        });
    });
}
/**
 * Yes / No Prompt
 */
function promptUserYesOrNo(message) {
    return __awaiter(this, void 0, void 0, function* () {
        return new Promise((resolve, reject) => {
            const screen = createScreen('Confirmation');
            const { finish, cancel } = cleanSettle(screen, resolve, reject);
            const headerText = figlet_1.default.textSync('Confirm', {
                font: 'Banner',
                horizontalLayout: 'default',
                verticalLayout: 'default'
            });
            const question = blessed_1.default.box({
                top: 0,
                left: 'center',
                width: '100%',
                height: 7,
                content: '{bold}' + headerText + '{/bold}',
                tags: true,
                align: 'center',
                valign: 'middle',
                style: {
                    fg: 'red',
                    bg: 'black'
                }
            });
            const headerLines = headerText.split('\n').length;
            const box = blessed_1.default.box({
                parent: screen,
                top: headerLines + 2,
                left: 'center',
                width: '60%',
                height: '50%',
                tags: true,
                border: { type: 'line' },
                style: { fg: 'white', bg: 'black', border: { fg: 'red' } },
                content: `${message}\n\nUse ↑/↓ and Enter, or press Y / N.`
            });
            const list = blessed_1.default.list({
                parent: box,
                top: 5,
                left: 'center',
                width: '50%',
                height: 4,
                items: ['Yes', 'No'],
                keys: true,
                vi: true,
                mouse: true,
                style: {
                    fg: 'white',
                    bg: 'black',
                    border: { fg: 'red' },
                    selected: { bg: 'red' }
                },
                border: { type: 'line' }
            });
            const status = blessed_1.default.box({
                parent: screen,
                bottom: 0,
                left: 'center',
                width: '100%',
                height: 3,
                content: '↑/↓: Navigate | Enter: Select | Y/N: Quick select | Esc/Ctrl+C: Cancel',
                style: { fg: 'white', bg: 'black' }
            });
            screen.append(question);
            screen.append(box);
            screen.append(status);
            list.on('select', (_item, index) => {
                finish(index === 0);
            });
            // Global quick keys + quit
            screen.key(['y', 'Y'], () => finish(true));
            screen.key(['n', 'N'], () => finish(false));
            screen.key(['escape'], () => cancel());
            screen.key(['C-c'], () => process.exit(0));
            list.focus();
            screen.render();
        });
    });
}
/**
 * Ask User For Free Text
 */
function askUserForInput(message) {
    return __awaiter(this, void 0, void 0, function* () {
        return new Promise((resolve, reject) => {
            const screen = createScreen('Input');
            const { finish, cancel } = cleanSettle(screen, resolve, reject);
            const headerText = figlet_1.default.textSync('Input', {
                font: 'Banner',
                horizontalLayout: 'default',
                verticalLayout: 'default'
            });
            const question = blessed_1.default.box({
                top: 0,
                left: 'center',
                width: '100%',
                height: 7,
                content: '{bold}' + headerText + '{/bold}',
                tags: true,
                align: 'center',
                valign: 'middle',
                style: {
                    fg: 'red',
                    bg: 'black'
                }
            });
            const headerLines = headerText.split('\n').length;
            const box = blessed_1.default.box({
                parent: screen,
                top: headerLines + 2,
                left: 'center',
                width: '70%',
                height: '50%',
                tags: true,
                border: { type: 'line' },
                style: { fg: 'white', bg: 'black', border: { fg: 'red' } },
                content: message
            });
            const input = blessed_1.default.textbox({
                parent: box,
                top: '70%',
                left: 'center',
                width: '80%',
                height: 3,
                inputOnFocus: true,
                border: { type: 'line' },
                style: { fg: 'white', bg: 'black', border: { fg: 'red' }, focus: { bg: 'red' } }
            });
            const status = blessed_1.default.box({
                parent: screen,
                bottom: 0,
                left: 'center',
                width: '100%',
                height: 3,
                content: 'Enter: Submit | Esc/Ctrl+C: Cancel',
                style: { fg: 'white', bg: 'black' }
            });
            screen.append(question);
            screen.append(box);
            screen.append(status);
            // Handle Enter from the textbox only; let screen handle Esc/Ctrl+C
            input.key(['enter'], () => {
                const value = input.getValue();
                finish(value);
            });
            // Global quit keys
            screen.key(['escape'], () => cancel());
            screen.key(['C-c'], () => process.exit(0));
            input.focus();
            screen.render();
        });
    });
}
/**
 * Search + Select (with type vs selection confirm)
 */
function searchAndSelect(options) {
    return __awaiter(this, void 0, void 0, function* () {
        return new Promise((resolve, reject) => {
            const screen = createScreen('Search and Select');
            const { finish, cancel } = cleanSettle(screen, resolve, reject);
            let items = uniqueStrings(options.itemsArray || []);
            if (!items.length)
                items = ['<no items>'];
            const headerText = figlet_1.default.textSync(options.prompt, {
                font: 'Banner',
                horizontalLayout: 'default',
                verticalLayout: 'default'
            });
            const question = blessed_1.default.box({
                top: 0,
                left: 'center',
                width: '100%',
                height: 7,
                content: '{bold}' + headerText + '{/bold}',
                tags: true,
                align: 'center',
                valign: 'middle',
                style: {
                    fg: 'red',
                    bg: 'black'
                }
            });
            const headerLines = headerText.split('\n').length;
            const searchBox = blessed_1.default.textbox({
                parent: screen,
                top: headerLines + 1,
                left: 'center',
                width: '60%',
                height: 3,
                inputOnFocus: false,
                border: { type: 'line' },
                style: { fg: 'white', bg: 'black', border: { fg: 'red' } }
            });
            const listBox = blessed_1.default.list({
                parent: screen,
                top: headerLines + 4,
                left: 'center',
                width: '60%',
                height: '60%',
                items,
                keys: true,
                vi: true,
                mouse: true,
                border: { type: 'line' },
                style: {
                    fg: 'white',
                    bg: 'black',
                    border: { fg: 'red' },
                    selected: { bg: 'red' }
                }
            });
            const status = blessed_1.default.box({
                parent: screen,
                bottom: 0,
                left: 'center',
                width: '100%',
                height: 3,
                content: '↑/↓: Navigate | Enter: Select | Type to filter | Esc/Ctrl+C: Cancel',
                style: { fg: 'white', bg: 'black' }
            });
            screen.append(question);
            screen.append(searchBox);
            screen.append(listBox);
            screen.append(status);
            const applyFilter = (raw) => {
                const term = raw.toLowerCase();
                const filtered = term.trim().length === 0
                    ? items
                    : items.filter((s) => s.toLowerCase().includes(term));
                listBox.clearItems();
                listBox.setItems(filtered.length ? filtered : ['<no results>']);
                listBox.fuzzyFind(raw);
                screen.render();
            };
            searchBox.on('keypress', (ch, key) => {
                if (key.name === 'enter')
                    return;
                if (key.name === 'backspace') {
                    const val = searchBox.getValue().slice(0, -1);
                    searchBox.setValue(val);
                    applyFilter(val);
                    screen.render();
                    return;
                }
                if (ch && !key.ctrl && !key.meta) {
                    const val = searchBox.getValue() + ch;
                    searchBox.setValue(val);
                    applyFilter(val);
                    screen.render();
                }
            });
            searchBox.key(['up', 'down', 'pageup', 'pagedown'], (_ch, key) => {
                switch (key.name) {
                    case 'up':
                        listBox.up(1);
                        break;
                    case 'down':
                        listBox.down(1);
                        break;
                    case 'pageup':
                        listBox.up(listBox.height - 1);
                        break;
                    case 'pagedown':
                        listBox.down(listBox.height - 1);
                        break;
                }
                screen.render();
            });
            searchBox.key(['enter'], () => __awaiter(this, void 0, void 0, function* () {
                const typedValue = searchBox.getValue();
                const selectedValue = getListSelectedValue(listBox);
                if (typedValue &&
                    selectedValue &&
                    selectedValue !== '<no results>') {
                    const useTyped = yield promptUserYesOrNo(`Use typed value "${typedValue}" instead of selected "${selectedValue}"?`);
                    if (useTyped) {
                        finish(typedValue);
                    }
                    else {
                        finish(selectedValue);
                    }
                }
                else if (typedValue) {
                    finish(typedValue);
                }
                else if (selectedValue !== '<no results>') {
                    finish(selectedValue);
                }
                else {
                    finish('');
                }
            }));
            screen.key(['escape'], () => cancel());
            screen.key(['C-c'], () => process.exit(0));
            searchBox.focus();
            screen.render();
        });
    });
}
/**
 * Search + Select (simple: always return list selection)
 */
function searchSelectAndReturnFromArray(options) {
    return __awaiter(this, void 0, void 0, function* () {
        return new Promise((resolve, reject) => {
            const screen = createScreen('Search and Select');
            const { finish, cancel } = cleanSettle(screen, resolve, reject);
            let items = uniqueStrings(options.itemsArray || []);
            if (!items.length)
                items = ['<no items>'];
            const headerText = figlet_1.default.textSync(options.prompt, {
                font: 'Banner', // try: 'Big', 'Standard', 'Banner', 'Block', etc.
                horizontalLayout: 'default',
                verticalLayout: 'default'
            });
            const question = blessed_1.default.box({
                top: 0,
                left: 'center',
                width: '100%',
                height: 7, // taller box for big text
                content: '{bold}' + headerText + '{/bold}',
                tags: true,
                align: 'center',
                valign: 'middle',
                style: {
                    fg: 'red',
                    bg: 'black'
                }
            });
            const headerLines = headerText.split('\n').length;
            const searchBox = blessed_1.default.textbox({
                parent: screen,
                top: headerLines + 1, // place just below the header
                left: 'center',
                width: '60%',
                height: 3,
                inputOnFocus: false,
                border: { type: 'line' },
                style: { fg: 'white', bg: 'black', border: { fg: 'red' } }
            });
            const listBox = blessed_1.default.list({
                parent: screen,
                top: headerLines + 4, // below search box
                left: 'center',
                width: '60%',
                height: '60%',
                items,
                keys: true,
                vi: true,
                mouse: true,
                border: { type: 'line' },
                style: { fg: 'white', bg: 'black', border: { fg: 'red' }, selected: { bg: 'red' } }
            });
            const status = blessed_1.default.box({
                parent: screen,
                bottom: 0,
                left: 'center',
                width: '100%',
                height: 3,
                content: '↑/↓: Navigate | Enter: Select | Type to filter | Esc/Ctrl+C: Cancel',
                style: { fg: 'white', bg: 'black' }
            });
            screen.append(question);
            screen.append(searchBox);
            screen.append(listBox);
            screen.append(status);
            const applyFilter = (raw) => {
                const term = raw.toLowerCase();
                const filtered = term.trim().length === 0
                    ? items
                    : items.filter((s) => s.toLowerCase().includes(term));
                listBox.clearItems();
                listBox.setItems(filtered.length ? filtered : ['<no results>']);
                listBox.fuzzyFind(raw);
                screen.render();
            };
            searchBox.on('keypress', (ch, key) => {
                if (key.name === 'enter')
                    return;
                if (key.name === 'backspace') {
                    const val = searchBox.getValue().slice(0, -1);
                    searchBox.setValue(val);
                    applyFilter(val);
                    screen.render();
                    return;
                }
                if (ch && !key.ctrl && !key.meta) {
                    const val = searchBox.getValue() + ch;
                    searchBox.setValue(val);
                    applyFilter(val);
                    screen.render();
                }
            });
            searchBox.key(['up', 'down', 'pageup', 'pagedown'], (_ch, key) => {
                switch (key.name) {
                    case 'up':
                        listBox.up(1);
                        break;
                    case 'down':
                        listBox.down(1);
                        break;
                    case 'pageup':
                        listBox.up(listBox.height - 1);
                        break;
                    case 'pagedown':
                        listBox.down(listBox.height - 1);
                        break;
                }
                screen.render();
            });
            searchBox.key(['enter'], () => {
                const value = getListSelectedValue(listBox);
                finish(value === '<no results>' ? '' : value);
            });
            screen.key(['escape'], () => cancel());
            screen.key(['C-c'], () => process.exit(0));
            searchBox.focus();
            screen.render();
        });
    });
}
