"use strict";
/**
 * First-run installer for kra-workflow.
 *
 * Idempotent. Performs:
 *   1. Create ~/.kra/ skeleton
 *   2. Migrate from legacy ~/programming/kra-tmux/ if present and ~/.kra is fresh
 *   3. Drop in default settings.toml from settings.toml.example if missing
 *   4. Patch ~/.bashrc and ~/.zshrc with `source <pkg>/automationScripts/source-all.sh`
 *   5. Copy neovimHooks.lua into ~/.config/nvim/lua/ and require it from init.lua
 *   6. Touch ~/.kra/.installed marker so future runs skip the heavy work
 *
 * Safe to re-run; nothing is overwritten.
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.installedMarkerPath = installedMarkerPath;
exports.isInstalled = isInstalled;
exports.runInstall = runInstall;
const fs_1 = __importDefault(require("fs"));
const os_1 = __importDefault(require("os"));
const path_1 = __importDefault(require("path"));
const filePaths_1 = require("@/filePaths");
const packagePaths_1 = require("@/packagePaths");
const LEGACY_PROJECT_ROOT = path_1.default.join(os_1.default.homedir(), 'programming', 'kra-tmux');
function copyDirRecursive(src, dest) {
    if (!fs_1.default.existsSync(src))
        return;
    fs_1.default.mkdirSync(dest, { recursive: true });
    for (const entry of fs_1.default.readdirSync(src, { withFileTypes: true })) {
        const s = path_1.default.join(src, entry.name);
        const d = path_1.default.join(dest, entry.name);
        if (entry.isDirectory()) {
            copyDirRecursive(s, d);
        }
        else if (entry.isFile() && !fs_1.default.existsSync(d)) {
            fs_1.default.copyFileSync(s, d);
        }
    }
}
function copyFileIfMissing(src, dest) {
    if (!fs_1.default.existsSync(src) || fs_1.default.existsSync(dest))
        return;
    fs_1.default.mkdirSync(path_1.default.dirname(dest), { recursive: true });
    fs_1.default.copyFileSync(src, dest);
}
function appendLineIfMissing(filePath, line) {
    if (!fs_1.default.existsSync(filePath))
        return false;
    const content = fs_1.default.readFileSync(filePath, 'utf8');
    if (content.includes(line))
        return false;
    fs_1.default.appendFileSync(filePath, `\n${line}\n`);
    return true;
}
function ensureKraHomeSkeleton(home) {
    const created = !fs_1.default.existsSync(home);
    const subdirs = [
        '',
        'git-files',
        'tmux-files/sessions',
        'tmux-files/nvim-sessions',
        'ai-files/chat-history',
        'ai-files/chat-history',
        'system-files/scripts',
        'lock-files',
        'model-catalog',
        'cache/fastembed',
    ];
    for (const sub of subdirs) {
        fs_1.default.mkdirSync(path_1.default.join(home, sub), { recursive: true });
    }
    return created;
}
function migrateFromLegacy(home) {
    if (!fs_1.default.existsSync(LEGACY_PROJECT_ROOT))
        return;
    console.log(`[kra] migrating user data from ${LEGACY_PROJECT_ROOT} -> ${home}`);
    const dirCopies = [
        ['git-files', 'git-files'],
        ['tmux-files', 'tmux-files'],
        ['ai-files', 'ai-files'],
        ['system-files', 'system-files'],
        ['lock-files', 'lock-files'],
    ];
    for (const [src, dst] of dirCopies) {
        copyDirRecursive(path_1.default.join(LEGACY_PROJECT_ROOT, src), path_1.default.join(home, dst));
    }
    copyFileIfMissing(path_1.default.join(LEGACY_PROJECT_ROOT, 'settings.toml'), path_1.default.join(home, 'settings.toml'));
    const legacyModelCatalog = path_1.default.join(os_1.default.homedir(), '.config', 'kra-tmux', 'model-catalog');
    const legacyFastembed = path_1.default.join(os_1.default.homedir(), '.cache', 'kra-tmux', 'fastembed');
    const legacyQuotaCache = path_1.default.join(os_1.default.homedir(), '.local', 'share', 'kra-tmux', 'quota-cache.json');
    copyDirRecursive(legacyModelCatalog, path_1.default.join(home, 'model-catalog'));
    copyDirRecursive(legacyFastembed, path_1.default.join(home, 'cache', 'fastembed'));
    copyFileIfMissing(legacyQuotaCache, path_1.default.join(home, 'quota-cache.json'));
}
function ensureDefaultSettings(home) {
    const target = path_1.default.join(home, 'settings.toml');
    if (fs_1.default.existsSync(target))
        return;
    if (fs_1.default.existsSync(packagePaths_1.settingsExamplePath)) {
        fs_1.default.copyFileSync(packagePaths_1.settingsExamplePath, target);
        console.log(`[kra] wrote default settings.toml from template`);
    }
}
function patchShellRcs() {
    const sourceLine = `source ${packagePaths_1.sourceAllShPath}`;
    for (const rc of [`${os_1.default.homedir()}/.bashrc`, `${os_1.default.homedir()}/.zshrc`]) {
        if (appendLineIfMissing(rc, sourceLine)) {
            console.log(`[kra] added kra-workflow source line to ${rc}`);
        }
    }
}
function patchNeovimConfig() {
    const nvimLuaDir = path_1.default.join(os_1.default.homedir(), '.config', 'nvim', 'lua');
    const nvimInit = path_1.default.join(os_1.default.homedir(), '.config', 'nvim', 'init.lua');
    fs_1.default.mkdirSync(nvimLuaDir, { recursive: true });
    const target = path_1.default.join(nvimLuaDir, 'neovimHooks.lua');
    if (fs_1.default.existsSync(packagePaths_1.neovimHooksLuaPath)) {
        fs_1.default.copyFileSync(packagePaths_1.neovimHooksLuaPath, target);
    }
    const requireLine = 'require("neovimHooks")';
    if (fs_1.default.existsSync(nvimInit)) {
        appendLineIfMissing(nvimInit, requireLine);
    }
    else if (fs_1.default.existsSync(path_1.default.dirname(nvimInit))) {
        fs_1.default.writeFileSync(nvimInit, `${requireLine}\n`);
    }
}
function installedMarkerPath(home = (0, filePaths_1.kraHome)()) {
    return path_1.default.join(home, '.installed');
}
function isInstalled() {
    return fs_1.default.existsSync(installedMarkerPath());
}
function runInstall(opts = {}) {
    const home = (0, filePaths_1.kraHome)();
    if (isInstalled() && !opts.force)
        return;
    const fresh = ensureKraHomeSkeleton(home);
    if (fresh) {
        migrateFromLegacy(home);
    }
    ensureDefaultSettings(home);
    patchShellRcs();
    patchNeovimConfig();
    fs_1.default.writeFileSync(installedMarkerPath(home), `installed-from=${(0, packagePaths_1.packageRoot)()}\nat=${new Date().toISOString()}\n`);
    console.log('[kra] setup complete. Restart your shell (or `source ~/.bashrc`) to enable autocompletion.');
}
