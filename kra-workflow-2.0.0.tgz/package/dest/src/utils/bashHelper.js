"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.execCommand = execCommand;
exports.sendKeysToTmuxTargetSession = sendKeysToTmuxTargetSession;
exports.sendKeysToTargetSessionAndWait = sendKeysToTargetSessionAndWait;
exports.grepFileForString = grepFileForString;
const child_process_1 = require("child_process");
function execCommand(command) {
    return __awaiter(this, void 0, void 0, function* () {
        return new Promise((resolve, reject) => {
            (0, child_process_1.exec)(command, (error, stdout, stderr) => {
                if (error) {
                    reject(error);
                }
                else {
                    resolve({ stdout, stderr });
                }
            });
        });
    });
}
;
function sendKeysToTmuxTargetSession(options) {
    return __awaiter(this, void 0, void 0, function* () {
        let commandString = 'tmux send-keys';
        const windowIndexIsSaved = typeof options.windowIndex === 'number';
        const panelIndexIsSaved = typeof options.paneIndex === 'number';
        if (options.sessionName || windowIndexIsSaved || panelIndexIsSaved) {
            commandString += ' -t ';
        }
        if (options.sessionName) {
            commandString += options.sessionName;
        }
        if (windowIndexIsSaved) {
            commandString += commandString[commandString.length - 1] === ' '
                ? options.windowIndex
                : `:${options.windowIndex}`;
        }
        if (panelIndexIsSaved) {
            commandString += commandString[commandString.length - 1] === ' '
                ? options.paneIndex
                : `.${options.paneIndex}`;
        }
        commandString += ` "${options.command}" C-m`;
        yield execCommand(commandString);
    });
}
function sendKeysToTargetSessionAndWait(options) {
    return __awaiter(this, void 0, void 0, function* () {
        const marker = `__DONE_`;
        const cmdWithMarker = `echo ${marker}`;
        yield sendKeysToTmuxTargetSession(Object.assign(Object.assign({}, options), { command: cmdWithMarker }));
        yield waitForTmuxMarker(options, marker);
    });
}
function waitForTmuxMarker(options, marker) {
    return __awaiter(this, void 0, void 0, function* () {
        return new Promise((resolve) => {
            const interval = setInterval(() => __awaiter(this, void 0, void 0, function* () {
                const target = getTmuxTarget(options);
                const { stdout } = yield execCommand(`tmux capture-pane -p -t ${target}`);
                if (stdout.includes(marker)) {
                    clearInterval(interval);
                    resolve();
                }
            }), 200);
        });
    });
}
function getTmuxTarget({ sessionName, windowIndex, paneIndex }) {
    let target = '';
    if (sessionName) {
        target += sessionName;
    }
    if (typeof windowIndex === 'number') {
        target += `:${windowIndex}`;
    }
    if (typeof paneIndex === 'number') {
        target += `.${paneIndex}`;
    }
    return target;
}
function grepFileForString(fileName, searchString) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const command = `grep -E "${searchString}" '${fileName}'`;
            const { stdout, stderr } = yield execCommand(command);
            if (stderr) {
                console.error(`grep error: ${stderr}`);
                return false;
            }
            return stdout !== "";
        }
        catch (_error) {
            return false;
        }
    });
}
