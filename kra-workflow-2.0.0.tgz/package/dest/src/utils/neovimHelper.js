"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.saveNvimSession = saveNvimSession;
exports.loadNvimSession = loadNvimSession;
exports.openVim = openVim;
const fs = __importStar(require("fs"));
const child_process_1 = require("child_process");
const bash = __importStar(require("@/utils/bashHelper"));
const filePaths_1 = require("@/filePaths");
function saveNvimSession(folderName, session, windowIndex, paneIndex) {
    return __awaiter(this, void 0, void 0, function* () {
        const nvimSessionFileName = `${session}_${windowIndex}_${paneIndex}.vim`;
        if (!fs.existsSync(filePaths_1.nvimSessionsPath)) {
            fs.mkdirSync(filePaths_1.nvimSessionsPath, { recursive: true });
        }
        if (!fs.existsSync(`${filePaths_1.nvimSessionsPath}/${folderName}`)) {
            fs.mkdirSync(`${filePaths_1.nvimSessionsPath}/${folderName}`, { recursive: true });
        }
        if (fs.existsSync(`${filePaths_1.nvimSessionsPath}/${folderName}/${nvimSessionFileName}`)) {
            fs.unlinkSync(`${filePaths_1.nvimSessionsPath}/${folderName}/${nvimSessionFileName}`);
        }
        yield bash.sendKeysToTmuxTargetSession({
            sessionName: session,
            windowIndex,
            paneIndex,
            command: `:mksession ${filePaths_1.nvimSessionsPath}/${folderName}/${nvimSessionFileName}`,
        });
    });
}
function loadNvimSession(folderName, session, windowIndex, paneIndex) {
    return __awaiter(this, void 0, void 0, function* () {
        yield bash.sendKeysToTmuxTargetSession({
            sessionName: session,
            windowIndex,
            paneIndex,
            command: `nvim -S ${filePaths_1.nvimSessionsPath}/${folderName}/${session}_${windowIndex}_${paneIndex}.vim`,
        });
    });
}
function openVim(filePath, ...args) {
    return __awaiter(this, void 0, void 0, function* () {
        const colonArgs = args.filter(arg => arg.startsWith(':'));
        const otherArgs = args.filter(arg => !arg.startsWith(':'));
        if (colonArgs.length > 0) {
            for (const arg of colonArgs) {
                yield bash.execCommand(`tmux send-keys ${arg} C-m`);
            }
        }
        return new Promise((resolve, reject) => {
            const vimProcess = (0, child_process_1.spawn)('nvim', [filePath, ...otherArgs], {
                stdio: 'inherit',
                shell: false,
            });
            vimProcess.on('close', (code) => {
                if (code === 0) {
                    return resolve();
                }
                else {
                    console.log(`Vim exited with code ${code}`);
                    return reject(new Error(`Vim exited with code ${code}`));
                }
            });
            vimProcess.on('error', (err) => {
                console.error('Failed to start Vim:', err);
                return reject(err);
            });
        });
    });
}
