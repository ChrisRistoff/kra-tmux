"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.loadSession = loadSession;
exports.getSessionsFromSaved = getSessionsFromSaved;
exports.handleSessionsIfServerIsRunning = handleSessionsIfServerIsRunning;
const fs = __importStar(require("fs/promises"));
const utils = __importStar(require("@/utils/common"));
const generalUI = __importStar(require("@/UI/generalUI"));
const filePaths_1 = require("@/filePaths");
const sessionUtils_1 = require("@/tmux/utils/sessionUtils");
const printSessions_1 = require("@/tmux/commands/printSessions");
const tmux = __importStar(require("@/tmux/utils/common"));
const saveSessions_1 = require("@/tmux/commands/saveSessions");
const lockFiles_1 = require("@/../eventSystem/lockFiles");
const bash = __importStar(require("@/utils/bashHelper"));
/**
 * Main session loading workflow
 * Handles session selection, base session creation, script generation and execution
 */
function loadSession() {
    return __awaiter(this, void 0, void 0, function* () {
        yield (0, lockFiles_1.createLockFile)(lockFiles_1.LockFiles.LoadInProgress);
        try {
            const itemsArray = yield (0, sessionUtils_1.getSavedSessionsNames)();
            const serverName = yield generalUI.searchSelectAndReturnFromArray({
                itemsArray,
                prompt: "Select a session to load from the list:",
            });
            const savedSessionsData = yield getSessionsFromSaved(serverName);
            if (!savedSessionsData) {
                console.error('No saved sessions found.');
                return;
            }
            const sessionNames = Object.keys(savedSessionsData);
            const sessionResults = yield createBaseSessions(sessionNames);
            const scriptLines = generateRespawnScript(sessionResults, savedSessionsData, serverName);
            yield executeTmuxScript(scriptLines);
            yield tmux.sourceTmuxConfig();
            tmux.updateCurrentSession(serverName).catch(error => {
                console.error('Error updating current session after load:', error);
            });
            console.log('Sessions loaded successfully');
        }
        catch (error) {
            console.error('Load session error:', error);
        }
    });
}
/**
 * Retrieves saved tmux sessions from a file for a specified server
 * @param serverName - Name of the server to load sessions from
 * @returns Parsed tmux session data or null if not found
 */
function getSessionsFromSaved(serverName) {
    return __awaiter(this, void 0, void 0, function* () {
        const filePath = `${filePaths_1.sessionFilesFolder}/${serverName}`;
        const sessionsObject = yield fs.readFile(filePath);
        return JSON.parse(sessionsObject.toString());
    });
}
/**
 * Generates performant tmux script using respawn-pane to bypass shell loading
 * Creates window/pane structure and configures commands/working directories
 * @param sessionResults - Session creation results from base session setup
 * @param savedData - Saved tmux session configuration data
 * @param serverName - Name of the server being restored
 * @returns Array of tmux commands to execute for session restoration
 */
function generateRespawnScript(sessionResults, savedData, serverName) {
    const scriptLines = [];
    for (const result of sessionResults) {
        const sessionConfig = savedData[result.sessionName];
        if (!sessionConfig.windows.length) {
            continue;
        }
        // sort windows by their saved index to ensure proper order
        const sortedWindows = [...sessionConfig.windows].sort((a, b) => {
            var _a, _b;
            // if windows have an index property, use it; otherwise use array index
            const aIndex = (_a = a.windowIndex) !== null && _a !== void 0 ? _a : sessionConfig.windows.indexOf(a);
            const bIndex = (_b = b.windowIndex) !== null && _b !== void 0 ? _b : sessionConfig.windows.indexOf(b);
            return aIndex - bIndex;
        });
        console.log(`Processing ${sortedWindows.length} windows for session ${result.sessionName}`);
        sortedWindows.forEach((window, arrayIndex) => {
            // skip invalid window configurations
            if (!validateWindowConfig(window)) {
                console.warn(`Skipping invalid window config: ${window.windowName}`);
                return;
            }
            // use the array index for tmux window targeting (0, 1, 2, 3, 4...)
            const tmuxWindowIndex = arrayIndex;
            const windowTarget = `${result.sessionName}:${tmuxWindowIndex}`;
            console.log(`Creating window ${tmuxWindowIndex}: ${window.windowName} with ${window.panes.length} panes`);
            // handle window creation/renaming
            if (tmuxWindowIndex === 0) {
                // Window 0 should already exist from session creation
                scriptLines.push(`select-window -t ${result.sessionName}:0`);
                scriptLines.push(`rename-window -t ${result.sessionName}:0 "${window.windowName}"`);
            }
            else {
                // create new windows with explicit index
                scriptLines.push(`new-window -t ${result.sessionName}:${tmuxWindowIndex} -n "${window.windowName}" -c ~/`);
            }
            // only create additional panes if we have more than 1 pane
            if (window.panes.length > 1) {
                // Create additional panes (starting from index 1 since pane 0 already exists)
                for (let i = 1; i < window.panes.length; i++) {
                    scriptLines.push(`split-window -t ${windowTarget} -c ~/`);
                }
                // Only apply layout if we have multiple panes AND layout exists
                if (window.layout) {
                    scriptLines.push(`select-layout -t ${windowTarget} "${window.layout}"`);
                }
            }
            // setup each pane with its command and working directory
            window.panes.forEach((pane, paneIndex) => {
                var _a, _b;
                const paneTarget = `${windowTarget}.${paneIndex}`;
                const workingDir = pane.currentPath.split('/').slice(3).join('/') || '~';
                if (pane.currentCommand === "nvim") {
                    const nvimSessionFile = `${filePaths_1.nvimSessionsPath}/${serverName}/${result.sessionName}_${tmuxWindowIndex}_${paneIndex}.vim`;
                    const shell = (_a = process.env.SHELL) !== null && _a !== void 0 ? _a : '/bin/bash';
                    const nvimCommand = `${shell} -c 'cd "${workingDir}" && (if [ -f "${nvimSessionFile}" ]; then nvim -S "${nvimSessionFile}"; else nvim; fi); exec ${shell}'`;
                    scriptLines.push(`respawn-pane -t ${paneTarget} -k "${nvimCommand}"`);
                }
                else {
                    const shell = (_b = process.env.SHELL) !== null && _b !== void 0 ? _b : '/bin/bash';
                    const shellCommand = `/bin/bash -c 'cd "${workingDir}" && exec ${shell}'`;
                    scriptLines.push(`respawn-pane -t ${paneTarget} -k "${shellCommand}"`);
                }
            });
            // select the first pane in the window
            scriptLines.push(`select-pane -t ${windowTarget}.0`);
        });
        // update result with the processed windows
        result.windows = sortedWindows;
    }
    return scriptLines;
}
/**
 * Validates window configuration to ensure layout matches pane count
 * @param window - Window configuration to validate
 * @returns True if window configuration is valid, false otherwise
 */
function validateWindowConfig(window) {
    const paneCount = window.panes.length || 0;
    // must have at least one pane
    if (!paneCount) {
        console.warn(`Window ${window.windowName} has no panes`);
        return false;
    }
    // if one pane, any layout should work
    if (paneCount === 1)
        return true;
    // For multiple panes, layout should exist
    if (!window.layout) {
        console.warn(`Window ${window.windowName} has ${paneCount} panes but no layout`);
        return false;
    }
    return true;
}
/**
 * Creates base tmux sessions with minimal shell initialization
 * Kills existing sessions and creates fresh ones with basic configuration
 * @param sessionNames - Array of session names to create
 * @returns Array of session creation results with success status
 */
function createBaseSessions(sessionNames) {
    return __awaiter(this, void 0, void 0, function* () {
        console.log(`Creating ${sessionNames.length} base sessions:`, sessionNames);
        // kill any existing sessions
        for (const sessionName of sessionNames) {
            try {
                yield bash.execCommand(`tmux kill-session -t "${sessionName}" 2>/dev/null || true`);
                console.log(`Cleaned up existing session: ${sessionName}`);
            }
            catch (_error) {
                // ignore
            }
        }
        const results = [];
        // create sessions one by one for better error handling, verification and consistency with saves
        for (const sessionName of sessionNames) {
            try {
                // hcreate new session
                yield bash.execCommand(`tmux new-session -d -s "${sessionName}" -c ~/`);
                // verify session was created
                yield bash.execCommand(`tmux has-session -t "${sessionName}"`);
                // list windows to verify structure
                const windowList = yield bash.execCommand(`tmux list-windows -t "${sessionName}" -F "#{window_index}:#{window_name}"`);
                console.log(`Session ${sessionName} created with windows:`, windowList.stdout.trim());
                results.push({
                    sessionName,
                    success: true,
                    windows: []
                });
            }
            catch (error) {
                console.error(`Failed to create session ${sessionName}:`, error);
                results.push({
                    sessionName,
                    success: false,
                    windows: []
                });
            }
        }
        console.log(`Successfully created ${results.filter(r => r.success).length}/${sessionNames.length} sessions`);
        return results;
    });
}
/**
 * Executes tmux script with window indexing safeguards
 * Creates temporary script file with base-index configuration and executes it
 * @param scriptLines - Array of tmux commands to execute
 */
function executeTmuxScript(scriptLines) {
    return __awaiter(this, void 0, void 0, function* () {
        const timestamp = Date.now();
        const scriptPath = `/tmp/tmux_ultra_script_${timestamp}.tmux`;
        // add commands to ensure consistent window indexing
        const safeguardedScript = [
            '# Ensure base-index is 0 for consistent window numbering',
            'set-option -g base-index 0',
            'set-option -g pane-base-index 0',
            '# Disable automatic window renumbering during script execution',
            'set-option -g renumber-windows off',
            '',
            ...scriptLines,
            '',
            '# Re-enable renumber-windows if it was previously enabled',
            'set-option -g renumber-windows on'
        ];
        const scriptContent = safeguardedScript.join('\n');
        yield bash.execCommand(`cat > "${scriptPath}" << 'SCRIPT_EOF'
${scriptContent}
SCRIPT_EOF`);
        try {
            yield bash.execCommand(`tmux source-file "${scriptPath}"`);
        }
        finally {
            yield fs.rm(scriptPath);
        }
    });
}
/**
 * Handles existing tmux server state
 * Offers to save running sessions and kills them before load
 */
function handleSessionsIfServerIsRunning() {
    return __awaiter(this, void 0, void 0, function* () {
        const currentSessions = yield (0, sessionUtils_1.getCurrentSessions)();
        let shouldSaveCurrentSessions = false;
        let serverIsRunning = false;
        if (Object.keys(currentSessions).length > 0) {
            (0, printSessions_1.printSessions)(currentSessions);
            serverIsRunning = true;
            shouldSaveCurrentSessions = yield generalUI.promptUserYesOrNo('Would you like to save currently running sessions?');
        }
        if (serverIsRunning) {
            if (shouldSaveCurrentSessions) {
                yield (0, saveSessions_1.saveSessionsToFile)();
            }
            yield tmux.killServer();
            yield utils.sleep(200);
        }
    });
}
