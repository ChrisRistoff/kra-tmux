"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.printCurrentSessions = printCurrentSessions;
exports.printSessions = printSessions;
const sessionUtils_1 = require("@/tmux/utils/sessionUtils");
/**
 * Prints all current tmux sessions by fetching session data and passing it to printSessions
 */
function printCurrentSessions() {
    return __awaiter(this, void 0, void 0, function* () {
        const sessions = yield (0, sessionUtils_1.getCurrentSessions)();
        printSessions(sessions);
    });
}
/**
 * Formats and prints tmux session information in a table format
 * @param sessions - Tmux session data to display
 * @remarks
 * - Path displays the current working directory of the first window found with a path
 * - Windows count shows the number of windows in each session
 * - Panes count aggregates all panes across all windows in a session
 */
function printSessions(sessions) {
    for (const sess in sessions) {
        const currentSession = sessions[sess];
        let panesCount = 0;
        let path = '';
        for (const window of currentSession.windows) {
            path = path || window.currentPath;
            panesCount += window.panes.length;
        }
        console.table({
            Name: sess,
            Path: path,
            Windows: currentSession.windows.length,
            Panes: panesCount,
        });
    }
}
