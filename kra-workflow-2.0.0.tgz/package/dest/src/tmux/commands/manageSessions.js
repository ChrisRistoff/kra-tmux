"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteSession = deleteSession;
const generalUI = __importStar(require("@/UI/generalUI"));
const fs = __importStar(require("fs/promises"));
const filePaths_1 = require("@/filePaths");
const sessionUtils_1 = require("@/tmux/utils/sessionUtils");
/**
 * Deletes a saved server session after user confirmation.
 *
 * Prompts the user to select a session from the list of saved servers,
 * displays the selected sessions for verification, and requests confirmation
 * before permanently deleting the session file.
 */
function deleteSession() {
    return __awaiter(this, void 0, void 0, function* () {
        const savedServers = yield (0, sessionUtils_1.getSavedSessionsNames)();
        const fileName = yield generalUI.searchSelectAndReturnFromArray({
            prompt: "Please select a server from the list to delete",
            itemsArray: savedServers,
        });
        if (!fileName) {
            return;
        }
        const filePath = `${filePaths_1.sessionFilesFolder}/${fileName}`;
        const sessions = yield (0, sessionUtils_1.getSavedSessionsByFilePath)(filePath);
        let sessionDetails = '';
        for (const sess in sessions) {
            const currentSession = sessions[sess];
            let panesCount = 0;
            let path = '';
            for (const window of currentSession.windows) {
                path = path || window.currentPath;
                panesCount += window.panes.length;
            }
            sessionDetails += `  - Name: ${sess}, Path: ${path}, Windows: ${currentSession.windows.length}, Panes: ${panesCount}\n`;
        }
        if (sessionDetails === '') {
            sessionDetails = '  No sessions in this save.';
        }
        const willDelete = yield generalUI.promptUserYesOrNo(`Are you sure you want to delete save ${fileName}?\n\nSessions in this save:\n${sessionDetails}`);
        if (willDelete) {
            yield fs.rm(filePath);
            console.log(`Deleted session save: ${fileName}`);
        }
    });
}
