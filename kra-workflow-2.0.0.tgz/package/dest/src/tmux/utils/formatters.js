"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.formatPane = formatPane;
exports.formatWindow = formatWindow;
const bash = __importStar(require("@/utils/bashHelper"));
/**
 * Formats raw pane information into a structured Pane object
 * @param pane Raw pane string in "PID:path:leftxTop" format
 * @returns Promise resolving to Pane object with
 * - command
 * - path
 * - git repo
 * - coordinates (left, top)
 */
function formatPane(pane) {
    return __awaiter(this, void 0, void 0, function* () {
        const [panePid, currentPath, paneCoords] = pane.split(':');
        const [paneLeft, paneTop] = paneCoords.split('x');
        const gitRepoLink = yield getGitRepoLink(currentPath);
        return {
            currentCommand: yield getForegroundCommand(panePid),
            currentPath,
            gitRepoLink,
            paneLeft,
            paneTop,
        };
    });
}
/**
 * Formats raw window information into a structured Window object
 * @param window Raw window string in "name:command:path:layout" format
 * @returns Promise resolving to Window object with
 *   - name
 *   - layout
 *   - git repo
 *   - command
 *   - path
 *   - panes - pane[]
 */
function formatWindow(window) {
    return __awaiter(this, void 0, void 0, function* () {
        const [windowName, currentCommand, currentPath, layout] = window.split(':');
        const gitRepoLink = yield getGitRepoLink(currentPath);
        return {
            windowName,
            layout,
            gitRepoLink,
            currentCommand,
            currentPath,
            panes: []
        };
    });
}
/**
 * Retrieves Git remote origin URL for a given path
 * @param path Directory path to check for Git repository
 * @returns Promise resolving to origin URL string or undefined if not found
 */
function getGitRepoLink(path) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const { stdout } = yield bash.execCommand(`git -C ${path} remote get-url origin`);
            return stdout.split('\n')[0];
        }
        catch (_error) {
            return undefined;
        }
    });
}
/**
 * Gets the foreground command running in a terminal pane
 * @param panePid Process ID of the pane to inspect
 * @returns Promise resolving to command name or empty string if not found
 */
function getForegroundCommand(panePid) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            // get children of the pane process
            const { stdout } = yield bash.execCommand(`pgrep -P ${panePid}`);
            const childPids = stdout.toString().trim().split("\n").filter(Boolean);
            if (childPids.length === 0) {
                return "";
            }
            // assume the last child is the foreground process
            const lastPid = childPids[childPids.length - 1];
            const { stdout: cmd } = yield bash.execCommand(`ps -p ${lastPid} -o comm=`);
            return cmd.toString().trim();
        }
        catch (e) {
            return "";
        }
    });
}
