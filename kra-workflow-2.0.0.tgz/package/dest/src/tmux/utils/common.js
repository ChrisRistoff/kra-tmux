"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.checkSessionExists = checkSessionExists;
exports.sourceTmuxConfig = sourceTmuxConfig;
exports.killServer = killServer;
exports.updateCurrentSession = updateCurrentSession;
const bash = __importStar(require("@/utils/bashHelper"));
const lockFiles_1 = require("@/../eventSystem/lockFiles");
const ipc_1 = require("@/../eventSystem/ipc");
const utils = __importStar(require("@/utils/common"));
const child_process_1 = require("child_process");
/**
 * Checks whether a tmux session with the specified name exists
 * @param sessionName - Name of the tmux session to check
 * @returns Boolean indicating if the session exists
 * @throws {Error} If unexpected error occurs during session check
 */
function checkSessionExists(sessionName) {
    try {
        (0, child_process_1.execSync)(`tmux has-session -t ${sessionName}`);
        return true;
    }
    catch (error) {
        if (error instanceof Error && error.message.includes(`can't find session`)) {
            return false;
        }
        throw new Error(`Unexpected error while checking session: ${error}`);
    }
}
/**
 * Sources/reloads the tmux configuration file from the project's tmux-files directory
 * @remarks Uses the bash.execCommand utility to execute tmux source command
 * @throws Will throw an error if the source command fails
 */
function sourceTmuxConfig() {
    return __awaiter(this, void 0, void 0, function* () {
        const sourceTmux = `tmux source ${__dirname}/../../../../tmux-files/.tmux.conf`;
        yield bash.execCommand(sourceTmux);
        console.log('Sourced tmux configuration file.');
    });
}
/**
 * Terminates the tmux server with safety checks
 * @remarks
 * - Creates a server kill lock file to prevent conflicts
 * - Waits for active autosave operations to complete
 * - Emits flush-autosave event if autosave is in progress
 * - Continuously checks for autosave completion before killing server
 * - Handles case where no server is running
 */
function killServer() {
    return __awaiter(this, void 0, void 0, function* () {
        yield (0, lockFiles_1.createLockFile)(lockFiles_1.LockFiles.ServerKillInProgress);
        try {
            if (yield (0, lockFiles_1.lockFileExist)(lockFiles_1.LockFiles.AutoSaveInProgress)) {
                const client = (0, ipc_1.createIPCClient)(ipc_1.IPCsockets.AutosaveSocket);
                yield client.emit(ipc_1.IPCEvents.FlushAutosave);
            }
            while (yield (0, lockFiles_1.lockFileExist)(lockFiles_1.LockFiles.AutoSaveInProgress)) {
                console.log("Autosaving completing before exit");
                yield utils.sleep(500);
            }
            yield bash.execCommand('tmux kill-server');
        }
        catch (_error) {
            console.log('No Server Running');
        }
    });
}
/**
 * Updates application settings with the current active session name
 * @param sessionName - Name of the session to set as current in settings
 * @remarks Loads existing settings, modifies currentSession property, and saves
 */
function updateCurrentSession(sessionName) {
    return __awaiter(this, void 0, void 0, function* () {
        const settings = yield utils.loadSettings();
        settings.autosave.currentSession = sessionName;
        yield utils.saveSettings(settings);
    });
}
