"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getCurrentSessions = getCurrentSessions;
exports.getWindowsForSession = getWindowsForSession;
exports.getPanesForWindow = getPanesForWindow;
exports.getSavedSessionsNames = getSavedSessionsNames;
exports.getSavedSessionsByFilePath = getSavedSessionsByFilePath;
exports.getDateString = getDateString;
const fs = __importStar(require("fs/promises"));
const bash = __importStar(require("@/utils/bashHelper"));
const filePaths_1 = require("@/filePaths");
const formatters_1 = require("@/tmux/utils/formatters");
const common_1 = require("@/utils/common");
/**
 * Retrieves all current tmux sessions with their associated windows
 * @returns Promise resolving to TmuxSessions object containing all active sessions
 * and their window and panes configurations. Returns empty object on error.
 */
function getCurrentSessions() {
    return __awaiter(this, void 0, void 0, function* () {
        let output;
        const currentSessions = {};
        try {
            output = yield bash.execCommand(`tmux list-sessions -F '#S'`);
        }
        catch (_error) {
            return currentSessions;
        }
        const sessions = output.stdout.toString().trim().split('\n');
        for (const session of sessions) {
            const windows = yield getWindowsForSession(session);
            currentSessions[session] = { windows };
        }
        return currentSessions;
    });
}
/**
 * Gets detailed window information for a specific tmux session
 * @param session - Name of the tmux session to inspect
 * @returns Promise resolving to array of Window objects containing window details,
 *          including formatted layout and associated panes. Returns empty array on error.
 */
function getWindowsForSession(session) {
    return __awaiter(this, void 0, void 0, function* () {
        const windows = yield bash.execCommand(`tmux list-windows -t ${session} -F "#{window_name}:#{pane_current_command}:#{pane_current_path}:#{window_layout}"`);
        const windowsArray = windows.stdout.toString().trim().split('\n');
        const formattedWindows = [];
        for (const [index, window] of windowsArray.entries()) {
            const formattedWindow = yield (0, formatters_1.formatWindow)(window);
            const panes = yield getPanesForWindow(session, index);
            formattedWindow.panes = panes;
            formattedWindows.push(formattedWindow);
        }
        return formattedWindows;
    });
}
/**
 * Retrieves pane information for a specific window in a tmux session
 * @param session - Name of the tmux session containing the window
 * @param windowIndex - Numeric index of the window to inspect
 * @returns Promise resolving to array of Pane objects with process and position details.
 *          Returns empty array if pane retrieval fails.
 */
function getPanesForWindow(session, windowIndex) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const panes = yield bash.execCommand(`tmux list-panes -t ${session}:${windowIndex} -F "#{pane_pid}:#{pane_current_path}:#{pane_left}x#{pane_top}"`);
            const panesArray = panes.stdout.toString().trim().split('\n');
            return Promise.all(panesArray.map(formatters_1.formatPane));
        }
        catch (error) {
            console.log('Error getting panes:', error);
            return [];
        }
    });
}
/**
 * Gets list of saved session names from persistent storage
 * @returns Promise resolving to array of session names, excluding .gitkeep files.
 *          Returns empty array if directory read fails.
 */
function getSavedSessionsNames() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            return (0, common_1.filterGitKeep)(yield fs.readdir(filePaths_1.sessionFilesFolder));
        }
        catch (error) {
            console.error('Error reading directory:', error);
            return [];
        }
    });
}
/**
 * Loads saved tmux session configuration from a specific file
 * @param filePath - Full path to the session configuration file
 * @returns Promise resolving to TmuxSessions object parsed from JSON file
 */
function getSavedSessionsByFilePath(filePath) {
    return __awaiter(this, void 0, void 0, function* () {
        const latestSessions = yield fs.readFile(filePath);
        return JSON.parse(latestSessions.toString());
    });
}
/**
 * Generates standardized date string for file naming
 * @returns String formatted as YYYY-MMM-DD-HHMM (e.g. "2023-Aug-25-1430")
 */
function getDateString() {
    const dateArray = new Date().toString().split(' ');
    const timeArray = dateArray[4].split(':');
    timeArray.pop();
    const timeString = timeArray.join(':');
    return [dateArray[3], dateArray[1], dateArray[2], timeString].join('-');
}
