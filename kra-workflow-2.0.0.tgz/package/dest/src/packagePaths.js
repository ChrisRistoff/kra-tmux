"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.settingsExamplePath = exports.autosaveJsPath = exports.autoSaveManagerJsPath = exports.aiLuaDir = exports.aiInitLuaPath = exports.aiFilesDir = exports.neovimHooksLuaPath = exports.attachTmuxSessionShPath = exports.tmuxHooksShPath = exports.autocompleteShPath = exports.sourceAllShPath = exports.automationScriptsDir = exports.loadSessionWorkerPath = void 0;
exports.packageRoot = packageRoot;
exports.assetPath = assetPath;
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
/**
 * Resolves to the installed kra-workflow package root (the directory that
 * contains package.json). At runtime this file lives at
 * `<pkgRoot>/dest/src/packagePaths.js`, so we walk up two directories.
 *
 * We verify by checking for package.json — guards against odd symlink layouts.
 */
function resolvePackageRoot() {
    const candidate = path_1.default.resolve(__dirname, '..', '..');
    if (fs_1.default.existsSync(path_1.default.join(candidate, 'package.json'))) {
        return candidate;
    }
    let dir = __dirname;
    for (let i = 0; i < 6; i++) {
        if (fs_1.default.existsSync(path_1.default.join(dir, 'package.json'))) {
            return dir;
        }
        const parent = path_1.default.dirname(dir);
        if (parent === dir)
            break;
        dir = parent;
    }
    return candidate;
}
const PACKAGE_ROOT = resolvePackageRoot();
function packageRoot() {
    return PACKAGE_ROOT;
}
function assetPath(...segments) {
    return path_1.default.join(PACKAGE_ROOT, ...segments);
}
// Worker scripts (compiled JS shipped under dest/)
exports.loadSessionWorkerPath = assetPath('dest', 'src', 'tmux', 'workers', 'loadSessionWorker.js');
// Automation script directory (raw .sh, .lua source ships in the package tarball)
exports.automationScriptsDir = assetPath('automationScripts');
exports.sourceAllShPath = path_1.default.join(exports.automationScriptsDir, 'source-all.sh');
exports.autocompleteShPath = path_1.default.join(exports.automationScriptsDir, 'autocomplete', 'autocomplete.sh');
exports.tmuxHooksShPath = path_1.default.join(exports.automationScriptsDir, 'hooks', 'tmuxHooks.sh');
exports.attachTmuxSessionShPath = path_1.default.join(exports.automationScriptsDir, 'hooks', 'attachTmuxSession.sh');
exports.neovimHooksLuaPath = path_1.default.join(exports.automationScriptsDir, 'hooks', 'neovimHooks.lua');
// AI agent neovim UI (init.lua + lua/ siblings) — shipped as package assets.
// init.lua resolves its own dir via debug.getinfo, so package.path picks up lua/ automatically.
exports.aiFilesDir = assetPath('ai-files');
exports.aiInitLuaPath = path_1.default.join(exports.aiFilesDir, 'init.lua');
exports.aiLuaDir = path_1.default.join(exports.aiFilesDir, 'lua');
// Compiled autosave entry points
exports.autoSaveManagerJsPath = assetPath('dest', 'automationScripts', 'autosave', 'autoSaveManager.js');
exports.autosaveJsPath = assetPath('dest', 'automationScripts', 'autosave', 'autosave.js');
// Default settings template that ships with the package
exports.settingsExamplePath = assetPath('settings.toml.example');
